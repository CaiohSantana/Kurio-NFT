import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/CatalogLink.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { Link, useLocation } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { validateCatalogSearch } from "/src/features/catalog/contracts.ts";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogLink.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function useCatalogDestination() {
	_s();
	const location = useLocation();
	return validateCatalogSearch({ ...location.pathname === "/" ? location.search : location.state.catalogSearch ?? {} });
}
_s(useCatalogDestination, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
	return [useLocation];
});
export function scrollToCatalog() {
	document.getElementById("catalog")?.scrollIntoView({
		behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "instant" : "smooth",
		block: "start"
	});
}
export function CatalogLink({ children, className, ariaLabel }) {
	_s2();
	const search = useCatalogDestination(), location = useLocation();
	return /* @__PURE__ */ _jsxDEV(Link, {
		to: "/",
		search,
		hash: "catalog",
		activeOptions: { includeHash: true },
		resetScroll: false,
		hashScrollIntoView: false,
		className,
		"aria-label": ariaLabel,
		onClick: (event) => {
			if (event.button === 0 && !event.ctrlKey && !event.metaKey && !event.shiftKey && !event.altKey && location.pathname === "/" && location.hash === "catalog") {
				event.preventDefault();
				scrollToCatalog();
			}
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 10
	}, this);
}
_s2(CatalogLink, "EtqgYpZ8wsx1WRuT4HqrFABs19k=", false, function() {
	return [useCatalogDestination, useLocation];
});
_c = CatalogLink;
var _c;
$RefreshReg$(_c, "CatalogLink");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/CatalogLink.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogLink.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogLink.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogLink.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG1CQUFtQjtBQUVsQyxTQUFTLDZCQUFpRDs7OztBQUcxRCxPQUFPLFNBQVMsd0JBQXdCOztDQUN0QyxNQUFNLFdBQVcsWUFBWTtDQUM3QixPQUFPLHNCQUFzQixFQUFFLEdBQUksU0FBUyxhQUFhLE1BQU0sU0FBUyxTQUFTLFNBQVMsTUFBTSxpQkFBaUIsQ0FBQyxFQUFHLENBQUM7QUFDeEg7Ozs7QUFDQSxPQUFPLFNBQVMsa0JBQWtCO0NBQ2hDLFNBQVMsZUFBZSxTQUFTLENBQUMsRUFBRSxlQUFlO0VBQUUsVUFBVSxXQUFXLGtDQUFrQyxDQUFDLENBQUMsVUFBVSxZQUFZO0VBQVUsT0FBTztDQUFRLENBQUM7QUFDaEs7QUFDQSxPQUFPLFNBQVMsWUFBWSxFQUFFLFVBQVUsV0FBVyxhQUE4RTs7Q0FDL0gsTUFBTSxTQUFTLHNCQUFzQixHQUFHLFdBQVcsWUFBWTtDQUMvRCxPQUFPLHdCQUFDLE1BQUQ7RUFBTSxJQUFHO0VBQVk7RUFBUSxNQUFLO0VBQVUsZUFBZSxFQUFFLGFBQWEsS0FBSztFQUFHLGFBQWE7RUFBTyxvQkFBb0I7RUFBa0I7RUFBVyxjQUFZO0VBQVcsVUFBVSxVQUFVO0dBQ3ZNLElBQUksTUFBTSxXQUFXLEtBQUssQ0FBQyxNQUFNLFdBQVcsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxNQUFNLFlBQVksQ0FBQyxNQUFNLFVBQVUsU0FBUyxhQUFhLE9BQU8sU0FBUyxTQUFTLFdBQVc7SUFBRSxNQUFNLGVBQWU7SUFBRyxnQkFBZ0I7R0FBRTtFQUMxTTtFQUFJO0NBQWU7Ozs7O0FBQ3JCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhdGFsb2dMaW5rLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgdHlwZSB7IFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdmFsaWRhdGVDYXRhbG9nU2VhcmNoLCB0eXBlIENhdGFsb2dTZWFyY2ggfSBmcm9tICcuL2NvbnRyYWN0cydcblxuZGVjbGFyZSBtb2R1bGUgJ0B0YW5zdGFjay9oaXN0b3J5JyB7IGludGVyZmFjZSBIaXN0b3J5U3RhdGUgeyBjYXRhbG9nU2VhcmNoPzogQ2F0YWxvZ1NlYXJjaCB9IH1cbmV4cG9ydCBmdW5jdGlvbiB1c2VDYXRhbG9nRGVzdGluYXRpb24oKSB7XG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxuICByZXR1cm4gdmFsaWRhdGVDYXRhbG9nU2VhcmNoKHsgLi4uKGxvY2F0aW9uLnBhdGhuYW1lID09PSAnLycgPyBsb2NhdGlvbi5zZWFyY2ggOiBsb2NhdGlvbi5zdGF0ZS5jYXRhbG9nU2VhcmNoID8/IHt9KSB9KVxufVxuZXhwb3J0IGZ1bmN0aW9uIHNjcm9sbFRvQ2F0YWxvZygpIHtcbiAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ2NhdGFsb2cnKT8uc2Nyb2xsSW50b1ZpZXcoeyBiZWhhdmlvcjogbWF0Y2hNZWRpYSgnKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzID8gJ2luc3RhbnQnIDogJ3Ntb290aCcsIGJsb2NrOiAnc3RhcnQnIH0pXG59XG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ0xpbmsoeyBjaGlsZHJlbiwgY2xhc3NOYW1lLCBhcmlhTGFiZWwgfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlOyBjbGFzc05hbWU/OiBzdHJpbmc7IGFyaWFMYWJlbD86IHN0cmluZyB9KSB7XG4gIGNvbnN0IHNlYXJjaCA9IHVzZUNhdGFsb2dEZXN0aW5hdGlvbigpLCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcbiAgcmV0dXJuIDxMaW5rIHRvPVwiL1wiIHNlYXJjaD17c2VhcmNofSBoYXNoPVwiY2F0YWxvZ1wiIGFjdGl2ZU9wdGlvbnM9e3sgaW5jbHVkZUhhc2g6IHRydWUgfX0gcmVzZXRTY3JvbGw9e2ZhbHNlfSBoYXNoU2Nyb2xsSW50b1ZpZXc9e2ZhbHNlfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0gYXJpYS1sYWJlbD17YXJpYUxhYmVsfSBvbkNsaWNrPXsoZXZlbnQpID0+IHtcbiAgICBpZiAoZXZlbnQuYnV0dG9uID09PSAwICYmICFldmVudC5jdHJsS2V5ICYmICFldmVudC5tZXRhS2V5ICYmICFldmVudC5zaGlmdEtleSAmJiAhZXZlbnQuYWx0S2V5ICYmIGxvY2F0aW9uLnBhdGhuYW1lID09PSAnLycgJiYgbG9jYXRpb24uaGFzaCA9PT0gJ2NhdGFsb2cnKSB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHNjcm9sbFRvQ2F0YWxvZygpIH1cbiAgfX0+e2NoaWxkcmVufTwvTGluaz5cbn1cbiJdfQ==