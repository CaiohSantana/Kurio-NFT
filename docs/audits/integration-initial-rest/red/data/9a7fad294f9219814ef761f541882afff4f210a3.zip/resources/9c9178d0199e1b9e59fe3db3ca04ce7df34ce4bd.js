import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/DetailPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport17_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport17_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { Link, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { isAxiosError } from "/node_modules/.vite/deps/axios.js?v=bc216558";
import { ArrowLeft, Search, ShoppingCart, Star } from "/node_modules/.vite/deps/lucide-react.js?v=643d2d14";
import { detailRoute } from "/src/app/router.tsx";
import { Button } from "/src/shared/ui/button.tsx";
import { Skeleton } from "/src/shared/ui/skeleton.tsx";
import { Modal } from "/src/shared/ui/modal.tsx";
import { catalogOptions, detailOptions } from "/src/features/catalog/api.ts";
import { validateCatalogSearch } from "/src/features/catalog/contracts.ts";
import { useUnavailable } from "/src/features/catalog/MarketShell.tsx";
import { CatalogLink } from "/src/features/catalog/CatalogLink.tsx";
import { RelatedNfts } from "/src/features/catalog/RelatedNfts.tsx";
import { FavoriteButton } from "/src/features/favorites/FavoriteButton.tsx";
import { useCartMutation } from "/src/features/cart/api.ts";
import { apiMessage } from "/src/features/auth/session.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/DetailPage.tsx";
import __vite__cjsImport17_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function DetailPage() {
	_s();
	const { nftId } = detailRoute.useParams();
	const selection = detailRoute.useSearch();
	const query = useQuery(detailOptions(nftId));
	const related = useQuery({
		...catalogOptions(validateCatalogSearch({})),
		enabled: !!query.data
	});
	if (query.isPending) return /* @__PURE__ */ _jsxDEV("main", {
		className: "detail-loading",
		role: "status",
		children: [
			/* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: "Carregando NFT…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 78
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "breadcrumb",
				"aria-hidden": "true",
				children: "\xA0"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 126
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "detail-top",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "gallery",
					children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "proof-skeleton" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 257
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 232
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "detail-info",
					children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "proof-skeleton" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 331
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 302
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 181
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "detail-description-skeleton",
				"aria-hidden": "true",
				children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "proof-skeleton" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 24,
					columnNumber: 454
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 386
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 31
	}, this);
	if (!query.data) return /* @__PURE__ */ _jsxDEV("main", {
		className: "empty-state",
		role: "alert",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: isAxiosError(query.error) && query.error.response?.status === 404 ? "NFT não encontrado" : "Não foi possível carregar o NFT" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 70
			}, this),
			/* @__PURE__ */ _jsxDEV(Button, {
				onClick: () => void query.refetch(),
				children: "Tentar novamente"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 205
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogLink, { children: "Voltar ao catálogo" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 275
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 27
	}, this);
	const nft = query.data.nft;
	return /* @__PURE__ */ _jsxDEV("main", { children: [
		query.isFetching && /* @__PURE__ */ _jsxDEV("p", {
			className: "background-loading",
			role: "status",
			children: "Atualizando NFT…"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 26
		}, this),
		query.isError && /* @__PURE__ */ _jsxDEV("div", {
			className: "query-error",
			role: "alert",
			children: ["Falha ao atualizar o NFT. ", /* @__PURE__ */ _jsxDEV(Button, {
				onClick: () => void query.refetch(),
				children: "Tentar novamente"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 91
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 23
		}, this),
		/* @__PURE__ */ _jsxDEV(DetailContent, { nft }, `${nft.id}:${selection.edition}`, false, {
			fileName: _jsxFileName,
			lineNumber: 30,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV(RelatedNfts, {
			title: "Mais desta coleção",
			items: [...related.data?.items ?? []].filter((item) => item.id !== nft.id).sort((a, b) => Number([
				"cosmic-118",
				"violet-314",
				"ivory-088",
				"golden-207",
				"signal-160"
			].includes(b.id)) - Number([
				"cosmic-118",
				"violet-314",
				"ivory-088",
				"golden-207",
				"signal-160"
			].includes(a.id)))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 5
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 27,
		columnNumber: 10
	}, this);
}
_s(DetailPage, "dWd6d9JXmgVGYqKjXR08oNHnrWI=", false, function() {
	return [
		detailRoute.useParams,
		detailRoute.useSearch,
		useQuery,
		useQuery
	];
});
_c = DetailPage;
function DetailContent({ nft }) {
	_s2();
	const [image, setImage] = useState(0), [zoom, setZoom] = useState(false), [tab, setTab] = useState("details");
	const { edition: editionId, quantity: initialQuantity } = detailRoute.useSearch(), navigate = useNavigate({ from: "/nfts/$nftId" }), cart = useCartMutation();
	const [invalidQuantity, setInvalidQuantity] = useState(null);
	const quantity = invalidQuantity ?? initialQuantity;
	const setQuantity = (value) => {
		setInvalidQuantity(Number.isInteger(value) && value > 0 && value <= 100 ? null : value);
		if (Number.isInteger(value) && value > 0 && value <= 100) void navigate({
			search: {
				edition: editionId,
				quantity: value
			},
			replace: true,
			resetScroll: false
		});
	};
	const chooseEdition = (value) => {
		void navigate({
			search: {
				edition: value,
				quantity: 1
			},
			replace: true,
			resetScroll: false
		});
	};
	const add = (goToCart) => cart.mutate({
		action: "add",
		nftId: nft.id,
		editionId,
		quantity
	}, { onSuccess: () => {
		if (goToCart) void navigate({ to: "/checkout" });
	} });
	const unavailable = useUnavailable();
	const edition = nft.editions.find((e) => e.id === editionId) ?? nft.editions[0];
	const max = Math.min(edition.available, edition.maxQuantity);
	const valid = Number.isInteger(quantity) && quantity >= 1 && quantity <= max;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "detail-mobile-top",
			children: [/* @__PURE__ */ _jsxDEV(CatalogLink, {
				ariaLabel: "Voltar ao catálogo",
				children: /* @__PURE__ */ _jsxDEV(ArrowLeft, { size: 20 }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 84
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 40
			}, this), /* @__PURE__ */ _jsxDEV(FavoriteButton, {
				id: nft.id,
				name: nft.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 47,
				columnNumber: 121
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("p", {
			className: "breadcrumb",
			children: [/* @__PURE__ */ _jsxDEV(CatalogLink, { children: "Início" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 48,
				columnNumber: 31
			}, this), " / Mercado"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "detail-top",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "gallery",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "gallery-thumbnails",
					"aria-label": "Galeria de imagens",
					children: nft.gallery.map((asset, i) => /* @__PURE__ */ _jsxDEV("button", {
						"aria-label": `Imagem ${i + 1}`,
						"aria-pressed": image === i,
						onClick: () => setImage(i),
						children: /* @__PURE__ */ _jsxDEV("img", {
							src: asset,
							alt: "",
							width: "100",
							height: "100"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 233
						}, this)
					}, i, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 131
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 32
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "gallery-main",
					children: [/* @__PURE__ */ _jsxDEV("img", {
						src: nft.gallery[image],
						srcSet: `${nft.gallery[image].replace("-900.webp", "-450.webp")} 450w, ${nft.gallery[image]} 900w`,
						sizes: "(max-width:639px) 100vw, 450px",
						alt: nft.name,
						width: "450",
						height: "450",
						fetchPriority: "high"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 331
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						"aria-label": "Ampliar imagem",
						onClick: () => setZoom(true),
						children: /* @__PURE__ */ _jsxDEV(Search, { size: 24 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 50,
							columnNumber: 629
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 50,
						columnNumber: 563
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 301
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "detail-info",
				children: [
					/* @__PURE__ */ _jsxDEV("h1", { children: nft.name }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 36
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "detail-price-review",
						children: [/* @__PURE__ */ _jsxDEV("strong", {
							"data-testid": "detail-price",
							children: [nft.priceEth, " ETH"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 92
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							"aria-label": "Avaliação 4,8 de 5, 19 avaliações",
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "stars",
									children: "★★★★★"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 207
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "desktop-title",
									children: "19 avaliações de colecionadores"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 243
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "mobile-title",
									children: [/* @__PURE__ */ _jsxDEV(Star, {
										size: 12,
										fill: "currentColor",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 51,
										columnNumber: 344
									}, this), " 4.8(19)"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 51,
									columnNumber: 313
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 154
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 55
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "about-label",
						children: "Sobre este NFT:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 429
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "short-description",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "desktop-title",
							children: [nft.description.split(". ")[0], "."]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 510
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "mobile-title",
							children: [
								"Um colecionável digital ",
								edition.label,
								" finalizado à mão da coleção Kurio Editions, verificado na ",
								nft.network,
								"."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 582
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 477
					}, this),
					/* @__PURE__ */ _jsxDEV("fieldset", {
						className: "edition-picker",
						children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Edição:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 46
						}, this), nft.editions.map((e) => /* @__PURE__ */ _jsxDEV("button", {
							disabled: e.available === 0,
							"aria-label": `Edição ${e.label}${e.available === 0 ? ", indisponível" : ""}`,
							"aria-pressed": editionId === e.id,
							onClick: () => {
								chooseEdition(e.id);
							},
							children: e.label
						}, e.id, false, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 95
						}, this))]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "buy-controls",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "quantity-control",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: "quantity",
										children: "Qtd."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 73
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										"aria-label": "Diminuir quantidade",
										disabled: quantity <= 1 || max === 0,
										onClick: () => setQuantity(quantity - 1),
										children: "−"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 111
									}, this),
									/* @__PURE__ */ _jsxDEV("input", {
										id: "quantity",
										"aria-label": "Qtd.",
										"aria-invalid": !valid,
										"aria-describedby": "quantity-error",
										type: "number",
										min: "1",
										max: max || 1,
										value: quantity,
										onChange: (e) => setQuantity(Number(e.target.value))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 242
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										"aria-label": "Aumentar quantidade",
										disabled: quantity >= max,
										onClick: () => setQuantity(quantity + 1),
										children: "+"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 447
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 39
							}, this),
							/* @__PURE__ */ _jsxDEV("strong", {
								className: "mobile-unit-price",
								"data-testid": "detail-price",
								children: [nft.priceEth, " ETH"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 573
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "purchase-actions",
								children: [
									/* @__PURE__ */ _jsxDEV(Button, {
										disabled: !valid || cart.isPending,
										onClick: () => add(true),
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "desktop-title",
											children: "COMPRAR"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 53,
											columnNumber: 769
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "mobile-title",
											children: "Comprar NFT"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 53,
											columnNumber: 815
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 699
									}, this),
									/* @__PURE__ */ _jsxDEV(Button, {
										variant: "outline",
										disabled: !valid || cart.isPending,
										"aria-label": "Adicionar ao carrinho",
										onClick: () => add(false),
										children: /* @__PURE__ */ _jsxDEV(ShoppingCart, { size: 20 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 53,
											columnNumber: 997
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 873
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "desktop-purchase-favorite",
										children: /* @__PURE__ */ _jsxDEV(FavoriteButton, {
											id: nft.id,
											name: nft.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 53,
											columnNumber: 1076
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 53,
										columnNumber: 1032
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 665
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								id: "quantity-error",
								className: "quantity-feedback",
								role: valid ? undefined : "alert",
								children: max === 0 ? "Edição esgotada." : !valid ? `Escolha uma quantidade inteira de 1 a ${max}.` : /* @__PURE__ */ _jsxDEV("span", {
									className: "desktop-title",
									children: `Até ${max} unidades disponíveis.`
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 1316
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 53,
								columnNumber: 1135
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 53,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "cart-add-feedback",
						children: [
							cart.isPending && /* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								children: "Adicionando ao carrinho…"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 63
							}, this),
							cart.isSuccess && /* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								children: ["Item adicionado ao carrinho. ", /* @__PURE__ */ _jsxDEV(Link, {
									to: "/cart",
									children: "Ver carrinho"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 54,
									columnNumber: 174
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 128
							}, this),
							cart.isError && /* @__PURE__ */ _jsxDEV("p", {
								role: "alert",
								children: apiMessage(cart.error)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 232
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("dl", {
						className: "nft-attributes",
						children: [
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "ID do token:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 319
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: nft.token }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 340
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 314
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Coleção:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 371
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ["Kurio Apes", /* @__PURE__ */ _jsxDEV("span", {
								className: "desktop-title",
								children: [" · ", nft.network]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 402
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 388
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 366
							}, this),
							/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Atributos:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 473
							}, this), /* @__PURE__ */ _jsxDEV("dd", { children: ["Óculos, Esmeralda, ", nft.rare ? "Raro" : "Verificado"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 492
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 468
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 283
					}, this),
					/* @__PURE__ */ _jsxDEV("details", {
						className: "mobile-detail-tools",
						open: matchMedia("(min-width:640px)").matches || undefined,
						children: [
							/* @__PURE__ */ _jsxDEV("summary", { children: "Galeria e compartilhamento" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 666
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "mobile-gallery",
								"aria-label": "Galeria mobile",
								children: nft.gallery.map((asset, i) => /* @__PURE__ */ _jsxDEV("button", {
									"aria-label": `Imagem ${i + 1}`,
									"aria-pressed": image === i,
									onClick: () => setImage(i),
									children: /* @__PURE__ */ _jsxDEV("img", {
										src: asset,
										alt: "",
										width: "36",
										height: "36"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 54,
										columnNumber: 904
									}, this)
								}, i, false, {
									fileName: _jsxFileName,
									lineNumber: 54,
									columnNumber: 802
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 711
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "share-row",
								children: ["Compartilhar este NFT: ", /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => unavailable("Compartilhamento"),
									children: "Compartilhar"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 54,
									columnNumber: 1020
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 970
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 565
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 51,
				columnNumber: 7
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "full-details",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				role: "tablist",
				"aria-label": "Informações do NFT",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					role: "tab",
					id: "details-tab",
					"aria-selected": tab === "details",
					"aria-controls": "details-panel",
					onClick: () => setTab("details"),
					children: "Detalhes do NFT"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 91
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					role: "tab",
					id: "reviews-tab",
					"aria-selected": tab === "reviews",
					"aria-controls": "reviews-panel",
					onClick: () => setTab("reviews"),
					children: "Avaliações de colecionadores (19)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 249
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 39
			}, this), tab === "details" ? /* @__PURE__ */ _jsxDEV("div", {
				role: "tabpanel",
				id: "details-panel",
				"aria-labelledby": "details-tab",
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: [
						nft.name,
						" é uma obra digital da coleção Kurio Editions. Cada atributo fica armazenado nos metadados do token. ",
						nft.description
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 522
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						"A propriedade inclui a arte em alta resolução, lançamentos exclusivos para colecionadores e um registro permanente de procedência. Nova Sato recebe ",
						nft.royalty,
						" de direitos autorais nas vendas secundárias, apoiando novos trabalhos e lançamentos da comunidade."
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 657
					}, this),
					/* @__PURE__ */ _jsxDEV("dl", { children: [
						/* @__PURE__ */ _jsxDEV("dt", { children: "Rede:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 928
						}, this),
						/* @__PURE__ */ _jsxDEV("dd", { children: [nft.network, " · Metadados armazenados no IPFS."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 942
						}, this),
						/* @__PURE__ */ _jsxDEV("dt", { children: "Contrato:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 997
						}, this),
						/* @__PURE__ */ _jsxDEV("dd", { children: nft.contract }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 1015
						}, this),
						/* @__PURE__ */ _jsxDEV("dt", { children: "Direitos autorais:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 1038
						}, this),
						/* @__PURE__ */ _jsxDEV("dd", { children: [nft.royalty, " nas vendas secundárias."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 57,
							columnNumber: 1065
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 924
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 452
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				role: "tabpanel",
				id: "reviews-panel",
				"aria-labelledby": "reviews-tab",
				children: /* @__PURE__ */ _jsxDEV("p", { children: "4,8 de 5 · 19 avaliações de colecionadores. O envio de avaliações não faz parte desta etapa." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 57,
					columnNumber: 1195
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 1125
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			title: "Imagem do NFT",
			open: zoom,
			onClose: () => setZoom(false),
			children: /* @__PURE__ */ _jsxDEV("img", {
				className: "zoom-image",
				src: nft.gallery[image].replace("-900.webp", ".webp"),
				alt: nft.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 58,
				columnNumber: 77
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 58,
			columnNumber: 5
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 46,
		columnNumber: 10
	}, this);
}
_s2(DetailContent, "3rhHC1BTMVKPJxZ1dYaKdONYQOM=", false, function() {
	return [
		detailRoute.useSearch,
		useNavigate,
		useCartMutation,
		useUnavailable
	];
});
_c2 = DetailContent;
var _c, _c2;
$RefreshReg$(_c, "DetailPage");
$RefreshReg$(_c2, "DetailContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/DetailPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/DetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/DetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/DetailPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLFdBQVcsUUFBUSxjQUFjLFlBQVk7QUFDdEQsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsYUFBYTtBQUN0QixTQUFTLGdCQUFnQixxQkFBcUI7QUFDOUMsU0FBUyw2QkFBdUM7QUFDaEQsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxrQkFBa0I7Ozs7QUFFM0IsT0FBTyxTQUFTLGFBQWE7O0NBQzNCLE1BQU0sRUFBRSxVQUFVLFlBQVksVUFBVTtDQUN4QyxNQUFNLFlBQVksWUFBWSxVQUFVO0NBQ3hDLE1BQU0sUUFBUSxTQUFTLGNBQWMsS0FBSyxDQUFDO0NBQzNDLE1BQU0sVUFBVSxTQUFTO0VBQUUsR0FBRyxlQUFlLHNCQUFzQixDQUFDLENBQUMsQ0FBQztFQUFHLFNBQVMsQ0FBQyxDQUFDLE1BQU07Q0FBSyxDQUFDO0NBQ2hHLElBQUksTUFBTSxXQUFXLE9BQU8sd0JBQUMsUUFBRDtFQUFNLFdBQVU7RUFBaUIsTUFBSztZQUF0QztHQUErQyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFVO0dBQXFCOzs7OztHQUFDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQWEsZUFBWTtjQUFPO0dBQVM7Ozs7O0dBQUMsd0JBQUMsV0FBRDtJQUFTLFdBQVU7SUFBYSxlQUFZO2NBQTVDLENBQW1ELHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQVUsd0JBQUMsVUFBRCxFQUFVLFdBQVUsaUJBQWtCOzs7OztJQUFNOzs7O2NBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBYyx3QkFBQyxVQUFELEVBQVUsV0FBVSxpQkFBa0I7Ozs7O0lBQU07Ozs7WUFBVTs7Ozs7O0dBQUMsd0JBQUMsV0FBRDtJQUFTLFdBQVU7SUFBOEIsZUFBWTtjQUFPLHdCQUFDLFVBQUQsRUFBVSxXQUFVLGlCQUFrQjs7Ozs7R0FBVTs7Ozs7RUFBTzs7Ozs7O0NBQzFmLElBQUksQ0FBQyxNQUFNLE1BQU0sT0FBTyx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFjLE1BQUs7WUFBbkM7R0FBMkMsd0JBQUMsTUFBRCxZQUFLLGFBQWEsTUFBTSxLQUFLLEtBQUssTUFBTSxNQUFNLFVBQVUsV0FBVyxNQUFNLHVCQUF1QixrQ0FBc0M7Ozs7O0dBQUMsd0JBQUMsUUFBRDtJQUFRLGVBQWUsS0FBSyxNQUFNLFFBQVE7Y0FBRztHQUF3Qjs7Ozs7R0FBQyx3QkFBQyxhQUFELFlBQWEscUJBQStCOzs7OztFQUFPOzs7Ozs7Q0FDblUsTUFBTSxNQUFNLE1BQU0sS0FBSztDQUN2QixPQUFPLHdCQUFDLFFBQUQ7RUFDSixNQUFNLGNBQWMsd0JBQUMsS0FBRDtHQUFHLFdBQVU7R0FBcUIsTUFBSzthQUFTO0VBQW1COzs7OztFQUN2RixNQUFNLFdBQVcsd0JBQUMsT0FBRDtHQUFLLFdBQVU7R0FBYyxNQUFLO2FBQWxDLENBQTBDLDhCQUEwQix3QkFBQyxRQUFEO0lBQVEsZUFBZSxLQUFLLE1BQU0sUUFBUTtjQUFHO0dBQXdCOzs7O1dBQU07Ozs7OztFQUNqSyx3QkFBQyxlQUFELEVBQTJELElBQU0sR0FBN0MsR0FBRyxJQUFJLEdBQUcsR0FBRyxVQUFVOzs7O1NBQXNCO0VBQ2pFLHdCQUFDLGFBQUQ7R0FBYSxPQUFNO0dBQXFCLE9BQU8sQ0FBQyxHQUFJLFFBQVEsTUFBTSxTQUFTLENBQUMsQ0FBRSxDQUFDLENBQUMsUUFBUSxTQUFTLEtBQUssT0FBTyxJQUFJLEVBQUUsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLE9BQU87SUFBQztJQUFjO0lBQWM7SUFBYTtJQUFjO0dBQVksQ0FBQyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsSUFBSSxPQUFPO0lBQUM7SUFBYztJQUFjO0lBQWE7SUFBYztHQUFZLENBQUMsQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7RUFBSTs7Ozs7Q0FDL1Q7Ozs7O0FBQ1I7Ozs7Ozs7Ozs7QUFDQSxTQUFTLGNBQWMsRUFBRSxPQUFxQjs7Q0FDNUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUssR0FBRyxDQUFDLEtBQUssVUFBVSxTQUFTLFNBQVM7Q0FDNUcsTUFBTSxFQUFFLFNBQVMsV0FBVyxVQUFVLG9CQUFvQixZQUFZLFVBQVUsR0FBRyxXQUFXLFlBQVksRUFBRSxNQUFNLGVBQWUsQ0FBQyxHQUFHLE9BQU8sZ0JBQWdCO0NBQzVKLE1BQU0sQ0FBQyxpQkFBaUIsc0JBQXNCLFNBQXdCLElBQUk7Q0FDMUUsTUFBTSxXQUFXLG1CQUFtQjtDQUNwQyxNQUFNLGVBQWUsVUFBa0I7RUFBRSxtQkFBbUIsT0FBTyxVQUFVLEtBQUssS0FBSyxRQUFRLEtBQUssU0FBUyxNQUFNLE9BQU8sS0FBSztFQUFHLElBQUksT0FBTyxVQUFVLEtBQUssS0FBSyxRQUFRLEtBQUssU0FBUyxLQUFLLEtBQUssU0FBUztHQUFFLFFBQVE7SUFBRSxTQUFTO0lBQVcsVUFBVTtHQUFNO0dBQUcsU0FBUztHQUFNLGFBQWE7RUFBTSxDQUFDO0NBQUU7Q0FDbFMsTUFBTSxpQkFBaUIsVUFBa0I7RUFBRSxLQUFLLFNBQVM7R0FBRSxRQUFRO0lBQUUsU0FBUztJQUFPLFVBQVU7R0FBRTtHQUFHLFNBQVM7R0FBTSxhQUFhO0VBQU0sQ0FBQztDQUFFO0NBQ3pJLE1BQU0sT0FBTyxhQUFzQixLQUFLLE9BQU87RUFBRSxRQUFRO0VBQU8sT0FBTyxJQUFJO0VBQUk7RUFBVztDQUFTLEdBQUcsRUFBRSxpQkFBaUI7RUFBRSxJQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUUsSUFBSSxZQUFZLENBQUM7Q0FBRSxFQUFFLENBQUM7Q0FDL0ssTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxVQUFVLElBQUksU0FBUyxNQUFNLE1BQU0sRUFBRSxPQUFPLFNBQVMsS0FBSyxJQUFJLFNBQVM7Q0FDN0UsTUFBTSxNQUFNLEtBQUssSUFBSSxRQUFRLFdBQVcsUUFBUSxXQUFXO0NBQzNELE1BQU0sUUFBUSxPQUFPLFVBQVUsUUFBUSxLQUFLLFlBQVksS0FBSyxZQUFZO0NBQ3pFLE9BQU87RUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQW1DLHdCQUFDLGFBQUQ7SUFBYSxXQUFVO2NBQXFCLHdCQUFDLFdBQUQsRUFBVyxNQUFNLEdBQUs7Ozs7O0dBQWM7Ozs7YUFBQyx3QkFBQyxnQkFBRDtJQUFnQixJQUFJLElBQUk7SUFBSSxNQUFNLElBQUk7R0FBTzs7OztXQUFNOzs7Ozs7RUFDdkssd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBYixDQUEwQix3QkFBQyxhQUFELFlBQWEsU0FBbUI7Ozs7YUFBQyxZQUFhOzs7Ozs7RUFDeEUsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFBbkIsQ0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQXlCLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO0tBQXFCLGNBQVc7ZUFBc0IsSUFBSSxRQUFRLEtBQUssT0FBTyxNQUFNLHdCQUFDLFVBQUQ7TUFBZ0IsY0FBWSxVQUFVLElBQUk7TUFBSyxnQkFBYyxVQUFVO01BQUcsZUFBZSxTQUFTLENBQUM7Z0JBQUcsd0JBQUMsT0FBRDtPQUFLLEtBQUs7T0FBTyxLQUFJO09BQUcsT0FBTTtPQUFNLFFBQU87TUFBTzs7Ozs7S0FBUyxHQUFwSjs7OztZQUFvSixDQUFDO0lBQU87Ozs7Y0FBQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQThCLHdCQUFDLE9BQUQ7TUFBSyxLQUFLLElBQUksUUFBUTtNQUFRLFFBQVEsR0FBRyxJQUFJLFFBQVEsTUFBTSxDQUFDLFFBQVEsYUFBYSxXQUFXLEVBQUUsU0FBUyxJQUFJLFFBQVEsT0FBTztNQUFRLE9BQU07TUFBaUMsS0FBSyxJQUFJO01BQU0sT0FBTTtNQUFNLFFBQU87TUFBTSxlQUFjO0tBQVE7Ozs7ZUFBQyx3QkFBQyxVQUFEO01BQVEsY0FBVztNQUFpQixlQUFlLFFBQVEsSUFBSTtnQkFBRyx3QkFBQyxRQUFELEVBQVEsTUFBTSxHQUFLOzs7OztLQUFTOzs7O2FBQU07Ozs7O1lBQU07Ozs7O2FBQ3RwQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmO0tBQTZCLHdCQUFDLE1BQUQsWUFBSyxJQUFJLEtBQVM7Ozs7O0tBQUMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FBcUMsd0JBQUMsVUFBRDtPQUFRLGVBQVk7aUJBQXBCLENBQW9DLElBQUksVUFBUyxNQUFZOzs7OztnQkFBQyx3QkFBQyxRQUFEO09BQU0sY0FBVztpQkFBakI7UUFBcUQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQVE7UUFBVzs7Ozs7UUFBQyx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBZ0I7UUFBcUM7Ozs7O1FBQUMsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQStCLHdCQUFDLE1BQUQ7VUFBTSxNQUFNO1VBQUksTUFBSztVQUFlLGVBQVk7U0FBUTs7OzttQkFBQyxVQUFjOzs7Ozs7T0FBTzs7Ozs7Y0FBTTs7Ozs7O0tBQUMsd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQWM7S0FBbUI7Ozs7O0tBQUMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FBaUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCLENBQWlDLElBQUksWUFBWSxNQUFNLElBQUksQ0FBQyxDQUFDLElBQUcsR0FBTzs7Ozs7Z0JBQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWhCO1FBQStCO1FBQXlCLFFBQVE7UUFBTTtRQUE0RCxJQUFJO1FBQVE7T0FBTzs7Ozs7Y0FBSTs7Ozs7O0tBQ3R0Qix3QkFBQyxZQUFEO01BQVUsV0FBVTtnQkFBcEIsQ0FBcUMsd0JBQUMsVUFBRCxZQUFRLFVBQWU7Ozs7Z0JBQUUsSUFBSSxTQUFTLEtBQUssTUFBTSx3QkFBQyxVQUFEO09BQW1CLFVBQVUsRUFBRSxjQUFjO09BQUcsY0FBWSxVQUFVLEVBQUUsUUFBUSxFQUFFLGNBQWMsSUFBSSxtQkFBbUI7T0FBTSxnQkFBYyxjQUFjLEVBQUU7T0FBSSxlQUFlO1FBQUUsY0FBYyxFQUFFLEVBQUU7T0FBRTtpQkFBSSxFQUFFO01BQWMsR0FBM00sRUFBRTs7OzthQUF5TSxDQUFDLENBQVk7Ozs7OztLQUMzVCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUE4Qix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUFrQyx3QkFBQyxTQUFEO1VBQU8sU0FBUTtvQkFBVztTQUFXOzs7OztTQUFDLHdCQUFDLFVBQUQ7VUFBUSxjQUFXO1VBQXNCLFVBQVUsWUFBWSxLQUFLLFFBQVE7VUFBRyxlQUFlLFlBQVksV0FBVyxDQUFDO29CQUFHO1NBQVM7Ozs7O1NBQUMsd0JBQUMsU0FBRDtVQUFPLElBQUc7VUFBVyxjQUFXO1VBQU8sZ0JBQWMsQ0FBQztVQUFPLG9CQUFpQjtVQUFpQixNQUFLO1VBQVMsS0FBSTtVQUFJLEtBQUssT0FBTztVQUFHLE9BQU87VUFBVSxXQUFXLE1BQU0sWUFBWSxPQUFPLEVBQUUsT0FBTyxLQUFLLENBQUM7U0FBSTs7Ozs7U0FBQyx3QkFBQyxVQUFEO1VBQVEsY0FBVztVQUFzQixVQUFVLFlBQVk7VUFBSyxlQUFlLFlBQVksV0FBVyxDQUFDO29CQUFHO1NBQVM7Ozs7O1FBQU07Ozs7OztPQUFDLHdCQUFDLFVBQUQ7UUFBUSxXQUFVO1FBQW9CLGVBQVk7a0JBQWxELENBQWtFLElBQUksVUFBUyxNQUFZOzs7Ozs7T0FBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUFrQyx3QkFBQyxRQUFEO1VBQVEsVUFBVSxDQUFDLFNBQVMsS0FBSztVQUFXLGVBQWUsSUFBSSxJQUFJO29CQUFuRSxDQUFzRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZ0I7VUFBYTs7OztvQkFBQyx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBZTtVQUFpQjs7OztrQkFBUzs7Ozs7O1NBQUMsd0JBQUMsUUFBRDtVQUFRLFNBQVE7VUFBVSxVQUFVLENBQUMsU0FBUyxLQUFLO1VBQVcsY0FBVztVQUF3QixlQUFlLElBQUksS0FBSztvQkFBRyx3QkFBQyxjQUFELEVBQWMsTUFBTSxHQUFLOzs7OztTQUFTOzs7OztTQUFDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUE0Qix3QkFBQyxnQkFBRDtXQUFnQixJQUFJLElBQUk7V0FBSSxNQUFNLElBQUk7VUFBTzs7Ozs7U0FBTzs7Ozs7UUFBTTs7Ozs7O09BQUMsd0JBQUMsS0FBRDtRQUFHLElBQUc7UUFBaUIsV0FBVTtRQUFvQixNQUFNLFFBQVEsWUFBWTtrQkFBVSxRQUFRLElBQUkscUJBQXFCLENBQUMsUUFBUSx5Q0FBeUMsSUFBSSxLQUFLLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFpQixPQUFPLElBQUk7UUFBOEI7Ozs7O09BQUs7Ozs7O01BQU07Ozs7OztLQUNoM0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FBb0MsS0FBSyxhQUFhLHdCQUFDLEtBQUQ7UUFBRyxNQUFLO2tCQUFTO09BQTJCOzs7OztPQUFHLEtBQUssYUFBYSx3QkFBQyxLQUFEO1FBQUcsTUFBSztrQkFBUixDQUFpQixpQ0FBNkIsd0JBQUMsTUFBRDtTQUFNLElBQUc7bUJBQVE7UUFBa0I7Ozs7Z0JBQUk7Ozs7OztPQUFHLEtBQUssV0FBVyx3QkFBQyxLQUFEO1FBQUcsTUFBSztrQkFBUyxXQUFXLEtBQUssS0FBSztPQUFLOzs7OztNQUFPOzs7Ozs7S0FBQyx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFBZDtPQUErQix3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7O2lCQUFDLHdCQUFDLE1BQUQsWUFBSyxJQUFJLE1BQVU7Ozs7ZUFBTTs7Ozs7T0FBQyx3QkFBQyxPQUFELGFBQUssd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7aUJBQUMsd0JBQUMsTUFBRCxhQUFJLGNBQVUsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQWdDLE9BQUksSUFBSSxPQUFjOzs7OztlQUFLOzs7O2VBQU07Ozs7O09BQUMsd0JBQUMsT0FBRCxhQUFLLHdCQUFDLE1BQUQsWUFBSSxhQUFjOzs7O2lCQUFDLHdCQUFDLE1BQUQsYUFBSSx1QkFBb0IsSUFBSSxPQUFPLFNBQVMsWUFBaUI7Ozs7ZUFBTTs7Ozs7TUFBSzs7Ozs7O0tBQUMsd0JBQUMsV0FBRDtNQUFTLFdBQVU7TUFBc0IsTUFBTSxXQUFXLG1CQUFtQixDQUFDLENBQUMsV0FBVztnQkFBMUY7T0FBcUcsd0JBQUMsV0FBRCxZQUFTLDZCQUFtQzs7Ozs7T0FBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtRQUFpQixjQUFXO2tCQUFrQixJQUFJLFFBQVEsS0FBSyxPQUFPLE1BQU0sd0JBQUMsVUFBRDtTQUFnQixjQUFZLFVBQVUsSUFBSTtTQUFLLGdCQUFjLFVBQVU7U0FBRyxlQUFlLFNBQVMsQ0FBQzttQkFBRyx3QkFBQyxPQUFEO1VBQUssS0FBSztVQUFPLEtBQUk7VUFBRyxPQUFNO1VBQUssUUFBTztTQUFNOzs7OztRQUFTLEdBQWxKOzs7O2VBQWtKLENBQUM7T0FBTzs7Ozs7T0FBQyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUEyQiwyQkFBdUIsd0JBQUMsVUFBRDtTQUFRLGVBQWUsWUFBWSxrQkFBa0I7bUJBQUc7UUFBb0I7Ozs7Z0JBQU07Ozs7OztNQUFVOzs7Ozs7SUFDNWtDOzs7OztXQUNFOzs7Ozs7RUFDVCx3QkFBQyxXQUFEO0dBQVMsV0FBVTthQUFuQixDQUFrQyx3QkFBQyxPQUFEO0lBQUssTUFBSztJQUFVLGNBQVc7Y0FBL0IsQ0FBb0Qsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBTSxJQUFHO0tBQWMsaUJBQWUsUUFBUTtLQUFXLGlCQUFjO0tBQWdCLGVBQWUsT0FBTyxTQUFTO2VBQUc7SUFBdUI7Ozs7Y0FBQyx3QkFBQyxVQUFEO0tBQVEsTUFBSztLQUFNLElBQUc7S0FBYyxpQkFBZSxRQUFRO0tBQVcsaUJBQWM7S0FBZ0IsZUFBZSxPQUFPLFNBQVM7ZUFBRztJQUF5Qzs7OztZQUFNOzs7OzthQUFFLFFBQVEsWUFBWSx3QkFBQyxPQUFEO0lBQUssTUFBSztJQUFXLElBQUc7SUFBZ0IsbUJBQWdCO2NBQXhEO0tBQXNFLHdCQUFDLEtBQUQ7TUFBSSxJQUFJO01BQUs7TUFBc0csSUFBSTtLQUFlOzs7OztLQUFDLHdCQUFDLEtBQUQ7TUFBRztNQUFxSixJQUFJO01BQVE7S0FBc0c7Ozs7O0tBQUMsd0JBQUMsTUFBRDtNQUFJLHdCQUFDLE1BQUQsWUFBSSxRQUFTOzs7OztNQUFDLHdCQUFDLE1BQUQsYUFBSyxJQUFJLFNBQVEsbUNBQXFDOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSSxZQUFhOzs7OztNQUFDLHdCQUFDLE1BQUQsWUFBSyxJQUFJLFNBQWE7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLHFCQUFzQjs7Ozs7TUFBQyx3QkFBQyxNQUFELGFBQUssSUFBSSxTQUFRLDBCQUE0Qjs7Ozs7S0FBSzs7Ozs7SUFBTTs7Ozs7Y0FBSSx3QkFBQyxPQUFEO0lBQUssTUFBSztJQUFXLElBQUc7SUFBZ0IsbUJBQWdCO2NBQWMsd0JBQUMsS0FBRCxZQUFHLCtGQUErRjs7Ozs7R0FBTTs7OztXQUFXOzs7Ozs7RUFDenhDLHdCQUFDLE9BQUQ7R0FBTyxPQUFNO0dBQWdCLE1BQU07R0FBTSxlQUFlLFFBQVEsS0FBSzthQUFHLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO0lBQWEsS0FBSyxJQUFJLFFBQVEsTUFBTSxDQUFDLFFBQVEsYUFBYSxPQUFPO0lBQUcsS0FBSyxJQUFJO0dBQU87Ozs7O0VBQVE7Ozs7O0NBQ25MOzs7OztBQUNKIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkRldGFpbFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VOYXZpZ2F0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXHJcbmltcG9ydCB7IGlzQXhpb3NFcnJvciB9IGZyb20gJ2F4aW9zJ1xyXG5pbXBvcnQgeyBBcnJvd0xlZnQsIFNlYXJjaCwgU2hvcHBpbmdDYXJ0LCBTdGFyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyBkZXRhaWxSb3V0ZSB9IGZyb20gJ0AvYXBwL3JvdXRlcidcclxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9zaGFyZWQvdWkvYnV0dG9uJ1xyXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJ0Avc2hhcmVkL3VpL3NrZWxldG9uJ1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gJ0Avc2hhcmVkL3VpL21vZGFsJ1xyXG5pbXBvcnQgeyBjYXRhbG9nT3B0aW9ucywgZGV0YWlsT3B0aW9ucyB9IGZyb20gJy4vYXBpJ1xyXG5pbXBvcnQgeyB2YWxpZGF0ZUNhdGFsb2dTZWFyY2gsIHR5cGUgTmZ0IH0gZnJvbSAnLi9jb250cmFjdHMnXHJcbmltcG9ydCB7IHVzZVVuYXZhaWxhYmxlIH0gZnJvbSAnLi9NYXJrZXRTaGVsbCdcclxuaW1wb3J0IHsgQ2F0YWxvZ0xpbmsgfSBmcm9tICcuL0NhdGFsb2dMaW5rJ1xyXG5pbXBvcnQgeyBSZWxhdGVkTmZ0cyB9IGZyb20gJy4vUmVsYXRlZE5mdHMnXHJcbmltcG9ydCB7IEZhdm9yaXRlQnV0dG9uIH0gZnJvbSAnQC9mZWF0dXJlcy9mYXZvcml0ZXMvRmF2b3JpdGVCdXR0b24nXHJcbmltcG9ydCB7IHVzZUNhcnRNdXRhdGlvbiB9IGZyb20gJ0AvZmVhdHVyZXMvY2FydC9hcGknXHJcbmltcG9ydCB7IGFwaU1lc3NhZ2UgfSBmcm9tICdAL2ZlYXR1cmVzL2F1dGgvc2Vzc2lvbidcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBEZXRhaWxQYWdlKCkge1xyXG4gIGNvbnN0IHsgbmZ0SWQgfSA9IGRldGFpbFJvdXRlLnVzZVBhcmFtcygpXHJcbiAgY29uc3Qgc2VsZWN0aW9uID0gZGV0YWlsUm91dGUudXNlU2VhcmNoKClcclxuICBjb25zdCBxdWVyeSA9IHVzZVF1ZXJ5KGRldGFpbE9wdGlvbnMobmZ0SWQpKVxyXG4gIGNvbnN0IHJlbGF0ZWQgPSB1c2VRdWVyeSh7IC4uLmNhdGFsb2dPcHRpb25zKHZhbGlkYXRlQ2F0YWxvZ1NlYXJjaCh7fSkpLCBlbmFibGVkOiAhIXF1ZXJ5LmRhdGEgfSlcclxuICBpZiAocXVlcnkuaXNQZW5kaW5nKSByZXR1cm4gPG1haW4gY2xhc3NOYW1lPVwiZGV0YWlsLWxvYWRpbmdcIiByb2xlPVwic3RhdHVzXCI+PHNwYW4gY2xhc3NOYW1lPVwic3Itb25seVwiPkNhcnJlZ2FuZG8gTkZU4oCmPC9zcGFuPjxwIGNsYXNzTmFtZT1cImJyZWFkY3J1bWJcIiBhcmlhLWhpZGRlbj1cInRydWVcIj4mbmJzcDs8L3A+PHNlY3Rpb24gY2xhc3NOYW1lPVwiZGV0YWlsLXRvcFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjxkaXYgY2xhc3NOYW1lPVwiZ2FsbGVyeVwiPjxTa2VsZXRvbiBjbGFzc05hbWU9XCJwcm9vZi1za2VsZXRvblwiIC8+PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJkZXRhaWwtaW5mb1wiPjxTa2VsZXRvbiBjbGFzc05hbWU9XCJwcm9vZi1za2VsZXRvblwiIC8+PC9kaXY+PC9zZWN0aW9uPjxzZWN0aW9uIGNsYXNzTmFtZT1cImRldGFpbC1kZXNjcmlwdGlvbi1za2VsZXRvblwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPjxTa2VsZXRvbiBjbGFzc05hbWU9XCJwcm9vZi1za2VsZXRvblwiIC8+PC9zZWN0aW9uPjwvbWFpbj5cclxuICBpZiAoIXF1ZXJ5LmRhdGEpIHJldHVybiA8bWFpbiBjbGFzc05hbWU9XCJlbXB0eS1zdGF0ZVwiIHJvbGU9XCJhbGVydFwiPjxoMT57aXNBeGlvc0Vycm9yKHF1ZXJ5LmVycm9yKSAmJiBxdWVyeS5lcnJvci5yZXNwb25zZT8uc3RhdHVzID09PSA0MDQgPyAnTkZUIG7Do28gZW5jb250cmFkbycgOiAnTsOjbyBmb2kgcG9zc8OtdmVsIGNhcnJlZ2FyIG8gTkZUJ308L2gxPjxCdXR0b24gb25DbGljaz17KCkgPT4gdm9pZCBxdWVyeS5yZWZldGNoKCl9PlRlbnRhciBub3ZhbWVudGU8L0J1dHRvbj48Q2F0YWxvZ0xpbms+Vm9sdGFyIGFvIGNhdMOhbG9nbzwvQ2F0YWxvZ0xpbms+PC9tYWluPlxyXG4gIGNvbnN0IG5mdCA9IHF1ZXJ5LmRhdGEubmZ0XHJcbiAgcmV0dXJuIDxtYWluPlxyXG4gICAge3F1ZXJ5LmlzRmV0Y2hpbmcgJiYgPHAgY2xhc3NOYW1lPVwiYmFja2dyb3VuZC1sb2FkaW5nXCIgcm9sZT1cInN0YXR1c1wiPkF0dWFsaXphbmRvIE5GVOKApjwvcD59XHJcbiAgICB7cXVlcnkuaXNFcnJvciAmJiA8ZGl2IGNsYXNzTmFtZT1cInF1ZXJ5LWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+RmFsaGEgYW8gYXR1YWxpemFyIG8gTkZULiA8QnV0dG9uIG9uQ2xpY2s9eygpID0+IHZvaWQgcXVlcnkucmVmZXRjaCgpfT5UZW50YXIgbm92YW1lbnRlPC9CdXR0b24+PC9kaXY+fVxyXG4gICAgPERldGFpbENvbnRlbnQga2V5PXtgJHtuZnQuaWR9OiR7c2VsZWN0aW9uLmVkaXRpb259YH0gbmZ0PXtuZnR9IC8+XHJcbiAgICA8UmVsYXRlZE5mdHMgdGl0bGU9XCJNYWlzIGRlc3RhIGNvbGXDp8Ojb1wiIGl0ZW1zPXtbLi4uKHJlbGF0ZWQuZGF0YT8uaXRlbXMgPz8gW10pXS5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uaWQgIT09IG5mdC5pZCkuc29ydCgoYSwgYikgPT4gTnVtYmVyKFsnY29zbWljLTExOCcsICd2aW9sZXQtMzE0JywgJ2l2b3J5LTA4OCcsICdnb2xkZW4tMjA3JywgJ3NpZ25hbC0xNjAnXS5pbmNsdWRlcyhiLmlkKSkgLSBOdW1iZXIoWydjb3NtaWMtMTE4JywgJ3Zpb2xldC0zMTQnLCAnaXZvcnktMDg4JywgJ2dvbGRlbi0yMDcnLCAnc2lnbmFsLTE2MCddLmluY2x1ZGVzKGEuaWQpKSl9IC8+XHJcbiAgPC9tYWluPlxyXG59XHJcbmZ1bmN0aW9uIERldGFpbENvbnRlbnQoeyBuZnQgfTogeyBuZnQ6IE5mdCB9KSB7XHJcbiAgY29uc3QgW2ltYWdlLCBzZXRJbWFnZV0gPSB1c2VTdGF0ZSgwKSwgW3pvb20sIHNldFpvb21dID0gdXNlU3RhdGUoZmFsc2UpLCBbdGFiLCBzZXRUYWJdID0gdXNlU3RhdGUoJ2RldGFpbHMnKVxyXG4gIGNvbnN0IHsgZWRpdGlvbjogZWRpdGlvbklkLCBxdWFudGl0eTogaW5pdGlhbFF1YW50aXR5IH0gPSBkZXRhaWxSb3V0ZS51c2VTZWFyY2goKSwgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSh7IGZyb206ICcvbmZ0cy8kbmZ0SWQnIH0pLCBjYXJ0ID0gdXNlQ2FydE11dGF0aW9uKClcclxuICBjb25zdCBbaW52YWxpZFF1YW50aXR5LCBzZXRJbnZhbGlkUXVhbnRpdHldID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbClcclxuICBjb25zdCBxdWFudGl0eSA9IGludmFsaWRRdWFudGl0eSA/PyBpbml0aWFsUXVhbnRpdHlcclxuICBjb25zdCBzZXRRdWFudGl0eSA9ICh2YWx1ZTogbnVtYmVyKSA9PiB7IHNldEludmFsaWRRdWFudGl0eShOdW1iZXIuaXNJbnRlZ2VyKHZhbHVlKSAmJiB2YWx1ZSA+IDAgJiYgdmFsdWUgPD0gMTAwID8gbnVsbCA6IHZhbHVlKTsgaWYgKE51bWJlci5pc0ludGVnZXIodmFsdWUpICYmIHZhbHVlID4gMCAmJiB2YWx1ZSA8PSAxMDApIHZvaWQgbmF2aWdhdGUoeyBzZWFyY2g6IHsgZWRpdGlvbjogZWRpdGlvbklkLCBxdWFudGl0eTogdmFsdWUgfSwgcmVwbGFjZTogdHJ1ZSwgcmVzZXRTY3JvbGw6IGZhbHNlIH0pIH1cclxuICBjb25zdCBjaG9vc2VFZGl0aW9uID0gKHZhbHVlOiBzdHJpbmcpID0+IHsgdm9pZCBuYXZpZ2F0ZSh7IHNlYXJjaDogeyBlZGl0aW9uOiB2YWx1ZSwgcXVhbnRpdHk6IDEgfSwgcmVwbGFjZTogdHJ1ZSwgcmVzZXRTY3JvbGw6IGZhbHNlIH0pIH1cclxuICBjb25zdCBhZGQgPSAoZ29Ub0NhcnQ6IGJvb2xlYW4pID0+IGNhcnQubXV0YXRlKHsgYWN0aW9uOiAnYWRkJywgbmZ0SWQ6IG5mdC5pZCwgZWRpdGlvbklkLCBxdWFudGl0eSB9LCB7IG9uU3VjY2VzczogKCkgPT4geyBpZiAoZ29Ub0NhcnQpIHZvaWQgbmF2aWdhdGUoeyB0bzogJy9jaGVja291dCcgfSkgfSB9KVxyXG4gIGNvbnN0IHVuYXZhaWxhYmxlID0gdXNlVW5hdmFpbGFibGUoKVxyXG4gIGNvbnN0IGVkaXRpb24gPSBuZnQuZWRpdGlvbnMuZmluZCgoZSkgPT4gZS5pZCA9PT0gZWRpdGlvbklkKSA/PyBuZnQuZWRpdGlvbnNbMF1cclxuICBjb25zdCBtYXggPSBNYXRoLm1pbihlZGl0aW9uLmF2YWlsYWJsZSwgZWRpdGlvbi5tYXhRdWFudGl0eSlcclxuICBjb25zdCB2YWxpZCA9IE51bWJlci5pc0ludGVnZXIocXVhbnRpdHkpICYmIHF1YW50aXR5ID49IDEgJiYgcXVhbnRpdHkgPD0gbWF4XHJcbiAgcmV0dXJuIDw+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImRldGFpbC1tb2JpbGUtdG9wXCI+PENhdGFsb2dMaW5rIGFyaWFMYWJlbD1cIlZvbHRhciBhbyBjYXTDoWxvZ29cIj48QXJyb3dMZWZ0IHNpemU9ezIwfSAvPjwvQ2F0YWxvZ0xpbms+PEZhdm9yaXRlQnV0dG9uIGlkPXtuZnQuaWR9IG5hbWU9e25mdC5uYW1lfSAvPjwvZGl2PlxyXG4gICAgPHAgY2xhc3NOYW1lPVwiYnJlYWRjcnVtYlwiPjxDYXRhbG9nTGluaz5JbsOtY2lvPC9DYXRhbG9nTGluaz4gLyBNZXJjYWRvPC9wPlxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZGV0YWlsLXRvcFwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdhbGxlcnlcIj48ZGl2IGNsYXNzTmFtZT1cImdhbGxlcnktdGh1bWJuYWlsc1wiIGFyaWEtbGFiZWw9XCJHYWxlcmlhIGRlIGltYWdlbnNcIj57bmZ0LmdhbGxlcnkubWFwKChhc3NldCwgaSkgPT4gPGJ1dHRvbiBrZXk9e2l9IGFyaWEtbGFiZWw9e2BJbWFnZW0gJHtpICsgMX1gfSBhcmlhLXByZXNzZWQ9e2ltYWdlID09PSBpfSBvbkNsaWNrPXsoKSA9PiBzZXRJbWFnZShpKX0+PGltZyBzcmM9e2Fzc2V0fSBhbHQ9XCJcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIC8+PC9idXR0b24+KX08L2Rpdj48ZGl2IGNsYXNzTmFtZT1cImdhbGxlcnktbWFpblwiPjxpbWcgc3JjPXtuZnQuZ2FsbGVyeVtpbWFnZV19IHNyY1NldD17YCR7bmZ0LmdhbGxlcnlbaW1hZ2VdLnJlcGxhY2UoXCItOTAwLndlYnBcIiwgXCItNDUwLndlYnBcIil9IDQ1MHcsICR7bmZ0LmdhbGxlcnlbaW1hZ2VdfSA5MDB3YH0gc2l6ZXM9XCIobWF4LXdpZHRoOjYzOXB4KSAxMDB2dywgNDUwcHhcIiBhbHQ9e25mdC5uYW1lfSB3aWR0aD1cIjQ1MFwiIGhlaWdodD1cIjQ1MFwiIGZldGNoUHJpb3JpdHk9XCJoaWdoXCIgLz48YnV0dG9uIGFyaWEtbGFiZWw9XCJBbXBsaWFyIGltYWdlbVwiIG9uQ2xpY2s9eygpID0+IHNldFpvb20odHJ1ZSl9PjxTZWFyY2ggc2l6ZT17MjR9IC8+PC9idXR0b24+PC9kaXY+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGV0YWlsLWluZm9cIj48aDE+e25mdC5uYW1lfTwvaDE+PGRpdiBjbGFzc05hbWU9XCJkZXRhaWwtcHJpY2UtcmV2aWV3XCI+PHN0cm9uZyBkYXRhLXRlc3RpZD1cImRldGFpbC1wcmljZVwiPntuZnQucHJpY2VFdGh9IEVUSDwvc3Ryb25nPjxzcGFuIGFyaWEtbGFiZWw9XCJBdmFsaWHDp8OjbyA0LDggZGUgNSwgMTkgYXZhbGlhw6fDtWVzXCI+PHNwYW4gY2xhc3NOYW1lPVwic3RhcnNcIj7imIXimIXimIXimIXimIU8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiZGVza3RvcC10aXRsZVwiPjE5IGF2YWxpYcOnw7VlcyBkZSBjb2xlY2lvbmFkb3Jlczwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJtb2JpbGUtdGl0bGVcIj48U3RhciBzaXplPXsxMn0gZmlsbD1cImN1cnJlbnRDb2xvclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+IDQuOCgxOSk8L3NwYW4+PC9zcGFuPjwvZGl2PjxoMiBjbGFzc05hbWU9XCJhYm91dC1sYWJlbFwiPlNvYnJlIGVzdGUgTkZUOjwvaDI+PHAgY2xhc3NOYW1lPVwic2hvcnQtZGVzY3JpcHRpb25cIj48c3BhbiBjbGFzc05hbWU9XCJkZXNrdG9wLXRpdGxlXCI+e25mdC5kZXNjcmlwdGlvbi5zcGxpdCgnLiAnKVswXX0uPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cIm1vYmlsZS10aXRsZVwiPlVtIGNvbGVjaW9uw6F2ZWwgZGlnaXRhbCB7ZWRpdGlvbi5sYWJlbH0gZmluYWxpemFkbyDDoCBtw6NvIGRhIGNvbGXDp8OjbyBLdXJpbyBFZGl0aW9ucywgdmVyaWZpY2FkbyBuYSB7bmZ0Lm5ldHdvcmt9Ljwvc3Bhbj48L3A+XHJcbiAgICAgICAgPGZpZWxkc2V0IGNsYXNzTmFtZT1cImVkaXRpb24tcGlja2VyXCI+PGxlZ2VuZD5FZGnDp8Ojbzo8L2xlZ2VuZD57bmZ0LmVkaXRpb25zLm1hcCgoZSkgPT4gPGJ1dHRvbiBrZXk9e2UuaWR9IGRpc2FibGVkPXtlLmF2YWlsYWJsZSA9PT0gMH0gYXJpYS1sYWJlbD17YEVkacOnw6NvICR7ZS5sYWJlbH0ke2UuYXZhaWxhYmxlID09PSAwID8gJywgaW5kaXNwb27DrXZlbCcgOiAnJ31gfSBhcmlhLXByZXNzZWQ9e2VkaXRpb25JZCA9PT0gZS5pZH0gb25DbGljaz17KCkgPT4geyBjaG9vc2VFZGl0aW9uKGUuaWQpIH19PntlLmxhYmVsfTwvYnV0dG9uPil9PC9maWVsZHNldD5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJ1eS1jb250cm9sc1wiPjxkaXYgY2xhc3NOYW1lPVwicXVhbnRpdHktY29udHJvbFwiPjxsYWJlbCBodG1sRm9yPVwicXVhbnRpdHlcIj5RdGQuPC9sYWJlbD48YnV0dG9uIGFyaWEtbGFiZWw9XCJEaW1pbnVpciBxdWFudGlkYWRlXCIgZGlzYWJsZWQ9e3F1YW50aXR5IDw9IDEgfHwgbWF4ID09PSAwfSBvbkNsaWNrPXsoKSA9PiBzZXRRdWFudGl0eShxdWFudGl0eSAtIDEpfT7iiJI8L2J1dHRvbj48aW5wdXQgaWQ9XCJxdWFudGl0eVwiIGFyaWEtbGFiZWw9XCJRdGQuXCIgYXJpYS1pbnZhbGlkPXshdmFsaWR9IGFyaWEtZGVzY3JpYmVkYnk9XCJxdWFudGl0eS1lcnJvclwiIHR5cGU9XCJudW1iZXJcIiBtaW49XCIxXCIgbWF4PXttYXggfHwgMX0gdmFsdWU9e3F1YW50aXR5fSBvbkNoYW5nZT17KGUpID0+IHNldFF1YW50aXR5KE51bWJlcihlLnRhcmdldC52YWx1ZSkpfSAvPjxidXR0b24gYXJpYS1sYWJlbD1cIkF1bWVudGFyIHF1YW50aWRhZGVcIiBkaXNhYmxlZD17cXVhbnRpdHkgPj0gbWF4fSBvbkNsaWNrPXsoKSA9PiBzZXRRdWFudGl0eShxdWFudGl0eSArIDEpfT4rPC9idXR0b24+PC9kaXY+PHN0cm9uZyBjbGFzc05hbWU9XCJtb2JpbGUtdW5pdC1wcmljZVwiIGRhdGEtdGVzdGlkPVwiZGV0YWlsLXByaWNlXCI+e25mdC5wcmljZUV0aH0gRVRIPC9zdHJvbmc+PGRpdiBjbGFzc05hbWU9XCJwdXJjaGFzZS1hY3Rpb25zXCI+PEJ1dHRvbiBkaXNhYmxlZD17IXZhbGlkIHx8IGNhcnQuaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBhZGQodHJ1ZSl9PjxzcGFuIGNsYXNzTmFtZT1cImRlc2t0b3AtdGl0bGVcIj5DT01QUkFSPC9zcGFuPjxzcGFuIGNsYXNzTmFtZT1cIm1vYmlsZS10aXRsZVwiPkNvbXByYXIgTkZUPC9zcGFuPjwvQnV0dG9uPjxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBkaXNhYmxlZD17IXZhbGlkIHx8IGNhcnQuaXNQZW5kaW5nfSBhcmlhLWxhYmVsPVwiQWRpY2lvbmFyIGFvIGNhcnJpbmhvXCIgb25DbGljaz17KCkgPT4gYWRkKGZhbHNlKX0+PFNob3BwaW5nQ2FydCBzaXplPXsyMH0gLz48L0J1dHRvbj48c3BhbiBjbGFzc05hbWU9XCJkZXNrdG9wLXB1cmNoYXNlLWZhdm9yaXRlXCI+PEZhdm9yaXRlQnV0dG9uIGlkPXtuZnQuaWR9IG5hbWU9e25mdC5uYW1lfSAvPjwvc3Bhbj48L2Rpdj48cCBpZD1cInF1YW50aXR5LWVycm9yXCIgY2xhc3NOYW1lPVwicXVhbnRpdHktZmVlZGJhY2tcIiByb2xlPXt2YWxpZCA/IHVuZGVmaW5lZCA6ICdhbGVydCd9PnttYXggPT09IDAgPyAnRWRpw6fDo28gZXNnb3RhZGEuJyA6ICF2YWxpZCA/IGBFc2NvbGhhIHVtYSBxdWFudGlkYWRlIGludGVpcmEgZGUgMSBhICR7bWF4fS5gIDogPHNwYW4gY2xhc3NOYW1lPVwiZGVza3RvcC10aXRsZVwiPntgQXTDqSAke21heH0gdW5pZGFkZXMgZGlzcG9uw612ZWlzLmB9PC9zcGFuPn08L3A+PC9kaXY+XHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJ0LWFkZC1mZWVkYmFja1wiPntjYXJ0LmlzUGVuZGluZyAmJiA8cCByb2xlPVwic3RhdHVzXCI+QWRpY2lvbmFuZG8gYW8gY2FycmluaG/igKY8L3A+fXtjYXJ0LmlzU3VjY2VzcyAmJiA8cCByb2xlPVwic3RhdHVzXCI+SXRlbSBhZGljaW9uYWRvIGFvIGNhcnJpbmhvLiA8TGluayB0bz1cIi9jYXJ0XCI+VmVyIGNhcnJpbmhvPC9MaW5rPjwvcD59e2NhcnQuaXNFcnJvciAmJiA8cCByb2xlPVwiYWxlcnRcIj57YXBpTWVzc2FnZShjYXJ0LmVycm9yKX08L3A+fTwvZGl2PjxkbCBjbGFzc05hbWU9XCJuZnQtYXR0cmlidXRlc1wiPjxkaXY+PGR0PklEIGRvIHRva2VuOjwvZHQ+PGRkPntuZnQudG9rZW59PC9kZD48L2Rpdj48ZGl2PjxkdD5Db2xlw6fDo286PC9kdD48ZGQ+S3VyaW8gQXBlczxzcGFuIGNsYXNzTmFtZT1cImRlc2t0b3AtdGl0bGVcIj4gwrcge25mdC5uZXR3b3JrfTwvc3Bhbj48L2RkPjwvZGl2PjxkaXY+PGR0PkF0cmlidXRvczo8L2R0PjxkZD7Dk2N1bG9zLCBFc21lcmFsZGEsIHtuZnQucmFyZSA/ICdSYXJvJyA6ICdWZXJpZmljYWRvJ308L2RkPjwvZGl2PjwvZGw+PGRldGFpbHMgY2xhc3NOYW1lPVwibW9iaWxlLWRldGFpbC10b29sc1wiIG9wZW49e21hdGNoTWVkaWEoJyhtaW4td2lkdGg6NjQwcHgpJykubWF0Y2hlcyB8fCB1bmRlZmluZWR9PjxzdW1tYXJ5PkdhbGVyaWEgZSBjb21wYXJ0aWxoYW1lbnRvPC9zdW1tYXJ5PjxkaXYgY2xhc3NOYW1lPVwibW9iaWxlLWdhbGxlcnlcIiBhcmlhLWxhYmVsPVwiR2FsZXJpYSBtb2JpbGVcIj57bmZ0LmdhbGxlcnkubWFwKChhc3NldCwgaSkgPT4gPGJ1dHRvbiBrZXk9e2l9IGFyaWEtbGFiZWw9e2BJbWFnZW0gJHtpICsgMX1gfSBhcmlhLXByZXNzZWQ9e2ltYWdlID09PSBpfSBvbkNsaWNrPXsoKSA9PiBzZXRJbWFnZShpKX0+PGltZyBzcmM9e2Fzc2V0fSBhbHQ9XCJcIiB3aWR0aD1cIjM2XCIgaGVpZ2h0PVwiMzZcIiAvPjwvYnV0dG9uPil9PC9kaXY+PGRpdiBjbGFzc05hbWU9XCJzaGFyZS1yb3dcIj5Db21wYXJ0aWxoYXIgZXN0ZSBORlQ6IDxidXR0b24gb25DbGljaz17KCkgPT4gdW5hdmFpbGFibGUoJ0NvbXBhcnRpbGhhbWVudG8nKX0+Q29tcGFydGlsaGFyPC9idXR0b24+PC9kaXY+PC9kZXRhaWxzPlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvc2VjdGlvbj5cclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImZ1bGwtZGV0YWlsc1wiPjxkaXYgcm9sZT1cInRhYmxpc3RcIiBhcmlhLWxhYmVsPVwiSW5mb3JtYcOnw7VlcyBkbyBORlRcIj48YnV0dG9uIHJvbGU9XCJ0YWJcIiBpZD1cImRldGFpbHMtdGFiXCIgYXJpYS1zZWxlY3RlZD17dGFiID09PSAnZGV0YWlscyd9IGFyaWEtY29udHJvbHM9XCJkZXRhaWxzLXBhbmVsXCIgb25DbGljaz17KCkgPT4gc2V0VGFiKCdkZXRhaWxzJyl9PkRldGFsaGVzIGRvIE5GVDwvYnV0dG9uPjxidXR0b24gcm9sZT1cInRhYlwiIGlkPVwicmV2aWV3cy10YWJcIiBhcmlhLXNlbGVjdGVkPXt0YWIgPT09ICdyZXZpZXdzJ30gYXJpYS1jb250cm9scz1cInJldmlld3MtcGFuZWxcIiBvbkNsaWNrPXsoKSA9PiBzZXRUYWIoJ3Jldmlld3MnKX0+QXZhbGlhw6fDtWVzIGRlIGNvbGVjaW9uYWRvcmVzICgxOSk8L2J1dHRvbj48L2Rpdj57dGFiID09PSAnZGV0YWlscycgPyA8ZGl2IHJvbGU9XCJ0YWJwYW5lbFwiIGlkPVwiZGV0YWlscy1wYW5lbFwiIGFyaWEtbGFiZWxsZWRieT1cImRldGFpbHMtdGFiXCI+PHA+e25mdC5uYW1lfSDDqSB1bWEgb2JyYSBkaWdpdGFsIGRhIGNvbGXDp8OjbyBLdXJpbyBFZGl0aW9ucy4gQ2FkYSBhdHJpYnV0byBmaWNhIGFybWF6ZW5hZG8gbm9zIG1ldGFkYWRvcyBkbyB0b2tlbi4ge25mdC5kZXNjcmlwdGlvbn08L3A+PHA+QSBwcm9wcmllZGFkZSBpbmNsdWkgYSBhcnRlIGVtIGFsdGEgcmVzb2x1w6fDo28sIGxhbsOnYW1lbnRvcyBleGNsdXNpdm9zIHBhcmEgY29sZWNpb25hZG9yZXMgZSB1bSByZWdpc3RybyBwZXJtYW5lbnRlIGRlIHByb2NlZMOqbmNpYS4gTm92YSBTYXRvIHJlY2ViZSB7bmZ0LnJveWFsdHl9IGRlIGRpcmVpdG9zIGF1dG9yYWlzIG5hcyB2ZW5kYXMgc2VjdW5kw6FyaWFzLCBhcG9pYW5kbyBub3ZvcyB0cmFiYWxob3MgZSBsYW7Dp2FtZW50b3MgZGEgY29tdW5pZGFkZS48L3A+PGRsPjxkdD5SZWRlOjwvZHQ+PGRkPntuZnQubmV0d29ya30gwrcgTWV0YWRhZG9zIGFybWF6ZW5hZG9zIG5vIElQRlMuPC9kZD48ZHQ+Q29udHJhdG86PC9kdD48ZGQ+e25mdC5jb250cmFjdH08L2RkPjxkdD5EaXJlaXRvcyBhdXRvcmFpczo8L2R0PjxkZD57bmZ0LnJveWFsdHl9IG5hcyB2ZW5kYXMgc2VjdW5kw6FyaWFzLjwvZGQ+PC9kbD48L2Rpdj4gOiA8ZGl2IHJvbGU9XCJ0YWJwYW5lbFwiIGlkPVwicmV2aWV3cy1wYW5lbFwiIGFyaWEtbGFiZWxsZWRieT1cInJldmlld3MtdGFiXCI+PHA+NCw4IGRlIDUgwrcgMTkgYXZhbGlhw6fDtWVzIGRlIGNvbGVjaW9uYWRvcmVzLiBPIGVudmlvIGRlIGF2YWxpYcOnw7VlcyBuw6NvIGZheiBwYXJ0ZSBkZXN0YSBldGFwYS48L3A+PC9kaXY+fTwvc2VjdGlvbj5cclxuICAgIDxNb2RhbCB0aXRsZT1cIkltYWdlbSBkbyBORlRcIiBvcGVuPXt6b29tfSBvbkNsb3NlPXsoKSA9PiBzZXRab29tKGZhbHNlKX0+PGltZyBjbGFzc05hbWU9XCJ6b29tLWltYWdlXCIgc3JjPXtuZnQuZ2FsbGVyeVtpbWFnZV0ucmVwbGFjZShcIi05MDAud2VicFwiLCBcIi53ZWJwXCIpfSBhbHQ9e25mdC5uYW1lfSAvPjwvTW9kYWw+XHJcbiAgPC8+XHJcbn1cclxuIl19