import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/HomeSections.tsx");const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { CarouselIndicators } from "/src/features/catalog/CarouselIndicators.tsx";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { CatalogLink, useCatalogDestination } from "/src/features/catalog/CatalogLink.tsx";
import { useUnavailable } from "/src/features/catalog/MarketShell.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/HomeSections.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export function Hero({ featured }) {
	_s();
	const search = useCatalogDestination(), [slide, setSlide] = useState(0), [animated, setAnimated] = useState(false);
	const gesture = useRef(null), swiped = useRef(false);
	const nft = featured?.[slide], mini = featured?.[(slide + 1) % 3];
	const first = slide === 0;
	const selectSlide = (index) => {
		setAnimated(true);
		setSlide(index);
	};
	const heading = /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
		className: "desktop-title",
		children: [
			"SEJA DONO DO FUTURO",
			/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 72
			}, this),
			"DA ARTE DIGITAL"
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 21
	}, this), /* @__PURE__ */ _jsxDEV("span", {
		className: "mobile-title",
		children: [
			"SEJA DONO DA",
			/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 143
			}, this),
			"CULTURA DIGITAL"
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 100
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 19
	}, this);
	const intro = /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
		className: "desktop-title",
		children: "Descubra NFTs de criadores emergentes e consagrados. Colecione arte digital rara, apoie artistas e tenha uma parte da cultura da internet."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 19
	}, this), /* @__PURE__ */ _jsxDEV("span", {
		className: "mobile-title",
		children: "Descubra NFTs selecionados de criadores do mundo todo."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 196
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 17
	}, this);
	const content = first ? heading : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("span", {
		className: "desktop-title",
		children: [
			nft?.name,
			/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 82
			}, this),
			"ARTE EM DESTAQUE"
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 39
	}, this), /* @__PURE__ */ _jsxDEV("span", {
		className: "mobile-title",
		children: [
			nft?.name.split(" #")[0],
			/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 168
			}, this),
			"#",
			nft?.name.split(" #")[1]
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 111
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 37
	}, this);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "home-hero",
		"aria-label": "Destaques de NFTs",
		onPointerDown: (event) => {
			if (event.target instanceof Element && event.target.closest("button")) return;
			gesture.current = {
				x: event.clientX,
				y: event.clientY
			};
			swiped.current = false;
		},
		onPointerCancel: () => {
			gesture.current = null;
		},
		onPointerUp: (event) => {
			if (!gesture.current || !featured?.length) return;
			const dx = event.clientX - gesture.current.x, dy = event.clientY - gesture.current.y;
			gesture.current = null;
			if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.4) {
				swiped.current = true;
				selectSlide((slide + (dx < 0 ? 1 : 2)) % 3);
			}
		},
		onClickCapture: (event) => {
			if (swiped.current && event.detail > 0 && event.target instanceof Element && event.target.closest(".hero-art a")) {
				event.preventDefault();
				event.stopPropagation();
			}
			swiped.current = false;
		},
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "hero-copy",
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: "Bem-vindo à Kurio" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 32
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", { children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "hero-sizing",
						"aria-hidden": "true",
						children: heading
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 60
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "hero-slide-copy",
						children: content
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 125
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 56
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "hero-description",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "hero-sizing",
							"aria-hidden": "true",
							children: intro
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 212
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "hero-slide-copy",
							children: first ? intro : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								"Colecione ",
								nft?.name,
								"."
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 25,
								columnNumber: 326
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 275
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 180
					}, this),
					nft ? /* @__PURE__ */ _jsxDEV(Link, {
						className: "hero-cta",
						"aria-label": `Explorar ${nft.name}`,
						to: "/nfts/$nftId",
						state: { catalogSearch: search },
						search: {
							edition: "fifty",
							quantity: 1
						},
						params: { nftId: nft.id },
						children: ["EXPLORAR ", /* @__PURE__ */ _jsxDEV("span", {
							className: "mobile-title",
							children: "→"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 561
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 372
					}, this) : /* @__PURE__ */ _jsxDEV("span", {
						className: "hero-cta",
						"aria-disabled": "true",
						children: ["EXPLORAR ", /* @__PURE__ */ _jsxDEV("span", {
							className: "mobile-title",
							children: "→"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 667
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 610
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "hero-art",
				children: [nft ? /* @__PURE__ */ _jsxDEV(Link, {
					className: animated ? "hero-changing" : undefined,
					to: "/nfts/$nftId",
					state: { catalogSearch: search },
					search: {
						edition: "fifty",
						quantity: 1
					},
					params: { nftId: nft.id },
					children: /* @__PURE__ */ _jsxDEV("img", {
						src: nft.image,
						srcSet: `${nft.image.replace("-900.webp", "-450.webp")} 450w, ${nft.image} 900w`,
						sizes: "(max-width:639px) 138px, 450px",
						alt: nft.name,
						width: "450",
						height: "450",
						fetchPriority: first ? "high" : "auto"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 26,
						columnNumber: 225
					}, this)
				}, nft.id, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 38
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "hero-art-placeholder",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 458
				}, this), mini && /* @__PURE__ */ _jsxDEV("img", {
					className: "hero-mini",
					src: mini.image.replace("-900.webp", "-450.webp"),
					alt: mini.name,
					width: "58",
					height: "58"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 527
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 5
			}, this),
			featured?.length === 3 && /* @__PURE__ */ _jsxDEV(CarouselIndicators, {
				className: "hero-dots",
				label: "Escolher destaque",
				labels: featured.map((item, index) => `Destaque ${index + 1}: ${item.name}`),
				active: slide,
				onChange: selectSlide
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 32
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 10
	}, this);
}
_s(Hero, "rJZWUGEu8OjdUJsN0WwpGo7BSgU=", false, function() {
	return [useCatalogDestination];
});
_c = Hero;
export function HomeSections() {
	_s2();
	const unavailable = useUnavailable();
	const posts = [
		[
			"9add2-900.webp",
			"Como funciona a propriedade de NFTs",
			"Aprenda a colecionar, negociar e verificar ativos digitais."
		],
		[
			"8f387-900.webp",
			"10 artistas digitais para acompanhar",
			"Conheça criadores que moldam a cultura digital."
		],
		[
			"83794-900.webp",
			"Raridade, atributos e procedência",
			"Entenda raridade, procedência, direitos autorais e utilidade."
		],
		[
			"b7cfc-900.webp",
			"Como proteger sua carteira",
			"Proteja sua carteira, seus NFTs e sua identidade."
		]
	];
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
		className: "promos",
		children: [[
			"8f387-900.webp",
			"Lançamentos gênesis de edição limitada",
			"Colecione edições escassas diretamente dos criadores antes da revelação pública."
		], [
			"9add2-900.webp",
			"Arte digital selecionada e muito mais",
			"Explore novos artistas, coleções verificadas e obras digitais que definem a cultura."
		]].map(([image, title, text]) => /* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("img", {
			src: `/assets/optimized/${image}`,
			alt: "",
			width: "292",
			height: "250",
			loading: "lazy"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 388
		}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
			/* @__PURE__ */ _jsxDEV("h2", { children: title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 482
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: text }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 498
			}, this),
			/* @__PURE__ */ _jsxDEV(CatalogLink, { children: "Explorar →" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 511
			}, this)
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 477
		}, this)] }, image, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 367
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 12
	}, this), /* @__PURE__ */ _jsxDEV("section", {
		className: "blog",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", { children: "Diário da Cunhagem" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 602
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: "Histórias, guias e insights para colecionadores sobre o universo da propriedade digital." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 629
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "blog-cards",
				children: posts.map(([image, title, text], i) => /* @__PURE__ */ _jsxDEV("article", { children: [/* @__PURE__ */ _jsxDEV("img", {
					src: `/assets/optimized/${image}`,
					alt: "",
					width: "268",
					height: "195",
					loading: "lazy"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 813
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("p", { children: [
						12 + i,
						" de setembro | Leitura de ",
						i === 0 ? 6 : 2,
						" min"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 907
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: title }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 969
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: text }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 985
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => unavailable("Conteúdo editorial"),
						children: "Ler mais →"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 998
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 902
				}, this)] }, image, true, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 792
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 724
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 576
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 10
	}, this);
}
_s2(HomeSections, "3GTIyVkn/0d+kJFcrsIhxFFQo30=", false, function() {
	return [useUnavailable];
});
_c2 = HomeSections;
var _c, _c2;
$RefreshReg$(_c, "Hero");
$RefreshReg$(_c2, "HomeSections");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/HomeSections.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/HomeSections.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/HomeSections.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/HomeSections.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxRQUFRLGdCQUFnQjtBQUVqQyxTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLFlBQVk7QUFDckIsU0FBUyxhQUFhLDZCQUE2QjtBQUNuRCxTQUFTLHNCQUFzQjs7OztBQUMvQixPQUFPLFNBQVMsS0FBSyxFQUFFLFlBQWtDOztDQUN2RCxNQUFNLFNBQVMsc0JBQXNCLEdBQUcsQ0FBQyxPQUFNLFlBQVksU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFTLGVBQWUsU0FBUyxLQUFLO0NBQy9HLE1BQU0sVUFBVSxPQUF3QyxJQUFJLEdBQUcsU0FBUyxPQUFPLEtBQUs7Q0FDcEYsTUFBTSxNQUFNLFdBQVcsUUFBUSxPQUFPLFlBQVksUUFBUSxLQUFLO0NBQy9ELE1BQU0sUUFBUSxVQUFVO0NBQ3hCLE1BQU0sZUFBZSxVQUFrQjtFQUFFLFlBQVksSUFBSTtFQUFHLFNBQVMsS0FBSztDQUFFO0NBQzVFLE1BQU0sVUFBVSxnREFBRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUFnQztHQUFtQix3QkFBQyxNQUFELENBQUs7Ozs7O0dBQUM7RUFBcUI7Ozs7O1dBQUMsd0JBQUMsUUFBRDtFQUFNLFdBQVU7WUFBaEI7R0FBK0I7R0FBWSx3QkFBQyxNQUFELENBQUs7Ozs7O0dBQUM7RUFBcUI7Ozs7O1NBQUc7Ozs7O0NBQzFLLE1BQU0sUUFBUSxnREFBRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFnQjtDQUFnSjs7OztXQUFDLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWU7Q0FBNEQ7Ozs7U0FBRzs7Ozs7Q0FDL1IsTUFBTSxVQUFVLFFBQVEsVUFBVSxnREFBRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtZQUFoQjtHQUFpQyxLQUFLO0dBQUssd0JBQUMsTUFBRCxDQUFLOzs7OztHQUFDO0VBQXNCOzs7OztXQUFDLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCO0dBQWdDLEtBQUssS0FBSyxNQUFNLElBQUksQ0FBQyxDQUFDO0dBQUcsd0JBQUMsTUFBRCxDQUFLOzs7OztHQUFDO0dBQUUsS0FBSyxLQUFLLE1BQU0sSUFBSSxDQUFDLENBQUM7RUFBUzs7Ozs7U0FBRzs7Ozs7Q0FDL00sT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtFQUFZLGNBQVc7RUFBb0IsZ0JBQWUsVUFBUztHQUMzRixJQUFJLE1BQU0sa0JBQWtCLFdBQVcsTUFBTSxPQUFPLFFBQVEsUUFBUSxHQUFHO0dBQ3ZFLFFBQVEsVUFBVTtJQUFFLEdBQUUsTUFBTTtJQUFTLEdBQUUsTUFBTTtHQUFRO0dBQUcsT0FBTyxVQUFVO0VBQzNFO0VBQUcsdUJBQXVCO0dBQUUsUUFBUSxVQUFVO0VBQUs7RUFBRyxjQUFhLFVBQVM7R0FDMUUsSUFBSSxDQUFDLFFBQVEsV0FBVyxDQUFDLFVBQVUsUUFBUTtHQUMzQyxNQUFNLEtBQUssTUFBTSxVQUFRLFFBQVEsUUFBUSxHQUFHLEtBQUssTUFBTSxVQUFRLFFBQVEsUUFBUTtHQUMvRSxRQUFRLFVBQVU7R0FDbEIsSUFBSSxLQUFLLElBQUksRUFBRSxJQUFJLE1BQU0sS0FBSyxJQUFJLEVBQUUsSUFBSSxLQUFLLElBQUksRUFBRSxJQUFFLEtBQUs7SUFBRSxPQUFPLFVBQVU7SUFBTSxhQUFhLFNBQVMsS0FBSyxJQUFJLElBQUksTUFBTSxDQUFDO0dBQUU7RUFDakk7RUFBRyxpQkFBZ0IsVUFBUztHQUFFLElBQUksT0FBTyxXQUFXLE1BQU0sU0FBUyxLQUFLLE1BQU0sa0JBQWtCLFdBQVcsTUFBTSxPQUFPLFFBQVEsYUFBYSxHQUFHO0lBQUUsTUFBTSxlQUFlO0lBQUcsTUFBTSxnQkFBZ0I7R0FBRTtHQUFFLE9BQU8sVUFBVTtFQUFNO1lBUnBOO0dBU0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUEyQix3QkFBQyxLQUFELFlBQUcsb0JBQW9COzs7OztLQUFDLHdCQUFDLE1BQUQsYUFBSSx3QkFBQyxRQUFEO01BQU0sV0FBVTtNQUFjLGVBQVk7Z0JBQVE7S0FBYzs7OztlQUFDLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFtQjtLQUFjOzs7O2FBQUs7Ozs7O0tBQUMsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWIsQ0FBZ0Msd0JBQUMsUUFBRDtPQUFNLFdBQVU7T0FBYyxlQUFZO2lCQUFRO01BQVk7Ozs7Z0JBQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQW1CLFFBQVEsUUFBUTtRQUFFO1FBQVcsS0FBSztRQUFLO09BQUc7Ozs7O01BQVE7Ozs7Y0FBSTs7Ozs7O0tBQUUsTUFBTSx3QkFBQyxNQUFEO01BQU0sV0FBVTtNQUFXLGNBQVksWUFBWSxJQUFJO01BQVEsSUFBRztNQUFlLE9BQU8sRUFBRSxlQUFjLE9BQU87TUFBRyxRQUFRO09BQUUsU0FBUTtPQUFRLFVBQVM7TUFBRTtNQUFHLFFBQVEsRUFBRSxPQUFNLElBQUksR0FBRztnQkFBakwsQ0FBb0wsYUFBUyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBZTtNQUFPOzs7O2NBQU87Ozs7O2dCQUFJLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO01BQVcsaUJBQWM7Z0JBQXpDLENBQWdELGFBQVMsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQWU7TUFBTzs7OztjQUFPOzs7Ozs7SUFBTzs7Ozs7O0dBQzFzQix3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQTJCLE1BQU0sd0JBQUMsTUFBRDtLQUFtQixXQUFXLFdBQVcsa0JBQWtCO0tBQVcsSUFBRztLQUFlLE9BQU8sRUFBRSxlQUFjLE9BQU87S0FBRyxRQUFRO01BQUUsU0FBUTtNQUFRLFVBQVM7S0FBRTtLQUFHLFFBQVEsRUFBRSxPQUFNLElBQUksR0FBRztlQUFHLHdCQUFDLE9BQUQ7TUFBSyxLQUFLLElBQUk7TUFBTyxRQUFRLEdBQUcsSUFBSSxNQUFNLFFBQVEsYUFBWSxXQUFXLEVBQUUsU0FBUyxJQUFJLE1BQU07TUFBUSxPQUFNO01BQWlDLEtBQUssSUFBSTtNQUFNLE9BQU07TUFBTSxRQUFPO01BQU0sZUFBZSxRQUFRLFNBQVM7S0FBUzs7Ozs7SUFBTyxHQUFyWixJQUFJOzs7O1dBQWlaLElBQUksd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBdUIsZUFBWTtJQUFROzs7O2NBQUcsUUFBUSx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFZLEtBQUssS0FBSyxNQUFNLFFBQVEsYUFBWSxXQUFXO0tBQUcsS0FBSyxLQUFLO0tBQU0sT0FBTTtLQUFLLFFBQU87SUFBTTs7OztZQUFPOzs7Ozs7R0FDcm9CLFVBQVUsV0FBVyxLQUFLLHdCQUFDLG9CQUFEO0lBQW9CLFdBQVU7SUFBWSxPQUFNO0lBQW9CLFFBQVEsU0FBUyxLQUFLLE1BQUssVUFBVSxZQUFZLFFBQVEsRUFBRSxJQUFJLEtBQUssTUFBTTtJQUFHLFFBQVE7SUFBTyxVQUFVO0dBQWM7Ozs7O0VBQzVNOzs7Ozs7QUFDWDs7Ozs7QUFDQSxPQUFPLFNBQVMsZUFBZTs7Q0FDN0IsTUFBTSxjQUFjLGVBQWU7Q0FDbkMsTUFBTSxRQUFRO0VBQUM7R0FBQztHQUFrQjtHQUF1QztFQUE2RDtFQUFHO0dBQUM7R0FBa0I7R0FBd0M7RUFBaUQ7RUFBRztHQUFDO0dBQWtCO0dBQXFDO0VBQStEO0VBQUc7R0FBQztHQUFrQjtHQUE4QjtFQUFtRDtDQUFDO0NBQ3ZkLE9BQU8sZ0RBQUUsd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBVSxDQUFDO0dBQUM7R0FBa0I7R0FBMEM7RUFBa0YsR0FBRztHQUFDO0dBQWtCO0dBQXlDO0VBQXNGLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLE9BQU8sVUFBVSx3QkFBQyxXQUFELGFBQXFCLHdCQUFDLE9BQUQ7R0FBSyxLQUFLLHFCQUFxQjtHQUFTLEtBQUk7R0FBRyxPQUFNO0dBQU0sUUFBTztHQUFNLFNBQVE7RUFBUTs7OztZQUFDLHdCQUFDLE9BQUQ7R0FBSyx3QkFBQyxNQUFELFlBQUssTUFBVTs7Ozs7R0FBQyx3QkFBQyxLQUFELFlBQUksS0FBUTs7Ozs7R0FBQyx3QkFBQyxhQUFELFlBQWEsYUFBdUI7Ozs7O0VBQU07Ozs7VUFBVSxLQUF0TDs7OztTQUFzTCxDQUFDO0NBQVc7Ozs7V0FBQyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUEwQix3QkFBQyxNQUFELFlBQUkscUJBQXNCOzs7OztHQUFDLHdCQUFDLEtBQUQsWUFBRywyRkFBMkY7Ozs7O0dBQUMsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBYyxNQUFNLEtBQUssQ0FBQyxPQUFPLE9BQU8sT0FBTyxNQUFNLHdCQUFDLFdBQUQsYUFBcUIsd0JBQUMsT0FBRDtLQUFLLEtBQUsscUJBQXFCO0tBQVMsS0FBSTtLQUFHLE9BQU07S0FBTSxRQUFPO0tBQU0sU0FBUTtJQUFROzs7O2NBQUMsd0JBQUMsT0FBRDtLQUFLLHdCQUFDLEtBQUQ7TUFBSSxLQUFLO01BQUU7TUFBMkIsTUFBTSxJQUFJLElBQUk7TUFBRTtLQUFPOzs7OztLQUFDLHdCQUFDLE1BQUQsWUFBSyxNQUFVOzs7OztLQUFDLHdCQUFDLEtBQUQsWUFBSSxLQUFROzs7OztLQUFDLHdCQUFDLFVBQUQ7TUFBUSxlQUFlLFlBQVksb0JBQW9CO2dCQUFHO0tBQWtCOzs7OztJQUFNOzs7O1lBQVUsS0FBNVI7Ozs7V0FBNFIsQ0FBQztHQUFPOzs7OztFQUFVOzs7OztTQUFHOzs7OztBQUN0bEMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSG9tZVNlY3Rpb25zLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB0eXBlIHsgTmZ0IH0gZnJvbSAnLi9jb250cmFjdHMnXHJcbmltcG9ydCB7IENhcm91c2VsSW5kaWNhdG9ycyB9IGZyb20gJy4vQ2Fyb3VzZWxJbmRpY2F0b3JzJ1xyXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcclxuaW1wb3J0IHsgQ2F0YWxvZ0xpbmssIHVzZUNhdGFsb2dEZXN0aW5hdGlvbiB9IGZyb20gJy4vQ2F0YWxvZ0xpbmsnXHJcbmltcG9ydCB7IHVzZVVuYXZhaWxhYmxlIH0gZnJvbSAnLi9NYXJrZXRTaGVsbCdcclxuZXhwb3J0IGZ1bmN0aW9uIEhlcm8oeyBmZWF0dXJlZCB9OiB7IGZlYXR1cmVkPzogTmZ0W10gfSkge1xyXG4gIGNvbnN0IHNlYXJjaCA9IHVzZUNhdGFsb2dEZXN0aW5hdGlvbigpLCBbc2xpZGUsc2V0U2xpZGVdID0gdXNlU3RhdGUoMCksIFthbmltYXRlZCxzZXRBbmltYXRlZF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBnZXN0dXJlID0gdXNlUmVmPHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB8IG51bGw+KG51bGwpLCBzd2lwZWQgPSB1c2VSZWYoZmFsc2UpXHJcbiAgY29uc3QgbmZ0ID0gZmVhdHVyZWQ/LltzbGlkZV0sIG1pbmkgPSBmZWF0dXJlZD8uWyhzbGlkZSArIDEpICUgM11cclxuICBjb25zdCBmaXJzdCA9IHNsaWRlID09PSAwXHJcbiAgY29uc3Qgc2VsZWN0U2xpZGUgPSAoaW5kZXg6IG51bWJlcikgPT4geyBzZXRBbmltYXRlZCh0cnVlKTsgc2V0U2xpZGUoaW5kZXgpIH1cclxuICBjb25zdCBoZWFkaW5nID0gPD48c3BhbiBjbGFzc05hbWU9XCJkZXNrdG9wLXRpdGxlXCI+U0VKQSBET05PIERPIEZVVFVSTzxiciAvPkRBIEFSVEUgRElHSVRBTDwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJtb2JpbGUtdGl0bGVcIj5TRUpBIERPTk8gREE8YnIgLz5DVUxUVVJBIERJR0lUQUw8L3NwYW4+PC8+XHJcbiAgY29uc3QgaW50cm8gPSA8PjxzcGFuIGNsYXNzTmFtZT1cImRlc2t0b3AtdGl0bGVcIj5EZXNjdWJyYSBORlRzIGRlIGNyaWFkb3JlcyBlbWVyZ2VudGVzIGUgY29uc2FncmFkb3MuIENvbGVjaW9uZSBhcnRlIGRpZ2l0YWwgcmFyYSwgYXBvaWUgYXJ0aXN0YXMgZSB0ZW5oYSB1bWEgcGFydGUgZGEgY3VsdHVyYSBkYSBpbnRlcm5ldC48L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwibW9iaWxlLXRpdGxlXCI+RGVzY3VicmEgTkZUcyBzZWxlY2lvbmFkb3MgZGUgY3JpYWRvcmVzIGRvIG11bmRvIHRvZG8uPC9zcGFuPjwvPlxyXG4gIGNvbnN0IGNvbnRlbnQgPSBmaXJzdCA/IGhlYWRpbmcgOiA8PjxzcGFuIGNsYXNzTmFtZT1cImRlc2t0b3AtdGl0bGVcIj57bmZ0Py5uYW1lfTxiciAvPkFSVEUgRU0gREVTVEFRVUU8L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwibW9iaWxlLXRpdGxlXCI+e25mdD8ubmFtZS5zcGxpdCgnICMnKVswXX08YnIgLz4je25mdD8ubmFtZS5zcGxpdCgnICMnKVsxXX08L3NwYW4+PC8+XHJcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cImhvbWUtaGVyb1wiIGFyaWEtbGFiZWw9XCJEZXN0YXF1ZXMgZGUgTkZUc1wiIG9uUG9pbnRlckRvd249e2V2ZW50ID0+IHtcclxuICAgIGlmIChldmVudC50YXJnZXQgaW5zdGFuY2VvZiBFbGVtZW50ICYmIGV2ZW50LnRhcmdldC5jbG9zZXN0KCdidXR0b24nKSkgcmV0dXJuXHJcbiAgICBnZXN0dXJlLmN1cnJlbnQgPSB7IHg6ZXZlbnQuY2xpZW50WCwgeTpldmVudC5jbGllbnRZIH07IHN3aXBlZC5jdXJyZW50ID0gZmFsc2VcclxuICB9fSBvblBvaW50ZXJDYW5jZWw9eygpID0+IHsgZ2VzdHVyZS5jdXJyZW50ID0gbnVsbCB9fSBvblBvaW50ZXJVcD17ZXZlbnQgPT4ge1xyXG4gICAgaWYgKCFnZXN0dXJlLmN1cnJlbnQgfHwgIWZlYXR1cmVkPy5sZW5ndGgpIHJldHVyblxyXG4gICAgY29uc3QgZHggPSBldmVudC5jbGllbnRYLWdlc3R1cmUuY3VycmVudC54LCBkeSA9IGV2ZW50LmNsaWVudFktZ2VzdHVyZS5jdXJyZW50LnlcclxuICAgIGdlc3R1cmUuY3VycmVudCA9IG51bGxcclxuICAgIGlmIChNYXRoLmFicyhkeCkgPiA0MCAmJiBNYXRoLmFicyhkeCkgPiBNYXRoLmFicyhkeSkqMS40KSB7IHN3aXBlZC5jdXJyZW50ID0gdHJ1ZTsgc2VsZWN0U2xpZGUoKHNsaWRlICsgKGR4IDwgMCA/IDEgOiAyKSkgJSAzKSB9XHJcbiAgfX0gb25DbGlja0NhcHR1cmU9e2V2ZW50ID0+IHsgaWYgKHN3aXBlZC5jdXJyZW50ICYmIGV2ZW50LmRldGFpbCA+IDAgJiYgZXZlbnQudGFyZ2V0IGluc3RhbmNlb2YgRWxlbWVudCAmJiBldmVudC50YXJnZXQuY2xvc2VzdCgnLmhlcm8tYXJ0IGEnKSkgeyBldmVudC5wcmV2ZW50RGVmYXVsdCgpOyBldmVudC5zdG9wUHJvcGFnYXRpb24oKSB9IHN3aXBlZC5jdXJyZW50ID0gZmFsc2UgfX0+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tY29weVwiPjxwPkJlbS12aW5kbyDDoCBLdXJpbzwvcD48aDE+PHNwYW4gY2xhc3NOYW1lPVwiaGVyby1zaXppbmdcIiBhcmlhLWhpZGRlbj1cInRydWVcIj57aGVhZGluZ308L3NwYW4+PHNwYW4gY2xhc3NOYW1lPVwiaGVyby1zbGlkZS1jb3B5XCI+e2NvbnRlbnR9PC9zcGFuPjwvaDE+PHAgY2xhc3NOYW1lPVwiaGVyby1kZXNjcmlwdGlvblwiPjxzcGFuIGNsYXNzTmFtZT1cImhlcm8tc2l6aW5nXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCI+e2ludHJvfTwvc3Bhbj48c3BhbiBjbGFzc05hbWU9XCJoZXJvLXNsaWRlLWNvcHlcIj57Zmlyc3QgPyBpbnRybyA6IDw+Q29sZWNpb25lIHtuZnQ/Lm5hbWV9LjwvPn08L3NwYW4+PC9wPntuZnQgPyA8TGluayBjbGFzc05hbWU9XCJoZXJvLWN0YVwiIGFyaWEtbGFiZWw9e2BFeHBsb3JhciAke25mdC5uYW1lfWB9IHRvPVwiL25mdHMvJG5mdElkXCIgc3RhdGU9e3sgY2F0YWxvZ1NlYXJjaDpzZWFyY2ggfX0gc2VhcmNoPXt7IGVkaXRpb246J2ZpZnR5JyxxdWFudGl0eToxIH19IHBhcmFtcz17eyBuZnRJZDpuZnQuaWQgfX0+RVhQTE9SQVIgPHNwYW4gY2xhc3NOYW1lPVwibW9iaWxlLXRpdGxlXCI+4oaSPC9zcGFuPjwvTGluaz4gOiA8c3BhbiBjbGFzc05hbWU9XCJoZXJvLWN0YVwiIGFyaWEtZGlzYWJsZWQ9XCJ0cnVlXCI+RVhQTE9SQVIgPHNwYW4gY2xhc3NOYW1lPVwibW9iaWxlLXRpdGxlXCI+4oaSPC9zcGFuPjwvc3Bhbj59PC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImhlcm8tYXJ0XCI+e25mdCA/IDxMaW5rIGtleT17bmZ0LmlkfSBjbGFzc05hbWU9e2FuaW1hdGVkID8gJ2hlcm8tY2hhbmdpbmcnIDogdW5kZWZpbmVkfSB0bz1cIi9uZnRzLyRuZnRJZFwiIHN0YXRlPXt7IGNhdGFsb2dTZWFyY2g6c2VhcmNoIH19IHNlYXJjaD17eyBlZGl0aW9uOidmaWZ0eScscXVhbnRpdHk6MSB9fSBwYXJhbXM9e3sgbmZ0SWQ6bmZ0LmlkIH19PjxpbWcgc3JjPXtuZnQuaW1hZ2V9IHNyY1NldD17YCR7bmZ0LmltYWdlLnJlcGxhY2UoJy05MDAud2VicCcsJy00NTAud2VicCcpfSA0NTB3LCAke25mdC5pbWFnZX0gOTAwd2B9IHNpemVzPVwiKG1heC13aWR0aDo2MzlweCkgMTM4cHgsIDQ1MHB4XCIgYWx0PXtuZnQubmFtZX0gd2lkdGg9XCI0NTBcIiBoZWlnaHQ9XCI0NTBcIiBmZXRjaFByaW9yaXR5PXtmaXJzdCA/ICdoaWdoJyA6ICdhdXRvJ30gLz48L0xpbms+IDogPGRpdiBjbGFzc05hbWU9XCJoZXJvLWFydC1wbGFjZWhvbGRlclwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+fXttaW5pICYmIDxpbWcgY2xhc3NOYW1lPVwiaGVyby1taW5pXCIgc3JjPXttaW5pLmltYWdlLnJlcGxhY2UoJy05MDAud2VicCcsJy00NTAud2VicCcpfSBhbHQ9e21pbmkubmFtZX0gd2lkdGg9XCI1OFwiIGhlaWdodD1cIjU4XCIgLz59PC9kaXY+XHJcbiAgICB7ZmVhdHVyZWQ/Lmxlbmd0aCA9PT0gMyAmJiA8Q2Fyb3VzZWxJbmRpY2F0b3JzIGNsYXNzTmFtZT1cImhlcm8tZG90c1wiIGxhYmVsPVwiRXNjb2xoZXIgZGVzdGFxdWVcIiBsYWJlbHM9e2ZlYXR1cmVkLm1hcCgoaXRlbSxpbmRleCkgPT4gYERlc3RhcXVlICR7aW5kZXggKyAxfTogJHtpdGVtLm5hbWV9YCl9IGFjdGl2ZT17c2xpZGV9IG9uQ2hhbmdlPXtzZWxlY3RTbGlkZX0gLz59XHJcbiAgPC9zZWN0aW9uPlxyXG59XHJcbmV4cG9ydCBmdW5jdGlvbiBIb21lU2VjdGlvbnMoKSB7XHJcbiAgY29uc3QgdW5hdmFpbGFibGUgPSB1c2VVbmF2YWlsYWJsZSgpXHJcbiAgY29uc3QgcG9zdHMgPSBbWyc5YWRkMi05MDAud2VicCcsICdDb21vIGZ1bmNpb25hIGEgcHJvcHJpZWRhZGUgZGUgTkZUcycsICdBcHJlbmRhIGEgY29sZWNpb25hciwgbmVnb2NpYXIgZSB2ZXJpZmljYXIgYXRpdm9zIGRpZ2l0YWlzLiddLCBbJzhmMzg3LTkwMC53ZWJwJywgJzEwIGFydGlzdGFzIGRpZ2l0YWlzIHBhcmEgYWNvbXBhbmhhcicsICdDb25oZcOnYSBjcmlhZG9yZXMgcXVlIG1vbGRhbSBhIGN1bHR1cmEgZGlnaXRhbC4nXSwgWyc4Mzc5NC05MDAud2VicCcsICdSYXJpZGFkZSwgYXRyaWJ1dG9zIGUgcHJvY2Vkw6puY2lhJywgJ0VudGVuZGEgcmFyaWRhZGUsIHByb2NlZMOqbmNpYSwgZGlyZWl0b3MgYXV0b3JhaXMgZSB1dGlsaWRhZGUuJ10sIFsnYjdjZmMtOTAwLndlYnAnLCAnQ29tbyBwcm90ZWdlciBzdWEgY2FydGVpcmEnLCAnUHJvdGVqYSBzdWEgY2FydGVpcmEsIHNldXMgTkZUcyBlIHN1YSBpZGVudGlkYWRlLiddXVxyXG4gIHJldHVybiA8PjxzZWN0aW9uIGNsYXNzTmFtZT1cInByb21vc1wiPntbWyc4ZjM4Ny05MDAud2VicCcsICdMYW7Dp2FtZW50b3MgZ8OqbmVzaXMgZGUgZWRpw6fDo28gbGltaXRhZGEnLCAnQ29sZWNpb25lIGVkacOnw7VlcyBlc2Nhc3NhcyBkaXJldGFtZW50ZSBkb3MgY3JpYWRvcmVzIGFudGVzIGRhIHJldmVsYcOnw6NvIHDDumJsaWNhLiddLCBbJzlhZGQyLTkwMC53ZWJwJywgJ0FydGUgZGlnaXRhbCBzZWxlY2lvbmFkYSBlIG11aXRvIG1haXMnLCAnRXhwbG9yZSBub3ZvcyBhcnRpc3RhcywgY29sZcOnw7VlcyB2ZXJpZmljYWRhcyBlIG9icmFzIGRpZ2l0YWlzIHF1ZSBkZWZpbmVtIGEgY3VsdHVyYS4nXV0ubWFwKChbaW1hZ2UsIHRpdGxlLCB0ZXh0XSkgPT4gPGFydGljbGUga2V5PXtpbWFnZX0+PGltZyBzcmM9e2AvYXNzZXRzL29wdGltaXplZC8ke2ltYWdlfWB9IGFsdD1cIlwiIHdpZHRoPVwiMjkyXCIgaGVpZ2h0PVwiMjUwXCIgbG9hZGluZz1cImxhenlcIiAvPjxkaXY+PGgyPnt0aXRsZX08L2gyPjxwPnt0ZXh0fTwvcD48Q2F0YWxvZ0xpbms+RXhwbG9yYXIg4oaSPC9DYXRhbG9nTGluaz48L2Rpdj48L2FydGljbGU+KX08L3NlY3Rpb24+PHNlY3Rpb24gY2xhc3NOYW1lPVwiYmxvZ1wiPjxoMj5EacOhcmlvIGRhIEN1bmhhZ2VtPC9oMj48cD5IaXN0w7NyaWFzLCBndWlhcyBlIGluc2lnaHRzIHBhcmEgY29sZWNpb25hZG9yZXMgc29icmUgbyB1bml2ZXJzbyBkYSBwcm9wcmllZGFkZSBkaWdpdGFsLjwvcD48ZGl2IGNsYXNzTmFtZT1cImJsb2ctY2FyZHNcIj57cG9zdHMubWFwKChbaW1hZ2UsIHRpdGxlLCB0ZXh0XSwgaSkgPT4gPGFydGljbGUga2V5PXtpbWFnZX0+PGltZyBzcmM9e2AvYXNzZXRzL29wdGltaXplZC8ke2ltYWdlfWB9IGFsdD1cIlwiIHdpZHRoPVwiMjY4XCIgaGVpZ2h0PVwiMTk1XCIgbG9hZGluZz1cImxhenlcIiAvPjxkaXY+PHA+ezEyICsgaX0gZGUgc2V0ZW1icm8gfCBMZWl0dXJhIGRlIHtpID09PSAwID8gNiA6IDJ9IG1pbjwvcD48aDM+e3RpdGxlfTwvaDM+PHA+e3RleHR9PC9wPjxidXR0b24gb25DbGljaz17KCkgPT4gdW5hdmFpbGFibGUoJ0NvbnRlw7pkbyBlZGl0b3JpYWwnKX0+TGVyIG1haXMg4oaSPC9idXR0b24+PC9kaXY+PC9hcnRpY2xlPil9PC9kaXY+PC9zZWN0aW9uPjwvPlxyXG59XHJcbiJdfQ==