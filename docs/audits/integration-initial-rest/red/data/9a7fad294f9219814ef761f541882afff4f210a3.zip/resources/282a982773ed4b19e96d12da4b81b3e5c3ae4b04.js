import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/Filters.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { Button } from "/src/shared/ui/button.tsx";
import { collections, networks } from "/src/features/catalog/contracts.ts";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/Filters.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function Filters({ search, facets, change }) {
	_s();
	const [min, setMin] = useState(search.minPrice), [max, setMax] = useState(search.maxPrice);
	const toggleCollection = (value) => change({ collections: search.collections.includes(value) ? search.collections.filter((c) => c !== value) : [...search.collections, value] });
	const toggleNetwork = (value) => change({ networks: search.networks.includes(value) ? search.networks.filter((n) => n !== value) : [...search.networks, value] });
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "filters-panel",
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				className: "mobile-sort",
				children: ["Ordenar NFTs", /* @__PURE__ */ _jsxDEV("select", {
					"aria-label": "Ordenar NFTs",
					value: search.sort,
					onChange: (e) => change({ sort: e.target.value }),
					children: [
						/* @__PURE__ */ _jsxDEV("option", {
							value: "recent",
							children: "Listados recentemente"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 10,
							columnNumber: 173
						}, this),
						/* @__PURE__ */ _jsxDEV("option", {
							value: "price-asc",
							children: "Menor preço"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 10,
							columnNumber: 226
						}, this),
						/* @__PURE__ */ _jsxDEV("option", {
							value: "price-desc",
							children: "Maior preço"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 10,
							columnNumber: 272
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 10,
					columnNumber: 48
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Coleções" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 15
			}, this), Object.entries(collections).map(([value, label]) => /* @__PURE__ */ _jsxDEV("label", {
				className: search.collections.includes(value) ? "selected" : "",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						checked: search.collections.includes(value),
						onChange: () => toggleCollection(value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 191
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 330
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: [
						"(",
						facets?.collections[value] ?? "—",
						")"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 11,
						columnNumber: 350
					}, this)
				]
			}, value, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 93
			}, this))] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Faixa de preço" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 15
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (e) => {
					e.preventDefault();
					change({
						minPrice: min,
						maxPrice: max
					});
				},
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "price-sliders",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "price-interval",
								style: {
									left: `${(Number(min) - .02) / 12.28 * 100}%`,
									right: `${(12.3 - Number(max)) / 12.28 * 100}%`
								}
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 12,
								columnNumber: 166
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								"aria-label": "Preço mínimo",
								type: "range",
								min: "0.02",
								max: "12.30",
								step: "0.01",
								value: min,
								onChange: (e) => setMin(String(Math.min(Number(e.target.value), Number(max))))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 12,
								columnNumber: 309
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								"aria-label": "Preço máximo",
								type: "range",
								min: "0.02",
								max: "12.30",
								step: "0.01",
								value: max,
								onChange: (e) => setMax(String(Math.max(Number(e.target.value), Number(min))))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 12,
								columnNumber: 484
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 135
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						"Preço: ",
						min,
						" – ",
						max,
						" ETH"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 665
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						size: "sm",
						children: "Aplicar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 12,
						columnNumber: 696
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 46
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("fieldset", { children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Rede" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 15
			}, this), networks.map((value) => /* @__PURE__ */ _jsxDEV("label", {
				className: search.networks.includes(value) ? "selected" : "",
				children: [
					/* @__PURE__ */ _jsxDEV("input", {
						type: "checkbox",
						checked: search.networks.includes(value),
						onChange: () => toggleNetwork(value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 142
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: value }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 247
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: [
						"(",
						facets?.networks[value] ?? "—",
						")"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 13,
						columnNumber: 267
					}, this)
				]
			}, value, true, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 61
			}, this))] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				className: "clear-filters",
				onClick: () => change({
					collections: [],
					networks: [],
					minPrice: "0.02",
					maxPrice: "12.30",
					q: "",
					tab: "all"
				}),
				children: "Limpar filtros"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 10
	}, this);
}
_s(Filters, "ulyQZxlC322DSHqWYuuPiGpSnQU=");
_c = Filters;
var _c;
$RefreshReg$(_c, "Filters");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/Filters.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/Filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/Filters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/Filters.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsYUFBYSxnQkFBeUY7Ozs7QUFFL0csT0FBTyxTQUFTLFFBQVEsRUFBRSxRQUFRLFFBQVEsVUFBMEg7O0NBQ2xLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsU0FBUyxPQUFPLFFBQVEsR0FBRyxDQUFDLEtBQUssVUFBVSxTQUFTLE9BQU8sUUFBUTtDQUN6RixNQUFNLG9CQUFvQixVQUFzQixPQUFPLEVBQUUsYUFBYSxPQUFPLFlBQVksU0FBUyxLQUFLLElBQUksT0FBTyxZQUFZLFFBQVEsTUFBTSxNQUFNLEtBQUssSUFBSSxDQUFDLEdBQUcsT0FBTyxhQUFhLEtBQUssRUFBRSxDQUFDO0NBQzNMLE1BQU0saUJBQWlCLFVBQW1CLE9BQU8sRUFBRSxVQUFVLE9BQU8sU0FBUyxTQUFTLEtBQUssSUFBSSxPQUFPLFNBQVMsUUFBUSxNQUFNLE1BQU0sS0FBSyxJQUFJLENBQUMsR0FBRyxPQUFPLFVBQVUsS0FBSyxFQUFFLENBQUM7Q0FDekssT0FBTyx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0wsd0JBQUMsU0FBRDtJQUFPLFdBQVU7Y0FBakIsQ0FBK0IsZ0JBQVksd0JBQUMsVUFBRDtLQUFRLGNBQVc7S0FBZSxPQUFPLE9BQU87S0FBTSxXQUFVLE1BQUssT0FBTyxFQUFDLE1BQUssRUFBRSxPQUFPLE1BQThCLENBQUM7ZUFBMUg7TUFBNkgsd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQVM7TUFBNkI7Ozs7O01BQUMsd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQVk7TUFBbUI7Ozs7O01BQUMsd0JBQUMsVUFBRDtPQUFRLE9BQU07aUJBQWE7TUFBbUI7Ozs7O0tBQVM7Ozs7O1lBQVE7Ozs7OztHQUMxVSx3QkFBQyxZQUFELGFBQVUsd0JBQUMsVUFBRCxZQUFRLFdBQWdCOzs7O2FBQUUsT0FBTyxRQUFRLFdBQVcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLFdBQVcsd0JBQUMsU0FBRDtJQUFPLFdBQVcsT0FBTyxZQUFZLFNBQVMsS0FBbUIsSUFBSSxhQUFhO2NBQWxGO0tBQWtHLHdCQUFDLFNBQUQ7TUFBTyxNQUFLO01BQVcsU0FBUyxPQUFPLFlBQVksU0FBUyxLQUFtQjtNQUFHLGdCQUFnQixpQkFBaUIsS0FBbUI7S0FBSTs7Ozs7S0FBQyx3QkFBQyxRQUFELFlBQU8sTUFBWTs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQU07TUFBRSxRQUFRLFlBQVksVUFBd0I7TUFBSTtLQUFPOzs7OztJQUFRO01BQTdPOzs7O1VBQTZPLENBQUMsQ0FBWTs7Ozs7R0FDN2Esd0JBQUMsWUFBRCxhQUFVLHdCQUFDLFVBQUQsWUFBUSxpQkFBc0I7Ozs7YUFBQyx3QkFBQyxRQUFEO0lBQU0sV0FBVyxNQUFNO0tBQUUsRUFBRSxlQUFlO0tBQUcsT0FBTztNQUFFLFVBQVU7TUFBSyxVQUFVO0tBQUksQ0FBQztJQUFFO2NBQXRGO0tBQXlGLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQStCLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO1FBQWlCLE9BQU87U0FBRSxNQUFNLElBQUksT0FBTyxHQUFHLElBQUksT0FBTyxRQUFRLElBQUk7U0FBSSxPQUFPLElBQUksT0FBUSxPQUFPLEdBQUcsS0FBSyxRQUFRLElBQUk7UUFBRztPQUFJOzs7OztPQUFDLHdCQUFDLFNBQUQ7UUFBTyxjQUFXO1FBQWUsTUFBSztRQUFRLEtBQUk7UUFBTyxLQUFJO1FBQVEsTUFBSztRQUFPLE9BQU87UUFBSyxXQUFXLE1BQU0sT0FBTyxPQUFPLEtBQUssSUFBSSxPQUFPLEVBQUUsT0FBTyxLQUFLLEdBQUcsT0FBTyxHQUFHLENBQUMsQ0FBQyxDQUFDO09BQUk7Ozs7O09BQUMsd0JBQUMsU0FBRDtRQUFPLGNBQVc7UUFBZSxNQUFLO1FBQVEsS0FBSTtRQUFPLEtBQUk7UUFBUSxNQUFLO1FBQU8sT0FBTztRQUFLLFdBQVcsTUFBTSxPQUFPLE9BQU8sS0FBSyxJQUFJLE9BQU8sRUFBRSxPQUFPLEtBQUssR0FBRyxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUM7T0FBSTs7Ozs7TUFBTTs7Ozs7O0tBQUMsd0JBQUMsS0FBRDtNQUFHO01BQVE7TUFBSTtNQUFJO01BQUk7S0FBTzs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQVEsTUFBSztnQkFBSztLQUFlOzs7OztJQUFPOzs7OztXQUFXOzs7OztHQUN0dUIsd0JBQUMsWUFBRCxhQUFVLHdCQUFDLFVBQUQsWUFBUSxPQUFZOzs7O2FBQUUsU0FBUyxLQUFLLFVBQVUsd0JBQUMsU0FBRDtJQUFtQixXQUFXLE9BQU8sU0FBUyxTQUFTLEtBQUssSUFBSSxhQUFhO2NBQTdFO0tBQWlGLHdCQUFDLFNBQUQ7TUFBTyxNQUFLO01BQVcsU0FBUyxPQUFPLFNBQVMsU0FBUyxLQUFLO01BQUcsZ0JBQWdCLGNBQWMsS0FBSztLQUFJOzs7OztLQUFDLHdCQUFDLFFBQUQsWUFBTyxNQUFZOzs7OztLQUFDLHdCQUFDLFFBQUQ7TUFBTTtNQUFFLFFBQVEsU0FBUyxVQUFVO01BQUk7S0FBTzs7Ozs7SUFBUTtNQUF4UDs7OztVQUF3UCxDQUFDLENBQVk7Ozs7O0dBQ3pVLHdCQUFDLFVBQUQ7SUFBUSxXQUFVO0lBQWdCLGVBQWUsT0FBTztLQUFFLGFBQWEsQ0FBQztLQUFHLFVBQVUsQ0FBQztLQUFHLFVBQVU7S0FBUSxVQUFVO0tBQVMsR0FBRztLQUFJLEtBQUs7SUFBTSxDQUFDO2NBQUc7R0FBc0I7Ozs7O0VBQ3ZLOzs7Ozs7QUFDUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGaWx0ZXJzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL3NoYXJlZC91aS9idXR0b24nXHJcbmltcG9ydCB7IGNvbGxlY3Rpb25zLCBuZXR3b3JrcywgdHlwZSBDYXRhbG9nU2VhcmNoLCB0eXBlIENhdGFsb2dSZXNwb25zZSwgdHlwZSBDb2xsZWN0aW9uLCB0eXBlIE5ldHdvcmsgfSBmcm9tICcuL2NvbnRyYWN0cydcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBGaWx0ZXJzKHsgc2VhcmNoLCBmYWNldHMsIGNoYW5nZSB9OiB7IHNlYXJjaDogQ2F0YWxvZ1NlYXJjaDsgZmFjZXRzPzogQ2F0YWxvZ1Jlc3BvbnNlWydmYWNldHMnXTsgY2hhbmdlOiAocGF0Y2g6IFBhcnRpYWw8Q2F0YWxvZ1NlYXJjaD4pID0+IHZvaWQgfSkge1xyXG4gIGNvbnN0IFttaW4sIHNldE1pbl0gPSB1c2VTdGF0ZShzZWFyY2gubWluUHJpY2UpLCBbbWF4LCBzZXRNYXhdID0gdXNlU3RhdGUoc2VhcmNoLm1heFByaWNlKVxyXG4gIGNvbnN0IHRvZ2dsZUNvbGxlY3Rpb24gPSAodmFsdWU6IENvbGxlY3Rpb24pID0+IGNoYW5nZSh7IGNvbGxlY3Rpb25zOiBzZWFyY2guY29sbGVjdGlvbnMuaW5jbHVkZXModmFsdWUpID8gc2VhcmNoLmNvbGxlY3Rpb25zLmZpbHRlcigoYykgPT4gYyAhPT0gdmFsdWUpIDogWy4uLnNlYXJjaC5jb2xsZWN0aW9ucywgdmFsdWVdIH0pXHJcbiAgY29uc3QgdG9nZ2xlTmV0d29yayA9ICh2YWx1ZTogTmV0d29yaykgPT4gY2hhbmdlKHsgbmV0d29ya3M6IHNlYXJjaC5uZXR3b3Jrcy5pbmNsdWRlcyh2YWx1ZSkgPyBzZWFyY2gubmV0d29ya3MuZmlsdGVyKChuKSA9PiBuICE9PSB2YWx1ZSkgOiBbLi4uc2VhcmNoLm5ldHdvcmtzLCB2YWx1ZV0gfSlcclxuICByZXR1cm4gPGRpdiBjbGFzc05hbWU9XCJmaWx0ZXJzLXBhbmVsXCI+XHJcbiAgICA8bGFiZWwgY2xhc3NOYW1lPVwibW9iaWxlLXNvcnRcIj5PcmRlbmFyIE5GVHM8c2VsZWN0IGFyaWEtbGFiZWw9XCJPcmRlbmFyIE5GVHNcIiB2YWx1ZT17c2VhcmNoLnNvcnR9IG9uQ2hhbmdlPXtlID0+IGNoYW5nZSh7c29ydDplLnRhcmdldC52YWx1ZSBhcyBDYXRhbG9nU2VhcmNoWydzb3J0J119KX0+PG9wdGlvbiB2YWx1ZT1cInJlY2VudFwiPkxpc3RhZG9zIHJlY2VudGVtZW50ZTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJwcmljZS1hc2NcIj5NZW5vciBwcmXDp288L29wdGlvbj48b3B0aW9uIHZhbHVlPVwicHJpY2UtZGVzY1wiPk1haW9yIHByZcOnbzwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+XHJcbiAgICA8ZmllbGRzZXQ+PGxlZ2VuZD5Db2xlw6fDtWVzPC9sZWdlbmQ+e09iamVjdC5lbnRyaWVzKGNvbGxlY3Rpb25zKS5tYXAoKFt2YWx1ZSwgbGFiZWxdKSA9PiA8bGFiZWwgY2xhc3NOYW1lPXtzZWFyY2guY29sbGVjdGlvbnMuaW5jbHVkZXModmFsdWUgYXMgQ29sbGVjdGlvbikgPyAnc2VsZWN0ZWQnIDogJyd9IGtleT17dmFsdWV9PjxpbnB1dCB0eXBlPVwiY2hlY2tib3hcIiBjaGVja2VkPXtzZWFyY2guY29sbGVjdGlvbnMuaW5jbHVkZXModmFsdWUgYXMgQ29sbGVjdGlvbil9IG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGVDb2xsZWN0aW9uKHZhbHVlIGFzIENvbGxlY3Rpb24pfSAvPjxzcGFuPntsYWJlbH08L3NwYW4+PHNwYW4+KHtmYWNldHM/LmNvbGxlY3Rpb25zW3ZhbHVlIGFzIENvbGxlY3Rpb25dID8/ICfigJQnfSk8L3NwYW4+PC9sYWJlbD4pfTwvZmllbGRzZXQ+XHJcbiAgICA8ZmllbGRzZXQ+PGxlZ2VuZD5GYWl4YSBkZSBwcmXDp288L2xlZ2VuZD48Zm9ybSBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBjaGFuZ2UoeyBtaW5QcmljZTogbWluLCBtYXhQcmljZTogbWF4IH0pIH19PjxkaXYgY2xhc3NOYW1lPVwicHJpY2Utc2xpZGVyc1wiPjxzcGFuIGNsYXNzTmFtZT1cInByaWNlLWludGVydmFsXCIgc3R5bGU9e3sgbGVmdDogYCR7KE51bWJlcihtaW4pIC0gLjAyKSAvIDEyLjI4ICogMTAwfSVgLCByaWdodDogYCR7KDEyLjMwIC0gTnVtYmVyKG1heCkpIC8gMTIuMjggKiAxMDB9JWAgfX0gLz48aW5wdXQgYXJpYS1sYWJlbD1cIlByZcOnbyBtw61uaW1vXCIgdHlwZT1cInJhbmdlXCIgbWluPVwiMC4wMlwiIG1heD1cIjEyLjMwXCIgc3RlcD1cIjAuMDFcIiB2YWx1ZT17bWlufSBvbkNoYW5nZT17KGUpID0+IHNldE1pbihTdHJpbmcoTWF0aC5taW4oTnVtYmVyKGUudGFyZ2V0LnZhbHVlKSwgTnVtYmVyKG1heCkpKSl9IC8+PGlucHV0IGFyaWEtbGFiZWw9XCJQcmXDp28gbcOheGltb1wiIHR5cGU9XCJyYW5nZVwiIG1pbj1cIjAuMDJcIiBtYXg9XCIxMi4zMFwiIHN0ZXA9XCIwLjAxXCIgdmFsdWU9e21heH0gb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXgoU3RyaW5nKE1hdGgubWF4KE51bWJlcihlLnRhcmdldC52YWx1ZSksIE51bWJlcihtaW4pKSkpfSAvPjwvZGl2PjxwPlByZcOnbzoge21pbn0g4oCTIHttYXh9IEVUSDwvcD48QnV0dG9uIHNpemU9XCJzbVwiPkFwbGljYXI8L0J1dHRvbj48L2Zvcm0+PC9maWVsZHNldD5cclxuICAgIDxmaWVsZHNldD48bGVnZW5kPlJlZGU8L2xlZ2VuZD57bmV0d29ya3MubWFwKCh2YWx1ZSkgPT4gPGxhYmVsIGtleT17dmFsdWV9IGNsYXNzTmFtZT17c2VhcmNoLm5ldHdvcmtzLmluY2x1ZGVzKHZhbHVlKSA/ICdzZWxlY3RlZCcgOiAnJ30+PGlucHV0IHR5cGU9XCJjaGVja2JveFwiIGNoZWNrZWQ9e3NlYXJjaC5uZXR3b3Jrcy5pbmNsdWRlcyh2YWx1ZSl9IG9uQ2hhbmdlPXsoKSA9PiB0b2dnbGVOZXR3b3JrKHZhbHVlKX0gLz48c3Bhbj57dmFsdWV9PC9zcGFuPjxzcGFuPih7ZmFjZXRzPy5uZXR3b3Jrc1t2YWx1ZV0gPz8gJ+KAlCd9KTwvc3Bhbj48L2xhYmVsPil9PC9maWVsZHNldD5cclxuICAgIDxidXR0b24gY2xhc3NOYW1lPVwiY2xlYXItZmlsdGVyc1wiIG9uQ2xpY2s9eygpID0+IGNoYW5nZSh7IGNvbGxlY3Rpb25zOiBbXSwgbmV0d29ya3M6IFtdLCBtaW5QcmljZTogJzAuMDInLCBtYXhQcmljZTogJzEyLjMwJywgcTogJycsIHRhYjogJ2FsbCcgfSl9PkxpbXBhciBmaWx0cm9zPC9idXR0b24+XHJcbiAgPC9kaXY+XHJcbn1cclxuIl19