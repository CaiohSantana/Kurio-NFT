import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/NftCard.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { FavoriteButton } from "/src/features/favorites/FavoriteButton.tsx";
import { useCatalogDestination } from "/src/features/catalog/CatalogLink.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/NftCard.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function NftCard({ nft }) {
	_s();
	const search = useCatalogDestination();
	return /* @__PURE__ */ _jsxDEV("article", {
		className: "nft-card",
		"data-testid": `nft-${nft.id}`,
		"data-version": nft.version,
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "card-art",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/nfts/$nftId",
						state: { catalogSearch: search },
						search: {
							edition: "fifty",
							quantity: 1
						},
						params: { nftId: nft.id },
						"aria-label": `Ver ${nft.name}`,
						children: /* @__PURE__ */ _jsxDEV("img", {
							src: nft.image,
							srcSet: `${nft.image.replace("-900.webp", "-450.webp")} 450w, ${nft.image} 900w`,
							sizes: "(max-width:639px) 50vw, 250px",
							alt: nft.name,
							width: "250",
							height: "250",
							loading: "lazy"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 8,
							columnNumber: 190
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 8,
						columnNumber: 31
					}, this),
					nft.rare && /* @__PURE__ */ _jsxDEV("span", {
						className: "rare-badge",
						children: "RARO"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 8,
						columnNumber: 408
					}, this),
					/* @__PURE__ */ _jsxDEV(FavoriteButton, {
						id: nft.id,
						name: nft.name,
						className: "card-favorite"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 8,
						columnNumber: 449
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV(Link, {
				className: "card-name",
				to: "/nfts/$nftId",
				state: { catalogSearch: search },
				search: {
					edition: "fifty",
					quantity: 1
				},
				params: { nftId: nft.id },
				children: nft.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "card-price",
				children: [
					nft.priceEth,
					" ETH ",
					nft.previousPrice && /* @__PURE__ */ _jsxDEV("del", { children: [nft.previousPrice, " ETH"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 9,
						columnNumber: 239
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 172
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 10
	}, this);
}
_s(NftCard, "ldeMrkzbKEPybsQIbGFaiqAiHGw=", false, function() {
	return [useCatalogDestination];
});
_c = NftCard;
var _c;
$RefreshReg$(_c, "NftCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/NftCard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/NftCard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/NftCard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/NftCard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxZQUFZO0FBRXJCLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsNkJBQTZCOzs7O0FBQ3RDLE9BQU8sU0FBUyxRQUFRLEVBQUUsT0FBcUI7O0NBQzdDLE1BQU0sU0FBUyxzQkFBc0I7Q0FDckMsT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtFQUFXLGVBQWEsT0FBTyxJQUFJO0VBQU0sZ0JBQWMsSUFBSTtZQUE5RTtHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FBMEIsd0JBQUMsTUFBRDtNQUFNLElBQUc7TUFBZSxPQUFPLEVBQUUsZUFBZSxPQUFPO01BQUcsUUFBUTtPQUFFLFNBQVM7T0FBUyxVQUFVO01BQUU7TUFBRyxRQUFRLEVBQUUsT0FBTyxJQUFJLEdBQUc7TUFBRyxjQUFZLE9BQU8sSUFBSTtnQkFBUSx3QkFBQyxPQUFEO09BQUssS0FBSyxJQUFJO09BQU8sUUFBUSxHQUFHLElBQUksTUFBTSxRQUFRLGFBQWEsV0FBVyxFQUFFLFNBQVMsSUFBSSxNQUFNO09BQVEsT0FBTTtPQUFnQyxLQUFLLElBQUk7T0FBTSxPQUFNO09BQU0sUUFBTztPQUFNLFNBQVE7TUFBUTs7Ozs7S0FBTzs7Ozs7S0FBRSxJQUFJLFFBQVEsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQWE7S0FBVTs7Ozs7S0FBRSx3QkFBQyxnQkFBRDtNQUFnQixJQUFJLElBQUk7TUFBSSxNQUFNLElBQUk7TUFBTSxXQUFVO0tBQWlCOzs7OztJQUFNOzs7Ozs7R0FDemdCLHdCQUFDLE1BQUQ7SUFBTSxXQUFVO0lBQVksSUFBRztJQUFlLE9BQU8sRUFBRSxlQUFlLE9BQU87SUFBRyxRQUFRO0tBQUUsU0FBUztLQUFTLFVBQVU7SUFBRTtJQUFHLFFBQVEsRUFBRSxPQUFPLElBQUksR0FBRztjQUFJLElBQUk7R0FBVzs7Ozs7R0FBQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiO0tBQTJCLElBQUk7S0FBUztLQUFNLElBQUksaUJBQWlCLHdCQUFDLE9BQUQsYUFBTSxJQUFJLGVBQWMsTUFBUzs7Ozs7SUFBSzs7Ozs7O0VBQ3pROzs7Ozs7QUFDWCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJOZnRDYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBMaW5rIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcclxuaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICcuL2NvbnRyYWN0cydcclxuaW1wb3J0IHsgRmF2b3JpdGVCdXR0b24gfSBmcm9tICdAL2ZlYXR1cmVzL2Zhdm9yaXRlcy9GYXZvcml0ZUJ1dHRvbidcclxuaW1wb3J0IHsgdXNlQ2F0YWxvZ0Rlc3RpbmF0aW9uIH0gZnJvbSAnLi9DYXRhbG9nTGluaydcclxuZXhwb3J0IGZ1bmN0aW9uIE5mdENhcmQoeyBuZnQgfTogeyBuZnQ6IE5mdCB9KSB7XHJcbiAgY29uc3Qgc2VhcmNoID0gdXNlQ2F0YWxvZ0Rlc3RpbmF0aW9uKClcclxuICByZXR1cm4gPGFydGljbGUgY2xhc3NOYW1lPVwibmZ0LWNhcmRcIiBkYXRhLXRlc3RpZD17YG5mdC0ke25mdC5pZH1gfSBkYXRhLXZlcnNpb249e25mdC52ZXJzaW9ufT5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY2FyZC1hcnRcIj48TGluayB0bz1cIi9uZnRzLyRuZnRJZFwiIHN0YXRlPXt7IGNhdGFsb2dTZWFyY2g6IHNlYXJjaCB9fSBzZWFyY2g9e3sgZWRpdGlvbjogJ2ZpZnR5JywgcXVhbnRpdHk6IDEgfX0gcGFyYW1zPXt7IG5mdElkOiBuZnQuaWQgfX0gYXJpYS1sYWJlbD17YFZlciAke25mdC5uYW1lfWB9PjxpbWcgc3JjPXtuZnQuaW1hZ2V9IHNyY1NldD17YCR7bmZ0LmltYWdlLnJlcGxhY2UoXCItOTAwLndlYnBcIiwgXCItNDUwLndlYnBcIil9IDQ1MHcsICR7bmZ0LmltYWdlfSA5MDB3YH0gc2l6ZXM9XCIobWF4LXdpZHRoOjYzOXB4KSA1MHZ3LCAyNTBweFwiIGFsdD17bmZ0Lm5hbWV9IHdpZHRoPVwiMjUwXCIgaGVpZ2h0PVwiMjUwXCIgbG9hZGluZz1cImxhenlcIiAvPjwvTGluaz57bmZ0LnJhcmUgJiYgPHNwYW4gY2xhc3NOYW1lPVwicmFyZS1iYWRnZVwiPlJBUk88L3NwYW4+fTxGYXZvcml0ZUJ1dHRvbiBpZD17bmZ0LmlkfSBuYW1lPXtuZnQubmFtZX0gY2xhc3NOYW1lPVwiY2FyZC1mYXZvcml0ZVwiIC8+PC9kaXY+XHJcbiAgICA8TGluayBjbGFzc05hbWU9XCJjYXJkLW5hbWVcIiB0bz1cIi9uZnRzLyRuZnRJZFwiIHN0YXRlPXt7IGNhdGFsb2dTZWFyY2g6IHNlYXJjaCB9fSBzZWFyY2g9e3sgZWRpdGlvbjogJ2ZpZnR5JywgcXVhbnRpdHk6IDEgfX0gcGFyYW1zPXt7IG5mdElkOiBuZnQuaWQgfX0+e25mdC5uYW1lfTwvTGluaz48cCBjbGFzc05hbWU9XCJjYXJkLXByaWNlXCI+e25mdC5wcmljZUV0aH0gRVRIIHtuZnQucHJldmlvdXNQcmljZSAmJiA8ZGVsPntuZnQucHJldmlvdXNQcmljZX0gRVRIPC9kZWw+fTwvcD5cclxuICA8L2FydGljbGU+XHJcbn1cclxuIl19