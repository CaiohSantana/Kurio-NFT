import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/proof/IntegrationProof.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { useMutation, useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { Button } from "/src/shared/ui/button.tsx";
import { Skeleton } from "/src/shared/ui/skeleton.tsx";
import { getProofNft, nftKey, runScenario } from "/src/proof/api.ts";
import { useNftSocket } from "/src/proof/use-nft-socket.ts";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/proof/IntegrationProof.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function IntegrationProof() {
	_s();
	const [message, setMessage] = useState("Escolha um cenário para observar a integração.");
	const nftQuery = useQuery({
		queryKey: nftKey,
		queryFn: ({ signal }) => getProofNft(signal),
		staleTime: 3e4,
		retry: false,
		refetchOnWindowFocus: false,
		structuralSharing: (previous, next) => {
			const old = previous;
			const incoming = next;
			return old && old.nft.version > incoming.nft.version ? old : incoming;
		}
	});
	const socket = useNftSocket();
	const scenario = useMutation({
		mutationFn: runScenario,
		onSuccess: (result, action) => {
			if (action === "reset") window.location.reload();
			else setMessage(result.message);
		},
		onError: () => setMessage("Não foi possível executar o cenário.")
	});
	return /* @__PURE__ */ _jsxDEV("main", {
		className: "mx-auto flex max-w-4xl flex-col gap-6 p-6 sm:p-10",
		children: [
			/* @__PURE__ */ _jsxDEV("header", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/preparation",
						className: "text-sm text-primary underline",
						children: "Voltar à preparação"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm font-bold tracking-widest text-primary",
						children: "KURIO · PROVA TÉCNICA"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("h1", {
						className: "text-2xl font-bold sm:text-3xl",
						children: "REST + Socket.IO"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm leading-6 text-muted-foreground",
						children: "Base de integração separada do marketplace. Os controles abaixo atuam nos handlers dos mocks."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": "NFT consultado",
				className: "rounded-lg border border-border bg-card p-6",
				children: [
					nftQuery.isPending ? /* @__PURE__ */ _jsxDEV("div", {
						role: "status",
						className: "min-h-40 space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("p", { children: "Carregando NFT por REST…" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 39,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Skeleton, { className: "proof-skeleton h-8 w-3/4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV(Skeleton, { className: "proof-skeleton h-16 w-full" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 11
					}, this) : nftQuery.data ? /* @__PURE__ */ _jsxDEV("div", {
						className: "min-h-40 space-y-4",
						"aria-live": "polite",
						children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-bold",
							children: nftQuery.data.nft.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("dl", {
							className: "grid grid-cols-2 gap-3 text-sm",
							children: [
								/* @__PURE__ */ _jsxDEV("dt", { children: "Preço" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 47,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("dd", {
									"data-testid": "price",
									children: [nftQuery.data.nft.priceEth, " ETH"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 47,
									columnNumber: 29
								}, this),
								/* @__PURE__ */ _jsxDEV("dt", { children: "Disponíveis" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 48,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("dd", {
									"data-testid": "available",
									children: nftQuery.data.nft.available
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 48,
									columnNumber: 35
								}, this),
								/* @__PURE__ */ _jsxDEV("dt", { children: "Versão REST" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("dd", {
									"data-testid": "version",
									children: nftQuery.data.nft.version
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 35
								}, this),
								/* @__PURE__ */ _jsxDEV("dt", { children: "Consultas REST" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("dd", {
									"data-testid": "read-count",
									children: nftQuery.data.readCount
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 50,
									columnNumber: 38
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 11
					}, this) : null,
					nftQuery.isFetching && !nftQuery.isPending && /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						className: "mt-4 text-sm",
						children: "Sincronizando por REST…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 56
					}, this),
					nftQuery.isError && /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						className: "mt-4 text-sm text-destructive",
						children: "Falha na consulta REST. Use “Consultar REST” para tentar novamente."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 30
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": "Estado do transporte",
				className: "space-y-2 text-sm",
				"aria-live": "polite",
				children: [/* @__PURE__ */ _jsxDEV("p", { children: ["Socket.IO: ", /* @__PURE__ */ _jsxDEV("strong", {
					"data-testid": "connection",
					children: socket.status
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 23
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
					"Conexões: ",
					/* @__PURE__ */ _jsxDEV("span", {
						"data-testid": "connections",
						children: socket.connections
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 22
					}, this),
					" · Eventos recebidos: ",
					/* @__PURE__ */ _jsxDEV("span", {
						"data-testid": "received",
						children: socket.received
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 103
					}, this),
					" · Ignorados: ",
					/* @__PURE__ */ _jsxDEV("span", {
						"data-testid": "ignored",
						children: socket.ignored
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 170
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 59,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": "Controles de cenário",
				className: "flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ _jsxDEV(Button, {
						disabled: scenario.isPending,
						onClick: () => scenario.mutate("change"),
						children: "Alterar NFT"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						disabled: scenario.isPending,
						onClick: () => scenario.mutate("duplicate"),
						children: "Evento duplicado"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						disabled: scenario.isPending,
						onClick: () => scenario.mutate("old"),
						children: "Evento antigo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						disabled: scenario.isPending,
						onClick: () => scenario.mutate("disconnect"),
						children: "Interromper conexão"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						disabled: scenario.isPending,
						onClick: () => scenario.mutate("fail-next"),
						children: "Falhar próxima consulta"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						disabled: nftQuery.isFetching,
						onClick: () => void nftQuery.refetch(),
						children: "Consultar REST"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						variant: "outline",
						disabled: scenario.isPending,
						onClick: () => scenario.mutate("reset"),
						children: "Reiniciar cenário"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				className: "min-h-12 text-sm leading-6 text-muted-foreground",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-xs leading-5 text-muted-foreground",
				children: "WebSocket · namespace padrão · dados simulados. Os fluxos de compra e conta ainda não foram implementados."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 29,
		columnNumber: 5
	}, this);
}
_s(IntegrationProof, "5oLLEScL5qbPZMMb2/GX+67IDGI=", false, function() {
	return [
		useQuery,
		useNftSocket,
		useMutation
	];
});
_c = IntegrationProof;
var _c;
$RefreshReg$(_c, "IntegrationProof");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/proof/IntegrationProof.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/proof/IntegrationProof.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/proof/IntegrationProof.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/proof/IntegrationProof.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsYUFBYSxnQkFBZ0I7QUFDdEMsU0FBUyxjQUFjO0FBQ3ZCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsYUFBYSxRQUFRLG1CQUFtQjtBQUNqRCxTQUFTLG9CQUFvQjs7OztBQUU3QixPQUFPLFNBQVMsbUJBQW1COztDQUNqQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsZ0RBQWdEO0NBQ3ZGLE1BQU0sV0FBVyxTQUFTO0VBQUUsVUFBVTtFQUFRLFVBQVUsRUFBRSxhQUFhLFlBQVksTUFBTTtFQUN2RixXQUFXO0VBQU8sT0FBTztFQUFPLHNCQUFzQjtFQUN0RCxvQkFBb0IsVUFBVSxTQUFTO0dBQ3JDLE1BQU0sTUFBTTtHQUNaLE1BQU0sV0FBVztHQUNqQixPQUFPLE9BQU8sSUFBSSxJQUFJLFVBQVUsU0FBUyxJQUFJLFVBQVUsTUFBTTtFQUMvRDtDQUNGLENBQUM7Q0FDRCxNQUFNLFNBQVMsYUFBYTtDQUM1QixNQUFNLFdBQVcsWUFBWTtFQUFFLFlBQVk7RUFDekMsWUFBWSxRQUFRLFdBQVc7R0FDN0IsSUFBSSxXQUFXLFNBQVMsT0FBTyxTQUFTLE9BQU87UUFDMUMsV0FBVyxPQUFPLE9BQU87RUFDaEM7RUFDQSxlQUFlLFdBQVcsc0NBQXNDO0NBQ2xFLENBQUM7Q0FFRCxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCO0dBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEI7S0FDRSx3QkFBQyxNQUFEO01BQU0sSUFBRztNQUFlLFdBQVU7Z0JBQWlDO0tBQXlCOzs7OztLQUM1Rix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBaUQ7S0FBd0I7Ozs7O0tBQ3RGLHdCQUFDLE1BQUQ7TUFBSSxXQUFVO2dCQUFpQztLQUFvQjs7Ozs7S0FDbkUsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQTBDO0tBQWdHOzs7OztJQUNqSjs7Ozs7O0dBQ1Isd0JBQUMsV0FBRDtJQUFTLGNBQVc7SUFBaUIsV0FBVTtjQUEvQztLQUNHLFNBQVMsWUFDUix3QkFBQyxPQUFEO01BQUssTUFBSztNQUFTLFdBQVU7Z0JBQTdCO09BQ0Usd0JBQUMsS0FBRCxZQUFHLDJCQUEyQjs7Ozs7T0FDOUIsd0JBQUMsVUFBRCxFQUFVLFdBQVUsMkJBQTRCOzs7OztPQUNoRCx3QkFBQyxVQUFELEVBQVUsV0FBVSw2QkFBOEI7Ozs7O01BQy9DOzs7OztnQkFDSCxTQUFTLE9BQ1gsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBcUIsYUFBVTtnQkFBOUMsQ0FDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBcUIsU0FBUyxLQUFLLElBQUk7TUFBUzs7OztnQkFDOUQsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQWQ7UUFDRSx3QkFBQyxNQUFELFlBQUksUUFBUzs7Ozs7UUFBQyx3QkFBQyxNQUFEO1NBQUksZUFBWTttQkFBaEIsQ0FBeUIsU0FBUyxLQUFLLElBQUksVUFBUyxNQUFROzs7Ozs7UUFDMUUsd0JBQUMsTUFBRCxZQUFJLGNBQWU7Ozs7O1FBQUMsd0JBQUMsTUFBRDtTQUFJLGVBQVk7bUJBQWEsU0FBUyxLQUFLLElBQUk7UUFBYzs7Ozs7UUFDakYsd0JBQUMsTUFBRCxZQUFJLGNBQWU7Ozs7O1FBQUMsd0JBQUMsTUFBRDtTQUFJLGVBQVk7bUJBQVcsU0FBUyxLQUFLLElBQUk7UUFBWTs7Ozs7UUFDN0Usd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7UUFBQyx3QkFBQyxNQUFEO1NBQUksZUFBWTttQkFBYyxTQUFTLEtBQUs7UUFBYzs7Ozs7T0FDL0U7Ozs7O2NBQ0Q7Ozs7O2dCQUNIO0tBQ0gsU0FBUyxjQUFjLENBQUMsU0FBUyxhQUFhLHdCQUFDLEtBQUQ7TUFBRyxNQUFLO01BQVMsV0FBVTtnQkFBZTtLQUEwQjs7Ozs7S0FDbEgsU0FBUyxXQUFXLHdCQUFDLEtBQUQ7TUFBRyxNQUFLO01BQVEsV0FBVTtnQkFBZ0M7S0FBc0U7Ozs7O0lBQzlJOzs7Ozs7R0FDVCx3QkFBQyxXQUFEO0lBQVMsY0FBVztJQUF1QixXQUFVO0lBQW9CLGFBQVU7Y0FBbkYsQ0FDRSx3QkFBQyxLQUFELGFBQUcsZUFBVyx3QkFBQyxVQUFEO0tBQVEsZUFBWTtlQUFjLE9BQU87SUFBZTs7OztZQUFJOzs7O2NBQzFFLHdCQUFDLEtBQUQ7S0FBRztLQUFVLHdCQUFDLFFBQUQ7TUFBTSxlQUFZO2dCQUFlLE9BQU87S0FBa0I7Ozs7O0tBQUM7S0FBc0Isd0JBQUMsUUFBRDtNQUFNLGVBQVk7Z0JBQVksT0FBTztLQUFlOzs7OztLQUFDO0tBQWMsd0JBQUMsUUFBRDtNQUFNLGVBQVk7Z0JBQVcsT0FBTztLQUFjOzs7OztJQUFJOzs7O1lBQ2hOOzs7Ozs7R0FDVCx3QkFBQyxXQUFEO0lBQVMsY0FBVztJQUF1QixXQUFVO2NBQXJEO0tBQ0Usd0JBQUMsUUFBRDtNQUFRLFVBQVUsU0FBUztNQUFXLGVBQWUsU0FBUyxPQUFPLFFBQVE7Z0JBQUc7S0FBbUI7Ozs7O0tBQ25HLHdCQUFDLFFBQUQ7TUFBUSxTQUFRO01BQVUsVUFBVSxTQUFTO01BQVcsZUFBZSxTQUFTLE9BQU8sV0FBVztnQkFBRztLQUF3Qjs7Ozs7S0FDN0gsd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBVSxVQUFVLFNBQVM7TUFBVyxlQUFlLFNBQVMsT0FBTyxLQUFLO2dCQUFHO0tBQXFCOzs7OztLQUNwSCx3QkFBQyxRQUFEO01BQVEsU0FBUTtNQUFVLFVBQVUsU0FBUztNQUFXLGVBQWUsU0FBUyxPQUFPLFlBQVk7Z0JBQUc7S0FBMkI7Ozs7O0tBQ2pJLHdCQUFDLFFBQUQ7TUFBUSxTQUFRO01BQVUsVUFBVSxTQUFTO01BQVcsZUFBZSxTQUFTLE9BQU8sV0FBVztnQkFBRztLQUErQjs7Ozs7S0FDcEksd0JBQUMsUUFBRDtNQUFRLFNBQVE7TUFBVSxVQUFVLFNBQVM7TUFBWSxlQUFlLEtBQUssU0FBUyxRQUFRO2dCQUFHO0tBQXNCOzs7OztLQUN2SCx3QkFBQyxRQUFEO01BQVEsU0FBUTtNQUFVLFVBQVUsU0FBUztNQUFXLGVBQWUsU0FBUyxPQUFPLE9BQU87Z0JBQUc7S0FBeUI7Ozs7O0lBQ25IOzs7Ozs7R0FDVCx3QkFBQyxLQUFEO0lBQUcsTUFBSztJQUFTLFdBQVU7Y0FBb0Q7R0FBVzs7Ozs7R0FDMUYsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBMEM7R0FBNkc7Ozs7O0VBQ2hLOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJJbnRlZ3JhdGlvblByb29mLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL3NoYXJlZC91aS9idXR0b24nXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJ0Avc2hhcmVkL3VpL3NrZWxldG9uJ1xuaW1wb3J0IHsgZ2V0UHJvb2ZOZnQsIG5mdEtleSwgcnVuU2NlbmFyaW8gfSBmcm9tICcuL2FwaSdcbmltcG9ydCB7IHVzZU5mdFNvY2tldCB9IGZyb20gJy4vdXNlLW5mdC1zb2NrZXQnXG5cbmV4cG9ydCBmdW5jdGlvbiBJbnRlZ3JhdGlvblByb29mKCkge1xuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnRXNjb2xoYSB1bSBjZW7DoXJpbyBwYXJhIG9ic2VydmFyIGEgaW50ZWdyYcOnw6NvLicpXG4gIGNvbnN0IG5mdFF1ZXJ5ID0gdXNlUXVlcnkoeyBxdWVyeUtleTogbmZ0S2V5LCBxdWVyeUZuOiAoeyBzaWduYWwgfSkgPT4gZ2V0UHJvb2ZOZnQoc2lnbmFsKSxcbiAgICBzdGFsZVRpbWU6IDMwMDAwLCByZXRyeTogZmFsc2UsIHJlZmV0Y2hPbldpbmRvd0ZvY3VzOiBmYWxzZSxcbiAgICBzdHJ1Y3R1cmFsU2hhcmluZzogKHByZXZpb3VzLCBuZXh0KSA9PiB7XG4gICAgICBjb25zdCBvbGQgPSBwcmV2aW91cyBhcyBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGdldFByb29mTmZ0Pj4gfCB1bmRlZmluZWRcbiAgICAgIGNvbnN0IGluY29taW5nID0gbmV4dCBhcyBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIGdldFByb29mTmZ0Pj5cbiAgICAgIHJldHVybiBvbGQgJiYgb2xkLm5mdC52ZXJzaW9uID4gaW5jb21pbmcubmZ0LnZlcnNpb24gPyBvbGQgOiBpbmNvbWluZ1xuICAgIH0sXG4gIH0pXG4gIGNvbnN0IHNvY2tldCA9IHVzZU5mdFNvY2tldCgpXG4gIGNvbnN0IHNjZW5hcmlvID0gdXNlTXV0YXRpb24oeyBtdXRhdGlvbkZuOiBydW5TY2VuYXJpbyxcbiAgICBvblN1Y2Nlc3M6IChyZXN1bHQsIGFjdGlvbikgPT4ge1xuICAgICAgaWYgKGFjdGlvbiA9PT0gJ3Jlc2V0Jykgd2luZG93LmxvY2F0aW9uLnJlbG9hZCgpXG4gICAgICBlbHNlIHNldE1lc3NhZ2UocmVzdWx0Lm1lc3NhZ2UpXG4gICAgfSxcbiAgICBvbkVycm9yOiAoKSA9PiBzZXRNZXNzYWdlKCdOw6NvIGZvaSBwb3Nzw612ZWwgZXhlY3V0YXIgbyBjZW7DoXJpby4nKSxcbiAgfSlcblxuICByZXR1cm4gKFxuICAgIDxtYWluIGNsYXNzTmFtZT1cIm14LWF1dG8gZmxleCBtYXgtdy00eGwgZmxleC1jb2wgZ2FwLTYgcC02IHNtOnAtMTBcIj5cbiAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwic3BhY2UteS0zXCI+XG4gICAgICAgIDxMaW5rIHRvPVwiL3ByZXBhcmF0aW9uXCIgY2xhc3NOYW1lPVwidGV4dC1zbSB0ZXh0LXByaW1hcnkgdW5kZXJsaW5lXCI+Vm9sdGFyIMOgIHByZXBhcmHDp8OjbzwvTGluaz5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGQgdHJhY2tpbmctd2lkZXN0IHRleHQtcHJpbWFyeVwiPktVUklPIMK3IFBST1ZBIFTDiUNOSUNBPC9wPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkIHNtOnRleHQtM3hsXCI+UkVTVCArIFNvY2tldC5JTzwvaDE+XG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gbGVhZGluZy02IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkJhc2UgZGUgaW50ZWdyYcOnw6NvIHNlcGFyYWRhIGRvIG1hcmtldHBsYWNlLiBPcyBjb250cm9sZXMgYWJhaXhvIGF0dWFtIG5vcyBoYW5kbGVycyBkb3MgbW9ja3MuPC9wPlxuICAgICAgPC9oZWFkZXI+XG4gICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsPVwiTkZUIGNvbnN1bHRhZG9cIiBjbGFzc05hbWU9XCJyb3VuZGVkLWxnIGJvcmRlciBib3JkZXItYm9yZGVyIGJnLWNhcmQgcC02XCI+XG4gICAgICAgIHtuZnRRdWVyeS5pc1BlbmRpbmcgPyAoXG4gICAgICAgICAgPGRpdiByb2xlPVwic3RhdHVzXCIgY2xhc3NOYW1lPVwibWluLWgtNDAgc3BhY2UteS00XCI+XG4gICAgICAgICAgICA8cD5DYXJyZWdhbmRvIE5GVCBwb3IgUkVTVOKApjwvcD5cbiAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJwcm9vZi1za2VsZXRvbiBoLTggdy0zLzRcIiAvPlxuICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cInByb29mLXNrZWxldG9uIGgtMTYgdy1mdWxsXCIgLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKSA6IG5mdFF1ZXJ5LmRhdGEgPyAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4taC00MCBzcGFjZS15LTRcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYm9sZFwiPntuZnRRdWVyeS5kYXRhLm5mdC5uYW1lfTwvaDI+XG4gICAgICAgICAgICA8ZGwgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBnYXAtMyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgIDxkdD5QcmXDp288L2R0PjxkZCBkYXRhLXRlc3RpZD1cInByaWNlXCI+e25mdFF1ZXJ5LmRhdGEubmZ0LnByaWNlRXRofSBFVEg8L2RkPlxuICAgICAgICAgICAgICA8ZHQ+RGlzcG9uw612ZWlzPC9kdD48ZGQgZGF0YS10ZXN0aWQ9XCJhdmFpbGFibGVcIj57bmZ0UXVlcnkuZGF0YS5uZnQuYXZhaWxhYmxlfTwvZGQ+XG4gICAgICAgICAgICAgIDxkdD5WZXJzw6NvIFJFU1Q8L2R0PjxkZCBkYXRhLXRlc3RpZD1cInZlcnNpb25cIj57bmZ0UXVlcnkuZGF0YS5uZnQudmVyc2lvbn08L2RkPlxuICAgICAgICAgICAgICA8ZHQ+Q29uc3VsdGFzIFJFU1Q8L2R0PjxkZCBkYXRhLXRlc3RpZD1cInJlYWQtY291bnRcIj57bmZ0UXVlcnkuZGF0YS5yZWFkQ291bnR9PC9kZD5cbiAgICAgICAgICAgIDwvZGw+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkgOiBudWxsfVxuICAgICAgICB7bmZ0UXVlcnkuaXNGZXRjaGluZyAmJiAhbmZ0UXVlcnkuaXNQZW5kaW5nICYmIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJtdC00IHRleHQtc21cIj5TaW5jcm9uaXphbmRvIHBvciBSRVNU4oCmPC9wPn1cbiAgICAgICAge25mdFF1ZXJ5LmlzRXJyb3IgJiYgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LXNtIHRleHQtZGVzdHJ1Y3RpdmVcIj5GYWxoYSBuYSBjb25zdWx0YSBSRVNULiBVc2Ug4oCcQ29uc3VsdGFyIFJFU1TigJ0gcGFyYSB0ZW50YXIgbm92YW1lbnRlLjwvcD59XG4gICAgICA8L3NlY3Rpb24+XG4gICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsPVwiRXN0YWRvIGRvIHRyYW5zcG9ydGVcIiBjbGFzc05hbWU9XCJzcGFjZS15LTIgdGV4dC1zbVwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICA8cD5Tb2NrZXQuSU86IDxzdHJvbmcgZGF0YS10ZXN0aWQ9XCJjb25uZWN0aW9uXCI+e3NvY2tldC5zdGF0dXN9PC9zdHJvbmc+PC9wPlxuICAgICAgICA8cD5Db25leMO1ZXM6IDxzcGFuIGRhdGEtdGVzdGlkPVwiY29ubmVjdGlvbnNcIj57c29ja2V0LmNvbm5lY3Rpb25zfTwvc3Bhbj4gwrcgRXZlbnRvcyByZWNlYmlkb3M6IDxzcGFuIGRhdGEtdGVzdGlkPVwicmVjZWl2ZWRcIj57c29ja2V0LnJlY2VpdmVkfTwvc3Bhbj4gwrcgSWdub3JhZG9zOiA8c3BhbiBkYXRhLXRlc3RpZD1cImlnbm9yZWRcIj57c29ja2V0Lmlnbm9yZWR9PC9zcGFuPjwvcD5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9XCJDb250cm9sZXMgZGUgY2Vuw6FyaW9cIiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBnYXAtM1wiPlxuICAgICAgICA8QnV0dG9uIGRpc2FibGVkPXtzY2VuYXJpby5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHNjZW5hcmlvLm11dGF0ZSgnY2hhbmdlJyl9PkFsdGVyYXIgTkZUPC9CdXR0b24+XG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBkaXNhYmxlZD17c2NlbmFyaW8uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBzY2VuYXJpby5tdXRhdGUoJ2R1cGxpY2F0ZScpfT5FdmVudG8gZHVwbGljYWRvPC9CdXR0b24+XG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBkaXNhYmxlZD17c2NlbmFyaW8uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBzY2VuYXJpby5tdXRhdGUoJ29sZCcpfT5FdmVudG8gYW50aWdvPC9CdXR0b24+XG4gICAgICAgIDxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBkaXNhYmxlZD17c2NlbmFyaW8uaXNQZW5kaW5nfSBvbkNsaWNrPXsoKSA9PiBzY2VuYXJpby5tdXRhdGUoJ2Rpc2Nvbm5lY3QnKX0+SW50ZXJyb21wZXIgY29uZXjDo288L0J1dHRvbj5cbiAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZVwiIGRpc2FibGVkPXtzY2VuYXJpby5pc1BlbmRpbmd9IG9uQ2xpY2s9eygpID0+IHNjZW5hcmlvLm11dGF0ZSgnZmFpbC1uZXh0Jyl9PkZhbGhhciBwcsOzeGltYSBjb25zdWx0YTwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgZGlzYWJsZWQ9e25mdFF1ZXJ5LmlzRmV0Y2hpbmd9IG9uQ2xpY2s9eygpID0+IHZvaWQgbmZ0UXVlcnkucmVmZXRjaCgpfT5Db25zdWx0YXIgUkVTVDwvQnV0dG9uPlxuICAgICAgICA8QnV0dG9uIHZhcmlhbnQ9XCJvdXRsaW5lXCIgZGlzYWJsZWQ9e3NjZW5hcmlvLmlzUGVuZGluZ30gb25DbGljaz17KCkgPT4gc2NlbmFyaW8ubXV0YXRlKCdyZXNldCcpfT5SZWluaWNpYXIgY2Vuw6FyaW88L0J1dHRvbj5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJtaW4taC0xMiB0ZXh0LXNtIGxlYWRpbmctNiB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57bWVzc2FnZX08L3A+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIGxlYWRpbmctNSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5XZWJTb2NrZXQgwrcgbmFtZXNwYWNlIHBhZHLDo28gwrcgZGFkb3Mgc2ltdWxhZG9zLiBPcyBmbHV4b3MgZGUgY29tcHJhIGUgY29udGEgYWluZGEgbsOjbyBmb3JhbSBpbXBsZW1lbnRhZG9zLjwvcD5cbiAgICA8L21haW4+XG4gIClcbn1cbiJdfQ==