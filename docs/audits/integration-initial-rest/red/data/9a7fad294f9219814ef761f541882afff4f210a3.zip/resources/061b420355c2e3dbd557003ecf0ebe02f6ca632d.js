import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/RequireSession.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { useLocation, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { sessionKey, useSession } from "/src/features/auth/session.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/RequireSession.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function RequireSession({ children }) {
	_s();
	const session = useSession(), location = useLocation(), navigate = useNavigate(), client = useQueryClient();
	const [returnTo] = useState(() => location.href);
	// Query notifications are batched. Login may navigate before Context renders
	// the just-written session; check the authoritative cache before redirecting.
	useEffect(() => {
		if (!client.getQueryData(sessionKey)?.user) void navigate({
			to: "/login",
			search: {
				returnTo,
				favorite: ""
			},
			replace: true
		});
	}, [
		session.user,
		client,
		navigate,
		returnTo
	]);
	return session.user ? children : /* @__PURE__ */ _jsxDEV("p", {
		role: "status",
		children: "Entre para acessar este conteúdo."
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 36
	}, this);
}
_s(RequireSession, "KhWNmOYJ/pnS9IEvj1mLj5ys5lE=", false, function() {
	return [
		useSession,
		useLocation,
		useNavigate,
		useQueryClient
	];
});
_c = RequireSession;
var _c;
$RefreshReg$(_c, "RequireSession");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/RequireSession.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/RequireSession.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/RequireSession.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/RequireSession.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQztBQUNwRCxTQUFTLGFBQWEsbUJBQW1CO0FBQ3pDLFNBQVMsc0JBQXNCO0FBQy9CLFNBQVMsWUFBWSxrQkFBa0I7Ozs7QUFFdkMsT0FBTyxTQUFTLGVBQWUsRUFBRSxZQUFxQzs7Q0FDcEUsTUFBTSxVQUFVLFdBQVcsR0FBRyxXQUFXLFlBQVksR0FBRyxXQUFXLFlBQVksR0FBRyxTQUFTLGVBQWU7Q0FDMUcsTUFBTSxDQUFDLFlBQVksZUFBZSxTQUFTLElBQUk7OztDQUcvQyxnQkFBZ0I7RUFBRSxJQUFJLENBQUMsT0FBTyxhQUFzQixVQUFVLENBQUMsRUFBRSxNQUFNLEtBQUssU0FBUztHQUFFLElBQUk7R0FBVSxRQUFRO0lBQUU7SUFBVSxVQUFVO0dBQUc7R0FBRyxTQUFTO0VBQUssQ0FBQztDQUFFLEdBQUc7RUFBQyxRQUFRO0VBQU07RUFBUTtFQUFVO0NBQVEsQ0FBQztDQUN2TSxPQUFPLFFBQVEsT0FBTyxXQUFXLHdCQUFDLEtBQUQ7RUFBRyxNQUFLO1lBQVM7Q0FBb0M7Ozs7O0FBQ3hGIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlJlcXVpcmVTZXNzaW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlLCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHVzZVF1ZXJ5Q2xpZW50IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgc2Vzc2lvbktleSwgdXNlU2Vzc2lvbiB9IGZyb20gJy4vc2Vzc2lvbidcbmltcG9ydCB0eXBlIHsgU2Vzc2lvbiB9IGZyb20gJy4vY29udHJhY3RzJ1xuZXhwb3J0IGZ1bmN0aW9uIFJlcXVpcmVTZXNzaW9uKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKSwgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpLCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCksIGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgY29uc3QgW3JldHVyblRvXSA9IHVzZVN0YXRlKCgpID0+IGxvY2F0aW9uLmhyZWYpXG4gIC8vIFF1ZXJ5IG5vdGlmaWNhdGlvbnMgYXJlIGJhdGNoZWQuIExvZ2luIG1heSBuYXZpZ2F0ZSBiZWZvcmUgQ29udGV4dCByZW5kZXJzXG4gIC8vIHRoZSBqdXN0LXdyaXR0ZW4gc2Vzc2lvbjsgY2hlY2sgdGhlIGF1dGhvcml0YXRpdmUgY2FjaGUgYmVmb3JlIHJlZGlyZWN0aW5nLlxuICB1c2VFZmZlY3QoKCkgPT4geyBpZiAoIWNsaWVudC5nZXRRdWVyeURhdGE8U2Vzc2lvbj4oc2Vzc2lvbktleSk/LnVzZXIpIHZvaWQgbmF2aWdhdGUoeyB0bzogJy9sb2dpbicsIHNlYXJjaDogeyByZXR1cm5UbywgZmF2b3JpdGU6ICcnIH0sIHJlcGxhY2U6IHRydWUgfSkgfSwgW3Nlc3Npb24udXNlciwgY2xpZW50LCBuYXZpZ2F0ZSwgcmV0dXJuVG9dKVxuICByZXR1cm4gc2Vzc2lvbi51c2VyID8gY2hpbGRyZW4gOiA8cCByb2xlPVwic3RhdHVzXCI+RW50cmUgcGFyYSBhY2Vzc2FyIGVzdGUgY29udGXDumRvLjwvcD5cbn1cbiJdfQ==