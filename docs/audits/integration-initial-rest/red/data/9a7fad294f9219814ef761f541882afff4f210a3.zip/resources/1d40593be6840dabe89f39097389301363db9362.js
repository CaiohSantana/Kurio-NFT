import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/shared/ui/modal.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { Button } from "/src/shared/ui/button.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/shared/ui/modal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function Modal({ title, open, onClose, children, className = "", showTitle = true }) {
	_s();
	const ref = useRef(null);
	useEffect(() => {
		if (open && !ref.current?.open) ref.current?.showModal();
		if (!open && ref.current?.open) ref.current?.close();
	}, [open]);
	return /* @__PURE__ */ _jsxDEV("dialog", {
		ref,
		className: `market-modal ${className}`,
		"aria-label": title,
		onCancel: onClose,
		onClose,
		onKeyDown: (event) => {
			if (event.key !== "Tab") return;
			const controls = [...event.currentTarget.querySelectorAll("button, input, select, textarea, a[href], summary, [tabindex]")].filter((node) => node.tabIndex >= 0 && !node.matches(":disabled, [type=hidden]") && node.getClientRects().length > 0);
			const first = controls[0], last = controls.at(-1);
			if (!first) {
				event.preventDefault();
				event.currentTarget.focus();
				return;
			}
			if (event.shiftKey && document.activeElement === first) {
				event.preventDefault();
				last?.focus();
			} else if (!event.shiftKey && document.activeElement === last) {
				event.preventDefault();
				first.focus();
			}
		},
		children: [/* @__PURE__ */ _jsxDEV("header", { children: [showTitle && /* @__PURE__ */ _jsxDEV("h2", { children: title }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 27
		}, this), /* @__PURE__ */ _jsxDEV(Button, {
			variant: "outline",
			onClick: onClose,
			"aria-label": "Fechar diálogo",
			children: "×"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 44
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 5
		}, this), children]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 7,
		columnNumber: 10
	}, this);
}
_s(Modal, "Vyxb9q8fGt0ixq8sdNNvSJELA9k=");
_c = Modal;
var _c;
$RefreshReg$(_c, "Modal");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/shared/ui/modal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/shared/ui/modal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/shared/ui/modal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/shared/ui/modal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGNBQThCO0FBQ2xELFNBQVMsY0FBYzs7OztBQUV2QixPQUFPLFNBQVMsTUFBTSxFQUFFLE9BQU8sTUFBTSxTQUFTLFVBQVUsWUFBWSxJQUFJLFlBQVksUUFBNkg7O0NBQy9NLE1BQU0sTUFBTSxPQUEwQixJQUFJO0NBQzFDLGdCQUFnQjtFQUFFLElBQUksUUFBUSxDQUFDLElBQUksU0FBUyxNQUFNLElBQUksU0FBUyxVQUFVO0VBQUcsSUFBSSxDQUFDLFFBQVEsSUFBSSxTQUFTLE1BQU0sSUFBSSxTQUFTLE1BQU07Q0FBRSxHQUFHLENBQUMsSUFBSSxDQUFDO0NBQzFJLE9BQU8sd0JBQUMsVUFBRDtFQUFhO0VBQUssV0FBVyxnQkFBZ0I7RUFBYSxjQUFZO0VBQU8sVUFBVTtFQUFrQjtFQUFTLFlBQVcsVUFBUztHQUMzSSxJQUFJLE1BQU0sUUFBUSxPQUFPO0dBQ3pCLE1BQU0sV0FBVyxDQUFDLEdBQUcsTUFBTSxjQUFjLGlCQUE4QiwrREFBK0QsQ0FBQyxDQUFDLENBQUMsUUFBTyxTQUFRLEtBQUssWUFBWSxLQUFLLENBQUMsS0FBSyxRQUFRLDBCQUEwQixLQUFLLEtBQUssZUFBZSxDQUFDLENBQUMsU0FBUyxDQUFDO0dBQzNQLE1BQU0sUUFBUSxTQUFTLElBQUksT0FBTyxTQUFTLEdBQUcsQ0FBQyxDQUFDO0dBQ2hELElBQUksQ0FBQyxPQUFPO0lBQUUsTUFBTSxlQUFlO0lBQUcsTUFBTSxjQUFjLE1BQU07SUFBRztHQUFPO0dBQzFFLElBQUksTUFBTSxZQUFZLFNBQVMsa0JBQWtCLE9BQU87SUFBRSxNQUFNLGVBQWU7SUFBRyxNQUFNLE1BQU07R0FBRSxPQUMzRixJQUFJLENBQUMsTUFBTSxZQUFZLFNBQVMsa0JBQWtCLE1BQU07SUFBRSxNQUFNLGVBQWU7SUFBRyxNQUFNLE1BQU07R0FBRTtFQUN2RztZQVBPLENBUUwsd0JBQUMsVUFBRCxhQUFTLGFBQWEsd0JBQUMsTUFBRCxZQUFLLE1BQVU7Ozs7WUFBRSx3QkFBQyxRQUFEO0dBQVEsU0FBUTtHQUFVLFNBQVM7R0FBUyxjQUFXO2FBQWlCO0VBQVM7Ozs7VUFBUzs7OztZQUNoSSxRQUNLOzs7Ozs7QUFDViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJtb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VSZWYsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICcuL2J1dHRvbidcblxuZXhwb3J0IGZ1bmN0aW9uIE1vZGFsKHsgdGl0bGUsIG9wZW4sIG9uQ2xvc2UsIGNoaWxkcmVuLCBjbGFzc05hbWUgPSAnJywgc2hvd1RpdGxlID0gdHJ1ZSB9OiB7IHRpdGxlOiBzdHJpbmc7IG9wZW46IGJvb2xlYW47IG9uQ2xvc2U6ICgpID0+IHZvaWQ7IGNoaWxkcmVuOiBSZWFjdE5vZGU7IGNsYXNzTmFtZT86IHN0cmluZzsgc2hvd1RpdGxlPzogYm9vbGVhbiB9KSB7XG4gIGNvbnN0IHJlZiA9IHVzZVJlZjxIVE1MRGlhbG9nRWxlbWVudD4obnVsbClcbiAgdXNlRWZmZWN0KCgpID0+IHsgaWYgKG9wZW4gJiYgIXJlZi5jdXJyZW50Py5vcGVuKSByZWYuY3VycmVudD8uc2hvd01vZGFsKCk7IGlmICghb3BlbiAmJiByZWYuY3VycmVudD8ub3BlbikgcmVmLmN1cnJlbnQ/LmNsb3NlKCkgfSwgW29wZW5dKVxuICByZXR1cm4gPGRpYWxvZyByZWY9e3JlZn0gY2xhc3NOYW1lPXtgbWFya2V0LW1vZGFsICR7Y2xhc3NOYW1lfWB9IGFyaWEtbGFiZWw9e3RpdGxlfSBvbkNhbmNlbD17b25DbG9zZX0gb25DbG9zZT17b25DbG9zZX0gb25LZXlEb3duPXtldmVudCA9PiB7XG4gICAgaWYgKGV2ZW50LmtleSAhPT0gJ1RhYicpIHJldHVyblxuICAgIGNvbnN0IGNvbnRyb2xzID0gWy4uLmV2ZW50LmN1cnJlbnRUYXJnZXQucXVlcnlTZWxlY3RvckFsbDxIVE1MRWxlbWVudD4oJ2J1dHRvbiwgaW5wdXQsIHNlbGVjdCwgdGV4dGFyZWEsIGFbaHJlZl0sIHN1bW1hcnksIFt0YWJpbmRleF0nKV0uZmlsdGVyKG5vZGUgPT4gbm9kZS50YWJJbmRleCA+PSAwICYmICFub2RlLm1hdGNoZXMoJzpkaXNhYmxlZCwgW3R5cGU9aGlkZGVuXScpICYmIG5vZGUuZ2V0Q2xpZW50UmVjdHMoKS5sZW5ndGggPiAwKVxuICAgIGNvbnN0IGZpcnN0ID0gY29udHJvbHNbMF0sIGxhc3QgPSBjb250cm9scy5hdCgtMSlcbiAgICBpZiAoIWZpcnN0KSB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IGV2ZW50LmN1cnJlbnRUYXJnZXQuZm9jdXMoKTsgcmV0dXJuIH1cbiAgICBpZiAoZXZlbnQuc2hpZnRLZXkgJiYgZG9jdW1lbnQuYWN0aXZlRWxlbWVudCA9PT0gZmlyc3QpIHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgbGFzdD8uZm9jdXMoKSB9XG4gICAgZWxzZSBpZiAoIWV2ZW50LnNoaWZ0S2V5ICYmIGRvY3VtZW50LmFjdGl2ZUVsZW1lbnQgPT09IGxhc3QpIHsgZXZlbnQucHJldmVudERlZmF1bHQoKTsgZmlyc3QuZm9jdXMoKSB9XG4gIH19PlxuICAgIDxoZWFkZXI+e3Nob3dUaXRsZSAmJiA8aDI+e3RpdGxlfTwvaDI+fTxCdXR0b24gdmFyaWFudD1cIm91dGxpbmVcIiBvbkNsaWNrPXtvbkNsb3NlfSBhcmlhLWxhYmVsPVwiRmVjaGFyIGRpw6Fsb2dvXCI+w5c8L0J1dHRvbj48L2hlYWRlcj5cbiAgICB7Y2hpbGRyZW59XG4gIDwvZGlhbG9nPlxufVxuIl19