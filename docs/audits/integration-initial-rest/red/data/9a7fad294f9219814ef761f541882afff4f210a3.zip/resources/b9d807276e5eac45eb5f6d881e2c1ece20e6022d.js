import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/CarouselIndicators.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"];var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CarouselIndicators.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
export function CarouselIndicators({ labels, active, onChange, label, className = "" }) {
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("nav", {
		className: `carousel-indicators ${className}`,
		"aria-label": label,
		onKeyDown: (event) => {
			const direction = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;
			if (!direction && event.key !== "Home" && event.key !== "End") return;
			event.preventDefault();
			const next = event.key === "Home" ? 0 : event.key === "End" ? labels.length - 1 : (active + direction + labels.length) % labels.length;
			onChange(next);
			event.currentTarget.querySelectorAll("button")[next]?.focus();
		},
		children: labels.map((name, index) => /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			"aria-label": name,
			"aria-current": active === index ? "page" : undefined,
			"aria-pressed": active === index,
			onClick: () => onChange(index),
			children: /* @__PURE__ */ _jsxDEV("span", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 8,
				columnNumber: 202
			}, this)
		}, name, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 34
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 2,
		columnNumber: 12
	}, this), /* @__PURE__ */ _jsxDEV("p", {
		className: "sr-only",
		role: "status",
		children: labels[active]
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 227
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 2,
		columnNumber: 10
	}, this);
}
_c = CarouselIndicators;
var _c;
$RefreshReg$(_c, "CarouselIndicators");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/CarouselIndicators.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CarouselIndicators.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CarouselIndicators.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CarouselIndicators.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxPQUFPLFNBQVMsbUJBQW1CLEVBQUUsUUFBUSxRQUFRLFVBQVUsT0FBTyxZQUFZLE1BQWtIO0NBQ2xNLE9BQU8sZ0RBQUUsd0JBQUMsT0FBRDtFQUFLLFdBQVcsdUJBQXVCO0VBQWEsY0FBWTtFQUFPLFlBQVcsVUFBUztHQUNsRyxNQUFNLFlBQVksTUFBTSxRQUFRLGVBQWUsSUFBSSxNQUFNLFFBQVEsY0FBYyxDQUFDLElBQUk7R0FDcEYsSUFBSSxDQUFDLGFBQWEsTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLE9BQU87R0FDL0QsTUFBTSxlQUFlO0dBQ3JCLE1BQU0sT0FBTyxNQUFNLFFBQVEsU0FBUyxJQUFJLE1BQU0sUUFBUSxRQUFRLE9BQU8sU0FBUyxLQUFLLFNBQVMsWUFBWSxPQUFPLFVBQVUsT0FBTztHQUNoSSxTQUFTLElBQUk7R0FBRyxNQUFNLGNBQWMsaUJBQWlCLFFBQVEsQ0FBQyxDQUFDLEtBQUssRUFBRSxNQUFNO0VBQzlFO1lBQUksT0FBTyxLQUFLLE1BQUssVUFBVSx3QkFBQyxVQUFEO0dBQVEsTUFBSztHQUFvQixjQUFZO0dBQU0sZ0JBQWMsV0FBVyxRQUFRLFNBQVM7R0FBVyxnQkFBYyxXQUFXO0dBQU8sZUFBZSxTQUFTLEtBQUs7YUFBRyx3QkFBQyxRQUFELENBQU87Ozs7O0VBQVMsR0FBN0o7Ozs7U0FBNkosQ0FBQztDQUFPOzs7O1dBQUMsd0JBQUMsS0FBRDtFQUFHLFdBQVU7RUFBVSxNQUFLO1lBQVUsT0FBTztDQUFXOzs7O1NBQUc7Ozs7O0FBQzdSIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcm91c2VsSW5kaWNhdG9ycy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIENhcm91c2VsSW5kaWNhdG9ycyh7IGxhYmVscywgYWN0aXZlLCBvbkNoYW5nZSwgbGFiZWwsIGNsYXNzTmFtZSA9ICcnIH06IHsgbGFiZWxzOiBzdHJpbmdbXTsgYWN0aXZlOiBudW1iZXI7IG9uQ2hhbmdlOiAoaW5kZXg6IG51bWJlcikgPT4gdm9pZDsgbGFiZWw6IHN0cmluZzsgY2xhc3NOYW1lPzogc3RyaW5nIH0pIHtcclxuICByZXR1cm4gPD48bmF2IGNsYXNzTmFtZT17YGNhcm91c2VsLWluZGljYXRvcnMgJHtjbGFzc05hbWV9YH0gYXJpYS1sYWJlbD17bGFiZWx9IG9uS2V5RG93bj17ZXZlbnQgPT4ge1xyXG4gICAgY29uc3QgZGlyZWN0aW9uID0gZXZlbnQua2V5ID09PSAnQXJyb3dSaWdodCcgPyAxIDogZXZlbnQua2V5ID09PSAnQXJyb3dMZWZ0JyA/IC0xIDogMFxyXG4gICAgaWYgKCFkaXJlY3Rpb24gJiYgZXZlbnQua2V5ICE9PSAnSG9tZScgJiYgZXZlbnQua2V5ICE9PSAnRW5kJykgcmV0dXJuXHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICBjb25zdCBuZXh0ID0gZXZlbnQua2V5ID09PSAnSG9tZScgPyAwIDogZXZlbnQua2V5ID09PSAnRW5kJyA/IGxhYmVscy5sZW5ndGggLSAxIDogKGFjdGl2ZSArIGRpcmVjdGlvbiArIGxhYmVscy5sZW5ndGgpICUgbGFiZWxzLmxlbmd0aFxyXG4gICAgb25DaGFuZ2UobmV4dCk7IGV2ZW50LmN1cnJlbnRUYXJnZXQucXVlcnlTZWxlY3RvckFsbCgnYnV0dG9uJylbbmV4dF0/LmZvY3VzKClcclxuICB9fT57bGFiZWxzLm1hcCgobmFtZSxpbmRleCkgPT4gPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIga2V5PXtuYW1lfSBhcmlhLWxhYmVsPXtuYW1lfSBhcmlhLWN1cnJlbnQ9e2FjdGl2ZSA9PT0gaW5kZXggPyAncGFnZScgOiB1bmRlZmluZWR9IGFyaWEtcHJlc3NlZD17YWN0aXZlID09PSBpbmRleH0gb25DbGljaz17KCkgPT4gb25DaGFuZ2UoaW5kZXgpfT48c3BhbiAvPjwvYnV0dG9uPil9PC9uYXY+PHAgY2xhc3NOYW1lPVwic3Itb25seVwiIHJvbGU9XCJzdGF0dXNcIj57bGFiZWxzW2FjdGl2ZV19PC9wPjwvPlxyXG59XHJcbiJdfQ==