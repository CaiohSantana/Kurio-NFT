import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/RelatedNfts.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { NftCard } from "/src/features/catalog/NftCard.tsx";
import { CarouselIndicators } from "/src/features/catalog/CarouselIndicators.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/RelatedNfts.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function RelatedNfts({ title, items }) {
	_s();
	const [group, setGroup] = useState(1);
	if (!items.length) return null;
	const starts = [
		Math.max(0, items.length - 5),
		0,
		Math.min(2, Math.max(0, items.length - 5))
	];
	const visible = items.slice(starts[group], starts[group] + 5);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "related",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", { children: title }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 39
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "related-items",
				children: visible.map((item) => /* @__PURE__ */ _jsxDEV(NftCard, { nft: item }, item.id, false, {
					fileName: _jsxFileName,
					lineNumber: 11,
					columnNumber: 109
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 55
			}, this),
			/* @__PURE__ */ _jsxDEV(CarouselIndicators, {
				label: `Grupos de ${title}`,
				labels: starts.map((_, index) => `Grupo ${index + 1} de ${title}`),
				active: group,
				onChange: setGroup
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 153
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 10
	}, this);
}
_s(RelatedNfts, "XcY+MBL6iVOz3/z3BUYyI7+fv8g=");
_c = RelatedNfts;
var _c;
$RefreshReg$(_c, "RelatedNfts");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/RelatedNfts.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/RelatedNfts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/RelatedNfts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/RelatedNfts.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFFekIsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsMEJBQTBCOzs7O0FBRW5DLE9BQU8sU0FBUyxZQUFZLEVBQUUsT0FBTyxTQUEwQzs7Q0FDN0UsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLENBQUM7Q0FDcEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxPQUFPO0NBQzFCLE1BQU0sU0FBUztFQUFDLEtBQUssSUFBSSxHQUFHLE1BQU0sU0FBUyxDQUFDO0VBQUc7RUFBRyxLQUFLLElBQUksR0FBRyxLQUFLLElBQUksR0FBRyxNQUFNLFNBQVMsQ0FBQyxDQUFDO0NBQUM7Q0FDNUYsTUFBTSxVQUFVLE1BQU0sTUFBTSxPQUFPLFFBQVEsT0FBTyxTQUFTLENBQUM7Q0FDNUQsT0FBTyx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUE2Qix3QkFBQyxNQUFELFlBQUssTUFBVTs7Ozs7R0FBQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFpQixRQUFRLEtBQUssU0FBUyx3QkFBQyxTQUFELEVBQVMsS0FBSyxLQUFxQixHQUFWLEtBQUs7Ozs7V0FBSyxDQUFDO0dBQU87Ozs7O0dBQUMsd0JBQUMsb0JBQUQ7SUFBb0IsT0FBTyxhQUFhO0lBQVMsUUFBUSxPQUFPLEtBQUssR0FBRSxVQUFVLFNBQVMsUUFBUSxFQUFFLE1BQU0sT0FBTztJQUFHLFFBQVE7SUFBTyxVQUFVO0dBQVc7Ozs7O0VBQVU7Ozs7OztBQUMxVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSZWxhdGVkTmZ0cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHR5cGUgeyBOZnQgfSBmcm9tICcuL2NvbnRyYWN0cydcclxuaW1wb3J0IHsgTmZ0Q2FyZCB9IGZyb20gJy4vTmZ0Q2FyZCdcclxuaW1wb3J0IHsgQ2Fyb3VzZWxJbmRpY2F0b3JzIH0gZnJvbSAnLi9DYXJvdXNlbEluZGljYXRvcnMnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gUmVsYXRlZE5mdHMoeyB0aXRsZSwgaXRlbXMgfTogeyB0aXRsZTogc3RyaW5nOyBpdGVtczogTmZ0W10gfSkge1xyXG4gIGNvbnN0IFtncm91cCwgc2V0R3JvdXBdID0gdXNlU3RhdGUoMSlcclxuICBpZiAoIWl0ZW1zLmxlbmd0aCkgcmV0dXJuIG51bGxcclxuICBjb25zdCBzdGFydHMgPSBbTWF0aC5tYXgoMCwgaXRlbXMubGVuZ3RoIC0gNSksIDAsIE1hdGgubWluKDIsIE1hdGgubWF4KDAsIGl0ZW1zLmxlbmd0aCAtIDUpKV1cclxuICBjb25zdCB2aXNpYmxlID0gaXRlbXMuc2xpY2Uoc3RhcnRzW2dyb3VwXSwgc3RhcnRzW2dyb3VwXSArIDUpXHJcbiAgcmV0dXJuIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJlbGF0ZWRcIj48aDI+e3RpdGxlfTwvaDI+PGRpdiBjbGFzc05hbWU9XCJyZWxhdGVkLWl0ZW1zXCI+e3Zpc2libGUubWFwKChpdGVtKSA9PiA8TmZ0Q2FyZCBuZnQ9e2l0ZW19IGtleT17aXRlbS5pZH0gLz4pfTwvZGl2PjxDYXJvdXNlbEluZGljYXRvcnMgbGFiZWw9e2BHcnVwb3MgZGUgJHt0aXRsZX1gfSBsYWJlbHM9e3N0YXJ0cy5tYXAoKF8saW5kZXgpID0+IGBHcnVwbyAke2luZGV4ICsgMX0gZGUgJHt0aXRsZX1gKX0gYWN0aXZlPXtncm91cH0gb25DaGFuZ2U9e3NldEdyb3VwfSAvPjwvc2VjdGlvbj5cclxufVxyXG4iXX0=