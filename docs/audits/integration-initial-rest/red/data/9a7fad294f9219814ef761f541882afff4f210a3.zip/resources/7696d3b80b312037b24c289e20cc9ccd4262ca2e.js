import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "demo", "PROD": false, "SSR": false, "VITE_ENABLE_MOCKS": "true"};const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { io } from "/node_modules/.vite/deps/socket__io-client.js?v=571df2d4";
import { catalogKey, detailKey } from "/src/features/catalog/api.ts";
export function useCatalogSocket(scope) {
	const queryClient = useQueryClient();
	const [notice, setNotice] = useState("");
	useEffect(() => {
		const versions = new Map();
		const socket = io(window.location.origin, {
			path: "/proof-socket.io/",
			query: { scope },
			transports: ["websocket"],
			autoConnect: false,
			forceNew: true,
			reconnectionDelay: 300,
			reconnectionDelayMax: 300,
			randomizationFactor: 0
		});
		let connectedOnce = false;
		let active = true;
		const refreshPrivate = (resource) => {
			if (active) void queryClient.cancelQueries({ queryKey: [
				"private",
				scope,
				resource
			] }).then(() => {
				if (active) return queryClient.invalidateQueries({ queryKey: [
					"private",
					scope,
					resource
				] });
			});
		};
		const reconcileCart = () => {
			refreshPrivate("quote");
			refreshPrivate("checkout-quote");
		};
		const reconcile = () => {
			if (connectedOnce) {
				setNotice("");
				// Cancel even a first pending read: its pre-outage snapshot may be old.
				void queryClient.cancelQueries({ queryKey: catalogKey }).then(() => queryClient.invalidateQueries({ queryKey: catalogKey }));
				void queryClient.cancelQueries({ queryKey: ["nft"] }).then(() => queryClient.invalidateQueries({ queryKey: ["nft"] }));
				reconcileCart();
				refreshPrivate("order");
				refreshPrivate("attempt");
				refreshPrivate("cart");
				refreshPrivate("connection");
			}
			connectedOnce = true;
		};
		const update = (event) => {
			if (!active) return;
			if (!event || typeof event.resourceId !== "string" || !Number.isSafeInteger(event.version)) return;
			const cachedListVersion = Math.max(0, ...queryClient.getQueriesData({ queryKey: catalogKey }).map(([, data]) => [...data?.items ?? [], ...data?.featured ?? []].find((nft) => nft.id === event.resourceId)?.version ?? 0));
			const current = Math.max(cachedListVersion, queryClient.getQueryData(detailKey(event.resourceId))?.nft.version ?? 0);
			if (event.version <= Math.max(versions.get(event.resourceId) ?? 0, current)) return;
			versions.set(event.resourceId, event.version);
			setNotice("Preço ou disponibilidade atualizado. Confira os dados antes de continuar.");
			reconcileCart();
			void queryClient.cancelQueries({ queryKey: catalogKey }).then(() => queryClient.invalidateQueries({ queryKey: catalogKey }));
			void queryClient.cancelQueries({ queryKey: detailKey(event.resourceId) }).then(() => queryClient.invalidateQueries({ queryKey: detailKey(event.resourceId) }));
		};
		const disconnected = () => setNotice("Conexão interrompida. A reconexão será automática.");
		const orderUpdated = (event) => {
			if (!active || event.scope !== scope || event.userId !== queryClient.getQueryData(["session"])?.user?.id || !Number.isSafeInteger(event.version)) return;
			const key = [
				"private",
				scope,
				"order",
				event.resourceId
			], current = queryClient.getQueryData(key)?.version ?? 0, seen = versions.get(`order:${event.resourceId}`) ?? 0;
			if (event.version <= Math.max(current, seen)) return;
			versions.set(`order:${event.resourceId}`, event.version);
			if (import.meta.env.MODE === "demo") console.debug("[Kurio realtime] order.updated", event.resourceId, event.version);
			refreshPrivate("order");
			refreshPrivate("attempt");
			refreshPrivate("cart");
			reconcileCart();
		};
		socket.on("connect", reconcile);
		socket.on("disconnect", disconnected);
		socket.on("nft.updated", update);
		socket.on("order.updated", orderUpdated);
		socket.connect();
		return () => {
			active = false;
			socket.off("connect", reconcile);
			socket.off("disconnect", disconnected);
			socket.off("nft.updated", update);
			socket.off("order.updated", orderUpdated);
			socket.disconnect();
		};
	}, [queryClient, scope]);
	return notice;
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLFVBQXVCO0FBQ2hDLFNBQVMsWUFBWSxpQkFBaUI7QUFNdEMsT0FBTyxTQUFTLGlCQUFpQixPQUFlO0NBQzlDLE1BQU0sY0FBYyxlQUFlO0NBQ25DLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLGdCQUFnQjtFQUNkLE1BQU0sV0FBVyxJQUFJLElBQW9CO0VBQ3pDLE1BQU0sU0FBK0IsR0FBRyxPQUFPLFNBQVMsUUFBUTtHQUFFLE1BQU07R0FBcUIsT0FBTyxFQUFFLE1BQU07R0FBRyxZQUFZLENBQUMsV0FBVztHQUFHLGFBQWE7R0FBTyxVQUFVO0dBQU0sbUJBQW1CO0dBQUssc0JBQXNCO0dBQUsscUJBQXFCO0VBQUUsQ0FBQztFQUN6UCxJQUFJLGdCQUFnQjtFQUNwQixJQUFJLFNBQVM7RUFDYixNQUFNLGtCQUFrQixhQUFxQjtHQUFFLElBQUksUUFBUSxLQUFLLFlBQVksY0FBYyxFQUFFLFVBQVU7SUFBQztJQUFXO0lBQU87R0FBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVc7SUFBRSxJQUFJLFFBQVEsT0FBTyxZQUFZLGtCQUFrQixFQUFFLFVBQVU7S0FBQztLQUFXO0tBQU87SUFBUSxFQUFFLENBQUM7R0FBRSxDQUFDO0VBQUU7RUFDblAsTUFBTSxzQkFBc0I7R0FBRSxlQUFlLE9BQU87R0FBRyxlQUFlLGdCQUFnQjtFQUFFO0VBQ3hGLE1BQU0sa0JBQWtCO0dBQ3RCLElBQUksZUFBZTtJQUNqQixVQUFVLEVBQUU7O0lBRVosS0FBSyxZQUFZLGNBQWMsRUFBRSxVQUFVLFdBQVcsQ0FBQyxDQUFDLENBQUMsV0FBVyxZQUFZLGtCQUFrQixFQUFFLFVBQVUsV0FBVyxDQUFDLENBQUM7SUFDM0gsS0FBSyxZQUFZLGNBQWMsRUFBRSxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLFdBQVcsWUFBWSxrQkFBa0IsRUFBRSxVQUFVLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztJQUNySCxjQUFjO0lBQ2QsZUFBZSxPQUFPO0lBQUcsZUFBZSxTQUFTO0lBQUcsZUFBZSxNQUFNO0lBQUcsZUFBZSxZQUFZO0dBQ3pHO0dBQ0EsZ0JBQWdCO0VBQ2xCO0VBQ0EsTUFBTSxVQUFVLFVBQXNCO0dBQ3BDLElBQUksQ0FBQyxRQUFRO0dBQ2IsSUFBSSxDQUFDLFNBQVMsT0FBTyxNQUFNLGVBQWUsWUFBWSxDQUFDLE9BQU8sY0FBYyxNQUFNLE9BQU8sR0FBRztHQUM1RixNQUFNLG9CQUFvQixLQUFLLElBQUksR0FBRyxHQUFHLFlBQVksZUFBZ0MsRUFBRSxVQUFVLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxHQUFJLE1BQU0sU0FBUyxDQUFDLEdBQUksR0FBSSxNQUFNLFlBQVksQ0FBQyxDQUFFLENBQUMsQ0FBQyxNQUFNLFFBQVEsSUFBSSxPQUFPLE1BQU0sVUFBVSxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7R0FDOU8sTUFBTSxVQUFVLEtBQUssSUFBSSxtQkFBbUIsWUFBWSxhQUEwQixVQUFVLE1BQU0sVUFBVSxDQUFDLENBQUMsRUFBRSxJQUFJLFdBQVcsQ0FBQztHQUNoSSxJQUFJLE1BQU0sV0FBVyxLQUFLLElBQUksU0FBUyxJQUFJLE1BQU0sVUFBVSxLQUFLLEdBQUcsT0FBTyxHQUFHO0dBQzdFLFNBQVMsSUFBSSxNQUFNLFlBQVksTUFBTSxPQUFPO0dBQzVDLFVBQVUsMkVBQTJFO0dBQ3JGLGNBQWM7R0FDZCxLQUFLLFlBQVksY0FBYyxFQUFFLFVBQVUsV0FBVyxDQUFDLENBQUMsQ0FBQyxXQUFXLFlBQVksa0JBQWtCLEVBQUUsVUFBVSxXQUFXLENBQUMsQ0FBQztHQUMzSCxLQUFLLFlBQVksY0FBYyxFQUFFLFVBQVUsVUFBVSxNQUFNLFVBQVUsRUFBRSxDQUFDLENBQUMsQ0FBQyxXQUFXLFlBQVksa0JBQWtCLEVBQUUsVUFBVSxVQUFVLE1BQU0sVUFBVSxFQUFFLENBQUMsQ0FBQztFQUMvSjtFQUNBLE1BQU0scUJBQXFCLFVBQVUsb0RBQW9EO0VBQ3pGLE1BQU0sZ0JBQWdCLFVBQXdCO0dBQzVDLElBQUksQ0FBQyxVQUFVLE1BQU0sVUFBVSxTQUFTLE1BQU0sV0FBVyxZQUFZLGFBQXNCLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxNQUFNLE1BQU0sQ0FBQyxPQUFPLGNBQWMsTUFBTSxPQUFPLEdBQUc7R0FDM0osTUFBTSxNQUFNO0lBQUM7SUFBVztJQUFPO0lBQVMsTUFBTTtHQUFVLEdBQUcsVUFBVSxZQUFZLGFBQW9CLEdBQUcsQ0FBQyxFQUFFLFdBQVcsR0FBRyxPQUFPLFNBQVMsSUFBSSxTQUFTLE1BQU0sWUFBWSxLQUFLO0dBQzdLLElBQUksTUFBTSxXQUFXLEtBQUssSUFBSSxTQUFTLElBQUksR0FBRztHQUM5QyxTQUFTLElBQUksU0FBUyxNQUFNLGNBQWMsTUFBTSxPQUFPO0dBQ3ZELElBQUksWUFBWSxJQUFJLFNBQVMsUUFBUSxRQUFRLE1BQU0sa0NBQWtDLE1BQU0sWUFBWSxNQUFNLE9BQU87R0FDcEgsZUFBZSxPQUFPO0dBQUcsZUFBZSxTQUFTO0dBQUcsZUFBZSxNQUFNO0dBQUcsY0FBYztFQUM1RjtFQUNBLE9BQU8sR0FBRyxXQUFXLFNBQVM7RUFBRyxPQUFPLEdBQUcsY0FBYyxZQUFZO0VBQUcsT0FBTyxHQUFHLGVBQWUsTUFBTTtFQUFHLE9BQU8sR0FBRyxpQkFBaUIsWUFBWTtFQUNqSixPQUFPLFFBQVE7RUFDZixhQUFhO0dBQUUsU0FBUztHQUFPLE9BQU8sSUFBSSxXQUFXLFNBQVM7R0FBRyxPQUFPLElBQUksY0FBYyxZQUFZO0dBQUcsT0FBTyxJQUFJLGVBQWUsTUFBTTtHQUFHLE9BQU8sSUFBSSxpQkFBaUIsWUFBWTtHQUFHLE9BQU8sV0FBVztFQUFFO0NBQzdNLEdBQUcsQ0FBQyxhQUFhLEtBQUssQ0FBQztDQUN2QixPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidXNlLWNhdGFsb2ctc29ja2V0LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IGlvLCB0eXBlIFNvY2tldCB9IGZyb20gJ3NvY2tldC5pby1jbGllbnQnXHJcbmltcG9ydCB7IGNhdGFsb2dLZXksIGRldGFpbEtleSB9IGZyb20gJy4vYXBpJ1xyXG5pbXBvcnQgdHlwZSB7IE5mdFJlc3BvbnNlLCBDYXRhbG9nUmVzcG9uc2UgfSBmcm9tICcuL2NvbnRyYWN0cydcclxuaW1wb3J0IHR5cGUgeyBOZnRVcGRhdGVkLCBTZXJ2ZXJFdmVudHMgfSBmcm9tICdAL3NoYXJlZC9hcGkvZXZlbnRzJ1xyXG5pbXBvcnQgdHlwZSB7IE9yZGVyVXBkYXRlZCwgT3JkZXIgfSBmcm9tICdAL2ZlYXR1cmVzL29yZGVycy9jb250cmFjdHMnXHJcbmltcG9ydCB0eXBlIHsgU2Vzc2lvbiB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9jb250cmFjdHMnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlQ2F0YWxvZ1NvY2tldChzY29wZTogc3RyaW5nKSB7XHJcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXHJcbiAgY29uc3QgW25vdGljZSwgc2V0Tm90aWNlXSA9IHVzZVN0YXRlKCcnKVxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCB2ZXJzaW9ucyA9IG5ldyBNYXA8c3RyaW5nLCBudW1iZXI+KClcclxuICAgIGNvbnN0IHNvY2tldDogU29ja2V0PFNlcnZlckV2ZW50cz4gPSBpbyh3aW5kb3cubG9jYXRpb24ub3JpZ2luLCB7IHBhdGg6ICcvcHJvb2Ytc29ja2V0LmlvLycsIHF1ZXJ5OiB7IHNjb3BlIH0sIHRyYW5zcG9ydHM6IFsnd2Vic29ja2V0J10sIGF1dG9Db25uZWN0OiBmYWxzZSwgZm9yY2VOZXc6IHRydWUsIHJlY29ubmVjdGlvbkRlbGF5OiAzMDAsIHJlY29ubmVjdGlvbkRlbGF5TWF4OiAzMDAsIHJhbmRvbWl6YXRpb25GYWN0b3I6IDAgfSlcclxuICAgIGxldCBjb25uZWN0ZWRPbmNlID0gZmFsc2VcclxuICAgIGxldCBhY3RpdmUgPSB0cnVlXHJcbiAgICBjb25zdCByZWZyZXNoUHJpdmF0ZSA9IChyZXNvdXJjZTogc3RyaW5nKSA9PiB7IGlmIChhY3RpdmUpIHZvaWQgcXVlcnlDbGllbnQuY2FuY2VsUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ3ByaXZhdGUnLCBzY29wZSwgcmVzb3VyY2VdIH0pLnRoZW4oKCkgPT4geyBpZiAoYWN0aXZlKSByZXR1cm4gcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydwcml2YXRlJywgc2NvcGUsIHJlc291cmNlXSB9KSB9KSB9XHJcbiAgICBjb25zdCByZWNvbmNpbGVDYXJ0ID0gKCkgPT4geyByZWZyZXNoUHJpdmF0ZSgncXVvdGUnKTsgcmVmcmVzaFByaXZhdGUoJ2NoZWNrb3V0LXF1b3RlJykgfVxyXG4gICAgY29uc3QgcmVjb25jaWxlID0gKCkgPT4ge1xyXG4gICAgICBpZiAoY29ubmVjdGVkT25jZSkge1xyXG4gICAgICAgIHNldE5vdGljZSgnJylcclxuICAgICAgICAvLyBDYW5jZWwgZXZlbiBhIGZpcnN0IHBlbmRpbmcgcmVhZDogaXRzIHByZS1vdXRhZ2Ugc25hcHNob3QgbWF5IGJlIG9sZC5cclxuICAgICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogY2F0YWxvZ0tleSB9KS50aGVuKCgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IGNhdGFsb2dLZXkgfSkpXHJcbiAgICAgICAgdm9pZCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IFsnbmZ0J10gfSkudGhlbigoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBbJ25mdCddIH0pKVxyXG4gICAgICAgIHJlY29uY2lsZUNhcnQoKVxyXG4gICAgICAgIHJlZnJlc2hQcml2YXRlKCdvcmRlcicpOyByZWZyZXNoUHJpdmF0ZSgnYXR0ZW1wdCcpOyByZWZyZXNoUHJpdmF0ZSgnY2FydCcpOyByZWZyZXNoUHJpdmF0ZSgnY29ubmVjdGlvbicpXHJcbiAgICAgIH1cclxuICAgICAgY29ubmVjdGVkT25jZSA9IHRydWVcclxuICAgIH1cclxuICAgIGNvbnN0IHVwZGF0ZSA9IChldmVudDogTmZ0VXBkYXRlZCkgPT4ge1xyXG4gICAgICBpZiAoIWFjdGl2ZSkgcmV0dXJuXHJcbiAgICAgIGlmICghZXZlbnQgfHwgdHlwZW9mIGV2ZW50LnJlc291cmNlSWQgIT09ICdzdHJpbmcnIHx8ICFOdW1iZXIuaXNTYWZlSW50ZWdlcihldmVudC52ZXJzaW9uKSkgcmV0dXJuXHJcbiAgICAgIGNvbnN0IGNhY2hlZExpc3RWZXJzaW9uID0gTWF0aC5tYXgoMCwgLi4ucXVlcnlDbGllbnQuZ2V0UXVlcmllc0RhdGE8Q2F0YWxvZ1Jlc3BvbnNlPih7IHF1ZXJ5S2V5OiBjYXRhbG9nS2V5IH0pLm1hcCgoWywgZGF0YV0pID0+IFsuLi4oZGF0YT8uaXRlbXMgPz8gW10pLCAuLi4oZGF0YT8uZmVhdHVyZWQgPz8gW10pXS5maW5kKChuZnQpID0+IG5mdC5pZCA9PT0gZXZlbnQucmVzb3VyY2VJZCk/LnZlcnNpb24gPz8gMCkpXHJcbiAgICAgIGNvbnN0IGN1cnJlbnQgPSBNYXRoLm1heChjYWNoZWRMaXN0VmVyc2lvbiwgcXVlcnlDbGllbnQuZ2V0UXVlcnlEYXRhPE5mdFJlc3BvbnNlPihkZXRhaWxLZXkoZXZlbnQucmVzb3VyY2VJZCkpPy5uZnQudmVyc2lvbiA/PyAwKVxyXG4gICAgICBpZiAoZXZlbnQudmVyc2lvbiA8PSBNYXRoLm1heCh2ZXJzaW9ucy5nZXQoZXZlbnQucmVzb3VyY2VJZCkgPz8gMCwgY3VycmVudCkpIHJldHVyblxyXG4gICAgICB2ZXJzaW9ucy5zZXQoZXZlbnQucmVzb3VyY2VJZCwgZXZlbnQudmVyc2lvbilcclxuICAgICAgc2V0Tm90aWNlKCdQcmXDp28gb3UgZGlzcG9uaWJpbGlkYWRlIGF0dWFsaXphZG8uIENvbmZpcmEgb3MgZGFkb3MgYW50ZXMgZGUgY29udGludWFyLicpXHJcbiAgICAgIHJlY29uY2lsZUNhcnQoKVxyXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogY2F0YWxvZ0tleSB9KS50aGVuKCgpID0+IHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IGNhdGFsb2dLZXkgfSkpXHJcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuY2FuY2VsUXVlcmllcyh7IHF1ZXJ5S2V5OiBkZXRhaWxLZXkoZXZlbnQucmVzb3VyY2VJZCkgfSkudGhlbigoKSA9PiBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBkZXRhaWxLZXkoZXZlbnQucmVzb3VyY2VJZCkgfSkpXHJcbiAgICB9XHJcbiAgICBjb25zdCBkaXNjb25uZWN0ZWQgPSAoKSA9PiBzZXROb3RpY2UoJ0NvbmV4w6NvIGludGVycm9tcGlkYS4gQSByZWNvbmV4w6NvIHNlcsOhIGF1dG9tw6F0aWNhLicpXHJcbiAgICBjb25zdCBvcmRlclVwZGF0ZWQgPSAoZXZlbnQ6IE9yZGVyVXBkYXRlZCkgPT4ge1xyXG4gICAgICBpZiAoIWFjdGl2ZSB8fCBldmVudC5zY29wZSAhPT0gc2NvcGUgfHwgZXZlbnQudXNlcklkICE9PSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8U2Vzc2lvbj4oWydzZXNzaW9uJ10pPy51c2VyPy5pZCB8fCAhTnVtYmVyLmlzU2FmZUludGVnZXIoZXZlbnQudmVyc2lvbikpIHJldHVyblxyXG4gICAgICBjb25zdCBrZXkgPSBbJ3ByaXZhdGUnLCBzY29wZSwgJ29yZGVyJywgZXZlbnQucmVzb3VyY2VJZF0sIGN1cnJlbnQgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8T3JkZXI+KGtleSk/LnZlcnNpb24gPz8gMCwgc2VlbiA9IHZlcnNpb25zLmdldChgb3JkZXI6JHtldmVudC5yZXNvdXJjZUlkfWApID8/IDBcclxuICAgICAgaWYgKGV2ZW50LnZlcnNpb24gPD0gTWF0aC5tYXgoY3VycmVudCwgc2VlbikpIHJldHVyblxyXG4gICAgICB2ZXJzaW9ucy5zZXQoYG9yZGVyOiR7ZXZlbnQucmVzb3VyY2VJZH1gLCBldmVudC52ZXJzaW9uKVxyXG4gICAgICBpZiAoaW1wb3J0Lm1ldGEuZW52Lk1PREUgPT09ICdkZW1vJykgY29uc29sZS5kZWJ1ZygnW0t1cmlvIHJlYWx0aW1lXSBvcmRlci51cGRhdGVkJywgZXZlbnQucmVzb3VyY2VJZCwgZXZlbnQudmVyc2lvbilcclxuICAgICAgcmVmcmVzaFByaXZhdGUoJ29yZGVyJyk7IHJlZnJlc2hQcml2YXRlKCdhdHRlbXB0Jyk7IHJlZnJlc2hQcml2YXRlKCdjYXJ0Jyk7IHJlY29uY2lsZUNhcnQoKVxyXG4gICAgfVxyXG4gICAgc29ja2V0Lm9uKCdjb25uZWN0JywgcmVjb25jaWxlKTsgc29ja2V0Lm9uKCdkaXNjb25uZWN0JywgZGlzY29ubmVjdGVkKTsgc29ja2V0Lm9uKCduZnQudXBkYXRlZCcsIHVwZGF0ZSk7IHNvY2tldC5vbignb3JkZXIudXBkYXRlZCcsIG9yZGVyVXBkYXRlZClcclxuICAgIHNvY2tldC5jb25uZWN0KClcclxuICAgIHJldHVybiAoKSA9PiB7IGFjdGl2ZSA9IGZhbHNlOyBzb2NrZXQub2ZmKCdjb25uZWN0JywgcmVjb25jaWxlKTsgc29ja2V0Lm9mZignZGlzY29ubmVjdCcsIGRpc2Nvbm5lY3RlZCk7IHNvY2tldC5vZmYoJ25mdC51cGRhdGVkJywgdXBkYXRlKTsgc29ja2V0Lm9mZignb3JkZXIudXBkYXRlZCcsIG9yZGVyVXBkYXRlZCk7IHNvY2tldC5kaXNjb25uZWN0KCkgfVxyXG4gIH0sIFtxdWVyeUNsaWVudCwgc2NvcGVdKVxyXG4gIHJldHVybiBub3RpY2VcclxufVxyXG4iXX0=