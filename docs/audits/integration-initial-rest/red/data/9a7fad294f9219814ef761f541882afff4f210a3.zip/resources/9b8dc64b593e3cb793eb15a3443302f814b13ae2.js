import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/MarketShell.tsx");const createContext = __vite__cjsImport1_react["createContext"]; const useContext = __vite__cjsImport1_react["useContext"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"];import { mobileIcons } from "/src/shared/ui/mobile-icons.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { Link, Outlet, useLocation, useNavigate } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { Search, LogIn, User } from "/node_modules/.vite/deps/lucide-react.js?v=643d2d14";
import { Modal } from "/src/shared/ui/modal.tsx";
import { useCatalogSocket } from "/src/features/catalog/use-catalog-socket.ts";
import { CatalogLink } from "/src/features/catalog/CatalogLink.tsx";
import { CartLink } from "/src/features/cart/CartLink.tsx";
import { defaultCatalogSearch } from "/src/features/catalog/contracts.ts";
import { SessionProvider, useSession, replaceSession, scopedConfig, apiMessage } from "/src/features/auth/session.tsx";
import { http } from "/src/shared/api/http.ts";
import { useMutation, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/MarketShell.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$(), _s3 = $RefreshSig$(), _s4 = $RefreshSig$();
const NoticeContext = createContext(_c = () => undefined);
_c2 = NoticeContext;
const SignOutContext = createContext(_c3 = () => undefined);
_c4 = SignOutContext;
export const useUnavailable = () => {
	_s();
	return useContext(NoticeContext);
};
_s(useUnavailable, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
export const useSignOut = () => {
	_s2();
	return useContext(SignOutContext);
};
_s2(useSignOut, "gDsCjeeItUuvgOWf1v4qoK9RF6k=");
export function MarketShell() {
	return /* @__PURE__ */ _jsxDEV(SessionProvider, { children: /* @__PURE__ */ _jsxDEV(MarketContent, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 27
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 10
	}, this);
}
_c5 = MarketShell;
function MarketContent() {
	_s3();
	const session = useSession(), client = useQueryClient();
	const [notice, setNotice] = useState(""), [accountOpen, setAccountOpen] = useState(false);
	const realtime = useCatalogSocket(session.scope);
	const pathname = useLocation({ select: (location) => location.pathname });
	const navigate = useNavigate();
	const logout = useMutation({
		mutationFn: async () => (await http.delete("/session", scopedConfig(session.scope))).data,
		onSuccess: async (incoming) => {
			await replaceSession(client, incoming);
			void navigate({
				to: "/",
				search: defaultCatalogSearch
			});
		},
		onError: (error) => setNotice(apiMessage(error))
	});
	const login = () => {
		void navigate({
			to: "/login",
			search: {
				returnTo: window.location.pathname + window.location.search,
				favorite: ""
			}
		});
	};
	const focusSearch = () => {
		const input = document.getElementById("catalog-search");
		if (input) input.focus();
		else void navigate({
			to: "/",
			search: defaultCatalogSearch
		}).then(() => document.getElementById("catalog-search")?.focus());
	};
	const unavailable = (action) => setNotice(`${action} não está disponível no momento. Nenhuma operação foi realizada.`);
	return /* @__PURE__ */ _jsxDEV(NoticeContext.Provider, {
		value: unavailable,
		children: /* @__PURE__ */ _jsxDEV(SignOutContext.Provider, {
			value: () => logout.mutate(),
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: `market ${pathname === "/" ? "home-market" : pathname.startsWith("/nfts/") ? "detail-market nft-market" : "detail-market"}`,
				children: [
					/* @__PURE__ */ _jsxDEV("header", {
						className: "desktop-header",
						children: [
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								search: defaultCatalogSearch,
								className: "wordmark",
								children: "KURIO"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 39,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("nav", {
								"aria-label": "Navegação principal",
								children: [
									/* @__PURE__ */ _jsxDEV(Link, {
										to: "/",
										search: defaultCatalogSearch,
										className: pathname === "/" || pathname.startsWith("/account") ? "active" : "",
										children: "Início"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 40,
										columnNumber: 47
									}, this),
									/* @__PURE__ */ _jsxDEV(CatalogLink, {
										className: pathname.startsWith("/nfts") || pathname === "/cart" || pathname === "/checkout" ? "active" : "",
										children: "Mercado"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 40,
										columnNumber: 183
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => unavailable("Criadores"),
										children: "Criadores"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 40,
										columnNumber: 326
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => unavailable("Aprenda"),
										children: "Aprenda"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 40,
										columnNumber: 393
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 40,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "header-actions",
								children: [
									/* @__PURE__ */ _jsxDEV("button", {
										"aria-label": "Abrir busca",
										onClick: focusSearch,
										children: /* @__PURE__ */ _jsxDEV(Search, { size: 20 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 41,
											columnNumber: 96
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 41,
										columnNumber: 41
									}, this),
									/* @__PURE__ */ _jsxDEV(CartLink, {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 41,
										columnNumber: 125
									}, this),
									session.user ? /* @__PURE__ */ _jsxDEV("button", {
										className: "login-button",
										"aria-label": `Minha conta: ${session.user.username}`,
										onClick: () => setAccountOpen(true),
										children: [/* @__PURE__ */ _jsxDEV(User, { size: 18 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 41,
											columnNumber: 276
										}, this), session.user.username]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 41,
										columnNumber: 153
									}, this) : /* @__PURE__ */ _jsxDEV("button", {
										className: "login-button",
										onClick: login,
										children: [/* @__PURE__ */ _jsxDEV(LogIn, { size: 18 }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 41,
											columnNumber: 378
										}, this), "Entrar"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 41,
										columnNumber: 329
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 41,
								columnNumber: 9
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 7
					}, this),
					session.user && /* @__PURE__ */ _jsxDEV("button", {
						className: "mobile-account-button",
						"aria-label": `Minha conta: ${session.user.username}`,
						onClick: () => setAccountOpen(true),
						children: /* @__PURE__ */ _jsxDEV(User, { size: 18 }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 43,
							columnNumber: 156
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 24
					}, this),
					realtime && !pathname.startsWith("/orders") && /* @__PURE__ */ _jsxDEV("p", {
						className: "realtime-notice",
						role: "status",
						children: realtime
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 55
					}, this),
					session.notices.filter((message) => message.startsWith("Não foi possível favoritar")).map((message) => /* @__PURE__ */ _jsxDEV("p", {
						role: "alert",
						children: message
					}, message, false, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 111
					}, this)),
					/* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV(Footer, { onAccount: () => setAccountOpen(true) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 7
					}, this),
					pathname === "/" && /* @__PURE__ */ _jsxDEV("nav", {
						className: "mobile-navigation",
						"aria-label": "Navegação mobile",
						children: [
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/",
								search: defaultCatalogSearch,
								"aria-label": "Início",
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: mobileIcons.home,
									width: "16",
									height: "17",
									alt: ""
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 72
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								"aria-label": "Favoritos",
								onClick: () => unavailable("Lista de favoritos — use os corações nos NFTs"),
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: mobileIcons.favorite,
									width: "20",
									height: "18",
									alt: ""
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 247
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 139
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								className: "scan",
								"aria-label": "Scanner indisponível",
								onClick: () => unavailable("Scanner"),
								children: /* @__PURE__ */ _jsxDEV("span", {
									className: "reference-scan",
									"aria-hidden": "true",
									children: [
										/* @__PURE__ */ _jsxDEV("img", {
											className: "scan-line",
											src: mobileIcons.scanLine,
											alt: ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 49,
											columnNumber: 470
										}, this),
										/* @__PURE__ */ _jsxDEV("img", {
											className: "scan-tl",
											src: mobileIcons.scanTopLeft,
											alt: ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 49,
											columnNumber: 533
										}, this),
										/* @__PURE__ */ _jsxDEV("img", {
											className: "scan-tr",
											src: mobileIcons.scanTopRight,
											alt: ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 49,
											columnNumber: 597
										}, this),
										/* @__PURE__ */ _jsxDEV("img", {
											className: "scan-br",
											src: mobileIcons.scanBottomRight,
											alt: ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 49,
											columnNumber: 662
										}, this),
										/* @__PURE__ */ _jsxDEV("img", {
											className: "scan-bl",
											src: mobileIcons.scanBottomLeft,
											alt: ""
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 49,
											columnNumber: 730
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 418
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 320
							}, this),
							/* @__PURE__ */ _jsxDEV(CartLink, { size: 20 }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 813
							}, this),
							/* @__PURE__ */ _jsxDEV(Link, {
								to: "/account/profile",
								"aria-label": "Perfil",
								onClick: (event) => {
									if (session.user) {
										event.preventDefault();
										setAccountOpen(true);
									}
								},
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: mobileIcons.profile,
									width: "20",
									height: "20",
									alt: ""
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 49,
									columnNumber: 972
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 49,
								columnNumber: 835
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 28
					}, this),
					/* @__PURE__ */ _jsxDEV(Modal, {
						title: "Funcionalidade indisponível",
						open: !!notice,
						onClose: () => setNotice(""),
						children: /* @__PURE__ */ _jsxDEV("p", { children: notice }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 51,
							columnNumber: 96
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 51,
						columnNumber: 7
					}, this),
					/* @__PURE__ */ _jsxDEV(Modal, {
						title: "Minha conta",
						open: accountOpen,
						onClose: () => setAccountOpen(false),
						children: /* @__PURE__ */ _jsxDEV("nav", {
							className: "account-actions",
							"aria-label": "Ações da conta",
							children: [
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/account/profile",
									onClick: () => setAccountOpen(false),
									children: "Meu perfil"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 152
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/account/wallets",
									search: { returnTo: "/" },
									onClick: () => setAccountOpen(false),
									children: "Carteiras"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 235
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setAccountOpen(false);
										logout.mutate();
									},
									disabled: logout.isPending,
									children: "Encerrar sessão"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 344
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => {
										setAccountOpen(false);
										login();
									},
									children: "Trocar usuário"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 52,
									columnNumber: 463
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 52,
							columnNumber: 91
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 52,
						columnNumber: 7
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 5
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 54
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 10
	}, this);
}
_s3(MarketContent, "hAg7qWwAaVCnchW3pUVOm2C/yPM=", false, function() {
	return [
		useSession,
		useQueryClient,
		useCatalogSocket,
		useLocation,
		useNavigate,
		useMutation
	];
});
_c6 = MarketContent;
function Footer({ onAccount }) {
	_s4();
	const unavailable = useUnavailable(), session = useSession();
	const groups = [
		[
			"Meu perfil",
			"Meu perfil",
			"Minha coleção",
			"Atividade",
			"Estúdio do criador",
			"Lista de interesse"
		],
		[
			"Central de ajuda",
			"Central de ajuda",
			"Como comprar NFTs",
			"Carteira e segurança",
			"Política do mercado",
			"Denunciar item"
		],
		[
			"Coleções",
			"Arte digital",
			"Fotografia",
			"Música",
			"Arte 3D",
			"Utilidade"
		]
	];
	return /* @__PURE__ */ _jsxDEV("footer", {
		className: "market-footer",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "benefits",
				children: [[
					[
						"W",
						"Segurança da carteira",
						"Proteja sua carteira e colecione arte digital verificada com confiança."
					],
					[
						"C",
						"Criadores em destaque",
						"Conheça artistas, estúdios e comunidades que moldam a cultura digital na rede."
					],
					[
						"D",
						"Alertas de lançamentos",
						"Receba calendários de cunhagem, novidades de listas de acesso e análises do mercado."
					]
				].map(([letter, title, description]) => /* @__PURE__ */ _jsxDEV("section", { children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "medallion",
						children: letter
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 435
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: title }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 478
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: description }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 60,
						columnNumber: 494
					}, this)
				] }, letter, true, {
					fileName: _jsxFileName,
					lineNumber: 60,
					columnNumber: 413
				}, this)), /* @__PURE__ */ _jsxDEV("section", {
					className: "newsletter",
					children: [
						/* @__PURE__ */ _jsxDEV("h3", { children: "Antecipe-se ao próximo lançamento" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 39
						}, this),
						/* @__PURE__ */ _jsxDEV("form", {
							onSubmit: (e) => {
								e.preventDefault();
								unavailable("Newsletter");
							},
							children: [
								/* @__PURE__ */ _jsxDEV("label", {
									className: "sr-only",
									htmlFor: "newsletter",
									children: "E-mail da newsletter"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 155
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									id: "newsletter",
									type: "email",
									placeholder: "digite seu e-mail..."
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 231
								}, this),
								/* @__PURE__ */ _jsxDEV("button", { children: "Enviar" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 61,
									columnNumber: 304
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 81
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: "Receba lançamentos selecionados, histórias de criadores e novidades do mercado." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 334
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 7
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "contact-band",
				children: [
					/* @__PURE__ */ _jsxDEV("span", {
						className: "wordmark",
						children: "KURIO"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 35
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: [
						"Feito para colecionadores,",
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 106
						}, this),
						"criadores e cultura"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 74
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => unavailable("Contato"),
						children: "contato@email.com"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 138
					}, this),
					/* @__PURE__ */ _jsxDEV("span", { children: "+55 11 4002 8922" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 211
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "footer-links",
				children: [groups.map(([title, ...links]) => /* @__PURE__ */ _jsxDEV("section", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 91
				}, this), links.map((label) => label === "Meu perfil" ? /* @__PURE__ */ _jsxDEV(Link, {
					to: "/account/profile",
					onClick: (event) => {
						if (session.user && matchMedia("(max-width:639px)").matches) {
							event.preventDefault();
							onAccount();
						}
					},
					children: label
				}, label, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 154
				}, this) : /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => unavailable(label),
					children: label
				}, label, false, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 326
				}, this))] }, title, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 70
				}, this)), /* @__PURE__ */ _jsxDEV("section", { children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: "Redes sociais" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 420
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "social-icons",
						children: [
							"99280.svg",
							"d48dd.svg",
							"b4111.svg",
							"b8b84.svg",
							"ca2da.svg"
						].map((asset, i) => /* @__PURE__ */ _jsxDEV("button", {
							"aria-label": [
								"Facebook",
								"Instagram",
								"Twitter",
								"LinkedIn",
								"YouTube"
							][i],
							onClick: () => unavailable("Redes sociais"),
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: `/assets/figma/${asset}`,
								width: "30",
								height: "30",
								alt: ""
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 698
							}, this)
						}, asset, false, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 557
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 442
					}, this),
					/* @__PURE__ */ _jsxDEV("h3", { children: "Carteiras compatíveis" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 783
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "wallet-chip",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "METAMASK" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 840
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "WALLETCONNECT" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 861
							}, this),
							/* @__PURE__ */ _jsxDEV("span", { children: "COINBASE" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 64,
								columnNumber: 887
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 813
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 64,
					columnNumber: 411
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 5
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "copyright",
				children: "© 2026 Kurio. Propriedade digital para todos."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 5
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 10
	}, this);
}
_s4(Footer, "gDAhW7wiQKafP4py8DA2IIYTiHI=", false, function() {
	return [useUnavailable, useSession];
});
_c7 = Footer;
var _c, _c2, _c3, _c4, _c5, _c6, _c7;
$RefreshReg$(_c, "NoticeContext$createContext");
$RefreshReg$(_c2, "NoticeContext");
$RefreshReg$(_c3, "SignOutContext$createContext");
$RefreshReg$(_c4, "SignOutContext");
$RefreshReg$(_c5, "MarketShell");
$RefreshReg$(_c6, "MarketContent");
$RefreshReg$(_c7, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/MarketShell.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/MarketShell.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/MarketShell.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/MarketShell.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxlQUFlLFlBQVksZ0JBQWdCO0FBQ3BELFNBQVMsTUFBTSxRQUFRLGFBQWEsbUJBQW1CO0FBQ3ZELFNBQVMsUUFBUSxPQUFPLFlBQVk7QUFDcEMsU0FBUyxhQUFhO0FBQ3RCLFNBQVMsd0JBQXdCO0FBQ2pDLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsNEJBQTRCO0FBQ3JDLFNBQVMsaUJBQWlCLFlBQVksZ0JBQWdCLGNBQWMsa0JBQWtCO0FBRXRGLFNBQVMsWUFBWTtBQUNyQixTQUFTLGFBQWEsc0JBQXNCOzs7O0FBRTVDLE1BQU0sZ0JBQWdCLHlCQUE4QyxTQUFTOztBQUM3RSxNQUFNLGlCQUFpQiwwQkFBZ0MsU0FBUzs7QUFDaEUsT0FBTyxNQUFNLHVCQUF1Qjs7bUJBQVcsYUFBYTs7O0FBQzVELE9BQU8sTUFBTSxtQkFBbUI7O21CQUFXLGNBQWM7OztBQUN6RCxPQUFPLFNBQVMsY0FBYztDQUM1QixPQUFPLHdCQUFDLGlCQUFELFlBQWlCLHdCQUFDLGVBQUQsQ0FBZ0I7Ozs7VUFBa0I7Ozs7O0FBQzVEOztBQUNBLFNBQVMsZ0JBQWdCOztDQUN2QixNQUFNLFVBQVUsV0FBVyxHQUFHLFNBQVMsZUFBZTtDQUN0RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRSxHQUFHLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3hGLE1BQU0sV0FBVyxpQkFBaUIsUUFBUSxLQUFLO0NBQy9DLE1BQU0sV0FBVyxZQUFZLEVBQUUsU0FBUyxhQUFhLFNBQVMsU0FBUyxDQUFDO0NBQ3hFLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sU0FBUyxZQUFZO0VBQUUsWUFBWSxhQUFhLE1BQU0sS0FBSyxPQUFnQixZQUFZLGFBQWEsUUFBUSxLQUFLLENBQUMsRUFBQyxDQUFFO0VBQU0sV0FBVyxPQUFPLGFBQWE7R0FBRSxNQUFNLGVBQWUsUUFBUSxRQUFRO0dBQUcsS0FBSyxTQUFTO0lBQUUsSUFBSTtJQUFLLFFBQVE7R0FBcUIsQ0FBQztFQUFFO0VBQUcsVUFBVSxVQUFVLFVBQVUsV0FBVyxLQUFLLENBQUM7Q0FBRSxDQUFDO0NBQ3hULE1BQU0sY0FBYztFQUFFLEtBQUssU0FBUztHQUFFLElBQUk7R0FBVSxRQUFRO0lBQUUsVUFBVSxPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVM7SUFBUSxVQUFVO0dBQUc7RUFBRSxDQUFDO0NBQUU7Q0FDN0ksTUFBTSxvQkFBb0I7RUFDeEIsTUFBTSxRQUFRLFNBQVMsZUFBZSxnQkFBZ0I7RUFDdEQsSUFBSSxPQUFPLE1BQU0sTUFBTTtPQUNsQixLQUFLLFNBQVM7R0FBRSxJQUFJO0dBQUssUUFBUTtFQUFxQixDQUFDLENBQUMsQ0FBQyxXQUFXLFNBQVMsZUFBZSxnQkFBZ0IsQ0FBQyxFQUFFLE1BQU0sQ0FBQztDQUM3SDtDQUNBLE1BQU0sZUFBZSxXQUFtQixVQUFVLEdBQUcsT0FBTyxpRUFBaUU7Q0FDN0gsT0FBTyx3QkFBQyxjQUFjLFVBQWY7RUFBd0IsT0FBTztZQUFhLHdCQUFDLGVBQWUsVUFBaEI7R0FBeUIsYUFBYSxPQUFPLE9BQU87YUFDckcsd0JBQUMsT0FBRDtJQUFLLFdBQVcsVUFBVSxhQUFhLE1BQU0sZ0JBQWdCLFNBQVMsV0FBVyxRQUFRLElBQUksNkJBQTZCO2NBQTFIO0tBQ0Usd0JBQUMsVUFBRDtNQUFRLFdBQVU7Z0JBQWxCO09BQ0Usd0JBQUMsTUFBRDtRQUFNLElBQUc7UUFBSSxRQUFRO1FBQXNCLFdBQVU7a0JBQVc7T0FBVzs7Ozs7T0FDM0Usd0JBQUMsT0FBRDtRQUFLLGNBQVc7a0JBQWhCO1NBQXNDLHdCQUFDLE1BQUQ7VUFBTSxJQUFHO1VBQUksUUFBUTtVQUFzQixXQUFXLGFBQWEsT0FBTyxTQUFTLFdBQVcsVUFBVSxJQUFJLFdBQVc7b0JBQUk7U0FBWTs7Ozs7U0FBQyx3QkFBQyxhQUFEO1VBQWEsV0FBVyxTQUFTLFdBQVcsT0FBTyxLQUFLLGFBQWEsV0FBVyxhQUFhLGNBQWMsV0FBVztvQkFBSTtTQUFvQjs7Ozs7U0FBQyx3QkFBQyxVQUFEO1VBQVEsZUFBZSxZQUFZLFdBQVc7b0JBQUc7U0FBaUI7Ozs7O1NBQUMsd0JBQUMsVUFBRDtVQUFRLGVBQWUsWUFBWSxTQUFTO29CQUFHO1NBQWU7Ozs7O1FBQU07Ozs7OztPQUNwYyx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUFnQyx3QkFBQyxVQUFEO1VBQVEsY0FBVztVQUFjLFNBQVM7b0JBQWEsd0JBQUMsUUFBRCxFQUFRLE1BQU0sR0FBSzs7Ozs7U0FBUzs7Ozs7U0FBQyx3QkFBQyxVQUFELENBQVc7Ozs7O1NBQUUsUUFBUSxPQUFPLHdCQUFDLFVBQUQ7VUFBUSxXQUFVO1VBQWUsY0FBWSxnQkFBZ0IsUUFBUSxLQUFLO1VBQVksZUFBZSxlQUFlLElBQUk7b0JBQXhILENBQTJILHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7b0JBQUUsUUFBUSxLQUFLLFFBQWlCOzs7OztvQkFBSSx3QkFBQyxVQUFEO1VBQVEsV0FBVTtVQUFlLFNBQVM7b0JBQTFDLENBQWlELHdCQUFDLE9BQUQsRUFBTyxNQUFNLEdBQUs7Ozs7b0JBQUMsUUFBYzs7Ozs7O1FBQU87Ozs7OztNQUNuWjs7Ozs7O0tBQ1AsUUFBUSxRQUFRLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQXdCLGNBQVksZ0JBQWdCLFFBQVEsS0FBSztNQUFZLGVBQWUsZUFBZSxJQUFJO2dCQUFHLHdCQUFDLE1BQUQsRUFBTSxNQUFNLEdBQUs7Ozs7O0tBQVM7Ozs7O0tBQzlLLFlBQVksQ0FBQyxTQUFTLFdBQVcsU0FBUyxLQUFLLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO01BQWtCLE1BQUs7Z0JBQVU7S0FBWTs7Ozs7S0FDekcsUUFBUSxRQUFRLFFBQVEsWUFBWSxRQUFRLFdBQVcsNEJBQTRCLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWSx3QkFBQyxLQUFEO01BQUcsTUFBSztnQkFBdUI7S0FBVyxHQUFyQjs7OztZQUFxQixDQUFDO0tBQ25KLHdCQUFDLFFBQUQsQ0FBUzs7Ozs7S0FDVCx3QkFBQyxRQUFELEVBQVEsaUJBQWlCLGVBQWUsSUFBSSxFQUFJOzs7OztLQUMvQyxhQUFhLE9BQU8sd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBb0IsY0FBVztnQkFBOUM7T0FDbkIsd0JBQUMsTUFBRDtRQUFNLElBQUc7UUFBSSxRQUFRO1FBQXNCLGNBQVc7a0JBQVMsd0JBQUMsT0FBRDtTQUFLLEtBQUssWUFBWTtTQUFNLE9BQU07U0FBSyxRQUFPO1NBQUssS0FBSTtRQUFJOzs7OztPQUFPOzs7OztPQUFDLHdCQUFDLFVBQUQ7UUFBUSxjQUFXO1FBQVksZUFBZSxZQUFZLCtDQUErQztrQkFBRyx3QkFBQyxPQUFEO1NBQUssS0FBSyxZQUFZO1NBQVUsT0FBTTtTQUFLLFFBQU87U0FBSyxLQUFJO1FBQUk7Ozs7O09BQVM7Ozs7O09BQUMsd0JBQUMsVUFBRDtRQUFRLFdBQVU7UUFBTyxjQUFXO1FBQXVCLGVBQWUsWUFBWSxTQUFTO2tCQUFHLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO1NBQWlCLGVBQVk7bUJBQTdDO1VBQW9ELHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQVksS0FBSyxZQUFZO1dBQVUsS0FBSTtVQUFJOzs7OztVQUFDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQVUsS0FBSyxZQUFZO1dBQWEsS0FBSTtVQUFJOzs7OztVQUFDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQVUsS0FBSyxZQUFZO1dBQWMsS0FBSTtVQUFJOzs7OztVQUFDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO1dBQVUsS0FBSyxZQUFZO1dBQWlCLEtBQUk7VUFBSTs7Ozs7VUFBQyx3QkFBQyxPQUFEO1dBQUssV0FBVTtXQUFVLEtBQUssWUFBWTtXQUFnQixLQUFJO1VBQUk7Ozs7O1NBQU87Ozs7OztPQUFTOzs7OztPQUFDLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEdBQUs7Ozs7O09BQUMsd0JBQUMsTUFBRDtRQUFNLElBQUc7UUFBbUIsY0FBVztRQUFTLFVBQVMsVUFBUztTQUFFLElBQUcsUUFBUSxNQUFNO1VBQUUsTUFBTSxlQUFlO1VBQUcsZUFBZSxJQUFJO1NBQUU7UUFBRTtrQkFBRyx3QkFBQyxPQUFEO1NBQUssS0FBSyxZQUFZO1NBQVMsT0FBTTtTQUFLLFFBQU87U0FBSyxLQUFJO1FBQUk7Ozs7O09BQU87Ozs7O01BQ3JnQzs7Ozs7O0tBQ0wsd0JBQUMsT0FBRDtNQUFPLE9BQU07TUFBOEIsTUFBTSxDQUFDLENBQUM7TUFBUSxlQUFlLFVBQVUsRUFBRTtnQkFBRyx3QkFBQyxLQUFELFlBQUksT0FBVTs7Ozs7S0FBUTs7Ozs7S0FDL0csd0JBQUMsT0FBRDtNQUFPLE9BQU07TUFBYyxNQUFNO01BQWEsZUFBZSxlQUFlLEtBQUs7Z0JBQUcsd0JBQUMsT0FBRDtPQUFLLFdBQVU7T0FBa0IsY0FBVztpQkFBNUM7UUFBNkQsd0JBQUMsTUFBRDtTQUFNLElBQUc7U0FBbUIsZUFBZSxlQUFlLEtBQUs7bUJBQUc7UUFBZ0I7Ozs7O1FBQUMsd0JBQUMsTUFBRDtTQUFNLElBQUc7U0FBbUIsUUFBUSxFQUFFLFVBQVUsSUFBSTtTQUFHLGVBQWUsZUFBZSxLQUFLO21CQUFHO1FBQWU7Ozs7O1FBQUMsd0JBQUMsVUFBRDtTQUFRLGVBQWU7VUFBRSxlQUFlLEtBQUs7VUFBRyxPQUFPLE9BQU87U0FBRTtTQUFHLFVBQVUsT0FBTzttQkFBVztRQUF1Qjs7Ozs7UUFBQyx3QkFBQyxVQUFEO1NBQVEsZUFBZTtVQUFFLGVBQWUsS0FBSztVQUFHLE1BQU07U0FBRTttQkFBRztRQUFzQjs7Ozs7T0FBTTs7Ozs7O0tBQVE7Ozs7O0lBQ3BpQjs7Ozs7O0VBQ2tCOzs7OztDQUF5Qjs7Ozs7QUFDcEQ7Ozs7Ozs7Ozs7OztBQUNBLFNBQVMsT0FBTyxFQUFDLGFBQWtDOztDQUNqRCxNQUFNLGNBQWMsZUFBZSxHQUFHLFVBQVEsV0FBVztDQUN6RCxNQUFNLFNBQVM7RUFBQztHQUFDO0dBQWM7R0FBYztHQUFpQjtHQUFhO0dBQXNCO0VBQW9CO0VBQUc7R0FBQztHQUFvQjtHQUFvQjtHQUFxQjtHQUF3QjtHQUF1QjtFQUFnQjtFQUFHO0dBQUM7R0FBWTtHQUFnQjtHQUFjO0dBQVU7R0FBVztFQUFXO0NBQUM7Q0FDcFUsT0FBTyx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUFsQjtHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FBMkI7S0FBQztNQUFDO01BQUs7TUFBeUI7S0FBeUU7S0FBRztNQUFDO01BQUs7TUFBeUI7S0FBZ0Y7S0FBRztNQUFDO01BQUs7TUFBMEI7S0FBc0Y7SUFBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFFBQVEsT0FBTyxpQkFBaUIsd0JBQUMsV0FBRDtLQUFzQix3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBYTtLQUFhOzs7OztLQUFDLHdCQUFDLE1BQUQsWUFBSyxNQUFVOzs7OztLQUFDLHdCQUFDLEtBQUQsWUFBSSxZQUFlOzs7OztJQUFVLEtBQWhHOzs7O1dBQWdHLENBQUMsR0FDcmdCLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CO01BQWdDLHdCQUFDLE1BQUQsWUFBSSxvQ0FBcUM7Ozs7O01BQUMsd0JBQUMsUUFBRDtPQUFNLFdBQVcsTUFBTTtRQUFFLEVBQUUsZUFBZTtRQUFHLFlBQVksWUFBWTtPQUFFO2lCQUF2RTtRQUEwRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTtTQUFVLFNBQVE7bUJBQWE7UUFBMkI7Ozs7O1FBQUMsd0JBQUMsU0FBRDtTQUFPLElBQUc7U0FBYSxNQUFLO1NBQVEsYUFBWTtRQUF3Qjs7Ozs7UUFBQyx3QkFBQyxVQUFELFlBQVEsU0FBYzs7Ozs7T0FBTzs7Ozs7O01BQUMsd0JBQUMsS0FBRCxZQUFHLGtGQUFrRjs7Ozs7S0FBVTs7Ozs7WUFDbmE7Ozs7OztHQUNMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FBOEIsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVc7S0FBVzs7Ozs7S0FBQyx3QkFBQyxRQUFEO01BQU07TUFBMEIsd0JBQUMsTUFBRCxDQUFLOzs7OztNQUFDO0tBQXlCOzs7OztLQUFDLHdCQUFDLFVBQUQ7TUFBUSxlQUFlLFlBQVksU0FBUztnQkFBRztLQUF5Qjs7Ozs7S0FBQyx3QkFBQyxRQUFELFlBQU0sbUJBQXNCOzs7OztJQUFNOzs7Ozs7R0FDaFAsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUErQixPQUFPLEtBQUssQ0FBQyxPQUFPLEdBQUcsV0FBVyx3QkFBQyxXQUFELGFBQXFCLHdCQUFDLE1BQUQsWUFBSyxNQUFVOzs7O2NBQUUsTUFBTSxLQUFLLFVBQVUsVUFBVSxlQUFlLHdCQUFDLE1BQUQ7S0FBTSxJQUFHO0tBQStCLFVBQVMsVUFBTztNQUFDLElBQUcsUUFBUSxRQUFRLFdBQVcsbUJBQW1CLENBQUMsQ0FBQyxTQUFRO09BQUMsTUFBTSxlQUFlO09BQUUsVUFBVTtNQUFDO0tBQUM7ZUFBSTtJQUFZLEdBQXZJOzs7O1dBQXVJLElBQUksd0JBQUMsVUFBRDtLQUFvQixlQUFlLFlBQVksS0FBSztlQUFJO0lBQWMsR0FBekQ7Ozs7V0FBeUQsQ0FBQyxDQUFXLEtBQXBVOzs7O1dBQW9VLENBQUMsR0FBRSx3QkFBQyxXQUFEO0tBQVMsd0JBQUMsTUFBRCxZQUFJLGdCQUFpQjs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZ0I7T0FBQztPQUFhO09BQWE7T0FBYTtPQUFhO01BQVcsQ0FBQyxDQUFDLEtBQUssT0FBTyxNQUFNLHdCQUFDLFVBQUQ7T0FBUSxjQUFZO1FBQUM7UUFBWTtRQUFhO1FBQVc7UUFBWTtPQUFTLENBQUMsQ0FBQztPQUFnQixlQUFlLFlBQVksZUFBZTtpQkFBRyx3QkFBQyxPQUFEO1FBQUssS0FBSyxpQkFBaUI7UUFBUyxPQUFNO1FBQUssUUFBTztRQUFLLEtBQUk7T0FBSTs7Ozs7TUFBUyxHQUFoSTs7OzthQUFnSSxDQUFDO0tBQU87Ozs7O0tBQUMsd0JBQUMsTUFBRCxZQUFJLHdCQUF5Qjs7Ozs7S0FBQyx3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYjtPQUEyQix3QkFBQyxRQUFELFlBQU0sV0FBYzs7Ozs7T0FBQyx3QkFBQyxRQUFELFlBQU0sZ0JBQW1COzs7OztPQUFDLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7OztNQUFJOzs7Ozs7SUFBVTs7OztZQUFNOzs7Ozs7R0FDMTVCLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQVk7R0FBZ0Q7Ozs7O0VBQ25FOzs7Ozs7QUFDViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJNYXJrZXRTaGVsbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgbW9iaWxlSWNvbnMgfSBmcm9tICdAL3NoYXJlZC91aS9tb2JpbGUtaWNvbnMnXHJcbmltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IExpbmssIE91dGxldCwgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcclxuaW1wb3J0IHsgU2VhcmNoLCBMb2dJbiwgVXNlciB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcclxuaW1wb3J0IHsgTW9kYWwgfSBmcm9tICdAL3NoYXJlZC91aS9tb2RhbCdcclxuaW1wb3J0IHsgdXNlQ2F0YWxvZ1NvY2tldCB9IGZyb20gJy4vdXNlLWNhdGFsb2ctc29ja2V0J1xyXG5pbXBvcnQgeyBDYXRhbG9nTGluayB9IGZyb20gJy4vQ2F0YWxvZ0xpbmsnXHJcbmltcG9ydCB7IENhcnRMaW5rIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXJ0L0NhcnRMaW5rJ1xyXG5pbXBvcnQgeyBkZWZhdWx0Q2F0YWxvZ1NlYXJjaCB9IGZyb20gJy4vY29udHJhY3RzJ1xyXG5pbXBvcnQgeyBTZXNzaW9uUHJvdmlkZXIsIHVzZVNlc3Npb24sIHJlcGxhY2VTZXNzaW9uLCBzY29wZWRDb25maWcsIGFwaU1lc3NhZ2UgfSBmcm9tICdAL2ZlYXR1cmVzL2F1dGgvc2Vzc2lvbidcclxuaW1wb3J0IHR5cGUgeyBTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL2NvbnRyYWN0cydcclxuaW1wb3J0IHsgaHR0cCB9IGZyb20gJ0Avc2hhcmVkL2FwaS9odHRwJ1xyXG5pbXBvcnQgeyB1c2VNdXRhdGlvbiwgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcblxyXG5jb25zdCBOb3RpY2VDb250ZXh0ID0gY3JlYXRlQ29udGV4dDwoYWN0aW9uOiBzdHJpbmcpID0+IHZvaWQ+KCgpID0+IHVuZGVmaW5lZClcclxuY29uc3QgU2lnbk91dENvbnRleHQgPSBjcmVhdGVDb250ZXh0PCgpID0+IHZvaWQ+KCgpID0+IHVuZGVmaW5lZClcclxuZXhwb3J0IGNvbnN0IHVzZVVuYXZhaWxhYmxlID0gKCkgPT4gdXNlQ29udGV4dChOb3RpY2VDb250ZXh0KVxyXG5leHBvcnQgY29uc3QgdXNlU2lnbk91dCA9ICgpID0+IHVzZUNvbnRleHQoU2lnbk91dENvbnRleHQpXHJcbmV4cG9ydCBmdW5jdGlvbiBNYXJrZXRTaGVsbCgpIHtcclxuICByZXR1cm4gPFNlc3Npb25Qcm92aWRlcj48TWFya2V0Q29udGVudCAvPjwvU2Vzc2lvblByb3ZpZGVyPlxyXG59XHJcbmZ1bmN0aW9uIE1hcmtldENvbnRlbnQoKSB7XHJcbiAgY29uc3Qgc2Vzc2lvbiA9IHVzZVNlc3Npb24oKSwgY2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxyXG4gIGNvbnN0IFtub3RpY2UsIHNldE5vdGljZV0gPSB1c2VTdGF0ZSgnJyksIFthY2NvdW50T3Blbiwgc2V0QWNjb3VudE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgcmVhbHRpbWUgPSB1c2VDYXRhbG9nU29ja2V0KHNlc3Npb24uc2NvcGUpXHJcbiAgY29uc3QgcGF0aG5hbWUgPSB1c2VMb2NhdGlvbih7IHNlbGVjdDogKGxvY2F0aW9uKSA9PiBsb2NhdGlvbi5wYXRobmFtZSB9KVxyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxyXG4gIGNvbnN0IGxvZ291dCA9IHVzZU11dGF0aW9uKHsgbXV0YXRpb25GbjogYXN5bmMgKCkgPT4gKGF3YWl0IGh0dHAuZGVsZXRlPFNlc3Npb24+KCcvc2Vzc2lvbicsIHNjb3BlZENvbmZpZyhzZXNzaW9uLnNjb3BlKSkpLmRhdGEsIG9uU3VjY2VzczogYXN5bmMgKGluY29taW5nKSA9PiB7IGF3YWl0IHJlcGxhY2VTZXNzaW9uKGNsaWVudCwgaW5jb21pbmcpOyB2b2lkIG5hdmlnYXRlKHsgdG86ICcvJywgc2VhcmNoOiBkZWZhdWx0Q2F0YWxvZ1NlYXJjaCB9KSB9LCBvbkVycm9yOiAoZXJyb3IpID0+IHNldE5vdGljZShhcGlNZXNzYWdlKGVycm9yKSkgfSlcclxuICBjb25zdCBsb2dpbiA9ICgpID0+IHsgdm9pZCBuYXZpZ2F0ZSh7IHRvOiAnL2xvZ2luJywgc2VhcmNoOiB7IHJldHVyblRvOiB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUgKyB3aW5kb3cubG9jYXRpb24uc2VhcmNoLCBmYXZvcml0ZTogJycgfSB9KSB9XHJcbiAgY29uc3QgZm9jdXNTZWFyY2ggPSAoKSA9PiB7XHJcbiAgICBjb25zdCBpbnB1dCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdjYXRhbG9nLXNlYXJjaCcpXHJcbiAgICBpZiAoaW5wdXQpIGlucHV0LmZvY3VzKClcclxuICAgIGVsc2Ugdm9pZCBuYXZpZ2F0ZSh7IHRvOiAnLycsIHNlYXJjaDogZGVmYXVsdENhdGFsb2dTZWFyY2ggfSkudGhlbigoKSA9PiBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY2F0YWxvZy1zZWFyY2gnKT8uZm9jdXMoKSlcclxuICB9XHJcbiAgY29uc3QgdW5hdmFpbGFibGUgPSAoYWN0aW9uOiBzdHJpbmcpID0+IHNldE5vdGljZShgJHthY3Rpb259IG7Do28gZXN0w6EgZGlzcG9uw612ZWwgbm8gbW9tZW50by4gTmVuaHVtYSBvcGVyYcOnw6NvIGZvaSByZWFsaXphZGEuYClcclxuICByZXR1cm4gPE5vdGljZUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3VuYXZhaWxhYmxlfT48U2lnbk91dENvbnRleHQuUHJvdmlkZXIgdmFsdWU9eygpID0+IGxvZ291dC5tdXRhdGUoKX0+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT17YG1hcmtldCAke3BhdGhuYW1lID09PSAnLycgPyAnaG9tZS1tYXJrZXQnIDogcGF0aG5hbWUuc3RhcnRzV2l0aCgnL25mdHMvJykgPyAnZGV0YWlsLW1hcmtldCBuZnQtbWFya2V0JyA6ICdkZXRhaWwtbWFya2V0J31gfT5cclxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJkZXNrdG9wLWhlYWRlclwiPlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIHNlYXJjaD17ZGVmYXVsdENhdGFsb2dTZWFyY2h9IGNsYXNzTmFtZT1cIndvcmRtYXJrXCI+S1VSSU88L0xpbms+XHJcbiAgICAgICAgPG5hdiBhcmlhLWxhYmVsPVwiTmF2ZWdhw6fDo28gcHJpbmNpcGFsXCI+PExpbmsgdG89XCIvXCIgc2VhcmNoPXtkZWZhdWx0Q2F0YWxvZ1NlYXJjaH0gY2xhc3NOYW1lPXtwYXRobmFtZSA9PT0gJy8nIHx8IHBhdGhuYW1lLnN0YXJ0c1dpdGgoJy9hY2NvdW50JykgPyAnYWN0aXZlJyA6ICcnfT5JbsOtY2lvPC9MaW5rPjxDYXRhbG9nTGluayBjbGFzc05hbWU9e3BhdGhuYW1lLnN0YXJ0c1dpdGgoJy9uZnRzJykgfHwgcGF0aG5hbWUgPT09ICcvY2FydCcgfHwgcGF0aG5hbWUgPT09ICcvY2hlY2tvdXQnID8gJ2FjdGl2ZScgOiAnJ30+TWVyY2FkbzwvQ2F0YWxvZ0xpbms+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB1bmF2YWlsYWJsZSgnQ3JpYWRvcmVzJyl9PkNyaWFkb3JlczwvYnV0dG9uPjxidXR0b24gb25DbGljaz17KCkgPT4gdW5hdmFpbGFibGUoJ0FwcmVuZGEnKX0+QXByZW5kYTwvYnV0dG9uPjwvbmF2PlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiaGVhZGVyLWFjdGlvbnNcIj48YnV0dG9uIGFyaWEtbGFiZWw9XCJBYnJpciBidXNjYVwiIG9uQ2xpY2s9e2ZvY3VzU2VhcmNofT48U2VhcmNoIHNpemU9ezIwfSAvPjwvYnV0dG9uPjxDYXJ0TGluayAvPntzZXNzaW9uLnVzZXIgPyA8YnV0dG9uIGNsYXNzTmFtZT1cImxvZ2luLWJ1dHRvblwiIGFyaWEtbGFiZWw9e2BNaW5oYSBjb250YTogJHtzZXNzaW9uLnVzZXIudXNlcm5hbWV9YH0gb25DbGljaz17KCkgPT4gc2V0QWNjb3VudE9wZW4odHJ1ZSl9PjxVc2VyIHNpemU9ezE4fSAvPntzZXNzaW9uLnVzZXIudXNlcm5hbWV9PC9idXR0b24+IDogPGJ1dHRvbiBjbGFzc05hbWU9XCJsb2dpbi1idXR0b25cIiBvbkNsaWNrPXtsb2dpbn0+PExvZ0luIHNpemU9ezE4fSAvPkVudHJhcjwvYnV0dG9uPn08L2Rpdj5cclxuICAgICAgPC9oZWFkZXI+XHJcbiAgICAgIHtzZXNzaW9uLnVzZXIgJiYgPGJ1dHRvbiBjbGFzc05hbWU9XCJtb2JpbGUtYWNjb3VudC1idXR0b25cIiBhcmlhLWxhYmVsPXtgTWluaGEgY29udGE6ICR7c2Vzc2lvbi51c2VyLnVzZXJuYW1lfWB9IG9uQ2xpY2s9eygpID0+IHNldEFjY291bnRPcGVuKHRydWUpfT48VXNlciBzaXplPXsxOH0gLz48L2J1dHRvbj59XHJcbiAgICAgIHtyZWFsdGltZSAmJiAhcGF0aG5hbWUuc3RhcnRzV2l0aCgnL29yZGVycycpICYmIDxwIGNsYXNzTmFtZT1cInJlYWx0aW1lLW5vdGljZVwiIHJvbGU9XCJzdGF0dXNcIj57cmVhbHRpbWV9PC9wPn1cclxuICAgICAge3Nlc3Npb24ubm90aWNlcy5maWx0ZXIoKG1lc3NhZ2UpID0+IG1lc3NhZ2Uuc3RhcnRzV2l0aCgnTsOjbyBmb2kgcG9zc8OtdmVsIGZhdm9yaXRhcicpKS5tYXAoKG1lc3NhZ2UpID0+IDxwIHJvbGU9XCJhbGVydFwiIGtleT17bWVzc2FnZX0+e21lc3NhZ2V9PC9wPil9XHJcbiAgICAgIDxPdXRsZXQgLz5cclxuICAgICAgPEZvb3RlciBvbkFjY291bnQ9eygpID0+IHNldEFjY291bnRPcGVuKHRydWUpfSAvPlxyXG4gICAgICB7cGF0aG5hbWUgPT09ICcvJyAmJiA8bmF2IGNsYXNzTmFtZT1cIm1vYmlsZS1uYXZpZ2F0aW9uXCIgYXJpYS1sYWJlbD1cIk5hdmVnYcOnw6NvIG1vYmlsZVwiPlxyXG4gICAgICAgIDxMaW5rIHRvPVwiL1wiIHNlYXJjaD17ZGVmYXVsdENhdGFsb2dTZWFyY2h9IGFyaWEtbGFiZWw9XCJJbsOtY2lvXCI+PGltZyBzcmM9e21vYmlsZUljb25zLmhvbWV9IHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxN1wiIGFsdD1cIlwiIC8+PC9MaW5rPjxidXR0b24gYXJpYS1sYWJlbD1cIkZhdm9yaXRvc1wiIG9uQ2xpY2s9eygpID0+IHVuYXZhaWxhYmxlKCdMaXN0YSBkZSBmYXZvcml0b3Mg4oCUIHVzZSBvcyBjb3Jhw6fDtWVzIG5vcyBORlRzJyl9PjxpbWcgc3JjPXttb2JpbGVJY29ucy5mYXZvcml0ZX0gd2lkdGg9XCIyMFwiIGhlaWdodD1cIjE4XCIgYWx0PVwiXCIgLz48L2J1dHRvbj48YnV0dG9uIGNsYXNzTmFtZT1cInNjYW5cIiBhcmlhLWxhYmVsPVwiU2Nhbm5lciBpbmRpc3BvbsOtdmVsXCIgb25DbGljaz17KCkgPT4gdW5hdmFpbGFibGUoJ1NjYW5uZXInKX0+PHNwYW4gY2xhc3NOYW1lPVwicmVmZXJlbmNlLXNjYW5cIiBhcmlhLWhpZGRlbj1cInRydWVcIj48aW1nIGNsYXNzTmFtZT1cInNjYW4tbGluZVwiIHNyYz17bW9iaWxlSWNvbnMuc2NhbkxpbmV9IGFsdD1cIlwiIC8+PGltZyBjbGFzc05hbWU9XCJzY2FuLXRsXCIgc3JjPXttb2JpbGVJY29ucy5zY2FuVG9wTGVmdH0gYWx0PVwiXCIgLz48aW1nIGNsYXNzTmFtZT1cInNjYW4tdHJcIiBzcmM9e21vYmlsZUljb25zLnNjYW5Ub3BSaWdodH0gYWx0PVwiXCIgLz48aW1nIGNsYXNzTmFtZT1cInNjYW4tYnJcIiBzcmM9e21vYmlsZUljb25zLnNjYW5Cb3R0b21SaWdodH0gYWx0PVwiXCIgLz48aW1nIGNsYXNzTmFtZT1cInNjYW4tYmxcIiBzcmM9e21vYmlsZUljb25zLnNjYW5Cb3R0b21MZWZ0fSBhbHQ9XCJcIiAvPjwvc3Bhbj48L2J1dHRvbj48Q2FydExpbmsgc2l6ZT17MjB9IC8+PExpbmsgdG89XCIvYWNjb3VudC9wcm9maWxlXCIgYXJpYS1sYWJlbD1cIlBlcmZpbFwiIG9uQ2xpY2s9e2V2ZW50ID0+IHsgaWYoc2Vzc2lvbi51c2VyKSB7IGV2ZW50LnByZXZlbnREZWZhdWx0KCk7IHNldEFjY291bnRPcGVuKHRydWUpIH0gfX0+PGltZyBzcmM9e21vYmlsZUljb25zLnByb2ZpbGV9IHdpZHRoPVwiMjBcIiBoZWlnaHQ9XCIyMFwiIGFsdD1cIlwiIC8+PC9MaW5rPlxyXG4gICAgICA8L25hdj59XHJcbiAgICAgIDxNb2RhbCB0aXRsZT1cIkZ1bmNpb25hbGlkYWRlIGluZGlzcG9uw612ZWxcIiBvcGVuPXshIW5vdGljZX0gb25DbG9zZT17KCkgPT4gc2V0Tm90aWNlKCcnKX0+PHA+e25vdGljZX08L3A+PC9Nb2RhbD5cclxuICAgICAgPE1vZGFsIHRpdGxlPVwiTWluaGEgY29udGFcIiBvcGVuPXthY2NvdW50T3Blbn0gb25DbG9zZT17KCkgPT4gc2V0QWNjb3VudE9wZW4oZmFsc2UpfT48bmF2IGNsYXNzTmFtZT1cImFjY291bnQtYWN0aW9uc1wiIGFyaWEtbGFiZWw9XCJBw6fDtWVzIGRhIGNvbnRhXCI+PExpbmsgdG89XCIvYWNjb3VudC9wcm9maWxlXCIgb25DbGljaz17KCkgPT4gc2V0QWNjb3VudE9wZW4oZmFsc2UpfT5NZXUgcGVyZmlsPC9MaW5rPjxMaW5rIHRvPVwiL2FjY291bnQvd2FsbGV0c1wiIHNlYXJjaD17eyByZXR1cm5UbzogJy8nIH19IG9uQ2xpY2s9eygpID0+IHNldEFjY291bnRPcGVuKGZhbHNlKX0+Q2FydGVpcmFzPC9MaW5rPjxidXR0b24gb25DbGljaz17KCkgPT4geyBzZXRBY2NvdW50T3BlbihmYWxzZSk7IGxvZ291dC5tdXRhdGUoKSB9fSBkaXNhYmxlZD17bG9nb3V0LmlzUGVuZGluZ30+RW5jZXJyYXIgc2Vzc8OjbzwvYnV0dG9uPjxidXR0b24gb25DbGljaz17KCkgPT4geyBzZXRBY2NvdW50T3BlbihmYWxzZSk7IGxvZ2luKCkgfX0+VHJvY2FyIHVzdcOhcmlvPC9idXR0b24+PC9uYXY+PC9Nb2RhbD5cclxuICAgIDwvZGl2PlxyXG4gIDwvU2lnbk91dENvbnRleHQuUHJvdmlkZXI+PC9Ob3RpY2VDb250ZXh0LlByb3ZpZGVyPlxyXG59XHJcbmZ1bmN0aW9uIEZvb3Rlcih7b25BY2NvdW50fToge29uQWNjb3VudDooKT0+dm9pZH0pIHtcclxuICBjb25zdCB1bmF2YWlsYWJsZSA9IHVzZVVuYXZhaWxhYmxlKCksIHNlc3Npb249dXNlU2Vzc2lvbigpXHJcbiAgY29uc3QgZ3JvdXBzID0gW1snTWV1IHBlcmZpbCcsICdNZXUgcGVyZmlsJywgJ01pbmhhIGNvbGXDp8OjbycsICdBdGl2aWRhZGUnLCAnRXN0w7pkaW8gZG8gY3JpYWRvcicsICdMaXN0YSBkZSBpbnRlcmVzc2UnXSwgWydDZW50cmFsIGRlIGFqdWRhJywgJ0NlbnRyYWwgZGUgYWp1ZGEnLCAnQ29tbyBjb21wcmFyIE5GVHMnLCAnQ2FydGVpcmEgZSBzZWd1cmFuw6dhJywgJ1BvbMOtdGljYSBkbyBtZXJjYWRvJywgJ0RlbnVuY2lhciBpdGVtJ10sIFsnQ29sZcOnw7VlcycsICdBcnRlIGRpZ2l0YWwnLCAnRm90b2dyYWZpYScsICdNw7pzaWNhJywgJ0FydGUgM0QnLCAnVXRpbGlkYWRlJ11dXHJcbiAgcmV0dXJuIDxmb290ZXIgY2xhc3NOYW1lPVwibWFya2V0LWZvb3RlclwiPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZW5lZml0c1wiPntbWydXJywgJ1NlZ3VyYW7Dp2EgZGEgY2FydGVpcmEnLCAnUHJvdGVqYSBzdWEgY2FydGVpcmEgZSBjb2xlY2lvbmUgYXJ0ZSBkaWdpdGFsIHZlcmlmaWNhZGEgY29tIGNvbmZpYW7Dp2EuJ10sIFsnQycsICdDcmlhZG9yZXMgZW0gZGVzdGFxdWUnLCAnQ29uaGXDp2EgYXJ0aXN0YXMsIGVzdMO6ZGlvcyBlIGNvbXVuaWRhZGVzIHF1ZSBtb2xkYW0gYSBjdWx0dXJhIGRpZ2l0YWwgbmEgcmVkZS4nXSwgWydEJywgJ0FsZXJ0YXMgZGUgbGFuw6dhbWVudG9zJywgJ1JlY2ViYSBjYWxlbmTDoXJpb3MgZGUgY3VuaGFnZW0sIG5vdmlkYWRlcyBkZSBsaXN0YXMgZGUgYWNlc3NvIGUgYW7DoWxpc2VzIGRvIG1lcmNhZG8uJ11dLm1hcCgoW2xldHRlciwgdGl0bGUsIGRlc2NyaXB0aW9uXSkgPT4gPHNlY3Rpb24ga2V5PXtsZXR0ZXJ9PjxzcGFuIGNsYXNzTmFtZT1cIm1lZGFsbGlvblwiPntsZXR0ZXJ9PC9zcGFuPjxoMz57dGl0bGV9PC9oMz48cD57ZGVzY3JpcHRpb259PC9wPjwvc2VjdGlvbj4pfVxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJuZXdzbGV0dGVyXCI+PGgzPkFudGVjaXBlLXNlIGFvIHByw7N4aW1vIGxhbsOnYW1lbnRvPC9oMz48Zm9ybSBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyB1bmF2YWlsYWJsZSgnTmV3c2xldHRlcicpIH19PjxsYWJlbCBjbGFzc05hbWU9XCJzci1vbmx5XCIgaHRtbEZvcj1cIm5ld3NsZXR0ZXJcIj5FLW1haWwgZGEgbmV3c2xldHRlcjwvbGFiZWw+PGlucHV0IGlkPVwibmV3c2xldHRlclwiIHR5cGU9XCJlbWFpbFwiIHBsYWNlaG9sZGVyPVwiZGlnaXRlIHNldSBlLW1haWwuLi5cIiAvPjxidXR0b24+RW52aWFyPC9idXR0b24+PC9mb3JtPjxwPlJlY2ViYSBsYW7Dp2FtZW50b3Mgc2VsZWNpb25hZG9zLCBoaXN0w7NyaWFzIGRlIGNyaWFkb3JlcyBlIG5vdmlkYWRlcyBkbyBtZXJjYWRvLjwvcD48L3NlY3Rpb24+XHJcbiAgICA8L2Rpdj5cclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1iYW5kXCI+PHNwYW4gY2xhc3NOYW1lPVwid29yZG1hcmtcIj5LVVJJTzwvc3Bhbj48c3Bhbj5GZWl0byBwYXJhIGNvbGVjaW9uYWRvcmVzLDxiciAvPmNyaWFkb3JlcyBlIGN1bHR1cmE8L3NwYW4+PGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB1bmF2YWlsYWJsZSgnQ29udGF0bycpfT5jb250YXRvQGVtYWlsLmNvbTwvYnV0dG9uPjxzcGFuPis1NSAxMSA0MDAyIDg5MjI8L3NwYW4+PC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZvb3Rlci1saW5rc1wiPntncm91cHMubWFwKChbdGl0bGUsIC4uLmxpbmtzXSkgPT4gPHNlY3Rpb24ga2V5PXt0aXRsZX0+PGgzPnt0aXRsZX08L2gzPntsaW5rcy5tYXAoKGxhYmVsKSA9PiBsYWJlbCA9PT0gJ01ldSBwZXJmaWwnID8gPExpbmsgdG89XCIvYWNjb3VudC9wcm9maWxlXCIga2V5PXtsYWJlbH0gb25DbGljaz17ZXZlbnQ9PntpZihzZXNzaW9uLnVzZXIgJiYgbWF0Y2hNZWRpYSgnKG1heC13aWR0aDo2MzlweCknKS5tYXRjaGVzKXtldmVudC5wcmV2ZW50RGVmYXVsdCgpO29uQWNjb3VudCgpfX19PntsYWJlbH08L0xpbms+IDogPGJ1dHRvbiBrZXk9e2xhYmVsfSBvbkNsaWNrPXsoKSA9PiB1bmF2YWlsYWJsZShsYWJlbCl9PntsYWJlbH08L2J1dHRvbj4pfTwvc2VjdGlvbj4pfTxzZWN0aW9uPjxoMz5SZWRlcyBzb2NpYWlzPC9oMz48ZGl2IGNsYXNzTmFtZT1cInNvY2lhbC1pY29uc1wiPntbJzk5MjgwLnN2ZycsICdkNDhkZC5zdmcnLCAnYjQxMTEuc3ZnJywgJ2I4Yjg0LnN2ZycsICdjYTJkYS5zdmcnXS5tYXAoKGFzc2V0LCBpKSA9PiA8YnV0dG9uIGFyaWEtbGFiZWw9e1snRmFjZWJvb2snLCAnSW5zdGFncmFtJywgJ1R3aXR0ZXInLCAnTGlua2VkSW4nLCAnWW91VHViZSddW2ldfSBrZXk9e2Fzc2V0fSBvbkNsaWNrPXsoKSA9PiB1bmF2YWlsYWJsZSgnUmVkZXMgc29jaWFpcycpfT48aW1nIHNyYz17YC9hc3NldHMvZmlnbWEvJHthc3NldH1gfSB3aWR0aD1cIjMwXCIgaGVpZ2h0PVwiMzBcIiBhbHQ9XCJcIiAvPjwvYnV0dG9uPil9PC9kaXY+PGgzPkNhcnRlaXJhcyBjb21wYXTDrXZlaXM8L2gzPjxwIGNsYXNzTmFtZT1cIndhbGxldC1jaGlwXCI+PHNwYW4+TUVUQU1BU0s8L3NwYW4+PHNwYW4+V0FMTEVUQ09OTkVDVDwvc3Bhbj48c3Bhbj5DT0lOQkFTRTwvc3Bhbj48L3A+PC9zZWN0aW9uPjwvZGl2PlxyXG4gICAgPHAgY2xhc3NOYW1lPVwiY29weXJpZ2h0XCI+wqkgMjAyNiBLdXJpby4gUHJvcHJpZWRhZGUgZGlnaXRhbCBwYXJhIHRvZG9zLjwvcD5cclxuICA8L2Zvb3Rlcj5cclxufVxyXG4iXX0=