import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/router.tsx");const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import { createRootRouteWithContext, createRoute, createRouter, lazyRouteComponent, Link, Outlet } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { detailOptions } from "/src/features/catalog/api.ts";
import { sessionOptions } from "/src/features/auth/session.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/app/router.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
const IntegrationProof = lazyRouteComponent(_c = () => import("/src/proof/IntegrationProof.tsx"), "IntegrationProof");
_c2 = IntegrationProof;
import { CatalogPage } from "/src/features/catalog/CatalogPage.tsx";
import { DetailPage } from "/src/features/catalog/DetailPage.tsx";
import { MarketShell } from "/src/features/catalog/MarketShell.tsx";
import { validateCatalogSearch, defaultCatalogSearch } from "/src/features/catalog/contracts.ts";
const AuthPage = lazyRouteComponent(_c3 = () => import("/src/features/auth/AuthPage.tsx"), "AuthPage");
_c4 = AuthPage;
import { authSearch, safeReturn } from "/src/features/auth/contracts.ts";
const CartPage = lazyRouteComponent(_c5 = () => import("/src/features/cart/CartPage.tsx"), "CartPage");
_c6 = CartPage;
import { RequireSession } from "/src/features/auth/RequireSession.tsx";
const ProfilePage = lazyRouteComponent(_c7 = () => import("/src/features/profile/ProfilePage.tsx"), "ProfilePage");
_c8 = ProfilePage;
const WalletsPage = lazyRouteComponent(_c9 = () => import("/src/features/wallets/WalletsPage.tsx"), "WalletsPage");
_c10 = WalletsPage;
const CheckoutPage = lazyRouteComponent(_c11 = () => import("/src/features/checkout/CheckoutPage.tsx"), "CheckoutPage");
_c12 = CheckoutPage;
const OrderPage = lazyRouteComponent(_c13 = () => import("/src/features/orders/OrderPage.tsx"), "OrderPage");
_c14 = OrderPage;
const rootRoute = createRootRouteWithContext()({
	component: Outlet,
	notFoundComponent: () => /* @__PURE__ */ _jsxDEV("main", {
		className: "p-8",
		children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Rota inexistente" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 50
		}, this), /* @__PURE__ */ _jsxDEV(Link, {
			to: "/",
			search: defaultCatalogSearch,
			className: "underline",
			children: "Voltar ao início"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 75
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 21,
		columnNumber: 28
	}, this)
});
const preparationRoute = createRoute({
	getParentRoute: () => rootRoute,
	path: "/preparation",
	component: () => /* @__PURE__ */ _jsxDEV("main", {
		className: "p-8",
		children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "mb-4 text-2xl font-bold",
			children: "Kurio · Preparação técnica"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 42
		}, this), /* @__PURE__ */ _jsxDEV(Link, {
			to: "/integration",
			className: "text-primary underline",
			children: "Abrir prova de integração"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 113
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 20
	}, this)
});
const marketRoute = createRoute({
	getParentRoute: () => rootRoute,
	id: "market",
	component: MarketShell,
	beforeLoad: ({ context }) => {
		void context.queryClient?.prefetchQuery(sessionOptions());
	}
});
export const catalogRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/",
	validateSearch: validateCatalogSearch,
	component: CatalogPage
});
export const detailRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/nfts/$nftId",
	validateSearch: (raw) => ({
		edition: typeof raw.edition === "string" && [
			"unique",
			"ten",
			"fifty",
			"open"
		].includes(raw.edition) ? raw.edition : "fifty",
		quantity: Number.isInteger(Number(raw.quantity)) && Number(raw.quantity) > 0 && Number(raw.quantity) <= 100 ? Number(raw.quantity) : 1
	}),
	component: DetailPage,
	beforeLoad: ({ context, params }) => {
		void context.queryClient?.prefetchQuery(detailOptions(params.nftId));
	}
});
const loginRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/login",
	validateSearch: authSearch,
	component: AuthPage
});
const signupRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/signup",
	validateSearch: authSearch,
	component: () => /* @__PURE__ */ _jsxDEV(AuthPage, { signup: true }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 30,
		columnNumber: 132
	}, this)
});
const cartRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/cart",
	component: CartPage
});
const profileRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/account/profile",
	component: () => /* @__PURE__ */ _jsxDEV(RequireSession, { children: /* @__PURE__ */ _jsxDEV(ProfilePage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 130
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 114
	}, this)
});
const walletsRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/account/wallets",
	validateSearch: (raw) => ({ returnTo: safeReturn(raw.returnTo) }),
	component: () => /* @__PURE__ */ _jsxDEV(RequireSession, { children: /* @__PURE__ */ _jsxDEV(WalletsPage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 222
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 33,
		columnNumber: 206
	}, this)
});
const checkoutRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/checkout",
	component: () => /* @__PURE__ */ _jsxDEV(RequireSession, { children: /* @__PURE__ */ _jsxDEV(CheckoutPage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 124
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 34,
		columnNumber: 108
	}, this)
});
export const orderRoute = createRoute({
	getParentRoute: () => marketRoute,
	path: "/orders/$orderId",
	component: () => /* @__PURE__ */ _jsxDEV(RequireSession, { children: /* @__PURE__ */ _jsxDEV(OrderPage, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 135
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 35,
		columnNumber: 119
	}, this)
});
const proofRoute = createRoute({
	getParentRoute: () => rootRoute,
	path: "/integration",
	component: IntegrationProof
});
export const router = createRouter({
	routeTree: rootRoute.addChildren([
		marketRoute.addChildren([
			catalogRoute,
			detailRoute,
			loginRoute,
			signupRoute,
			cartRoute,
			profileRoute,
			walletsRoute,
			checkoutRoute,
			orderRoute
		]),
		preparationRoute,
		proofRoute
	]),
	scrollRestoration: true
});
var _c, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14;
$RefreshReg$(_c, "IntegrationProof$lazyRouteComponent");
$RefreshReg$(_c2, "IntegrationProof");
$RefreshReg$(_c3, "AuthPage$lazyRouteComponent");
$RefreshReg$(_c4, "AuthPage");
$RefreshReg$(_c5, "CartPage$lazyRouteComponent");
$RefreshReg$(_c6, "CartPage");
$RefreshReg$(_c7, "ProfilePage$lazyRouteComponent");
$RefreshReg$(_c8, "ProfilePage");
$RefreshReg$(_c9, "WalletsPage$lazyRouteComponent");
$RefreshReg$(_c10, "WalletsPage");
$RefreshReg$(_c11, "CheckoutPage$lazyRouteComponent");
$RefreshReg$(_c12, "CheckoutPage");
$RefreshReg$(_c13, "OrderPage$lazyRouteComponent");
$RefreshReg$(_c14, "OrderPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/router.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/app/router.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/app/router.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/app/router.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyw0QkFBNEIsYUFBYSxjQUFjLG9CQUFvQixNQUFNLGNBQWM7QUFFeEcsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyxzQkFBc0I7OztBQUMvQixNQUFNLG1CQUFtQiw4QkFBeUIsT0FBTyw2QkFBNkIsa0JBQWtCOztBQUN4RyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHVCQUF1Qiw0QkFBNEI7QUFDNUQsTUFBTSxXQUFXLCtCQUF5QixPQUFPLDZCQUE2QixVQUFVOztBQUN4RixTQUFTLFlBQVksa0JBQWtCO0FBQ3ZDLE1BQU0sV0FBVywrQkFBeUIsT0FBTyw2QkFBNkIsVUFBVTs7QUFDeEYsU0FBUyxzQkFBc0I7QUFDL0IsTUFBTSxjQUFjLCtCQUF5QixPQUFPLG1DQUFtQyxhQUFhOztBQUNwRyxNQUFNLGNBQWMsK0JBQXlCLE9BQU8sbUNBQW1DLGFBQWE7O0FBQ3BHLE1BQU0sZUFBZSxnQ0FBeUIsT0FBTyxxQ0FBcUMsY0FBYzs7QUFDeEcsTUFBTSxZQUFZLGdDQUF5QixPQUFPLGdDQUFnQyxXQUFXOztBQUU3RixNQUFNLFlBQVksMkJBQTBELENBQUMsQ0FBQztDQUM1RSxXQUFXO0NBQ1gseUJBQXlCLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQXNCLHdCQUFDLE1BQUQsWUFBSSxtQkFBb0I7Ozs7WUFBQyx3QkFBQyxNQUFEO0dBQU0sSUFBRztHQUFJLFFBQVE7R0FBc0IsV0FBVTthQUFZO0VBQXNCOzs7O1VBQU87Ozs7OztBQUN4SyxDQUFDO0FBQ0QsTUFBTSxtQkFBbUIsWUFBWTtDQUFFLHNCQUFzQjtDQUFXLE1BQU07Q0FDNUUsaUJBQWlCLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO1lBQWhCLENBQXNCLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQTBCO0VBQThCOzs7O1lBQUMsd0JBQUMsTUFBRDtHQUFNLElBQUc7R0FBZSxXQUFVO2FBQXlCO0VBQStCOzs7O1VBQU87Ozs7OztBQUNqTixDQUFDO0FBQ0QsTUFBTSxjQUFjLFlBQVk7Q0FBRSxzQkFBc0I7Q0FBVyxJQUFJO0NBQVUsV0FBVztDQUFhLGFBQWEsRUFBRSxjQUFjO0VBQUUsS0FBSyxRQUFRLGFBQWEsY0FBYyxlQUFlLENBQUM7Q0FBRTtBQUFFLENBQUM7QUFDck0sT0FBTyxNQUFNLGVBQWUsWUFBWTtDQUFFLHNCQUFzQjtDQUFhLE1BQU07Q0FBSyxnQkFBZ0I7Q0FBdUIsV0FBVztBQUFZLENBQUM7QUFDdkosT0FBTyxNQUFNLGNBQWMsWUFBWTtDQUFFLHNCQUFzQjtDQUFhLE1BQU07Q0FBZ0IsaUJBQWlCLFNBQWtDO0VBQUUsU0FBUyxPQUFPLElBQUksWUFBWSxZQUFZO0dBQUM7R0FBVTtHQUFPO0dBQVM7RUFBTSxDQUFDLENBQUMsU0FBUyxJQUFJLE9BQU8sSUFBSSxJQUFJLFVBQVU7RUFBUyxVQUFVLE9BQU8sVUFBVSxPQUFPLElBQUksUUFBUSxDQUFDLEtBQUssT0FBTyxJQUFJLFFBQVEsSUFBSSxLQUFLLE9BQU8sSUFBSSxRQUFRLEtBQUssTUFBTSxPQUFPLElBQUksUUFBUSxJQUFJO0NBQUU7Q0FBSSxXQUFXO0NBQVksYUFBYSxFQUFFLFNBQVMsYUFBYTtFQUFFLEtBQUssUUFBUSxhQUFhLGNBQWMsY0FBYyxPQUFPLEtBQUssQ0FBQztDQUFFO0FBQUUsQ0FBQztBQUN0aUIsTUFBTSxhQUFhLFlBQVk7Q0FBRSxzQkFBc0I7Q0FBYSxNQUFNO0NBQVUsZ0JBQWdCO0NBQVksV0FBVztBQUFTLENBQUM7QUFDckksTUFBTSxjQUFjLFlBQVk7Q0FBRSxzQkFBc0I7Q0FBYSxNQUFNO0NBQVcsZ0JBQWdCO0NBQVksaUJBQWlCLHdCQUFDLFVBQUQsRUFBVSxhQUFROzs7OztBQUFFLENBQUM7QUFDeEosTUFBTSxZQUFZLFlBQVk7Q0FBRSxzQkFBc0I7Q0FBYSxNQUFNO0NBQVMsV0FBVztBQUFTLENBQUM7QUFDdkcsTUFBTSxlQUFlLFlBQVk7Q0FBRSxzQkFBc0I7Q0FBYSxNQUFNO0NBQW9CLGlCQUFpQix3QkFBQyxnQkFBRCxZQUFnQix3QkFBQyxhQUFELENBQWM7Ozs7VUFBaUI7Ozs7O0FBQUUsQ0FBQztBQUNuSyxNQUFNLGVBQWUsWUFBWTtDQUFFLHNCQUFzQjtDQUFhLE1BQU07Q0FBb0IsaUJBQWlCLFNBQWtDLEVBQUUsVUFBVSxXQUFXLElBQUksUUFBUSxFQUFFO0NBQUksaUJBQWlCLHdCQUFDLGdCQUFELFlBQWdCLHdCQUFDLGFBQUQsQ0FBYzs7OztVQUFpQjs7Ozs7QUFBRSxDQUFDO0FBQy9QLE1BQU0sZ0JBQWdCLFlBQVk7Q0FBRSxzQkFBc0I7Q0FBYSxNQUFNO0NBQWEsaUJBQWlCLHdCQUFDLGdCQUFELFlBQWdCLHdCQUFDLGNBQUQsQ0FBZTs7OztVQUFpQjs7Ozs7QUFBRSxDQUFDO0FBQzlKLE9BQU8sTUFBTSxhQUFhLFlBQVk7Q0FBRSxzQkFBc0I7Q0FBYSxNQUFNO0NBQW9CLGlCQUFpQix3QkFBQyxnQkFBRCxZQUFnQix3QkFBQyxXQUFELENBQVk7Ozs7VUFBaUI7Ozs7O0FBQUUsQ0FBQztBQUN0SyxNQUFNLGFBQWEsWUFBWTtDQUFFLHNCQUFzQjtDQUFXLE1BQU07Q0FBZ0IsV0FBVztBQUFpQixDQUFDO0FBQ3JILE9BQU8sTUFBTSxTQUFTLGFBQWE7Q0FBRSxXQUFXLFVBQVUsWUFBWTtFQUFDLFlBQVksWUFBWTtHQUFDO0dBQWM7R0FBYTtHQUFZO0dBQWE7R0FBVztHQUFjO0dBQWM7R0FBZTtFQUFVLENBQUM7RUFBRztFQUFrQjtDQUFVLENBQUM7Q0FBRyxtQkFBbUI7QUFBSyxDQUFDIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInJvdXRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHQsIGNyZWF0ZVJvdXRlLCBjcmVhdGVSb3V0ZXIsIGxhenlSb3V0ZUNvbXBvbmVudCwgTGluaywgT3V0bGV0IH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcclxuaW1wb3J0IHR5cGUgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgZGV0YWlsT3B0aW9ucyB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9hcGknXHJcbmltcG9ydCB7IHNlc3Npb25PcHRpb25zIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL3Nlc3Npb24nXHJcbmNvbnN0IEludGVncmF0aW9uUHJvb2YgPSBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL3Byb29mL0ludGVncmF0aW9uUHJvb2YnKSwgJ0ludGVncmF0aW9uUHJvb2YnKVxyXG5pbXBvcnQgeyBDYXRhbG9nUGFnZSB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9DYXRhbG9nUGFnZSdcclxuaW1wb3J0IHsgRGV0YWlsUGFnZSB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9EZXRhaWxQYWdlJ1xyXG5pbXBvcnQgeyBNYXJrZXRTaGVsbCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9NYXJrZXRTaGVsbCdcclxuaW1wb3J0IHsgdmFsaWRhdGVDYXRhbG9nU2VhcmNoLCBkZWZhdWx0Q2F0YWxvZ1NlYXJjaCB9IGZyb20gJ0AvZmVhdHVyZXMvY2F0YWxvZy9jb250cmFjdHMnXHJcbmNvbnN0IEF1dGhQYWdlID0gbGF6eVJvdXRlQ29tcG9uZW50KCgpID0+IGltcG9ydCgnQC9mZWF0dXJlcy9hdXRoL0F1dGhQYWdlJyksICdBdXRoUGFnZScpXHJcbmltcG9ydCB7IGF1dGhTZWFyY2gsIHNhZmVSZXR1cm4gfSBmcm9tICdAL2ZlYXR1cmVzL2F1dGgvY29udHJhY3RzJ1xyXG5jb25zdCBDYXJ0UGFnZSA9IGxhenlSb3V0ZUNvbXBvbmVudCgoKSA9PiBpbXBvcnQoJ0AvZmVhdHVyZXMvY2FydC9DYXJ0UGFnZScpLCAnQ2FydFBhZ2UnKVxyXG5pbXBvcnQgeyBSZXF1aXJlU2Vzc2lvbiB9IGZyb20gJ0AvZmVhdHVyZXMvYXV0aC9SZXF1aXJlU2Vzc2lvbidcclxuY29uc3QgUHJvZmlsZVBhZ2UgPSBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL2ZlYXR1cmVzL3Byb2ZpbGUvUHJvZmlsZVBhZ2UnKSwgJ1Byb2ZpbGVQYWdlJylcclxuY29uc3QgV2FsbGV0c1BhZ2UgPSBsYXp5Um91dGVDb21wb25lbnQoKCkgPT4gaW1wb3J0KCdAL2ZlYXR1cmVzL3dhbGxldHMvV2FsbGV0c1BhZ2UnKSwgJ1dhbGxldHNQYWdlJylcclxuY29uc3QgQ2hlY2tvdXRQYWdlID0gbGF6eVJvdXRlQ29tcG9uZW50KCgpID0+IGltcG9ydCgnQC9mZWF0dXJlcy9jaGVja291dC9DaGVja291dFBhZ2UnKSwgJ0NoZWNrb3V0UGFnZScpXHJcbmNvbnN0IE9yZGVyUGFnZSA9IGxhenlSb3V0ZUNvbXBvbmVudCgoKSA9PiBpbXBvcnQoJ0AvZmVhdHVyZXMvb3JkZXJzL09yZGVyUGFnZScpLCAnT3JkZXJQYWdlJylcclxuXHJcbmNvbnN0IHJvb3RSb3V0ZSA9IGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0PHsgcXVlcnlDbGllbnQ/OiBRdWVyeUNsaWVudCB9PigpKHtcclxuICBjb21wb25lbnQ6IE91dGxldCxcclxuICBub3RGb3VuZENvbXBvbmVudDogKCkgPT4gPG1haW4gY2xhc3NOYW1lPVwicC04XCI+PGgxPlJvdGEgaW5leGlzdGVudGU8L2gxPjxMaW5rIHRvPVwiL1wiIHNlYXJjaD17ZGVmYXVsdENhdGFsb2dTZWFyY2h9IGNsYXNzTmFtZT1cInVuZGVybGluZVwiPlZvbHRhciBhbyBpbsOtY2lvPC9MaW5rPjwvbWFpbj4sXHJcbn0pXHJcbmNvbnN0IHByZXBhcmF0aW9uUm91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsIHBhdGg6ICcvcHJlcGFyYXRpb24nLFxyXG4gIGNvbXBvbmVudDogKCkgPT4gPG1haW4gY2xhc3NOYW1lPVwicC04XCI+PGgxIGNsYXNzTmFtZT1cIm1iLTQgdGV4dC0yeGwgZm9udC1ib2xkXCI+S3VyaW8gwrcgUHJlcGFyYcOnw6NvIHTDqWNuaWNhPC9oMT48TGluayB0bz1cIi9pbnRlZ3JhdGlvblwiIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeSB1bmRlcmxpbmVcIj5BYnJpciBwcm92YSBkZSBpbnRlZ3Jhw6fDo288L0xpbms+PC9tYWluPixcclxufSlcclxuY29uc3QgbWFya2V0Um91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiByb290Um91dGUsIGlkOiAnbWFya2V0JywgY29tcG9uZW50OiBNYXJrZXRTaGVsbCwgYmVmb3JlTG9hZDogKHsgY29udGV4dCB9KSA9PiB7IHZvaWQgY29udGV4dC5xdWVyeUNsaWVudD8ucHJlZmV0Y2hRdWVyeShzZXNzaW9uT3B0aW9ucygpKSB9IH0pXHJcbmV4cG9ydCBjb25zdCBjYXRhbG9nUm91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiBtYXJrZXRSb3V0ZSwgcGF0aDogJy8nLCB2YWxpZGF0ZVNlYXJjaDogdmFsaWRhdGVDYXRhbG9nU2VhcmNoLCBjb21wb25lbnQ6IENhdGFsb2dQYWdlIH0pXHJcbmV4cG9ydCBjb25zdCBkZXRhaWxSb3V0ZSA9IGNyZWF0ZVJvdXRlKHsgZ2V0UGFyZW50Um91dGU6ICgpID0+IG1hcmtldFJvdXRlLCBwYXRoOiAnL25mdHMvJG5mdElkJywgdmFsaWRhdGVTZWFyY2g6IChyYXc6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KSA9PiAoeyBlZGl0aW9uOiB0eXBlb2YgcmF3LmVkaXRpb24gPT09ICdzdHJpbmcnICYmIFsndW5pcXVlJywgJ3RlbicsICdmaWZ0eScsICdvcGVuJ10uaW5jbHVkZXMocmF3LmVkaXRpb24pID8gcmF3LmVkaXRpb24gOiAnZmlmdHknLCBxdWFudGl0eTogTnVtYmVyLmlzSW50ZWdlcihOdW1iZXIocmF3LnF1YW50aXR5KSkgJiYgTnVtYmVyKHJhdy5xdWFudGl0eSkgPiAwICYmIE51bWJlcihyYXcucXVhbnRpdHkpIDw9IDEwMCA/IE51bWJlcihyYXcucXVhbnRpdHkpIDogMSB9KSwgY29tcG9uZW50OiBEZXRhaWxQYWdlLCBiZWZvcmVMb2FkOiAoeyBjb250ZXh0LCBwYXJhbXMgfSkgPT4geyB2b2lkIGNvbnRleHQucXVlcnlDbGllbnQ/LnByZWZldGNoUXVlcnkoZGV0YWlsT3B0aW9ucyhwYXJhbXMubmZ0SWQpKSB9IH0pXHJcbmNvbnN0IGxvZ2luUm91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiBtYXJrZXRSb3V0ZSwgcGF0aDogJy9sb2dpbicsIHZhbGlkYXRlU2VhcmNoOiBhdXRoU2VhcmNoLCBjb21wb25lbnQ6IEF1dGhQYWdlIH0pXHJcbmNvbnN0IHNpZ251cFJvdXRlID0gY3JlYXRlUm91dGUoeyBnZXRQYXJlbnRSb3V0ZTogKCkgPT4gbWFya2V0Um91dGUsIHBhdGg6ICcvc2lnbnVwJywgdmFsaWRhdGVTZWFyY2g6IGF1dGhTZWFyY2gsIGNvbXBvbmVudDogKCkgPT4gPEF1dGhQYWdlIHNpZ251cCAvPiB9KVxyXG5jb25zdCBjYXJ0Um91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiBtYXJrZXRSb3V0ZSwgcGF0aDogJy9jYXJ0JywgY29tcG9uZW50OiBDYXJ0UGFnZSB9KVxyXG5jb25zdCBwcm9maWxlUm91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiBtYXJrZXRSb3V0ZSwgcGF0aDogJy9hY2NvdW50L3Byb2ZpbGUnLCBjb21wb25lbnQ6ICgpID0+IDxSZXF1aXJlU2Vzc2lvbj48UHJvZmlsZVBhZ2UgLz48L1JlcXVpcmVTZXNzaW9uPiB9KVxyXG5jb25zdCB3YWxsZXRzUm91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiBtYXJrZXRSb3V0ZSwgcGF0aDogJy9hY2NvdW50L3dhbGxldHMnLCB2YWxpZGF0ZVNlYXJjaDogKHJhdzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4pID0+ICh7IHJldHVyblRvOiBzYWZlUmV0dXJuKHJhdy5yZXR1cm5UbykgfSksIGNvbXBvbmVudDogKCkgPT4gPFJlcXVpcmVTZXNzaW9uPjxXYWxsZXRzUGFnZSAvPjwvUmVxdWlyZVNlc3Npb24+IH0pXHJcbmNvbnN0IGNoZWNrb3V0Um91dGUgPSBjcmVhdGVSb3V0ZSh7IGdldFBhcmVudFJvdXRlOiAoKSA9PiBtYXJrZXRSb3V0ZSwgcGF0aDogJy9jaGVja291dCcsIGNvbXBvbmVudDogKCkgPT4gPFJlcXVpcmVTZXNzaW9uPjxDaGVja291dFBhZ2UgLz48L1JlcXVpcmVTZXNzaW9uPiB9KVxyXG5leHBvcnQgY29uc3Qgb3JkZXJSb3V0ZSA9IGNyZWF0ZVJvdXRlKHsgZ2V0UGFyZW50Um91dGU6ICgpID0+IG1hcmtldFJvdXRlLCBwYXRoOiAnL29yZGVycy8kb3JkZXJJZCcsIGNvbXBvbmVudDogKCkgPT4gPFJlcXVpcmVTZXNzaW9uPjxPcmRlclBhZ2UgLz48L1JlcXVpcmVTZXNzaW9uPiB9KVxyXG5jb25zdCBwcm9vZlJvdXRlID0gY3JlYXRlUm91dGUoeyBnZXRQYXJlbnRSb3V0ZTogKCkgPT4gcm9vdFJvdXRlLCBwYXRoOiAnL2ludGVncmF0aW9uJywgY29tcG9uZW50OiBJbnRlZ3JhdGlvblByb29mIH0pXHJcbmV4cG9ydCBjb25zdCByb3V0ZXIgPSBjcmVhdGVSb3V0ZXIoeyByb3V0ZVRyZWU6IHJvb3RSb3V0ZS5hZGRDaGlsZHJlbihbbWFya2V0Um91dGUuYWRkQ2hpbGRyZW4oW2NhdGFsb2dSb3V0ZSwgZGV0YWlsUm91dGUsIGxvZ2luUm91dGUsIHNpZ251cFJvdXRlLCBjYXJ0Um91dGUsIHByb2ZpbGVSb3V0ZSwgd2FsbGV0c1JvdXRlLCBjaGVja291dFJvdXRlLCBvcmRlclJvdXRlXSksIHByZXBhcmF0aW9uUm91dGUsIHByb29mUm91dGVdKSwgc2Nyb2xsUmVzdG9yYXRpb246IHRydWUgfSlcclxuZGVjbGFyZSBtb2R1bGUgJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInIHsgaW50ZXJmYWNlIFJlZ2lzdGVyIHsgcm91dGVyOiB0eXBlb2Ygcm91dGVyIH0gfVxyXG4iXX0=