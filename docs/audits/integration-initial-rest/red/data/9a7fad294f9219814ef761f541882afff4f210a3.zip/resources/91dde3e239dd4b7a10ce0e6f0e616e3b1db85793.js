"use client";
import { r as __toESM, t as __commonJSMin } from "/node_modules/.vite/deps/rolldown-runtime-DC62tzP2.js?v=2117f7ee";
import { t as require_react } from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/react_jsx-runtime.js?v=4f1d3af0";
//#region node_modules/@tanstack/router-core/dist/esm/not-found.js
/**
* Create a not-found error object recognized by TanStack Router.
*
* Throw this from loaders/actions to trigger the nearest `notFoundComponent`.
* Use `routeId` to target a specific route's not-found boundary. If `throw`
* is true, the error is thrown instead of returned.
*
* @param options Optional settings including `routeId`, `headers`, and `throw`.
* @returns A not-found error object that can be thrown or returned.
* @link https://tanstack.com/router/latest/docs/router/framework/react/api/router/notFoundFunction
*/
function notFound(options = {}) {
	options.isNotFound = true;
	if (options.throw) throw options;
	return options;
}
/** Determine if a value is a TanStack Router not-found error. */
function isNotFound(obj) {
	return obj?.isNotFound === true;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/root.js
/** Stable identifier used for the root route in a route tree. */
var rootRouteId = "__root__";
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/redirect.js
/**
* Create a redirect Response understood by TanStack Router.
*
* Use from route `loader`/`beforeLoad` or server functions to trigger a
* navigation. If `throw: true` is set, the redirect is thrown instead of
* returned. External `href` values are classified as full-document
* navigations when the router resolves the redirect.
*
* @param opts Options for the redirect. Common fields:
* - `href`: absolute URL for external redirects.
* - `statusCode`: HTTP status code to use (defaults to 307).
* - `headers`: additional headers to include on the Response.
* - Standard navigation options like `to`, `params`, `search`, `replace`,
*   and `reloadDocument` for internal redirects.
* @returns A Response augmented with router navigation options.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/redirectFunction
*/
function redirect(opts) {
	opts.statusCode = opts.statusCode || opts.code || 307;
	const headers = new Headers(opts.headers);
	if (opts.href && headers.get("Location") === null) headers.set("Location", opts.href);
	const response = new Response(null, {
		status: opts.statusCode,
		headers
	});
	response.options = opts;
	if (opts.throw) throw response;
	return response;
}
/** Check whether a value is a TanStack Router redirect Response. */
function isRedirect(obj) {
	return obj instanceof Response && !!obj.options;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/utils.js
/**
* Return the last element of an array.
* Intended for non-empty arrays used within router internals.
*/
function last(arr) {
	return arr[arr.length - 1];
}
/**
* Apply a value-or-updater to a previous value.
* Accepts either a literal value or a function of the previous value.
*/
function functionalUpdate(updater, previous) {
	if (typeof updater === "function") return updater(previous);
	return updater;
}
var hasOwn = Object.prototype.hasOwnProperty;
function hasKeys(obj) {
	for (const key in obj) if (hasOwn.call(obj, key)) return true;
	return false;
}
var createNull = () => Object.create(null);
var nullReplaceEqualDeep = (prev, next) => replaceEqualDeep(prev, next, true);
function replaceEqualDeep(prev, next, _nullProto, _depth = 0) {
	if (prev === next) return prev;
	if (_depth++ > 500) return next;
	const array = Array.isArray(prev) && Array.isArray(next);
	if (!array && !(isPlainObject(prev) && isPlainObject(next))) return next;
	const prevKeys = Object.keys(prev);
	const previousCount = prevKeys.length;
	const nextKeys = Object.keys(next);
	const length = nextKeys.length;
	if (array ? previousCount !== prev.length || length !== next.length || previousCount && last(prevKeys) !== `${previousCount - 1}` || length && last(nextKeys) !== `${length - 1}` : previousCount !== Object.getOwnPropertyNames(prev).length || length !== Object.getOwnPropertyNames(next).length || Object.getOwnPropertySymbols(next).length) return next;
	let i = 0;
	let child;
	let previous;
	let key;
	if (array) {
		for (; i < length; i++) {
			key = i;
			previous = prev[key];
			child = next[key];
			child = previous === child ? previous : typeof previous === "object" ? replaceEqualDeep(previous, child, _nullProto, _depth) : child;
			if (child !== previous) break;
		}
		if (i === length && previousCount === length) return prev;
	} else {
		let equal = previousCount === length;
		let unchanged = true;
		for (; i < length; i++) {
			key = nextKeys[i];
			previous = prev[key];
			const incoming = next[key];
			child = previous === incoming ? previous : typeof previous === "object" ? replaceEqualDeep(previous, incoming, _nullProto, _depth) : incoming;
			equal &&= child === previous && (prevKeys[i] === key || hasOwn.call(prev, key));
			unchanged &&= Object.is(child, incoming);
			prevKeys[i] = child;
		}
		if (equal) return Object.getOwnPropertySymbols(prev).length ? next : prev;
		if (unchanged) return next;
	}
	const copy = array ? nextKeys.fill(0) : _nullProto ? createNull() : {};
	for (let j = 0; j < length; j++) {
		key = array ? j : nextKeys[j];
		if (array) {
			previous = prev[key];
			if (j > i) {
				child = next[key];
				child = previous === child ? previous : typeof previous === "object" ? replaceEqualDeep(previous, child, _nullProto, _depth) : child;
			}
			copy[key] = j < i ? previous : child;
		} else copy[key] = prevKeys[j];
	}
	return copy;
}
function isPlainObject(o) {
	if (!o || typeof o !== "object") return false;
	return (Object.getPrototypeOf(o)?.constructor ?? Object) === Object;
}
/**
* Perform a deep equality check optimized for router state comparisons.
*
* - `partial`: `b` may omit keys that `a` has (arrays stay length-exact).
* - `explicitUndefined`: keys holding `undefined` take part in the comparison
*   instead of being ignored.
*
* Internal: the flags are positional so hot callers pass no options object.
*/
function deepEqual(a, b, partial, explicitUndefined) {
	if (a === b) return true;
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return false;
		for (let i = 0, l = a.length; i < l; i++) {
			const av = a[i];
			const bv = b[i];
			if (av !== bv && !deepEqual(av, bv, partial, explicitUndefined)) return false;
		}
		return true;
	}
	if (isPlainObject(a) && isPlainObject(b)) {
		if (partial) {
			for (const k in b) if (explicitUndefined || b[k] !== void 0) {
				if (!deepEqual(a[k], b[k], partial, explicitUndefined)) return false;
			}
			return true;
		}
		let aCount = 0;
		if (explicitUndefined) aCount = Object.keys(a).length;
		else for (const k in a) if (a[k] !== void 0) aCount++;
		for (const k in b) if (explicitUndefined || b[k] !== void 0) {
			if (aCount-- === 0 || !deepEqual(a[k], b[k], partial, explicitUndefined)) return false;
		}
		return aCount === 0;
	}
	return false;
}
/**
* Create a promise with exposed resolve/reject and status fields.
* Useful for coordinating async router lifecycle operations.
*/
function createControlledPromise(onResolve) {
	let resolveLoadPromise;
	let rejectLoadPromise;
	const controlledPromise = new Promise((resolve, reject) => {
		resolveLoadPromise = resolve;
		rejectLoadPromise = reject;
	});
	controlledPromise.status = "pending";
	controlledPromise.resolve = (value) => {
		controlledPromise.status = "resolved";
		controlledPromise.value = value;
		resolveLoadPromise(value);
		onResolve?.(value);
	};
	controlledPromise.reject = (e) => {
		controlledPromise.status = "rejected";
		rejectLoadPromise(e);
	};
	return controlledPromise;
}
/**
* Heuristically detect dynamic import "module not found" errors
* across major browsers for lazy route component handling.
*/
function isModuleNotFoundError(error) {
	if (typeof error?.message !== "string") return false;
	return error.message.startsWith("Failed to fetch dynamically imported module") || error.message.startsWith("error loading dynamically imported module") || error.message.startsWith("Importing a module script failed");
}
function findLast(array, predicate) {
	for (let i = array.length - 1; i >= 0; i--) {
		const item = array[i];
		if (predicate(item)) return item;
	}
}
/**
* Re-encode characters that are unsafe in URL paths.
* Includes ASCII control characters (0x00-0x1F, 0x7F) and a subset of the
* WHATWG URL "path percent-encode set" (", <, >, `, {, }).
*
* Space (0x20) is intentionally excluded — decodeURI decodes %20 to space
* and the router stores decoded spaces in location.pathname. The existing
* encodePathLikeUrl already handles re-encoding spaces for outgoing URLs.
*
* These characters are decoded by decodeURI but must remain percent-encoded
* in paths to match how upstream layers (CDNs, edge middleware, browsers)
* interpret the URL, preventing infinite redirect loops and path mismatches.
*/
var PATH_UNSAFE_RE = /[\x00-\x1f\x7f"<>`{}]/g;
function sanitizePathSegment(segment) {
	return segment.replace(PATH_UNSAFE_RE, (ch) => "%" + ch.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0"));
}
function decodeSegment(segment) {
	let decoded;
	try {
		decoded = decodeURI(segment);
	} catch {
		decoded = segment.replaceAll(/%[0-9A-F]{2}/gi, (match) => {
			try {
				return decodeURI(match);
			} catch {
				return match;
			}
		});
	}
	return sanitizePathSegment(decoded);
}
/**
* Default list of URL protocols to allow in links, redirects, and navigation.
* Any absolute URL protocol not in this list is treated as dangerous by default.
*/
var DEFAULT_PROTOCOL_ALLOWLIST = [
	"http:",
	"https:",
	"mailto:",
	"tel:"
];
/**
* Extract the explicit URL scheme, including its colon, using WHATWG
* normalization rules. This does not validate the rest of the URL.
*
* Returning `undefined` means "no explicit scheme", not "safe URL";
* protocol-relative URLs such as "//evil.example" require a separate check.
*/
function getUrlScheme(url) {
	if (url[0] === "/") return;
	if (!url.includes(":")) return;
	return /^[\x00-\x20]*([a-z][a-z\d+.\t\n\r-]*:)/i.exec(url)?.[1]?.replace(/[\t\n\r]/g, "").toLowerCase();
}
var protocolRelativePrefixRegex = /^[\x00-\x20]*[\\/][\t\n\r]*[\\/]/;
/**
* Check if a URL string uses a protocol that is not in the allowlist or is
* protocol-relative (e.g. "//evil.example"), which can navigate to another host.
* Returns true for blocked protocols like javascript:, blob:, and data:, as
* well as slash/backslash variants of protocol-relative URLs.
*
* Scheme parsing normalizes:
* - Mixed case (JavaScript: → javascript:)
* - Whitespace/control characters (java\nscript: → javascript:)
* - Leading whitespace
*
* For relative URLs without a protocol-relative prefix, returns false.
*
* @param url - The URL string to check
* @param allowlist - Set of protocols to allow
* @returns true if the URL uses a protocol that is not allowed or can escape
* the current origin through a protocol-relative URL
*/
function isDangerousProtocol(url, allowlist) {
	if (!url) return false;
	if (protocolRelativePrefixRegex.test(url)) return true;
	const scheme = getUrlScheme(url);
	return scheme ? !allowlist.has(scheme) : false;
}
var HTML_ESCAPE_LOOKUP = {
	"&": "\\u0026",
	">": "\\u003e",
	"<": "\\u003c",
	"\u2028": "\\u2028",
	"\u2029": "\\u2029"
};
var HTML_ESCAPE_REGEX = /[&><\u2028\u2029]/g;
/**
* Escape HTML special characters in a string to prevent XSS attacks
* when embedding strings in script tags during SSR.
*
* This is essential for preventing XSS vulnerabilities when user-controlled
* content is embedded in inline scripts.
*/
function escapeHtml(str) {
	return str.replace(HTML_ESCAPE_REGEX, (match) => HTML_ESCAPE_LOOKUP[match]);
}
function decodePath(path) {
	if (!path) return path;
	let result = path;
	if (/[%\\\x00-\x1f\x7f]/.test(path)) {
		const re = /%25|%5C/gi;
		let cursor = 0;
		let match;
		result = "";
		while (null !== (match = re.exec(path))) {
			result += decodeSegment(path.slice(cursor, match.index)) + match[0];
			cursor = re.lastIndex;
		}
		result += decodeSegment(cursor ? path.slice(cursor) : path);
	}
	return result;
}
/**
* Encodes a path the same way `new URL()` would, but without the overhead of full URL parsing.
*
* This function encodes:
* - Whitespace characters (spaces → %20, tabs → %09, etc.)
* - Non-ASCII/Unicode characters (emojis, accented characters, etc.)
*
* It preserves:
* - Already percent-encoded sequences (won't double-encode %2F, %25, etc.)
* - ASCII special characters valid in URL paths (@, $, &, +, etc.)
* - Forward slashes as path separators
*
* Used to generate proper href values for SSR without constructing URL objects.
*
* @example
* encodePathLikeUrl('/path/file name.pdf') // '/path/file%20name.pdf'
* encodePathLikeUrl('/path/日本語') // '/path/%E6%97%A5%E6%9C%AC%E8%AA%9E'
* encodePathLikeUrl('/path/already%20encoded') // '/path/already%20encoded' (preserved)
*/
function encodePathLikeUrl(path) {
	if (!/[\s\u0080-\uFFFF]/.test(path)) return path;
	return path.replace(/\s|[^\u0000-\u007F]/gu, encodeURIComponent);
}
function arraysEqual(a, b) {
	if (a === b) return true;
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/path.js
/** Join path segments, cleaning duplicate slashes between parts. */
function joinPaths(paths) {
	return cleanPath(paths.filter((val) => {
		return val !== void 0;
	}).join("/"));
}
/** Remove repeated slashes from a path string. */
function cleanPath(path) {
	return path.replace(/\/{2,}/g, "/");
}
/** Trim leading slashes (except preserving root '/'). */
function trimPathLeft(path) {
	return path === "/" ? path : path.replace(/^\/+/, "");
}
/** Trim trailing slashes (except preserving root '/'). */
function trimPathRight(path) {
	const len = path.length;
	return len > 1 && path[len - 1] === "/" ? path.replace(/\/+$/, "") : path;
}
/** Trim both leading and trailing slashes. */
function trimPath(path) {
	return trimPathRight(trimPathLeft(path));
}
/** Remove a trailing slash from value when appropriate for comparisons. */
function removeTrailingSlash(value, basepath) {
	if (value?.endsWith("/") && value !== "/" && value !== `${basepath}/`) return value.slice(0, -1);
	return value;
}
/**
* Resolve a destination path against a base, honoring trailing-slash policy
* and supporting relative segments (`.`/`..`) and absolute `to` values.
*
* Internal: parameters are positional so the router's hot callers pass no
* options object.
*/
function resolvePath(base, to, trailingSlash = "never", cache) {
	if (to.includes("//")) to = cleanPath(to);
	if (to.startsWith("/")) {
		if (to.length === 1 || trailingSlash === "preserve") return to;
		if (trailingSlash === "always") return to.endsWith("/") ? to : `${to}/`;
		return to.endsWith("/") ? to.slice(0, -1) : to;
	}
	const isBase = to === ".";
	let key;
	if (cache) {
		key = isBase ? base : base + "\0" + to;
		const cached = cache.get(key);
		if (cached) return cached;
	}
	let baseSegments;
	if (isBase) baseSegments = base.split("/");
	else {
		if (base.includes("//")) base = cleanPath(base);
		baseSegments = base.split("/");
		while (baseSegments.length > 1 && last(baseSegments) === "") baseSegments.pop();
		const toSegments = to.split("/");
		for (let index = 0, length = toSegments.length; index < length; index++) {
			const value = toSegments[index];
			if (value === "") {
				if (!index) baseSegments = [value];
				else if (index === length - 1) baseSegments.push(value);
			} else if (value === "..") if (baseSegments.length > 1) baseSegments.pop();
			else baseSegments = [""];
			else if (value === ".") {} else baseSegments.push(value);
		}
	}
	if (baseSegments.length > 1) {
		if (last(baseSegments) === "") {
			if (trailingSlash === "never") baseSegments.pop();
		} else if (trailingSlash === "always") baseSegments.push("");
	}
	const joined = baseSegments.join("/");
	const result = (isBase ? cleanPath(joined) : joined) || "/";
	if (key && cache) cache.set(key, result);
	return result;
}
/**
* Create a pre-compiled decode config from allowed characters.
* Created once for the router's fixed encoding configuration.
*/
function compileDecodeCharMap(pathParamsAllowedCharacters) {
	const charMap = new Map(pathParamsAllowedCharacters.map((char) => [encodeURIComponent(char), char]));
	const regex = new RegExp([...charMap.keys()].join("|").replace(/[.*()]/g, "\\$&"), "g");
	return (encoded) => encoded.replace(regex, (match) => charMap.get(match) ?? match);
}
/** A splat is missing when it has no value; `0` and `false` are stringified like any other param. */
function isMissingSplat(value) {
	return value == null || value === "";
}
function encodeParam(key, value, decoder) {
	if (typeof value !== "string") return "" + (value ?? void 0);
	const splat = key === "_splat";
	if (splat && (!value || /^[a-zA-Z0-9\-._~!/]*$/.test(value))) return value;
	let encoded = encodeURIComponent(value);
	if (splat) encoded = encoded.replaceAll("%2F", "/");
	return decoder ? decoder(encoded) : encoded;
}
/** Substitute current values into parsed segments, optionally collecting raw params. */
function interpolatePath(path, segments, params, decoder, usedParams) {
	const trailingSlash = path.endsWith("/") ? "/" : "";
	let joined = "";
	for (const part of segments) {
		if (typeof part === "string") {
			joined += part;
			continue;
		}
		const [kind, key, prefix, rawSuffix] = part;
		const splat = kind === 2;
		const suffix = splat && rawSuffix !== void 0 ? rawSuffix + trailingSlash : rawSuffix;
		let paramValue = params[key];
		if (kind === 3 && paramValue == null) continue;
		if (usedParams) {
			usedParams[key] = paramValue;
			if (splat) usedParams["*"] = paramValue;
		}
		if (splat && isMissingSplat(paramValue)) {
			if (prefix === "/" && !suffix) continue;
			paramValue = "";
		}
		joined += prefix + encodeParam(key, paramValue, decoder) + (suffix || "");
	}
	return joined + trailingSlash || "/";
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/sieve-cache.js
/**
* A fixed-capacity cache using the SIEVE eviction algorithm
* (https://cachemon.github.io/SIEVE-website/).
*
* Entries live in the Map's FIFO insertion order; a hit only flips a `visited`
* bit instead of relinking the entry, which makes `get` (by far the hottest
* operation here) one `Map.get` plus a boolean store. Eviction sweeps a `hand`
* from the oldest entry towards the newest, clearing `visited` bits until it
* finds an unvisited entry to drop, so entries touched since the last sweep
* survive one more round. This keeps LRU-like hit ratios while being
* scan-resistant.
*/
function createSieveCache(max) {
	const cache = /* @__PURE__ */ new Map();
	let hand;
	let newest;
	return {
		get(key) {
			const entry = cache.get(key);
			if (!entry) return;
			entry.visited = true;
			return entry.value;
		},
		set(key, value) {
			const existing = cache.get(key);
			if (existing) {
				existing.value = value;
				return;
			}
			if (cache.size >= max) {
				let node = hand?.next().value;
				while (!node || node.visited) {
					if (node) node.visited = false;
					else hand = cache.values();
					node = hand.next().value;
				}
				if (node === newest) hand = void 0;
				cache.delete(node.key);
			}
			const entry = {
				key,
				value,
				visited: false
			};
			newest = entry;
			cache.set(key, entry);
		},
		clear() {
			cache.clear();
			hand = void 0;
			newest = void 0;
		}
	};
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/new-process-route-tree.js
var SEGMENT_TYPE_INDEX = 4;
var SEGMENT_TYPE_PATHLESS = 5;
function getParamNames(data) {
	const cached = data.names;
	if (cached) return cached;
	const keys = [];
	for (const segment of data) if (typeof segment !== "string") keys.push(segment[1]);
	return data.names = keys;
}
/** Parse one segment for matching and retain the same record for interpolation. */
function parseSegment(path, start, end) {
	const part = path.substring(start, end);
	if (part.charCodeAt(0) === 36) return part.length === 1 ? [
		2,
		"_splat",
		"",
		void 0
	] : [
		1,
		part.substring(1),
		"",
		""
	];
	const open = part.indexOf("{");
	if (open >= 0) {
		const close = part.indexOf("}", open);
		const optional = part.charCodeAt(open + 1) === 45;
		const nameStart = open + (optional ? 3 : 2);
		if (close >= 0 && part.charCodeAt(nameStart - 1) === 36 && (!optional || nameStart < close)) {
			const key = part.substring(nameStart, close);
			return [
				optional ? 3 : key ? 1 : 2,
				key || "_splat",
				part.substring(0, open),
				path.substring(start + close + 1, key ? end : path.length)
			];
		}
	}
	return part;
}
function parseSegments(defaultCaseSensitive, route, start, node, dynamicListsToSort, parentInterpolation) {
	let cursor = start;
	const path = route.fullPath ?? route.from;
	const options = route.options;
	const length = path.length;
	const literalEnd = path.endsWith("/") ? length - 1 : length;
	const caseSensitive = options?.caseSensitive ?? defaultCaseSensitive;
	const parseParams = options?.params?.parse ?? options?.parseParams;
	let interpolation;
	let literalStart = parentInterpolation ? start - 1 : 0;
	if (!node || path.includes("$")) {
		interpolation = parentInterpolation?.slice() ?? [];
		const tail = last(interpolation);
		if (tail && typeof tail !== "string" && tail[0] === 2) {
			interpolation[interpolation.length - 1] = [
				tail[0],
				tail[1],
				tail[2],
				tail[3] === void 0 ? void 0 : tail[3] + path.substring(start - (path[start - 2] === "/" ? 2 : 1), literalEnd)
			];
			literalStart = length;
		}
	}
	while (cursor < length) {
		const start = cursor;
		const next = path.indexOf("/", start);
		let end = next === -1 ? length : next;
		const segment = parseSegment(path, start, end);
		cursor = end + 1;
		let nextNode;
		if (typeof segment === "string") {
			if (!node) continue;
			let name = segment;
			let staticChildren;
			if (caseSensitive) staticChildren = node.static ??= /* @__PURE__ */ new Map();
			else {
				name = segment.toLowerCase();
				staticChildren = node.staticInsensitive ??= /* @__PURE__ */ new Map();
			}
			const existingNode = staticChildren.get(name);
			if (existingNode) nextNode = existingNode;
			else {
				const next = createSegmentNode(node);
				nextNode = next;
				staticChildren.set(name, next);
			}
		} else {
			const kind = segment[0];
			let prefix = segment[2];
			let suffix = segment[3] ?? "";
			if (kind === 2) {
				end = length;
				cursor = end + 1;
			}
			if (interpolation && literalStart < end) {
				if (literalStart < start - 1) interpolation.push(path.substring(literalStart, start - 1));
				segment[2] = "/" + prefix;
				if (kind === 2 && segment[3] !== void 0 && literalEnd < length) segment[3] = suffix.slice(0, -1);
				interpolation.push(segment);
				literalStart = end;
			}
			if (!node) continue;
			const actuallyCaseSensitive = caseSensitive && !!(prefix || suffix);
			if (!caseSensitive) {
				prefix = prefix.toLowerCase();
				suffix = suffix.toLowerCase();
			}
			const siblings = kind === 1 ? node.dynamic ??= [] : kind === 3 ? node.optional ??= [] : node.wildcard ??= [];
			const existingNode = kind !== 2 && !parseParams && siblings.find((s) => !s.parse && s.caseSensitive === actuallyCaseSensitive && s.prefix === prefix && s.suffix === suffix);
			if (existingNode) nextNode = existingNode;
			else {
				const next = createSegmentNode(node, kind, actuallyCaseSensitive, prefix, suffix);
				nextNode = next;
				siblings.push(next);
				if (siblings.length === 2) dynamicListsToSort?.push(siblings);
			}
		}
		node = nextNode;
	}
	if (interpolation && literalStart < literalEnd) interpolation.push(path.substring(literalStart, literalEnd));
	const segmentData = interpolation?.slice();
	if (!node) return segmentData;
	if (parseParams && route.children && !route.isRoot && route.id && route.id.charCodeAt(route.id.lastIndexOf("/") + 1) === 95) {
		const pathlessNode = createSegmentNode(node, SEGMENT_TYPE_PATHLESS);
		(node.pathless ??= []).push(pathlessNode);
		node = pathlessNode;
	}
	const isLeaf = (route.path || !route.children) && !route.isRoot;
	if (isLeaf && literalEnd < length) {
		const indexNode = createSegmentNode(node, SEGMENT_TYPE_INDEX);
		node.index = indexNode;
		node = indexNode;
	}
	node.parse = parseParams ?? null;
	node.priority = options?.params?.priority ?? 0;
	if (!node.route) {
		node.data = segmentData;
		if (isLeaf) node.route = route;
	}
	return [
		node,
		cursor,
		segmentData
	];
}
function sortDynamic(a, b) {
	if (a.parse && !b.parse) return -1;
	if (!a.parse && b.parse) return 1;
	if (a.parse && b.parse && (a.priority || b.priority)) return b.priority - a.priority;
	if (a.prefix && b.prefix && a.prefix !== b.prefix) {
		if (a.prefix.startsWith(b.prefix)) return -1;
		if (b.prefix.startsWith(a.prefix)) return 1;
	}
	if (a.suffix && b.suffix && a.suffix !== b.suffix) {
		if (a.suffix.endsWith(b.suffix)) return -1;
		if (b.suffix.endsWith(a.suffix)) return 1;
	}
	if (a.prefix && !b.prefix) return -1;
	if (!a.prefix && b.prefix) return 1;
	if (a.suffix && !b.suffix) return -1;
	if (!a.suffix && b.suffix) return 1;
	if (a.caseSensitive && !b.caseSensitive) return -1;
	if (!a.caseSensitive && b.caseSensitive) return 1;
	return 0;
}
function createSegmentNode(parent, kind = 0, caseSensitive, prefix, suffix) {
	return {
		kind,
		depth: parent ? parent.depth + 1 : 0,
		pathless: null,
		index: null,
		static: null,
		staticInsensitive: null,
		dynamic: null,
		optional: null,
		wildcard: null,
		route: null,
		data: void 0,
		parent,
		parse: null,
		priority: 0,
		caseSensitive,
		prefix,
		suffix
	};
}
function processRouteMasks(routeList, processedTree) {
	const segmentTree = createSegmentNode();
	const dynamicListsToSort = [];
	function visit(route, start, parentNode, parentInterpolation) {
		const [node, cursor, segments] = parseSegments(false, route, start, parentNode, dynamicListsToSort, parentInterpolation);
		if (route.children) for (const child of route.children) visit(child, cursor, node, segments);
	}
	for (const route of routeList) visit(route, 1, segmentTree);
	for (const nodes of dynamicListsToSort) nodes.sort(sortDynamic);
	processedTree.masksTree = segmentTree;
	processedTree.flatCache = createSieveCache(1e3);
}
/**
* Take an arbitrary list of routes, create a tree from them (if it hasn't been created already), and match a path against it.
*/
function findFlatMatch(path, processedTree) {
	path ||= "/";
	const cached = processedTree.flatCache.get(path);
	if (cached !== void 0) return cached;
	const result = findMatch(path, processedTree.masksTree);
	processedTree.flatCache.set(path, result);
	return result;
}
/**
* @deprecated keep until v2 so that `router.matchRoute` can keep not caring about the actual route tree
*/
function findSingleMatch(from, caseSensitive, fuzzy, path, processedTree) {
	from ||= "/";
	path ||= "/";
	const key = caseSensitive ? `case\0${from}` : from;
	let tree = processedTree.singleCache.get(key);
	if (!tree) {
		tree = createSegmentNode();
		parseSegments(caseSensitive, { from }, 1, tree);
		processedTree.singleCache.set(key, tree);
	}
	return findMatch(path, tree, fuzzy);
}
function findRouteMatch(path, processedTree, fuzzy = false) {
	const key = fuzzy ? path : `nofuzz\0${path}`;
	const cached = processedTree.matchCache.get(key);
	if (cached !== void 0) return cached;
	path ||= "/";
	let result;
	try {
		result = findMatch(path, processedTree.segmentTree, fuzzy);
	} catch (err) {
		if (err instanceof URIError) result = null;
		else throw err;
	}
	if (result) result.branch = buildRouteBranch(result.route);
	processedTree.matchCache.set(key, result);
	return result;
}
/**
* Processes a route tree into a segment trie for efficient path matching.
* Also builds lookup maps for routes by ID and by trimmed full path.
*/
function processRouteTree(routeTree, caseSensitive = false) {
	const segmentTree = createSegmentNode();
	const dynamicListsToSort = [];
	const routesById = {};
	const routesByPath = {};
	let index = 0;
	function visit(route, start, parentNode, parentInterpolation) {
		route.init(index);
		if (route.id in routesById) throw new Error(`Invariant failed: Duplicate routes found with id: ${String(route.id)}`);
		routesById[route.id] = route;
		if (index !== 0 && route.path) {
			const trimmedFullPath = trimPathRight(route.fullPath);
			if (!routesByPath[trimmedFullPath] || route.fullPath.endsWith("/")) routesByPath[trimmedFullPath] = route;
		}
		index++;
		const [node, cursor, segments] = parseSegments(caseSensitive, route, start, parentNode, dynamicListsToSort, parentInterpolation);
		route._interpolation = segments;
		if (route.children) for (const child of route.children) visit(child, cursor, node, segments);
	}
	visit(routeTree, 1, segmentTree);
	for (const nodes of dynamicListsToSort) nodes.sort(sortDynamic);
	return {
		processedTree: {
			segmentTree,
			singleCache: createSieveCache(1e3),
			matchCache: createSieveCache(1e3),
			flatCache: null,
			masksTree: null
		},
		routesById,
		routesByPath
	};
}
function findMatch(path, segmentTree, fuzzy = false) {
	const parts = path.split("/");
	const leaf = getNodeMatch(path, parts, segmentTree, fuzzy);
	if (!leaf) return null;
	const [rawParams] = extractParams(path, parts, leaf);
	return {
		route: leaf.node.route,
		rawParams
	};
}
/**
* This function is "resumable":
* - the `leaf` input can contain `extract` and `rawParams` properties from a previous `extractParams` call
* - the returned `state` can be passed back as `extract` in a future call to continue extracting params from where we left off
*
* Inputs are *not* mutated.
*/
function extractParams(path, parts, leaf) {
	const list = buildBranch(leaf.node);
	const names = leaf.node.data && getParamNames(leaf.node.data);
	const rawParams = Object.create(null);
	/** which segment of the path we're currently processing */
	let partIndex = leaf.extract?.part ?? 0;
	/** which node of the route tree branch we're currently processing */
	let nodeIndex = leaf.extract?.node ?? 0;
	/** index of the 1st character of the segment we're processing in the path string */
	let pathIndex = leaf.extract?.path ?? 0;
	/** Next original parameter name, independent of pathless/static nodes. */
	let paramIndex = leaf.extract?.param ?? 0;
	for (; nodeIndex < list.length; partIndex++, nodeIndex++, pathIndex++) {
		const node = list[nodeIndex];
		if (node.kind === SEGMENT_TYPE_INDEX) break;
		if (node.kind === SEGMENT_TYPE_PATHLESS) {
			partIndex--;
			pathIndex--;
			continue;
		}
		const part = parts[partIndex];
		const currentPathIndex = pathIndex;
		if (part) pathIndex += part.length;
		if (node.kind === 1 || node.kind === 3) {
			const name = names[paramIndex++];
			if (node.kind === 3 && leaf.skipped & 1 << nodeIndex) {
				partIndex--;
				pathIndex = currentPathIndex - 1;
				continue;
			}
			const value = node.suffix || node.prefix ? part.substring(node.prefix.length, part.length - node.suffix.length) : part;
			if (value || node.kind === 1) rawParams[name] = decodeURIComponent(value);
		} else if (node.kind === 2) {
			const n = node;
			const value = path.substring(currentPathIndex + n.prefix.length, path.length - n.suffix.length);
			const splat = decodeURIComponent(value);
			rawParams["*"] = splat;
			rawParams._splat = splat;
			break;
		}
	}
	if (leaf.rawParams) Object.assign(rawParams, leaf.rawParams);
	return [rawParams, {
		part: partIndex,
		node: nodeIndex,
		path: pathIndex,
		param: paramIndex
	}];
}
function buildRouteBranch(route) {
	const list = [route];
	while (route.parentRoute) {
		route = route.parentRoute;
		list.push(route);
	}
	list.reverse();
	return list;
}
function buildBranch(node) {
	const list = Array(node.depth + 1);
	do {
		list[node.depth] = node;
		node = node.parent;
	} while (node);
	return list;
}
function getNodeMatch(path, parts, segmentTree, fuzzy) {
	if (path === "/" && segmentTree.index) return {
		node: segmentTree.index,
		skipped: 0
	};
	const trailingSlash = !last(parts);
	const pathIsIndex = trailingSlash && path !== "/";
	const partsLength = parts.length - (trailingSlash ? 1 : 0);
	const stack = [{
		node: segmentTree,
		index: 1,
		skipped: 0,
		statics: 0,
		dynamics: 0,
		optionals: 0
	}];
	let bestFuzzy = null;
	let bestMatch = null;
	while (stack.length) {
		const frame = stack.pop();
		const { node, index, skipped, statics, dynamics, optionals } = frame;
		let { extract, rawParams } = frame;
		if (node.kind === 2 && node.route && !isFrameMoreSpecific(bestMatch, frame)) continue;
		if (node.parse) {
			if (!validateParseParams(path, parts, frame)) continue;
			rawParams = frame.rawParams;
			extract = frame.extract;
		}
		if (fuzzy && node.route && node.kind !== SEGMENT_TYPE_INDEX && isFrameMoreSpecific(bestFuzzy, frame)) bestFuzzy = frame;
		const isBeyondPath = index === partsLength;
		if (isBeyondPath) {
			if (node.route && (!pathIsIndex || node.kind === SEGMENT_TYPE_INDEX || node.kind === 2) && isFrameMoreSpecific(bestMatch, frame)) bestMatch = frame;
			if (!node.optional && !node.wildcard && !node.index && !node.pathless) continue;
		}
		const part = isBeyondPath ? void 0 : parts[index];
		let lowerPart;
		if (isBeyondPath && node.index) {
			const indexFrame = {
				node: node.index,
				index,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			};
			let indexValid = true;
			if (node.index.parse) {
				if (!validateParseParams(path, parts, indexFrame)) indexValid = false;
			}
			if (indexValid) {
				if (!dynamics && !optionals && !skipped && isPerfectStaticMatch(statics, partsLength)) return indexFrame;
				if (isFrameMoreSpecific(bestMatch, indexFrame)) bestMatch = indexFrame;
			}
		}
		if (node.wildcard) for (let i = node.wildcard.length - 1; i >= 0; i--) {
			const segment = node.wildcard[i];
			const { prefix, suffix } = segment;
			if (prefix) {
				if (isBeyondPath) continue;
				if (!(segment.caseSensitive ? part : lowerPart ??= part.toLowerCase()).startsWith(prefix)) continue;
			}
			if (suffix) {
				if (isBeyondPath) continue;
				const end = parts.slice(index).join("/");
				const suffixPart = end.slice(-suffix.length);
				if ((segment.caseSensitive ? suffixPart : suffixPart.toLowerCase()) !== suffix || end.length - suffix.length < prefix.length) continue;
			}
			stack.push({
				node: segment,
				index: partsLength,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (node.optional) {
			const nextSkipped = skipped | 1 << node.depth + 1;
			for (let i = node.optional.length - 1; i >= 0; i--) {
				const segment = node.optional[i];
				stack.push({
					node: segment,
					index,
					skipped: nextSkipped,
					statics,
					dynamics,
					optionals,
					extract,
					rawParams
				});
			}
			if (!isBeyondPath) for (let i = node.optional.length - 1; i >= 0; i--) {
				const segment = node.optional[i];
				const { prefix, suffix } = segment;
				if (prefix || suffix) {
					const casePart = segment.caseSensitive ? part : lowerPart ??= part.toLowerCase();
					if (prefix && !casePart.startsWith(prefix)) continue;
					if (suffix && casePart.indexOf(suffix, casePart.length - suffix.length) < prefix.length) continue;
				}
				stack.push({
					node: segment,
					index: index + 1,
					skipped,
					statics,
					dynamics,
					optionals: optionals + segmentScore(partsLength, index),
					extract,
					rawParams
				});
			}
		}
		if (!isBeyondPath && node.dynamic && part) for (let i = node.dynamic.length - 1; i >= 0; i--) {
			const segment = node.dynamic[i];
			const { prefix, suffix } = segment;
			if (prefix || suffix) {
				const casePart = segment.caseSensitive ? part : lowerPart ??= part.toLowerCase();
				if (prefix && !casePart.startsWith(prefix)) continue;
				if (suffix && casePart.indexOf(suffix, casePart.length - suffix.length) < prefix.length) continue;
			}
			stack.push({
				node: segment,
				index: index + 1,
				skipped,
				statics,
				dynamics: dynamics + segmentScore(partsLength, index),
				optionals,
				extract,
				rawParams
			});
		}
		if (!isBeyondPath && node.staticInsensitive) {
			const match = node.staticInsensitive.get(lowerPart ??= part.toLowerCase());
			if (match) stack.push({
				node: match,
				index: index + 1,
				skipped,
				statics: statics + segmentScore(partsLength, index),
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (!isBeyondPath && node.static) {
			const match = node.static.get(part);
			if (match) stack.push({
				node: match,
				index: index + 1,
				skipped,
				statics: statics + segmentScore(partsLength, index),
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (node.pathless) for (let i = node.pathless.length - 1; i >= 0; i--) {
			const segment = node.pathless[i];
			stack.push({
				node: segment,
				index,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
	}
	if (bestMatch) return bestMatch;
	if (fuzzy && bestFuzzy) {
		let sliceIndex = bestFuzzy.index;
		for (let i = 0; i < bestFuzzy.index; i++) sliceIndex += parts[i].length;
		const splat = sliceIndex === path.length ? "/" : path.slice(sliceIndex);
		bestFuzzy.rawParams ??= Object.create(null);
		bestFuzzy.rawParams["**"] = decodeURIComponent(splat);
		return bestFuzzy;
	}
	return null;
}
function segmentScore(partsLength, index) {
	return 2 ** (partsLength - index - 1);
}
function isPerfectStaticMatch(statics, partsLength) {
	return statics === 2 ** (partsLength - 1) - 1;
}
function validateParseParams(path, parts, frame) {
	let rawParams;
	let state;
	try {
		[rawParams, state] = extractParams(path, parts, frame);
	} catch {
		return null;
	}
	frame.rawParams = rawParams;
	frame.extract = state;
	if (!frame.node.parse) return true;
	try {
		if (frame.node.parse(rawParams) === false) return null;
	} catch {}
	return true;
}
function isFrameMoreSpecific(prev, next) {
	if (!prev) return true;
	return next.statics > prev.statics || next.statics === prev.statics && (next.dynamics > prev.dynamics || next.dynamics === prev.dynamics && (next.optionals > prev.optionals || next.optionals === prev.optionals && ((next.node.kind === SEGMENT_TYPE_INDEX) > (prev.node.kind === SEGMENT_TYPE_INDEX) || next.node.kind === SEGMENT_TYPE_INDEX === (prev.node.kind === SEGMENT_TYPE_INDEX) && next.node.depth > prev.node.depth)));
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/scroll-restoration.js
function getSafeSessionStorage() {
	try {
		return sessionStorage;
	} catch {
		return;
	}
}
var storageKey = "tsr-scroll-restoration-v1_3";
var safeSessionStorage = getSafeSessionStorage();
function createScrollRestorationCache() {
	try {
		return JSON.parse(safeSessionStorage?.getItem("tsr-scroll-restoration-v1_3") || "{}");
	} catch {
		return {};
	}
}
var scrollRestorationCache = /* @__PURE__ */ createScrollRestorationCache();
var scrollRestorationIdAttribute = "data-scroll-restoration-id";
/**
* The default `getKey` function for `useScrollRestoration`.
* It returns the `key` from the location state or the `href` of the location.
*
* The `location.href` is used as a fallback to support the use case where the location state is not available like the initial render.
*/
var defaultGetScrollRestorationKey = (location) => {
	return location.state.__TSR_key || location.href;
};
function getScrollRestorationSelector(element) {
	const attrId = element.getAttribute(scrollRestorationIdAttribute);
	if (attrId) return `[${scrollRestorationIdAttribute}="${attrId}"]`;
	let selector = "";
	let el = element;
	let parent;
	while (parent = el.parentNode) {
		let index = 1;
		let sibling = el;
		while (sibling = sibling.previousElementSibling) index++;
		const part = `${el.localName}:nth-child(${index})`;
		selector = selector ? `${part} > ${selector}` : part;
		el = parent;
	}
	return selector;
}
function getElementScrollRestorationEntry(router, options) {
	const entries = scrollRestorationCache[(options.getKey || defaultGetScrollRestorationKey)(router.latestLocation)];
	if (!entries) return;
	if (options.id) return entries[`[${scrollRestorationIdAttribute}="${options.id}"]`];
	const element = options.getElement?.();
	if (!element) return;
	return entries[element === window ? windowScrollTarget : getScrollRestorationSelector(element)];
}
var ignoreScroll = false;
var windowScrollTarget = "window";
function getElement(selector) {
	try {
		return typeof selector === "function" ? selector() : document.querySelector(selector);
	} catch {}
}
function getScrollToTopElements(scrollToTopSelectors) {
	const elements = /* @__PURE__ */ new Set();
	for (const selector of scrollToTopSelectors) {
		if (selector === windowScrollTarget) continue;
		const element = getElement(selector);
		if (element) elements.add(element);
	}
	return elements;
}
function setupScrollRestoration(router, force) {
	const shouldSetupScrollRestoration = force ?? router.options.scrollRestoration;
	const scroll = router._scroll;
	if (shouldSetupScrollRestoration) scroll.e = true;
	if (router.isServer) return;
	const getKey = router.options.getScrollRestorationKey || defaultGetScrollRestorationKey;
	const trackedScrollTargets = /* @__PURE__ */ new Set();
	const snapshotCurrentScrollTargets = (restoreKey) => {
		const keyEntry = scrollRestorationCache[restoreKey] ||= {};
		for (const target of trackedScrollTargets) if (target === document) keyEntry[windowScrollTarget] = {
			scrollX,
			scrollY
		};
		else if (target.isConnected) keyEntry[getScrollRestorationSelector(target)] = {
			scrollX: target.scrollLeft,
			scrollY: target.scrollTop
		};
	};
	if (shouldSetupScrollRestoration && !scroll.s) {
		scroll.s = true;
		ignoreScroll = false;
		history.scrollRestoration = "manual";
		document.addEventListener("scroll", (event) => {
			if (ignoreScroll) return;
			trackedScrollTargets.add(event.target);
		}, true);
		router.subscribe("onBeforeLoad", (event) => {
			if (event.fromLocation) snapshotCurrentScrollTargets(getKey(event.fromLocation));
			trackedScrollTargets.clear();
		});
		addEventListener("pagehide", () => {
			history.scrollRestoration = "auto";
			snapshotCurrentScrollTargets(getKey(router.stores.resolvedLocation.get() ?? router.stores.location.get()));
			try {
				safeSessionStorage?.setItem(storageKey, JSON.stringify(scrollRestorationCache));
			} catch {
				console.warn("[ts-router] Could not persist scroll restoration state to sessionStorage.");
			}
		});
		addEventListener("pageshow", (event) => {
			if (event.persisted) history.scrollRestoration = "manual";
		});
	}
	if (scroll.r) return;
	scroll.r = true;
	router.subscribe("onRendered", (event) => {
		const behavior = router.options.scrollRestorationBehavior;
		const scrollToTopSelectors = router.options.scrollToTopSelectors;
		const shouldResetScroll = scroll.n;
		const hashNavigation = scroll.h;
		let scrollToTopElements;
		trackedScrollTargets.clear();
		scroll.n = true;
		scroll.h = false;
		if (typeof router.options.scrollRestoration === "function" && !router.options.scrollRestoration({ location: router.latestLocation })) return;
		const cacheKey = getKey(event.toLocation);
		const fromCacheKey = event.fromLocation && getKey(event.fromLocation);
		if (scroll.e && fromCacheKey && fromCacheKey !== cacheKey) {
			const fromElementEntries = scrollRestorationCache[fromCacheKey];
			if (fromElementEntries) {
				let toElementEntries = scrollRestorationCache[cacheKey];
				for (const elementSelector in fromElementEntries) {
					if (elementSelector === windowScrollTarget) {
						if (shouldResetScroll) continue;
					} else {
						const element = getElement(elementSelector);
						if (!element) continue;
						if (shouldResetScroll && scrollToTopSelectors) {
							scrollToTopElements ??= getScrollToTopElements(scrollToTopSelectors);
							if (scrollToTopElements.has(element)) continue;
						}
					}
					if (!toElementEntries) toElementEntries = scrollRestorationCache[cacheKey] = {};
					toElementEntries[elementSelector] ??= fromElementEntries[elementSelector];
				}
			}
		}
		ignoreScroll = true;
		try {
			const hash = event.toLocation.hash;
			const hashScrollIntoViewOptions = event.toLocation.state.__hashScrollIntoViewOptions ?? true;
			let windowRestored = false;
			if (shouldResetScroll) {
				if (!hash && scrollToTopSelectors) scrollToTopElements ??= getScrollToTopElements(scrollToTopSelectors);
				const skipWindowRestore = hash && hashScrollIntoViewOptions && hashNavigation;
				const elementEntries = scroll.e ? scrollRestorationCache[cacheKey] : void 0;
				if (elementEntries) for (const elementSelector in elementEntries) {
					const { scrollX, scrollY } = elementEntries[elementSelector];
					if (elementSelector === windowScrollTarget) {
						if (skipWindowRestore) continue;
						scrollTo({
							top: scrollY,
							left: scrollX,
							behavior
						});
						windowRestored = true;
					} else {
						const element = getElement(elementSelector);
						if (element) {
							element.scrollLeft = scrollX;
							element.scrollTop = scrollY;
							scrollToTopElements?.delete(element);
						}
					}
				}
				if (!hash) {
					const scrollOptions = {
						top: 0,
						left: 0,
						behavior
					};
					if (!windowRestored) scrollTo(scrollOptions);
					if (scrollToTopElements) for (const element of scrollToTopElements) element.scrollTo(scrollOptions);
				}
			}
			if (!windowRestored && hash && hashScrollIntoViewOptions) document.getElementById(hash)?.scrollIntoView(hashScrollIntoViewOptions);
		} finally {
			ignoreScroll = false;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/qss.js
/**
* Program is a reimplementation of the `qss` package:
* Copyright (c) Luke Edwards luke.edwards05@gmail.com, MIT License
* https://github.com/lukeed/qss/blob/master/license.md
*
* This reimplementation uses modern browser APIs
* (namely URLSearchParams) and TypeScript while still
* maintaining the original functionality and interface.
*
* Update: this implementation has also been mangled to
* fit exactly our use-case (single value per key in encoding).
*/
/**
* Encodes an object into a query string.
* @param obj - The object to encode into a query string.
* @param stringify - An optional custom stringify function.
* @returns The encoded query string.
* @example
* ```
* // Example input: encode({ token: 'foo', key: 'value' })
* // Expected output: "token=foo&key=value"
* ```
*/
function encode(obj, stringify = String) {
	let result;
	for (const key in obj) {
		const val = obj[key];
		if (val !== void 0) (result ||= new URLSearchParams()).set(key, stringify(val));
	}
	return result ? result.toString() : "";
}
/**
* Converts a string value to its appropriate type (string, number, boolean).
* @param mix - The string value to convert.
* @returns The converted value.
* @example
* // Example input: toValue("123")
* // Expected output: 123
*/
function toValue(str) {
	if (!str) return "";
	if (str === "false") return false;
	if (str === "true") return true;
	return +str * 0 === 0 && +str + "" === str ? +str : str;
}
/**
* Decodes a query string into an object.
* @param str - The query string to decode.
* @returns The decoded key-value pairs in an object format.
* @example
* // Example input: decode("token=foo&key=value")
* // Expected output: { "token": "foo", "key": "value" }
*/
function decode(str) {
	const searchParams = new URLSearchParams(str);
	const result = Object.create(null);
	for (const [key, value] of searchParams.entries()) {
		const previousValue = result[key];
		if (previousValue == null) result[key] = toValue(value);
		else if (Array.isArray(previousValue)) previousValue.push(toValue(value));
		else result[key] = [previousValue, toValue(value)];
	}
	return result;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/searchParams.js
var jsonStart = /^(?:\s|["[{\d-]|fa|nu|tr)/;
/** Default `parseSearch` that strips leading '?' and JSON-parses values. */
var defaultParseSearch = parseSearchWith(JSON.parse);
/** Default `stringifySearch` using JSON.stringify for complex values. */
var defaultStringifySearch = stringifySearchWith(JSON.stringify, JSON.parse);
/**
* Build a `parseSearch` function using a provided JSON-like parser.
*
* The returned function strips a leading `?`, decodes values, and attempts to
* JSON-parse string values using the given `parser`.
*
* @param parser Function to parse a string value (e.g. `JSON.parse`).
* @returns A `parseSearch` function compatible with `Router` options.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-search-param-serialization
*/
function parseSearchWith(parser) {
	const isJsonParser = parser === JSON.parse;
	return (searchStr) => {
		if (searchStr[0] === "?") searchStr = searchStr.substring(1);
		const query = decode(searchStr);
		for (const key in query) {
			const value = query[key];
			if (typeof value === "string") {
				if (isJsonParser && !jsonStart.test(value)) continue;
				try {
					query[key] = parser(value);
				} catch (_err) {}
			}
		}
		return query;
	};
}
/**
* Build a `stringifySearch` function using a provided serializer.
*
* Non-primitive values are serialized with `stringify`. If a `parser` is
* supplied, string values that are parseable are re-serialized to ensure
* symmetry with `parseSearch`.
*
* @param stringify Function to serialize a value (e.g. `JSON.stringify`).
* @param parser Optional parser to detect parseable strings.
* @returns A `stringifySearch` function compatible with `Router` options.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-search-param-serialization
*/
function stringifySearchWith(stringify, parser) {
	const isJsonParser = parser === JSON.parse;
	function stringifyValue(val) {
		if (val && typeof val === "object") try {
			return stringify(val);
		} catch (_err) {}
		else if (parser && typeof val === "string") {
			if (isJsonParser && !jsonStart.test(val)) return val;
			try {
				parser(val);
				return stringify(val);
			} catch (_err) {}
		}
		return val;
	}
	return (search) => {
		const searchStr = encode(search, stringifyValue);
		return searchStr ? `?${searchStr}` : "";
	};
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/rewrite.js
/** Compose multiple rewrite pairs into a single in/out rewrite. */
function composeRewrites(rewrites) {
	return {
		input: ({ url }) => {
			for (const rewrite of rewrites) url = executeRewriteInput(rewrite, url);
			return url;
		},
		output: ({ url }) => {
			for (let i = rewrites.length - 1; i >= 0; i--) url = executeRewriteOutput(rewrites[i], url);
			return url;
		}
	};
}
/** Create a rewrite pair that strips/adds a basepath on input/output. */
function rewriteBasepath(basepath, caseSensitive, rewrite) {
	const trimmedBasepath = trimPath(basepath);
	const normalizedBasepath = `/${trimmedBasepath}`;
	const checkBasepath = caseSensitive ? normalizedBasepath : normalizedBasepath.toLowerCase();
	const checkBasepathWithSlash = `${checkBasepath}/`;
	const basepathRewrite = {
		input: ({ url }) => {
			const pathname = caseSensitive ? url.pathname : url.pathname.toLowerCase();
			if (pathname === checkBasepath) url.pathname = "/";
			else if (pathname.startsWith(checkBasepathWithSlash)) url.pathname = url.pathname.slice(normalizedBasepath.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = cleanPath(`/${trimmedBasepath}${url.pathname}`);
			return url;
		}
	};
	return rewrite ? {
		input: ({ url }) => executeRewriteInput(rewrite, basepathRewrite.input({ url })),
		output: ({ url }) => basepathRewrite.output({ url: executeRewriteOutput(rewrite, url) })
	} : basepathRewrite;
}
/** Execute a location input rewrite if provided. */
function executeRewriteInput(rewrite, url) {
	const res = rewrite?.input?.({ url });
	if (res) {
		if (typeof res === "string") return new URL(res);
		else if (res instanceof URL) return res;
	}
	return url;
}
/** Execute a location output rewrite if provided. */
function executeRewriteOutput(rewrite, url) {
	const res = rewrite?.output?.({ url });
	if (res) {
		if (typeof res === "string") return new URL(res);
		else if (res instanceof URL) return res;
	}
	return url;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/stores.js
/** SSR non-reactive createMutableStore */
function createNonReactiveMutableStore(initialValue) {
	let value = initialValue;
	return {
		get() {
			return value;
		},
		set(nextOrUpdater) {
			value = functionalUpdate(nextOrUpdater, value);
		}
	};
}
/** SSR non-reactive createReadonlyStore */
function createNonReactiveReadonlyStore(read) {
	return { get() {
		return read();
	} };
}
function createRouterStores(initialLocation, config) {
	const { createMutableStore, createReadonlyStore, batch } = config;
	const byRoute = /* @__PURE__ */ new Map();
	const status = createMutableStore("idle");
	const location = createMutableStore(initialLocation);
	const resolvedLocation = createMutableStore(void 0);
	const ids = createMutableStore([]);
	const matches = createReadonlyStore(() => ids.get().map((id) => byRoute.get(id).get()));
	const __store = createReadonlyStore(() => ({
		status: status.get(),
		isLoading: status.get() === "pending",
		matches: matches.get(),
		location: location.get(),
		resolvedLocation: resolvedLocation.get()
	}));
	function getMatchStore(routeId) {
		let matchStore = byRoute.get(routeId);
		if (!matchStore) {
			matchStore = createMutableStore(void 0);
			byRoute.set(routeId, matchStore);
		}
		return matchStore;
	}
	const store = {
		status,
		location,
		resolvedLocation,
		ids,
		matches,
		byRoute,
		__store,
		getMatchStore,
		setMatches
	};
	function setMatches(nextMatches) {
		const previousIds = ids.get();
		const nextIds = nextMatches.map((match) => match.routeId);
		batch(() => {
			if (!arraysEqual(previousIds, nextIds)) ids.set(nextIds);
			for (const id of previousIds) if (!nextIds.includes(id)) byRoute.get(id).set(() => void 0);
			for (const nextMatch of nextMatches) {
				const matchStore = getMatchStore(nextMatch.routeId);
				if (matchStore.get() !== nextMatch) matchStore.set(nextMatch);
			}
		});
	}
	return store;
}
//#endregion
//#region node_modules/@tanstack/history/dist/esm/index.js
var stateIndexKey = "__TSR_index";
var popStateEvent = "popstate";
var beforeUnloadEvent = "beforeunload";
/**
* Turn protocol-relative inputs such as "//evil.example" into paths
* such as "/evil.example", keeping navigation on the current origin.
*
* For HTTP(S) URLs, WHATWG parsing ignores leading C0 controls and spaces,
* removes tabs/newlines, and treats backslashes as slashes, so inputs like
* "/\evil.example" also need normalization. This only allocates when those
* rules would make the input protocol-relative.
*/
var protocolRelativePrefix = /^[\x00-\x20]*(?:[\\/][\t\n\r]*){2,}/;
function normalizeProtocolRelative(url) {
	const match = protocolRelativePrefix.exec(url);
	return match ? "/" + url.slice(match[0].length) : url;
}
function normalizeHref(href) {
	if (/[\x00-\x1f\x7f]/.test(href)) href = href.replace(/[\x00-\x1f\x7f]/g, (character) => "	\n\r".includes(character) ? "" : encodeURIComponent(character));
	return normalizeProtocolRelative(href);
}
function createHistory(opts) {
	let location = opts.getLocation();
	const subscribers = /* @__PURE__ */ new Set();
	const notify = (action) => {
		location = opts.getLocation();
		subscribers.forEach((subscriber) => subscriber({
			location,
			action
		}));
	};
	const handleIndexChange = (action) => {
		if (opts.notifyOnIndexChange ?? true) notify(action);
		else location = opts.getLocation();
	};
	const tryNavigation = async ({ task, navigateOpts, ...actionInfo }) => {
		if (navigateOpts?.ignoreBlocker ?? false) {
			task();
			return;
		}
		const blockers = opts.getBlockers?.() ?? [];
		const isPushOrReplace = actionInfo.type === "PUSH" || actionInfo.type === "REPLACE";
		if (typeof document !== "undefined" && blockers.length && isPushOrReplace) for (const blocker of blockers) {
			const nextLocation = parseHref(actionInfo.path, actionInfo.state);
			if (await blocker.blockerFn({
				currentLocation: location,
				nextLocation,
				action: actionInfo.type
			})) {
				opts.onBlocked?.();
				return;
			}
		}
		task();
	};
	return {
		get location() {
			return location;
		},
		get length() {
			return opts.getLength();
		},
		subscribers,
		subscribe: (cb) => {
			subscribers.add(cb);
			return () => {
				subscribers.delete(cb);
			};
		},
		push: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex + 1, state);
			tryNavigation({
				task: () => {
					opts.pushState(path, state);
					notify({ type: "PUSH" });
				},
				navigateOpts,
				type: "PUSH",
				path,
				state
			});
		},
		replace: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex, state);
			tryNavigation({
				task: () => {
					opts.replaceState(path, state);
					notify({ type: "REPLACE" });
				},
				navigateOpts,
				type: "REPLACE",
				path,
				state
			});
		},
		go: (index, navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.go(index, navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({
						type: "GO",
						index
					});
				},
				navigateOpts,
				type: "GO"
			});
		},
		back: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.back(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "BACK" });
				},
				navigateOpts,
				type: "BACK"
			});
		},
		forward: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.forward(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "FORWARD" });
				},
				navigateOpts,
				type: "FORWARD"
			});
		},
		canGoBack: () => location.state[stateIndexKey] !== 0,
		createHref: (str) => opts.createHref(str),
		block: (blocker) => {
			if (!opts.setBlockers) return () => {};
			const blockers = opts.getBlockers?.() ?? [];
			opts.setBlockers([...blockers, blocker]);
			return () => {
				const blockers = opts.getBlockers?.() ?? [];
				opts.setBlockers?.(blockers.filter((b) => b !== blocker));
			};
		},
		flush: () => opts.flush?.(),
		destroy: () => opts.destroy?.(),
		notify,
		_getBlockers: () => opts.getBlockers?.() ?? []
	};
}
function assignKeyAndIndex(index, state) {
	const key = createRandomKey();
	return {
		...state,
		key,
		__TSR_key: key,
		[stateIndexKey]: index
	};
}
/**
* Creates a history object that can be used to interact with the browser's
* navigation. This is a lightweight API wrapping the browser's native methods.
* It is designed to work with TanStack Router, but could be used as a standalone API as well.
* IMPORTANT: This API implements history throttling via a microtask to prevent
* excessive calls to the history API. In some browsers, calling history.pushState or
* history.replaceState in quick succession can cause the browser to ignore subsequent
* calls. This API smooths out those differences and ensures that your application
* state will *eventually* match the browser state. In most cases, this is not a problem,
* but if you need to ensure that the browser state is up to date, you can use the
* `history.flush` method to immediately flush all pending state changes to the browser URL.
* @param opts
* @param opts.getHref A function that returns the current href (path + search + hash)
* @param opts.createHref A function that takes a path and returns a href (path + search + hash)
* @returns A history instance
*/
function createBrowserHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	const originalPushState = win.history.pushState;
	const originalReplaceState = win.history.replaceState;
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	const createHref = (path) => normalizeHref(opts?.createHref ? opts.createHref(path) : path);
	const parseLocation = opts?.parseLocation ?? (() => parseHref(`${win.location.pathname}${win.location.search}${win.location.hash}`, win.history.state));
	if (!win.history.state?.__TSR_key && !win.history.state?.key) {
		const addedKey = createRandomKey();
		win.history.replaceState({
			[stateIndexKey]: 0,
			key: addedKey,
			__TSR_key: addedKey
		}, "");
	}
	let currentLocation = parseLocation();
	let rollbackLocation;
	let nextPopIsGo = false;
	let ignoreNextPop = false;
	let skipBlockerNextPop = false;
	let ignoreNextBeforeUnload = false;
	const getLocation = () => currentLocation;
	let next;
	const flush = () => {
		if (!next) return;
		history._ignoreSubscribers = true;
		(next[2] ? win.history.pushState : win.history.replaceState)(next[1], "", next[0]);
		history._ignoreSubscribers = false;
		next = void 0;
		rollbackLocation = void 0;
	};
	const queueHistoryAction = (isPush, destHref, state) => {
		const href = opts?.createHref ? createHref(destHref) : void 0;
		const hasPendingAction = !!next;
		if (!hasPendingAction) rollbackLocation = currentLocation;
		currentLocation = parseHref(destHref, state);
		next = [
			href ?? currentLocation.href,
			state,
			next?.[2] || isPush
		];
		if (!hasPendingAction) queueMicrotask(() => flush());
	};
	const onPushPop = (type) => {
		currentLocation = parseLocation();
		history.notify({ type });
	};
	const onPushPopEvent = async () => {
		ignoreNextBeforeUnload = false;
		if (ignoreNextPop) {
			ignoreNextPop = false;
			return;
		}
		const nextLocation = parseLocation();
		const delta = nextLocation.state[stateIndexKey] - currentLocation.state[stateIndexKey];
		const isForward = delta === 1;
		const isBack = delta === -1;
		const isGo = !isForward && !isBack || nextPopIsGo;
		nextPopIsGo = false;
		const action = isGo ? "GO" : isBack ? "BACK" : "FORWARD";
		const notify = isGo ? {
			type: "GO",
			index: delta
		} : { type: isBack ? "BACK" : "FORWARD" };
		if (skipBlockerNextPop) skipBlockerNextPop = false;
		else {
			const blockers = _getBlockers();
			if (typeof document !== "undefined" && blockers.length) {
				for (const blocker of blockers) if (await blocker.blockerFn({
					currentLocation,
					nextLocation,
					action
				})) {
					ignoreNextPop = true;
					win.history.go(-delta);
					history.notify(notify);
					return;
				}
			}
		}
		currentLocation = parseLocation();
		history.notify(notify);
	};
	const onBeforeUnload = (e) => {
		if (ignoreNextBeforeUnload) {
			ignoreNextBeforeUnload = false;
			return;
		}
		let shouldBlock = false;
		const blockers = _getBlockers();
		if (typeof document !== "undefined" && blockers.length) for (const blocker of blockers) {
			const shouldHaveBeforeUnload = blocker.enableBeforeUnload ?? true;
			if (shouldHaveBeforeUnload === true) {
				shouldBlock = true;
				break;
			}
			if (typeof shouldHaveBeforeUnload === "function" && shouldHaveBeforeUnload() === true) {
				shouldBlock = true;
				break;
			}
		}
		if (shouldBlock) {
			e.preventDefault();
			return e.returnValue = "";
		}
	};
	const history = createHistory({
		getLocation,
		getLength: () => win.history.length,
		pushState: (href, state) => queueHistoryAction(true, href, state),
		replaceState: (href, state) => queueHistoryAction(false, href, state),
		back: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			return win.history.back();
		},
		forward: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.forward();
		},
		go: (n, ignoreBlocker) => {
			nextPopIsGo = true;
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.go(n);
		},
		createHref: (href) => createHref(href),
		flush,
		destroy: () => {
			win.history.pushState = originalPushState;
			win.history.replaceState = originalReplaceState;
			win.removeEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
			win.removeEventListener(popStateEvent, onPushPopEvent);
		},
		onBlocked: () => {
			if (rollbackLocation && currentLocation !== rollbackLocation) currentLocation = rollbackLocation;
		},
		getBlockers: _getBlockers,
		setBlockers: _setBlockers,
		notifyOnIndexChange: false
	});
	history._ignoreNextBeforeUnload = (href) => {
		ignoreNextBeforeUnload = false;
		try {
			href = new URL(href, win.document.baseURI).href;
			ignoreNextBeforeUnload = /^https?:/.test(href) && (!href.includes("#") || href.split("#")[0] !== win.location.href.split("#")[0]);
		} catch {}
	};
	win.addEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
	win.addEventListener(popStateEvent, onPushPopEvent);
	win.history.pushState = function(...args) {
		const res = originalPushState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("PUSH");
		return res;
	};
	win.history.replaceState = function(...args) {
		const res = originalReplaceState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("REPLACE");
		return res;
	};
	return history;
}
/**
* Create a hash-based history implementation.
* Useful for static hosts or environments without server URL rewriting.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createHashHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	return createBrowserHistory({
		window: win,
		parseLocation: () => {
			const hashSplit = win.location.hash.split("#").slice(1);
			const pathPart = hashSplit[0] ?? "/";
			const searchPart = win.location.search;
			const hashEntries = hashSplit.slice(1);
			return parseHref(`${pathPart}${searchPart}${hashEntries.length === 0 ? "" : `#${hashEntries.join("#")}`}`, win.history.state);
		},
		createHref: (href) => `${win.location.pathname}${win.location.search}#${href}`
	});
}
/**
* Create an in-memory history implementation.
* Ideal for server rendering, tests, and non-DOM environments.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createMemoryHistory(opts = { initialEntries: ["/"] }) {
	const entries = opts.initialEntries;
	let index = opts.initialIndex ? Math.min(Math.max(opts.initialIndex, 0), entries.length - 1) : entries.length - 1;
	const states = entries.map((_entry, index) => assignKeyAndIndex(index, void 0));
	const getLocation = () => parseHref(entries[index], states[index]);
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	return createHistory({
		getLocation,
		getLength: () => entries.length,
		pushState: (path, state) => {
			index = index < entries.length - 1 ? index + 1 : entries.length;
			states[index] = state;
			entries[index] = path;
			if (index < entries.length - 1) {
				entries.length = index + 1;
				states.length = index + 1;
			}
		},
		replaceState: (path, state) => {
			states[index] = state;
			entries[index] = path;
		},
		back: () => {
			index = Math.max(index - 1, 0);
		},
		forward: () => {
			index = Math.min(index + 1, entries.length - 1);
		},
		go: (n) => {
			index = Math.min(Math.max(index + n, 0), entries.length - 1);
		},
		createHref: normalizeHref,
		getBlockers: _getBlockers,
		setBlockers: _setBlockers
	});
}
function parseHref(href, state) {
	const sanitizedHref = normalizeHref(href);
	const hashIndex = sanitizedHref.indexOf("#");
	const searchIndex = sanitizedHref.indexOf("?");
	if (!state) {
		const key = createRandomKey();
		state = {
			[stateIndexKey]: 0,
			key,
			__TSR_key: key
		};
	}
	return {
		href: sanitizedHref,
		pathname: sanitizedHref.substring(0, hashIndex > 0 ? searchIndex > 0 ? Math.min(hashIndex, searchIndex) : hashIndex : searchIndex > 0 ? searchIndex : sanitizedHref.length),
		hash: hashIndex > -1 ? sanitizedHref.substring(hashIndex) : "",
		search: searchIndex > -1 ? sanitizedHref.slice(searchIndex, hashIndex === -1 ? void 0 : hashIndex) : "",
		state
	};
}
function createRandomKey() {
	return (Math.random() + 1).toString(36).substring(7);
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/router.js
function isExternalUrl(url, origin) {
	return url.protocol !== "http:" && url.protocol !== "https:" || url.origin !== origin || !!url.username || !!url.password;
}
function getUrlPath(url) {
	return url.pathname + url.search + url.hash;
}
function routeNeedsLoad(route) {
	return route.options.loader || route.options.beforeLoad || route.lazyFn || route.options.component?.preload || route.options.pendingComponent?.preload;
}
/**
* Convert an unknown error into a minimal, serializable object.
* Includes name and message (and stack in development).
*/
function defaultSerializeError(err) {
	if (err instanceof Error) {
		const obj = {
			name: err.name,
			message: err.message
		};
		obj.stack = err.stack;
		return obj;
	}
	return { data: err };
}
/**
* Compute whether path, href or hash changed between previous and current
* resolved locations.
*/
function getLocationChangeInfo(location, resolvedLocation) {
	return {
		fromLocation: resolvedLocation,
		toLocation: location,
		pathChanged: resolvedLocation?.pathname !== location.pathname,
		hrefChanged: resolvedLocation?.href !== location.href,
		hashChanged: resolvedLocation?.hash !== location.hash
	};
}
/**
* Return only state owned by the application, excluding volatile history
* bookkeeping. Mask payloads (`__tempLocation`/`__tempKey`) are kept: they
* distinguish otherwise-identical locations.
*/
function _getUserHistoryState({ key: _key, __TSR_key: _tsrKey, __TSR_index: _tsrIndex, __hashScrollIntoViewOptions: _hashScroll, ...state }) {
	return state;
}
function lifecycleEnd(matches) {
	return matches.findIndex((match) => match.status === "error" || match.status === "notFound" || match._notFound) + 1;
}
/** Run route lifecycle callbacks in leave/enter/stay phases. */
function runRouteLifecycle(router, previous, matches, previousEnd, nextEnd, owner) {
	if (previousEnd) previous = previous.slice(0, previousEnd);
	if (nextEnd) matches = matches.slice(0, nextEnd);
	for (const match of previous) {
		if (owner && router._tx !== owner) return;
		if (!matches.some((candidate) => candidate.routeId === match.routeId)) router.routesById[match.routeId].options.onLeave?.(match);
	}
	for (const match of matches) {
		if (owner && router._tx !== owner) return;
		router.routesById[match.routeId].options[previous.some((candidate) => candidate.routeId === match.routeId) ? "onStay" : "onEnter"]?.(match);
	}
}
/**
* Core, framework-agnostic router engine that powers TanStack Router.
*
* Provides navigation, matching, loading, preloading, caching and event APIs
* used by framework adapters (React/Solid). Prefer framework helpers like
* `createRouter` in app code.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/RouterType
*/
var RouterCore = class {
	/**
	* @deprecated Use the `createRouter` function instead
	*/
	constructor(options, getStoreConfig) {
		this.tempLocationKey = `${Math.round(Math.random() * 1e7)}`;
		this._scroll = { n: true };
		this.subscribers = /* @__PURE__ */ new Set();
		this._cache = /* @__PURE__ */ new Map();
		this._committed = [];
		this.startTransition = async (fn) => {
			fn();
			return false;
		};
		this.update = (newOptions) => {
			if (newOptions.notFoundRoute) console.warn("The notFoundRoute API is deprecated and will be removed in the next major version. See https://tanstack.com/router/v1/docs/framework/react/guide/not-found-errors#migrating-from-notfoundroute for more info.");
			const prevOptions = this.options;
			this.options = {
				...prevOptions,
				...newOptions
			};
			this.isServer = this.options.isServer ?? void 0 ?? typeof document === "undefined";
			if (!this.isServer) this.staticLocations = /* @__PURE__ */ new WeakMap();
			this.protocolAllowlist = new Set(this.options.protocolAllowlist);
			if (!this.history || this.options.history && this.options.history !== this.history) if (!this.options.history) {
				if (!this.isServer) this.history = createBrowserHistory();
			} else this.history = this.options.history;
			this.origin = this.options.origin;
			if (!this.origin) if (!this.isServer && window?.origin && window.origin !== "null") this.origin = window.origin;
			else this.origin = "http://localhost";
			const nextBasepath = this.options.basepath ?? "/";
			const nextRewriteOption = this.options.rewrite;
			const rewriteChanged = this.basepath !== nextBasepath || prevOptions?.rewrite !== nextRewriteOption || prevOptions?.caseSensitive !== this.options.caseSensitive;
			if (rewriteChanged) {
				this.basepath = nextBasepath;
				this.rewrite = nextBasepath !== "/" && trimPath(nextBasepath) ? rewriteBasepath(nextBasepath, this.options.caseSensitive, nextRewriteOption) : nextRewriteOption;
			}
			if (this.history) this.updateLatestLocation();
			if (this.options.routeTree !== this.routeTree || this.isServer && prevOptions?.caseSensitive !== this.options.caseSensitive) {
				this.routeTree = this.options.routeTree;
				let processRouteTreeResult;
				processRouteTreeResult = this.buildRouteTree();
				this.setRoutes(processRouteTreeResult);
			}
			if (!this.stores) {
				if (this.latestLocation) {
					const config = this.getStoreConfig(this);
					this.batch = config.batch;
					this.stores = createRouterStores(this.latestLocation, config);
					if (!this.isServer) setupScrollRestoration(this);
				}
			} else if (rewriteChanged) this.stores.location.set(this.latestLocation);
		};
		this.updateLatestLocation = () => {
			this.latestLocation = this.parseLocation(this.history.location, this.latestLocation);
		};
		this.buildRouteTree = () => {
			const result = processRouteTree(this.routeTree, this.options.caseSensitive);
			if (this.options.routeMasks) processRouteMasks(this.options.routeMasks, result.processedTree);
			return {
				...result,
				resolvePathCache: createSieveCache(1e3)
			};
		};
		this.subscribe = (eventType, fn) => {
			const listener = {
				eventType,
				fn
			};
			this.subscribers.add(listener);
			return () => {
				this.subscribers.delete(listener);
			};
		};
		this.emit = (routerEvent) => {
			for (const listener of this.subscribers) if (listener.eventType === routerEvent.type) try {
				listener.fn(routerEvent);
			} catch (e) {
				console.error(e);
			}
		};
		this.parseLocation = (locationToParse, previousLocation) => {
			const parse = ({ pathname, search, hash, href }, state) => {
				if (!this.rewrite && !/[ \x00-\x1f\x7f\u0080-\uffff]/.test(pathname)) {
					const parsedSearch = this.options.parseSearch(search);
					const searchStr = this.options.stringifySearch(parsedSearch);
					return {
						href: pathname + searchStr + hash,
						publicHref: pathname + searchStr + hash,
						pathname: decodePath(pathname),
						external: false,
						searchStr,
						search: nullReplaceEqualDeep(previousLocation?.search, parsedSearch),
						hash: decodePath(hash.slice(1)),
						state: replaceEqualDeep(previousLocation?.state, state)
					};
				}
				const url = executeRewriteInput(this.rewrite, new URL(href, this.origin));
				const parsedSearch = this.options.parseSearch(url.search);
				const searchStr = this.options.stringifySearch(parsedSearch);
				url.search = searchStr;
				return {
					href: url.href.replace(url.origin, ""),
					publicHref: href,
					pathname: decodePath(normalizeProtocolRelative(url.pathname)),
					external: !!this.rewrite && isExternalUrl(url, this.origin),
					searchStr,
					search: nullReplaceEqualDeep(previousLocation?.search, parsedSearch),
					hash: decodePath(url.hash.slice(1)),
					state: replaceEqualDeep(previousLocation?.state, state)
				};
			};
			const location = parse(locationToParse, locationToParse.state);
			const { __tempLocation, __tempKey } = location.state;
			if (__tempLocation && (!__tempKey || __tempKey === this.tempLocationKey)) {
				const parsedTempLocation = parse(__tempLocation, {
					...__tempLocation.state,
					__tempLocation: void 0,
					key: location.state.key,
					__TSR_key: location.state.__TSR_key
				});
				parsedTempLocation.maskedLocation = location;
				return parsedTempLocation;
			}
			return location;
		};
		this.matchRoutes = (pathnameOrNext, locationSearchOrOpts, opts) => {
			if (typeof pathnameOrNext === "string") return this.matchRoutesInternal({
				pathname: pathnameOrNext,
				search: locationSearchOrOpts
			}, opts);
			return this.matchRoutesInternal(pathnameOrNext, locationSearchOrOpts);
		};
		this.getMatchedRoutes = (pathname) => {
			const rawParams = Object.create(null);
			const match = findRouteMatch(trimPathRight(pathname), this.processedTree, true);
			if (match) Object.assign(rawParams, match.rawParams);
			return [
				match?.branch || [this.routesById["__root__"]],
				rawParams,
				match?.route
			];
		};
		this.buildLocation = (opts) => {
			if (!this.isServer) {
				const cached = this.staticLocations.get(opts);
				if (cached) return cached;
			}
			let usedCurrent = false;
			const build = (dest = {}) => {
				if (dest.href) {
					const parsed = parseHref(dest.href, {});
					dest = {
						...dest,
						to: executeRewriteInput(this.rewrite, new URL(parsed.pathname, this.origin)).pathname,
						search: this.options.parseSearch(parsed.search),
						hash: parsed.hash.slice(1)
					};
				}
				const currentLocation = dest._fromLocation || this._pendingLocation || this.latestLocation;
				let lightweight;
				const current = () => {
					usedCurrent = true;
					return currentLocation;
				};
				const currentMatch = () => {
					usedCurrent = true;
					return lightweight ??= this.matchRoutesLightweight(currentLocation);
				};
				if (dest.from && dest._isNavigate) {
					const [allFromMatches] = this.getMatchedRoutes(dest.from);
					const [matchedRoutes, fullPath] = currentMatch();
					const matchedFrom = findLast(matchedRoutes, (d) => {
						return comparePaths(d.fullPath, dest.from);
					});
					const matchedCurrent = findLast(allFromMatches, (d) => {
						return comparePaths(d.fullPath, fullPath);
					});
					if (!matchedFrom && !matchedCurrent) console.warn(`Could not find match for from: ${dest.from}`);
				}
				const to = dest.to ? `${dest.to}` : ".";
				const nextTo = resolvePath(to[0] === "/" ? "" : dest.unsafeRelative === "path" ? current().pathname : dest.from ?? currentMatch()[1], to, this.options.trailingSlash, this.resolvePathCache);
				const destRoute = this.routesByPath[trimPathRight(nextTo)];
				const isTemplate = nextTo.includes("$");
				let destRoutes;
				if (destRoute) destRoutes = destRoute._branch ??= buildRouteBranch(destRoute);
				else if (isTemplate) destRoutes = [];
				else {
					const [matchedRoutes, rawParams, foundRoute] = this.getMatchedRoutes(nextTo);
					destRoutes = matchedRoutes;
					if (this.options.notFoundRoute && (!foundRoute || foundRoute.path !== "/" && rawParams["**"])) destRoutes = [...destRoutes, this.options.notFoundRoute];
				}
				const interpolation = isTemplate ? destRoute?._interpolation ?? parseSegments(false, { fullPath: nextTo }, 0) : void 0;
				let nextParams;
				for (const route of destRoutes) {
					const fn = route.options.params?.stringify ?? route.options.stringifyParams;
					if (fn) {
						const fromParams = currentMatch()[3];
						nextParams ??= resolveNextParams(dest.params, fromParams);
						if (!hasKeys(nextParams)) break;
						if (nextParams === fromParams) nextParams = Object.assign(createNull(), nextParams);
						try {
							Object.assign(nextParams, fn(nextParams));
						} catch {}
					}
				}
				nextParams ??= resolveNextParams(dest.params, needsInheritedParams(dest.params, interpolation) ? currentMatch()[3] : EMPTY_RECORD);
				const nextPathname = opts.leaveParams ? nextTo : normalizeProtocolRelative(decodePath(interpolation ? interpolatePath(nextTo, interpolation, nextParams, this.pathParamsDecoder) : nextTo));
				if (destRoute && !opts.leaveParams) try {
					const foundRoute = this.getMatchedRoutes(nextPathname)[2];
					if (foundRoute?.id !== destRoute.id) console.warn(`Generated path "${nextPathname}" for route "${destRoute.id}" matched route "${foundRoute?.id}" instead. This can happen when multiple route templates resolve to the same URL. Use the route template that matches the intended route, or adjust params.stringify if it changed the target path.`);
				} catch {}
				const middlewares = getSearchMiddlewares(destRoutes, opts._includeValidateSearch);
				const fromSearch = () => {
					let search = currentMatch()[2];
					if (opts._includeValidateSearch && this.options.search?.strict) {
						const validatedSearch = {};
						destRoutes.forEach((route) => {
							if (route.options.validateSearch) try {
								Object.assign(validatedSearch, validateSearch(route.options.validateSearch, {
									...validatedSearch,
									...search
								}));
							} catch {}
						});
						search = validatedSearch;
					}
					return search;
				};
				const nextSearch = middlewares.length ? applySearchMiddleware(middlewares, fromSearch(), dest) : dest.search === true ? fromSearch() : typeof dest.search === "function" ? dest.search(fromSearch()) : dest.search || EMPTY_RECORD;
				const searchStr = this.options.stringifySearch(nextSearch);
				const hash = dest.hash === true ? current().hash : typeof dest.hash === "function" ? dest.hash(current().hash) : dest.hash || void 0;
				const hashStr = hash ? `#${hash}` : "";
				const nextState = !dest.state ? EMPTY_RECORD : dest.state === true ? current().state : typeof dest.state === "function" ? dest.state(current().state) : dest.state;
				const fullPath = `${nextPathname}${searchStr}${hashStr}`;
				let href;
				let publicHref;
				let external = false;
				if (this.rewrite) {
					const url = new URL(fullPath, this.origin);
					const origin = url.origin;
					const rewrittenUrl = executeRewriteOutput(this.rewrite, url);
					href = getUrlPath(url);
					if (isExternalUrl(rewrittenUrl, origin)) {
						publicHref = rewrittenUrl.href;
						external = true;
					} else publicHref = normalizeProtocolRelative(getUrlPath(rewrittenUrl));
				} else {
					href = encodePathLikeUrl(fullPath);
					publicHref = href;
				}
				return {
					publicHref,
					href,
					pathname: nextPathname,
					search: nextSearch,
					searchStr,
					state: nextState,
					hash: hash ?? "",
					external,
					unmaskOnReload: dest.unmaskOnReload
				};
			};
			const next = build(opts);
			if (opts.mask) next.maskedLocation = build({
				from: opts.from,
				...opts.mask
			});
			else if (this.options.routeMasks) {
				const match = findFlatMatch(next.pathname, this.processedTree);
				if (match) {
					const params = Object.assign(createNull(), match.rawParams);
					const { from: _from, params: maskParams, ...maskProps } = match.route;
					const nextParams = resolveNextParams(maskParams, params);
					next.maskedLocation = build({
						from: opts.from,
						...maskProps,
						params: nextParams
					});
				}
			}
			if (!this.isServer && !usedCurrent && opts._fromLocation && !next.maskedLocation) this.staticLocations.set(opts, next);
			return next;
		};
		this.commitLocation = async ({ viewTransition, ignoreBlocker, ...next }) => {
			if (this.isServer) return;
			const nextLocation = next.maskedLocation ?? next;
			if (nextLocation.external && !this.isServer) return documentNavigation(this, nextLocation.publicHref, {
				replace: next.replace,
				ignoreBlocker
			});
			let historyAction;
			const isSameLocation = trimPathRight(this.latestLocation.href) === trimPathRight(next.href) && deepEqual(_getUserHistoryState(next.state), _getUserHistoryState(this.latestLocation.state));
			const previousCommitPromise = this._commitPromise;
			let resolve;
			const commitPromise = new Promise((done) => {
				resolve = done;
			});
			commitPromise.resolve = () => {
				resolve();
				previousCommitPromise?.resolve();
			};
			this._commitPromise = commitPromise;
			if (isSameLocation) this.load();
			else {
				let { maskedLocation, hashScrollIntoView, ...nextHistory } = next;
				if (maskedLocation) {
					nextHistory = {
						...maskedLocation,
						state: {
							...maskedLocation.state,
							__tempKey: void 0,
							__tempLocation: {
								...nextHistory,
								search: nextHistory.searchStr,
								state: {
									...nextHistory.state,
									__tempKey: void 0,
									__tempLocation: void 0,
									__TSR_key: void 0,
									key: void 0
								}
							}
						}
					};
					if (nextHistory.unmaskOnReload ?? this.options.unmaskOnReload ?? false) nextHistory.state.__tempKey = this.tempLocationKey;
				}
				nextHistory.state = {
					...nextHistory.state,
					__hashScrollIntoViewOptions: hashScrollIntoView ?? this.options.defaultHashScrollIntoView ?? true
				};
				this.shouldViewTransition = viewTransition;
				historyAction = next.replace ? "REPLACE" : "PUSH";
				this.history[historyAction === "REPLACE" ? "replace" : "push"](nextHistory.publicHref, nextHistory.state, { ignoreBlocker });
				if (!this.history.subscribers.size) this.load({ action: { type: historyAction } });
			}
			this._scroll.n = next.resetScroll ?? true;
			return this._commitPromise;
		};
		this.buildAndCommitLocation = ({ replace, resetScroll, hashScrollIntoView, viewTransition, ignoreBlocker, ...rest } = {}) => {
			if (this.isServer) return Promise.resolve();
			const location = this.buildLocation({
				...rest,
				_includeValidateSearch: true
			});
			this._pendingLocation = location;
			const commitPromise = this.commitLocation({
				...location,
				viewTransition,
				replace,
				resetScroll,
				hashScrollIntoView,
				ignoreBlocker
			});
			queueMicrotask(() => {
				if (this._pendingLocation === location) this._pendingLocation = void 0;
			});
			return commitPromise;
		};
		this.navigate = async ({ to, reloadDocument, href, publicHref, ...rest }) => {
			if (this.isServer) return;
			const hrefScheme = href ? getUrlScheme(href) : void 0;
			if (hrefScheme || reloadDocument) {
				if (to !== void 0 || !href) {
					const location = this.buildLocation({
						to,
						...rest
					});
					const publicLocation = location.maskedLocation ?? location;
					href ??= publicLocation.publicHref;
					publicHref ??= publicLocation.publicHref;
				}
				const reloadHref = !hrefScheme && publicHref ? publicHref : href;
				return documentNavigation(this, reloadHref, rest);
			}
			return this.buildAndCommitLocation({
				...rest,
				href,
				to,
				_isNavigate: true
			});
		};
		this.load = async (opts) => {
			if (this.isServer) return loadServerRoute(this, opts);
			this.updateLatestLocation();
			if (opts?.action) this._scroll.h = opts.action.type === "PUSH" || opts.action.type === "REPLACE";
			await loadClientRoute(this, opts);
		};
		this.startViewTransition = (fn) => {
			const shouldViewTransition = this.shouldViewTransition ?? this.options.defaultViewTransition;
			this.shouldViewTransition = void 0;
			if (shouldViewTransition && !(typeof document === "undefined") && typeof document.startViewTransition === "function") {
				let startViewTransitionParams;
				if (typeof shouldViewTransition === "object" && window.CSS?.supports?.("selector(:active-view-transition-type(a))")) {
					const next = this.latestLocation;
					const prevLocation = this.stores.resolvedLocation.get();
					const resolvedViewTransitionTypes = typeof shouldViewTransition.types === "function" ? shouldViewTransition.types(getLocationChangeInfo(next, prevLocation)) : shouldViewTransition.types;
					if (resolvedViewTransitionTypes === false) return fn();
					startViewTransitionParams = {
						update: fn,
						types: resolvedViewTransitionTypes
					};
				} else startViewTransitionParams = fn;
				return document.startViewTransition(startViewTransitionParams).updateCallbackDone;
			}
			return fn();
		};
		this.invalidate = (opts) => {
			const committedMatches = this._committed;
			const filter = opts?.filter;
			const preloads = this._preloads;
			const invalidIds = /* @__PURE__ */ new Set();
			const consider = (match) => {
				if (!filter || filter(match)) invalidIds.add(match.id);
			};
			committedMatches.forEach(consider);
			this._cache.forEach(consider);
			preloads?.forEach((matches) => matches.forEach(consider));
			this._tx?.[3].forEach(consider);
			const abort = [];
			for (const [controller, matches] of preloads ?? []) if (matches.some((match) => invalidIds.has(match.id))) {
				preloads.delete(controller);
				abort.push(controller);
			}
			const invalidate = (d) => {
				if (invalidIds.has(d.id)) {
					const route = this.routesById[d.routeId];
					const next = {
						...d,
						invalid: true,
						...(opts?.forcePending || d.status === "error" || d.status === "notFound") && routeNeedsLoad(route) ? {
							status: "pending",
							error: void 0
						} : void 0
					};
					d._flight = void 0;
					return next;
				}
				return d;
			};
			this._committed = committedMatches.map(invalidate);
			for (const [id, match] of this._cache) if (invalidIds.has(id)) {
				match.invalid = true;
				if (opts?.forcePending) match.status = "pending";
			}
			for (const id of invalidIds) {
				const flight = this._flights?.get(id);
				this._flights?.delete(id);
				if (flight && !flight[2]) abort.push(flight[1]);
			}
			for (const controller of abort) controller.abort();
			this.shouldViewTransition = false;
			return this.load({ sync: opts?.sync });
		};
		this.resolveRedirect = (redirect) => {
			const options = redirect.options;
			let href = redirect.headers.get("Location") || options.href;
			if (!href) {
				const location = this.buildLocation(options);
				href = (location.maskedLocation ?? location).publicHref || "/";
			}
			let scheme;
			if (protocolRelativePrefixRegex.test(href) || (scheme = getUrlScheme(href)) && !this.protocolAllowlist.has(scheme)) throw new Error(`Redirect blocked: unsafe protocol in href "${href}". Allowed protocols: ${Array.from(this.protocolAllowlist).join(", ")}.`);
			if (scheme === "http:" || scheme === "https:") {
				const url = new URL(href);
				if (url.pathname.startsWith("//")) href = url.href;
				else if (!isExternalUrl(url, this.origin)) {
					href = getUrlPath(url);
					scheme = void 0;
				}
			}
			if (scheme) options.reloadDocument = true;
			options.href = href;
			redirect.headers.set("Location", href);
			return redirect;
		};
		this.clearCache = (opts) => {
			const cached = this._cache;
			const preloads = this._preloads;
			const filter = opts?.filter;
			const discarded = [];
			const discardedIds = [];
			for (const [id, match] of cached) if (!filter || filter(match)) {
				discardedIds.push(id);
				discarded.push(match);
			}
			const abort = [];
			for (const [controller, matches] of preloads ?? []) if (!filter || matches.some(filter)) {
				abort.push(controller);
				discarded.push(...matches);
			}
			for (const id of discardedIds) cached.delete(id);
			for (const controller of abort) preloads.delete(controller);
			for (const match of discarded) {
				const flight = match._flight;
				match._flight = void 0;
				if (flight && !--flight[2]) {
					if (this._flights?.get(match.id) === flight) this._flights.delete(match.id);
					abort.push(flight[1]);
				}
			}
			for (const controller of abort) controller.abort();
		};
		this.loadRouteChunk = loadRouteChunk;
		this.preloadRoute = (opts) => preloadClientRoute(this, opts);
		this.matchRoute = (location, opts) => {
			const matchLocation = {
				...location,
				to: location.to ? resolvePath(location.from || "", location.to, this.options.trailingSlash, this.resolvePathCache) : void 0,
				params: location.params || {},
				leaveParams: true
			};
			const next = this.buildLocation(matchLocation);
			const isPending = this.stores.status.get() === "pending";
			if (opts?.pending && !isPending) return false;
			const baseLocation = opts?.pending ?? !isPending ? this.latestLocation : this.stores.resolvedLocation.get() || this.stores.location.get();
			const match = findSingleMatch(next.pathname, opts?.caseSensitive ?? false, opts?.fuzzy ?? false, baseLocation.pathname, this.processedTree);
			if (!match) return false;
			if (location.params) {
				if (!deepEqual(match.rawParams, location.params, true)) return false;
			}
			if (opts?.includeSearch ?? true) return deepEqual(baseLocation.search, next.search, true) ? match.rawParams : false;
			return match.rawParams;
		};
		this.getStoreConfig = getStoreConfig;
		if (options.pathParamsAllowedCharacters?.length) this.pathParamsDecoder = compileDecodeCharMap(options.pathParamsAllowedCharacters);
		this.update({
			defaultPreloadDelay: 50,
			defaultPendingMs: 1e3,
			defaultPendingMinMs: 500,
			context: void 0,
			...options,
			caseSensitive: options.caseSensitive ?? false,
			notFoundMode: options.notFoundMode ?? "fuzzy",
			stringifySearch: options.stringifySearch ?? defaultStringifySearch,
			parseSearch: options.parseSearch ?? defaultParseSearch,
			protocolAllowlist: options.protocolAllowlist ?? DEFAULT_PROTOCOL_ALLOWLIST
		});
		if (!(typeof document === "undefined")) self.__TSR_ROUTER__ = this;
	}
	isShell() {
		return !!this.options.isShell;
	}
	get state() {
		return this.stores.__store.get();
	}
	setRoutes(caches) {
		Object.assign(this, caches);
		this.lightweightCache = /* @__PURE__ */ new WeakMap();
		if (!this.isServer) this.staticLocations = /* @__PURE__ */ new WeakMap();
		const notFoundRoute = this.options.notFoundRoute;
		if (notFoundRoute) {
			notFoundRoute.init(99999999999);
			if (this.routesById[notFoundRoute.id] !== notFoundRoute) notFoundRoute._interpolation = parseSegments(false, notFoundRoute, 0);
			this.routesById[notFoundRoute.id] = notFoundRoute;
		}
	}
	matchRoutesInternal(next, opts) {
		const [initialMatchedRoutes, rawParams, foundRoute] = this.getMatchedRoutes(next.pathname);
		let matchedRoutes = initialMatchedRoutes;
		let isGlobalNotFound = false;
		if (foundRoute ? foundRoute.path !== "/" && rawParams["**"] : trimPathRight(next.pathname)) if (this.options.notFoundRoute) matchedRoutes = [...matchedRoutes, this.options.notFoundRoute];
		else isGlobalNotFound = true;
		const _notFoundRouteId = isGlobalNotFound ? findGlobalNotFoundRouteId(this.options.notFoundMode, matchedRoutes) : void 0;
		const matches = new Array(matchedRoutes.length);
		const committed = this._committed;
		const previousAt = (route, index) => {
			const match = committed[index];
			return match?.routeId === route.id ? match : route === this.options.notFoundRoute ? committed.find((candidate) => candidate.routeId === route.id) : void 0;
		};
		let strictParams;
		for (let index = 0; index < matchedRoutes.length; index++) {
			const route = matchedRoutes[index];
			const parentMatch = matches[index - 1];
			let preMatchSearch;
			let strictMatchSearch;
			let searchError;
			{
				const parentSearch = parentMatch?.search ?? next.search;
				const parentStrictSearch = parentMatch?._strictSearch ?? void 0;
				try {
					const strictSearch = validateSearch(route.options.validateSearch, { ...parentSearch }) ?? void 0;
					preMatchSearch = {
						...parentSearch,
						...strictSearch
					};
					strictMatchSearch = {
						...parentStrictSearch,
						...strictSearch
					};
				} catch (err) {
					let searchParamError = err;
					if (!(err instanceof SearchParamError)) searchParamError = new SearchParamError(err.message, { cause: err });
					if (opts?.throwOnError) throw searchParamError;
					preMatchSearch = parentSearch;
					strictMatchSearch = {};
					searchError = searchParamError;
				}
			}
			let loaderDeps = "";
			let loaderDepsHash = "";
			try {
				loaderDeps = route.options.loaderDeps?.({ search: preMatchSearch }) ?? "";
				loaderDepsHash = loaderDeps ? JSON.stringify(loaderDeps) || "" : "";
			} catch (cause) {
				if (opts?.throwOnError) throw cause;
				searchError ??= cause;
			}
			const usedParams = createNull();
			const interpolatedPath = route._interpolation ? interpolatePath(route.fullPath, route._interpolation, rawParams, this.pathParamsDecoder, usedParams) : route.fullPath;
			const matchId = route.id + interpolatedPath + loaderDepsHash;
			const previousMatch = previousAt(route, index);
			const existingMatch = opts?._rematerialize ? void 0 : this._cache.get(matchId) ?? (previousMatch?.id === matchId ? previousMatch : void 0);
			strictParams = existingMatch?._strictParams ?? Object.assign(usedParams, strictParams);
			let paramsError;
			if (!existingMatch) try {
				extractStrictParams(route, strictParams);
			} catch (err) {
				if (isNotFound(err) || isRedirect(err)) paramsError = err;
				else paramsError = new PathParamError(err.message, { cause: err });
				if (opts?.throwOnError) throw paramsError;
			}
			const cause = previousMatch ? "stay" : "enter";
			let match;
			if (existingMatch) match = {
				...existingMatch,
				cause,
				search: previousMatch ? nullReplaceEqualDeep(previousMatch.search, preMatchSearch) : nullReplaceEqualDeep(existingMatch.search, preMatchSearch),
				_strictSearch: strictMatchSearch,
				searchError
			};
			else {
				const status = routeNeedsLoad(route) ? "pending" : "success";
				match = {
					id: matchId,
					ssr: this.isServer ? void 0 : route.options.ssr,
					index,
					routeId: route.id,
					params: previousMatch?.params ?? strictParams,
					_strictParams: strictParams,
					pathname: interpolatedPath,
					updatedAt: Date.now(),
					search: previousMatch ? nullReplaceEqualDeep(previousMatch.search, preMatchSearch) : preMatchSearch,
					_strictSearch: strictMatchSearch,
					searchError,
					status,
					isFetching: false,
					error: void 0,
					paramsError,
					context: {},
					abortController: opts?._controller ?? new AbortController(),
					cause,
					loaderDeps: previousMatch ? replaceEqualDeep(previousMatch.loaderDeps, loaderDeps) : loaderDeps,
					invalid: false,
					preload: false,
					staticData: route.options.staticData || {},
					fullPath: route.fullPath
				};
			}
			const _notFound = _notFoundRouteId === route.id;
			if (match._notFound && !_notFound) match.error = void 0;
			match._notFound = _notFound;
			matches[index] = match;
		}
		for (let index = 0; index < matches.length; index++) {
			const match = matches[index];
			match.params = match.cause === "stay" ? nullReplaceEqualDeep(match.params, strictParams) : strictParams;
			if (opts?._controller) match.context = {};
		}
		return matches;
	}
	/**
	* Lightweight route matching for buildLocation.
	* Only computes fullPath, accumulated search, and params - skipping expensive
	* operations like AbortController, loaderDeps, and full match objects.
	*/
	matchRoutesLightweight(location) {
		const lastRouteId = last(this.stores.ids.get());
		const lastStateMatch = lastRouteId ? this.stores.byRoute.get(lastRouteId).get() : void 0;
		const lastStateMatchId = lastStateMatch?.id;
		const cached = this.lightweightCache.get(location);
		if (cached && cached[0] === lastStateMatchId) return cached[1];
		const [matchedRoutes, rawParams] = this.getMatchedRoutes(location.pathname);
		const lastRoute = last(matchedRoutes);
		const accumulatedSearch = { ...location.search };
		for (const route of matchedRoutes) try {
			Object.assign(accumulatedSearch, validateSearch(route.options.validateSearch, accumulatedSearch));
		} catch {}
		const canReuseParams = lastStateMatch && lastStateMatch.routeId === lastRoute.id && lastStateMatch.pathname === location.pathname;
		let params;
		if (canReuseParams) params = lastStateMatch.params;
		else {
			const strictParams = rawParams;
			for (const route of matchedRoutes) try {
				extractStrictParams(route, strictParams);
			} catch {}
			params = strictParams;
		}
		const result = [
			matchedRoutes,
			lastRoute.fullPath,
			accumulatedSearch,
			params
		];
		this.lightweightCache.set(location, [lastStateMatchId, result]);
		return result;
	}
};
async function documentNavigation(router, href, { replace, ignoreBlocker }) {
	if (isDangerousProtocol(href, router.protocolAllowlist)) {
		console.warn(`Blocked navigation to dangerous protocol: ${href}`);
		return;
	}
	if (!ignoreBlocker) {
		const blockers = router.history._getBlockers();
		for (const blocker of blockers) if (blocker?.blockerFn) {
			if (await blocker.blockerFn({
				currentLocation: router.history.location,
				nextLocation: router.history.location,
				action: replace ? "REPLACE" : "PUSH"
			})) return;
		}
	}
	router.history._ignoreNextBeforeUnload?.(href);
	if (replace) window.location.replace(href);
	else window.location.href = href;
}
RouterCore.prototype._replaceRouteChunk = replaceRouteChunk;
RouterCore.prototype._refreshRoute = async function() {
	this._serverResult = void 0;
	this.updateLatestLocation();
	await refreshClientRoute(this);
};
/** Error thrown when search parameter validation fails. */
var SearchParamError = class extends Error {};
/** Error thrown when path parameter parsing/validation fails. */
var PathParamError = class extends Error {};
var normalize$2 = (str) => str.endsWith("/") && str.length > 1 ? str.slice(0, -1) : str;
function comparePaths(a, b) {
	return normalize$2(a) === normalize$2(b);
}
/**
* Lazily import a module function and forward arguments to it, retaining
* parameter and return types for the selected export key.
*/
function lazyFn(fn, key) {
	return async (...args) => {
		return (await fn())[key || "default"](...args);
	};
}
function validateSearch(validateSearch, input) {
	if (validateSearch == null) return {};
	if ("~standard" in validateSearch) {
		const result = validateSearch["~standard"].validate(input);
		if (result instanceof Promise) throw new SearchParamError("Async validation not supported");
		if (result.issues) throw new SearchParamError(JSON.stringify(result.issues, void 0, 2), { cause: result });
		return result.value;
	}
	if ("parse" in validateSearch) return validateSearch.parse(input);
	if (typeof validateSearch === "function") return validateSearch(input);
	return {};
}
function resolveNextParams(spec, base) {
	if (spec === void 0 || spec === true) return base;
	const next = Object.create(null);
	if (spec === false || spec === null) return next;
	if (typeof spec === "function") {
		Object.assign(next, base);
		return Object.assign(next, spec(next));
	}
	return Object.assign(next, base, spec);
}
function needsInheritedParams(spec, interpolation) {
	if (typeof spec === "function") return true;
	if (!interpolation || spec === false || spec === null) return false;
	return spec === void 0 || spec === true || interpolation.some((part) => typeof part !== "string" && !hasOwn.call(spec, part[1]));
}
var EMPTY_RECORD = Object.freeze({});
function getSearchMiddlewares(destRoutes, includeValidateSearch) {
	const middlewares = [];
	for (let i = 0; i < destRoutes.length; i++) {
		const routeOptions = destRoutes[i].options;
		if ("search" in routeOptions) {
			if (routeOptions.search?.middlewares) middlewares.push(...routeOptions.search.middlewares);
		} else if (routeOptions.preSearchFilters || routeOptions.postSearchFilters) {
			const legacyMiddleware = ({ search, next }) => {
				const result = next(routeOptions.preSearchFilters ? routeOptions.preSearchFilters.reduce((prev, next) => next(prev), search) : search);
				return routeOptions.postSearchFilters ? routeOptions.postSearchFilters.reduce((prev, next) => next(prev), result) : result;
			};
			middlewares.push(legacyMiddleware);
		}
		const routeValidateSearch = routeOptions.validateSearch;
		if (includeValidateSearch && routeValidateSearch) {
			const validate = ({ search, next, meta }) => {
				const result = next(search);
				try {
					const validated = validateSearch(routeValidateSearch, result);
					if (meta && validated) {
						for (const key in validated) if (!(key in result)) (meta.defaulted ||= /* @__PURE__ */ new Map()).set(key, validated[key]);
					}
					return {
						...result,
						...validated
					};
				} catch {}
				return result;
			};
			middlewares.push(validate);
		}
	}
	return middlewares;
}
function applySearchMiddleware(middlewares, search, dest) {
	const applyNext = (index, currentSearch, meta) => {
		if (index >= middlewares.length) {
			if (!dest.search) return {};
			if (dest.search === true) return currentSearch;
			const result = functionalUpdate(dest.search, currentSearch);
			if (meta) meta.explicit = result;
			return result;
		}
		const next = (newSearch, collectMeta) => {
			if (collectMeta) {
				const nextMeta = meta || {};
				return {
					search: applyNext(index + 1, newSearch, nextMeta),
					meta: nextMeta
				};
			}
			return applyNext(index + 1, newSearch, meta);
		};
		return middlewares[index]({
			search: currentSearch,
			next,
			meta
		});
	};
	return applyNext(0, search);
}
function findGlobalNotFoundRouteId(notFoundMode, routes) {
	if (notFoundMode !== "root") {
		let fallback;
		for (let i = routes.length - 1; i >= 0; i--) {
			const route = routes[i];
			if (route.options.notFoundComponent) return route.id;
			fallback ||= route.children && route.id;
		}
		if (fallback) return fallback;
	}
	return rootRouteId;
}
function extractStrictParams(route, accumulatedParams) {
	const parseParams = route.options.params?.parse ?? route.options.parseParams;
	if (parseParams) Object.assign(accumulatedParams, parseParams(accumulatedParams));
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/load-client.js
function replaceRouteChunk(route, lazyFn) {
	route.lazyFn = lazyFn ?? route.lazyFn;
	route._lazy = void 0;
}
function preloadComponent(route, type) {
	return route.options[type]?.preload?.();
}
function loadComponents(route, onPendingReady) {
	const component = preloadComponent(route, "component");
	let pending = preloadComponent(route, "pendingComponent");
	if (onPendingReady) if (pending) pending = pending.then(onPendingReady);
	else onPendingReady();
	if (component && pending) return Promise.all([component, pending]).then(() => {});
	return component ?? pending;
}
function loadRouteChunk(route, componentType, onPendingReady) {
	const afterLazy = () => componentType === false ? void 0 : componentType ? preloadComponent(route, componentType) : loadComponents(route, onPendingReady);
	const current = route._lazy;
	if (current) return current === true ? afterLazy() : current.then(afterLazy);
	if (!route.lazyFn) return afterLazy();
	const promise = route.lazyFn().then((lazyRoute) => {
		if (route._lazy === promise) {
			const { id: _id, ...options } = lazyRoute.options;
			Object.assign(route.options, options);
			route._lazy = true;
		}
	}, (error) => {
		if (route._lazy === promise) route._lazy = void 0;
		throw error;
	});
	route._lazy = promise;
	return promise.then(afterLazy);
}
/** Return the structural lane through the first terminal render boundary. */
function _getRenderedMatches(matches) {
	const end = matches.findIndex((match) => match.status !== "success" || match._notFound) + 1;
	return end && end < matches.length ? matches.slice(0, end) : matches;
}
/** Return the lane whose document assets belong to the current presentation. */
function _getAssetMatches(matches) {
	let end = matches.length;
	for (let index = 0; index < end; index++) {
		const match = matches[index];
		if (match._assetEnd !== void 0) {
			end = Math.min(end, Math.max(index + 1, match._assetEnd));
			continue;
		}
		if (match.status !== "success" || match._notFound) {
			end = index + 1;
			break;
		}
	}
	return end < matches.length ? matches.slice(0, end) : matches;
}
var SUCCESS$1 = 0;
var ERROR$1 = 1;
var NOT_FOUND$1 = 2;
var REDIRECTED$1 = 3;
var CANCELED_OUTCOME = [4];
function isControl(result) {
	return typeof result[0] === "number";
}
function waitFor$1(value, signal) {
	if (signal.aborted) return Promise.race([Promise.reject(signal), value]);
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal);
		signal.addEventListener("abort", abort, { once: true });
		Promise.resolve(value).then(resolve, reject).then(() => signal.removeEventListener("abort", abort));
	});
}
function getRoute$1(router, match) {
	return router.routesById[match.routeId];
}
function normalize$1(value, rejected, routeId) {
	if (isRedirect(value)) return [REDIRECTED$1, value];
	if (isNotFound(value)) {
		value.routeId ||= routeId;
		return [NOT_FOUND$1, value];
	}
	if (!rejected) return [SUCCESS$1, value];
	if (typeof value?.then === "function") value = new Error("A Promise was thrown", { cause: value });
	return [ERROR$1, value];
}
function normalizeError$1(route, cause) {
	let outcome = normalize$1(cause, true, route.id);
	if (outcome[0] !== ERROR$1) return outcome;
	try {
		route.options.onError?.(outcome[1]);
	} catch (onErrorCause) {
		outcome = normalize$1(onErrorCause, true, route.id);
	}
	return outcome;
}
function normalizeLaneError(router, lane, route, cause, options) {
	if (options[0].signal.aborted) return CANCELED_OUTCOME;
	return materializeRedirect$1(router, lane, route, normalizeError$1(route, cause), options);
}
async function contextualize$1(router, lane, options, end, planSuccessfulLane, retainedEnd) {
	const [location, matches] = lane;
	const signal = options[0].signal;
	const preload = !!options[3];
	for (let index = options[6] ?? 0; index < end; index++) {
		const match = matches[index];
		const route = getRoute$1(router, match);
		match.abortController = options[0];
		const parentContext = matches[index - 1]?.context ?? router.options.context ?? {};
		const common = {
			params: match.params,
			location,
			navigate: (opts) => router.navigate({
				...opts,
				_fromLocation: location
			}),
			buildLocation: router.buildLocation,
			cause: preload ? "preload" : match.cause,
			abortController: options[0],
			preload,
			matches,
			routeId: route.id
		};
		try {
			const routeContext = match._ctx ||= route.options.context ? route.options.context({
				...common,
				deps: match.loaderDeps,
				context: parentContext
			}) || {} : void 0;
			match.context = {
				...parentContext,
				...routeContext
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		if (signal.aborted) return [index, CANCELED_OUTCOME];
		const validationError = match.paramsError ?? match.searchError;
		if (validationError !== void 0) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, validationError, options)];
		}
		const beforeLoad = route.options.beforeLoad;
		if (!beforeLoad) continue;
		const previousStatus = match.status;
		if (index >= retainedEnd) {
			match.status = "pending";
			options[7]?.();
		}
		try {
			setFetching(router, match, "beforeLoad", options[0]);
			const value = beforeLoad({
				...common,
				search: match.search,
				context: match.context,
				...router.options.additionalContext
			});
			const result = await (typeof value?.then === "function" ? waitFor$1(value, signal) : value);
			if (signal.aborted) return [index, CANCELED_OUTCOME];
			const outcome = materializeRedirect$1(router, lane, route, normalize$1(result, false, route.id), options);
			if (outcome[0] !== SUCCESS$1) {
				releaseFlight(router, match);
				return [index, outcome];
			}
			match.context = {
				...match.context,
				...result
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		} finally {
			match.status = previousStatus;
			setFetching(router, match, false, options[0]);
		}
	}
	planSuccessfulLane();
}
function releaseOwnedFlight(router, match, flight) {
	if (!flight || --flight[2]) return;
	if (router._flights?.get(match.id) === flight) {
		const current = router._tx;
		if (current && !current[0].signal.aborted && !current[3].includes(match) && current[3].some((candidate) => candidate.id === match.id) && current[3].some((candidate) => candidate.isFetching === "beforeLoad")) return;
		router._flights.delete(match.id);
	}
	return flight[1];
}
function releaseFlight(router, match) {
	const flight = match._flight;
	match._flight = void 0;
	releaseOwnedFlight(router, match, flight)?.abort();
}
/**
* Not passing in a `next` ownership recipient
* is equivalent to discarding the match resources
*/
function transferMatchResources(router, previous, next, deferSameIdFlight) {
	const abort = [];
	for (const match of previous) if (!next?.includes(match)) {
		const flight = match._flight;
		match._flight = void 0;
		if (deferSameIdFlight && flight?.[2] === 1 && router._flights?.get(match.id) === flight && next?.some((candidate) => candidate.id === match.id)) flight[2] = 0;
		else {
			const controller = releaseOwnedFlight(router, match, flight);
			if (controller) abort.push(controller);
		}
	}
	for (const controller of abort) controller.abort();
}
function acquireMatchResources(matches) {
	for (const match of matches) {
		const flight = match._flight;
		if (flight) flight[2]++;
	}
}
function setFetching(router, match, value, owner) {
	match.isFetching = value;
	if (owner && router._tx?.[0] !== owner) return;
	const store = router.stores.byRoute.get(match.routeId);
	const presented = store?.get();
	if (presented?.id === match.id) store.set({
		...presented,
		isFetching: value
	});
}
function getLoaderContext$1(router, lane, match, route, controller, parentMatchPromise, preload) {
	const location = lane[0];
	return {
		params: match.params,
		location,
		navigate: (opts) => router.navigate({
			...opts,
			_fromLocation: location
		}),
		cause: preload ? "preload" : match.cause,
		abortController: controller,
		preload,
		deps: match.loaderDeps,
		parentMatchPromise,
		context: match.context,
		route,
		...router.options.additionalContext
	};
}
async function loadResource(router, lane, match, route, loader, parentMatchPromise, options) {
	const owner = options[0];
	const signal = owner.signal;
	if (signal.aborted) return CANCELED_OUTCOME;
	if (!loader) return [SUCCESS$1, void 0];
	let flight = match._flight;
	setFetching(router, match, "loader", owner);
	try {
		if (!flight) {
			const controller = new AbortController();
			flight = [
				Promise.resolve().then(() => loader(getLoaderContext$1(router, lane, match, route, controller, parentMatchPromise, !!options[3]))).then((value) => normalize$1(value, false, route.id), (cause) => normalize$1(cause, true, route.id)).then((result) => {
					if (result[0] !== SUCCESS$1 && router._flights?.get(match.id) === flight) {
						router._flights.delete(match.id);
						if (!flight[2]) controller.abort();
					}
					return result[0] === ERROR$1 && flight[2] ? normalizeError$1(route, result[1]) : result;
				}),
				controller,
				1
			];
			(router._flights ??= /* @__PURE__ */ new Map()).set(match.id, flight);
		}
		match._flight = flight;
		match.abortController = flight[1];
		return materializeRedirect$1(router, lane, route, await waitFor$1(flight[0], signal), options);
	} catch (cause) {
		if (cause !== signal || !signal.aborted) throw cause;
		releaseFlight(router, match);
		return CANCELED_OUTCOME;
	} finally {
		setFetching(router, match, false, owner);
	}
}
function settleInto(match, result, preload) {
	if (result[0] === REDIRECTED$1) return;
	match.status = "success";
	match.error = void 0;
	if (result[0] === SUCCESS$1) {
		match.loaderData = result[1];
		match.invalid = false;
		match.updatedAt = Date.now();
		match.preload = preload;
	} else match.invalid = true;
}
function cacheLoaderMatch(router, match, planned) {
	const current = router._cache.get(match.id);
	if (current !== planned || router._committed.some((candidate) => candidate.id === match.id && candidate._flight === match._flight)) return;
	const cached = {
		...match,
		_notFound: void 0,
		context: {}
	};
	if (cached._flight) cached._flight[2]++;
	router._cache.set(match.id, cached);
	if (current) releaseFlight(router, current);
}
function getParentSnapshot(match, outcome) {
	if (outcome[0] === ERROR$1 || outcome[0] === NOT_FOUND$1) return {
		...match,
		status: outcome[0] === ERROR$1 ? "error" : "notFound",
		error: outcome[1],
		_flight: void 0
	};
	return match;
}
function createLoaderTask$1(router, lane, index, tasks, semanticParent, options, retainedEnd) {
	const match = lane[1][index];
	const route = getRoute$1(router, match);
	const preload = !!options[3];
	const plannedCacheMatch = router._cache.get(match.id);
	let configured;
	let reload = false;
	let reloadFailure;
	try {
		if (match.status === "success") {
			configured = route.options.shouldReload;
			if (typeof configured === "function") configured = configured(getLoaderContext$1(router, lane, match, route, options[0], semanticParent, preload));
			if (options[0].signal.aborted) reloadFailure = CANCELED_OUTCOME;
		}
		if (!reloadFailure) if (match.status !== "success") reload = true;
		else {
			const staleAge = preload || match.preload ? route.options.preloadStaleTime ?? router.options.defaultPreloadStaleTime ?? 3e4 : route.options.staleTime ?? router.options.defaultStaleTime ?? 0;
			reload = !!(match.invalid || configured || configured === void 0 && Date.now() - match.updatedAt >= staleAge && (options[5] || match.cause === "enter" || options[2].some((candidate) => candidate.routeId === match.routeId && candidate.id !== match.id)));
		}
	} catch (cause) {
		match.invalid = true;
		releaseFlight(router, match);
		reloadFailure = normalizeLaneError(router, lane, route, cause, options);
	}
	const routeLoader = route.options.loader;
	const isLoaderFn = typeof routeLoader === "function";
	const loader = isLoaderFn ? routeLoader : routeLoader?.handler;
	const preloadable = !preload || route.options.preload !== false;
	let donor = preloadable && routeLoader && !router._tx?.[6] ? router._flights?.get(match.id) : void 0;
	if (donor === match._flight || reloadFailure) donor = void 0;
	else if (donor && !reload && !preload && configured === void 0) reload = true;
	else if (!reload) donor = void 0;
	const background = !!(routeLoader && reload && match.status === "success" && !preload && !options[4] && ((isLoaderFn ? void 0 : routeLoader.staleReloadMode) ?? router.options.defaultStaleReloadMode) !== "blocking");
	const loaded = reload && preloadable;
	const blocking = loaded && !background && (match.status !== "success" || !!routeLoader);
	const onReady = index >= retainedEnd ? options[7] : void 0;
	const onLazyReady = route.lazyFn && route._lazy !== true ? onReady : void 0;
	if (loaded && !routeLoader) {
		match.invalid = false;
		match.updatedAt = Date.now();
	}
	if (donor) donor[2]++;
	if (blocking) {
		const acceptedFlight = match._flight;
		match._flight = donor;
		releaseOwnedFlight(router, match, acceptedFlight)?.abort();
		if (index >= retainedEnd) match.status = "pending";
		onReady?.();
	}
	if (!loaded) match.isFetching = false;
	const outcome = !reloadFailure && blocking ? loadResource(router, lane, match, route, loader, semanticParent, options).then((result) => {
		settleInto(match, result, preload);
		if (result[0] === SUCCESS$1) {
			if (routeLoader && !options[0].signal.aborted) cacheLoaderMatch(router, match, plannedCacheMatch);
			if (index >= retainedEnd) match.status = "pending";
		}
		return result;
	}) : Promise.resolve(reloadFailure ?? [SUCCESS$1, match.loaderData]);
	const chunkFailure = (async () => {
		try {
			const chunk = loadRouteChunk(route, void 0, onLazyReady);
			if (chunk) await waitFor$1(chunk, options[0].signal);
		} catch (cause) {
			if (!lane[1].some((candidate, candidateIndex) => candidateIndex <= index && (candidate.status === "error" || candidate.status === "notFound" || candidate._notFound))) return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		const result = await outcome;
		if (blocking && result[0] === SUCCESS$1 && match.status === "pending" && !options[0].signal.aborted) {
			match.status = "success";
			onReady?.();
		}
	})();
	tasks.push([
		index,
		outcome,
		chunkFailure
	]);
	if (!background) return outcome.then((result) => getParentSnapshot(match, result));
	const candidate = {
		...match,
		status: "pending",
		preload: false,
		_flight: donor
	};
	match.invalid = false;
	match.isFetching = "loader";
	const backgroundOutcome = loadResource(router, lane, candidate, route, loader, semanticParent, options).then((result) => {
		match.isFetching = false;
		settleInto(candidate, result, false);
		return result;
	});
	(lane[2] ??= []).push([
		index,
		backgroundOutcome,
		chunkFailure,
		candidate
	]);
	return backgroundOutcome.then((result) => getParentSnapshot(candidate, result));
}
async function getNotFoundBoundary$1(router, matches, indexed, signal, fallback = 0) {
	const cause = indexed?.[1][1];
	let index = cause?.routeId ? matches.findIndex((match) => match.routeId === cause.routeId) : indexed?.[0] ?? matches.length - 1;
	if (index < 0) index = 0;
	for (let i = index; i >= 0; i--) {
		const route = getRoute$1(router, matches[i]);
		try {
			const loading = loadRouteChunk(route, false);
			if (loading) await waitFor$1(loading, signal);
		} catch (cause) {
			if (cause === signal && signal.aborted) throw cause;
		}
		if (route.options.notFoundComponent) return i;
	}
	return cause?.routeId ? index : fallback;
}
function discardBackground(router, lane) {
	if (lane[2]) {
		transferMatchResources(router, lane[2].map((task) => task[3]));
		lane[2] = void 0;
	}
}
async function settleTasks(tasks, serialFailure, redirectTasks, gate) {
	let loaderFailure;
	try {
		await Promise.all(tasks.map((task) => task[1].then(async (outcome) => {
			const taskIndex = task[0];
			if (gate && taskIndex >= await gate) return;
			if (outcome[0] >= REDIRECTED$1) throw [taskIndex, outcome];
			if (!loaderFailure && outcome[0] !== SUCCESS$1) {
				loaderFailure = [taskIndex, outcome];
				await Promise.all((redirectTasks ?? []).map((nextTask) => {
					if (nextTask[0] <= taskIndex) return;
					return nextTask[1].then((nextOutcome) => {
						if (nextOutcome[0] === REDIRECTED$1) throw [nextTask[0], nextOutcome];
					});
				}));
			}
		})));
	} catch (cause) {
		return cause;
	}
	return serialFailure ?? loaderFailure;
}
function materializeRedirect$1(router, lane, route, outcome, options, failed) {
	while (outcome[0] === REDIRECTED$1) {
		const redirect = outcome[1];
		const redirectOptions = redirect.options;
		try {
			if (redirectOptions.href || redirect.headers.has("Location")) {
				router.resolveRedirect(redirect);
				if (redirectOptions.reloadDocument) return outcome;
			}
			if (redirectOptions.reloadDocument ? options[3] : options[1] >= 20) return outcome;
			const location = router.buildLocation({
				...redirectOptions,
				_fromLocation: lane[0],
				_includeValidateSearch: true
			});
			const publicLocation = location.maskedLocation ?? location;
			if (publicLocation.external) {
				const resolved = redirect.clone();
				resolved.options = { ...redirectOptions };
				resolved.headers.set("Location", publicLocation.publicHref);
				router.resolveRedirect(resolved);
				return options[3] ? [REDIRECTED$1, resolved] : [
					REDIRECTED$1,
					resolved,
					publicLocation
				];
			}
			return [
				REDIRECTED$1,
				redirect,
				location
			];
		} catch (cause) {
			outcome = failed ? [ERROR$1, cause] : normalizeError$1(route, cause);
			failed = true;
		}
	}
	return outcome;
}
async function reduceLane(router, lane, tasks, controller, settlement, onReady) {
	const matches = lane[1];
	let failure = await settlement;
	let redirectLimitExceeded = false;
	const plannedBoundary = matches.findIndex((match) => match._notFound);
	const boundaryOf = (found) => found[1][0] === NOT_FOUND$1 ? getNotFoundBoundary$1(router, matches, found, controller.signal) : found[0];
	let readinessEnd = plannedBoundary < 0 ? matches.length : plannedBoundary;
	if ((failure?.[1][0] ?? 0) >= REDIRECTED$1) readinessEnd = 0;
	else if (failure) {
		readinessEnd = failure[2] ??= await boundaryOf(failure);
		for (const task of tasks) {
			if (task[0] >= readinessEnd) break;
			const outcome = await task[1];
			if (outcome[0] !== SUCCESS$1 && outcome[0] < REDIRECTED$1 && !("loaderData" in matches[task[0]])) {
				failure = [task[0], outcome];
				readinessEnd = failure[2] = await boundaryOf(failure);
				break;
			}
		}
	}
	for (const task of tasks) {
		if (task[0] >= readinessEnd) break;
		const chunkFailure = await task[2];
		if (!chunkFailure) continue;
		failure = chunkFailure;
		break;
	}
	if ((failure?.[1][0] ?? 0) >= REDIRECTED$1) {
		const outcome = failure[1];
		if (outcome[0] !== REDIRECTED$1 || outcome[1].options.reloadDocument || outcome[2]) {
			discardBackground(router, lane);
			return outcome;
		}
		redirectLimitExceeded = true;
		failure = [0, [ERROR$1, /* @__PURE__ */ new Error("Too many redirects")]];
	}
	const boundary = failure ? failure[2] ?? await boundaryOf(failure) : plannedBoundary;
	if (boundary >= 0) {
		const outcome = failure?.[1];
		const kind = outcome?.[0];
		const match = matches[boundary];
		const cause = outcome?.[1];
		const install = () => {
			if (outcome) {
				match._notFound = void 0;
				if (kind === ERROR$1) match.status = "error";
				else {
					cause.routeId = match.routeId;
					if (match.routeId === router.routeTree.id) {
						match.status = "success";
						match._notFound = true;
					} else match.status = "notFound";
				}
				match.error = cause;
				match.isFetching = false;
			}
		};
		install();
		if (!outcome) onReady?.();
		const route = getRoute$1(router, match);
		try {
			await waitFor$1(outcome ? Promise.resolve().then(() => loadRouteChunk(route, kind === ERROR$1 ? "errorComponent" : "notFoundComponent")) : Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]), controller.signal);
		} catch (cause) {
			if (cause === controller.signal && controller.signal.aborted) {
				discardBackground(router, lane);
				return CANCELED_OUTCOME;
			}
		}
		if (!outcome) match.status = "success";
		else if (redirectLimitExceeded) {
			controller.abort();
			await Promise.all([
				...tasks.map((task) => task[1]),
				...tasks.map((task) => task[2]),
				...(lane[2] ?? []).map((task) => task[1])
			]);
			discardBackground(router, lane);
			transferMatchResources(router, matches);
			install();
		}
	}
	return lane;
}
async function projectLane$1(router, lane, signal, start = 0, end = lane[1].length) {
	const matches = lane[1];
	for (let index = start; index < end; index++) {
		const match = matches[index];
		const routeOptions = getRoute$1(router, match).options;
		if (routeOptions.head || routeOptions.scripts) try {
			const context = {
				ssr: router.options.ssr,
				matches,
				match,
				params: match.params,
				loaderData: match.loaderData
			};
			const [head, scripts] = await waitFor$1(Promise.all([routeOptions.head?.(context), routeOptions.scripts?.(context)]), signal);
			match.meta = head?.meta;
			match.links = head?.links;
			match.headScripts = head?.scripts;
			match.styles = head?.styles;
			match.scripts = scripts;
		} catch (cause) {
			if (cause === signal && signal.aborted) break;
			console.error(cause);
		}
		if (match.status !== "success" || match._notFound) break;
	}
	return lane;
}
async function executeClientLane(router, location, matches, options) {
	const matched = [location, matches];
	const signal = options[0].signal;
	let reduced;
	try {
		const presented = router.stores.matches.get();
		let plannedBoundary = matches.findIndex((match) => match._notFound);
		if (router.options.notFoundMode !== "root" && plannedBoundary >= 0) {
			const boundary = await getNotFoundBoundary$1(router, matches, void 0, signal, plannedBoundary);
			matches[plannedBoundary]._notFound = void 0;
			matches[boundary]._notFound = true;
			plannedBoundary = boundary;
		}
		let end = plannedBoundary < 0 ? matches.length : plannedBoundary + 1;
		let retainedEnd = 0;
		while (retainedEnd < end && retainedEnd !== plannedBoundary) {
			const match = matches[retainedEnd];
			const committed = options[2][retainedEnd];
			const visible = presented[retainedEnd];
			if (committed?.id !== match.id || committed.status !== "success" || match.preload || visible?.id !== match.id || visible.status !== "success") break;
			retainedEnd++;
			if (committed._notFound || visible._notFound) break;
		}
		const tasks = [];
		const start = options[6] ?? 0;
		let semanticParent = start ? Promise.resolve(matches[start - 1]) : void 0;
		const planSuccessfulLane = () => {
			for (let index = start; index < end; index++) {
				if (signal.aborted) break;
				semanticParent = createLoaderTask$1(router, matched, index, tasks, semanticParent, options, retainedEnd);
			}
		};
		const failure = await contextualize$1(router, matched, options, end, planSuccessfulLane, retainedEnd);
		if (failure) {
			options[4] = true;
			end = failure[0];
			if (failure[1][0] === NOT_FOUND$1) {
				const boundary = await getNotFoundBoundary$1(router, matches, failure, signal);
				failure[2] = boundary;
				end = Math.min(end, boundary + 1);
			} else if (failure[1][0] >= REDIRECTED$1) end = 0;
			planSuccessfulLane();
		}
		if (!signal.aborted && !options[3]) {
			const abort = [];
			for (const [id, flight] of router._flights ?? []) if (!flight[2]) {
				router._flights.delete(id);
				abort.push(flight[1]);
			}
			for (const controller of abort) controller.abort();
		}
		const reduction = reduceLane(router, matched, tasks, options[0], settleTasks(tasks, failure, matched[2]), options[7]);
		if (matched[2]?.length) matched[3] = settleTasks(matched[2], void 0, void 0, reduction.then((foreground) => isControl(foreground) ? 0 : _getRenderedMatches(matches).length, () => 0));
		reduced = await reduction;
	} catch (cause) {
		discardBackground(router, matched);
		if (cause === signal && signal.aborted) return CANCELED_OUTCOME;
		throw cause;
	}
	if (isControl(reduced)) return reduced;
	return projectLane$1(router, reduced, signal, options[6] === matches.length ? options[6] : 0);
}
/**
* Waits for `pendingMs`, then presents the complete lane. Rendering applies the
* selected boundary cutoff while retaining every match's structural state.
* A replacement load for the same match keeps the timer; choosing a different
* match resets it. `pendingMinMs` starts after the fallback renders.
*/
function offerPending(router, tx) {
	if (router._tx !== tx) return;
	const matches = tx[3];
	const presented = router.stores.matches.get();
	let session = router._pending;
	for (let index = 0; index < matches.length; index++) {
		const match = matches[index];
		const success = match.status === "success" && !match._notFound;
		const presentedPending = presented[index]?.id === match.id && presented[index]?.status === "pending";
		if (success && !presentedPending) continue;
		const route = getRoute$1(router, match);
		const delay = success || match.invalid ? 0 : route.options.pendingMs ?? router.options.defaultPendingMs;
		const component = route.options.pendingComponent ?? router.options.defaultPendingComponent;
		if (!component || typeof delay !== "number" || delay === Infinity) {
			if (session) {
				session[0] = tx;
				session[2] = 0;
				session[4] = true;
			}
			return;
		}
		const min = route.options.pendingMinMs ?? router.options.defaultPendingMinMs ?? 0;
		let tookOver = false;
		if (session?.[1] === match.id) {
			tookOver = session[0] !== tx;
			session[0] = tx;
		} else {
			clearTimeout(session?.[3]);
			router._pending = session = void 0;
		}
		if (!session) router._pending = session = [
			tx,
			match.id,
			presentedPending ? Date.now() + min : tx[4] + delay,
			void 0,
			presentedPending || void 0,
			component
		];
		if (session[4] && !tookOver && session[5] === component) return;
		session[5] = component;
		if (!session[4]) {
			clearTimeout(session[3]);
			const remaining = session[2] - Date.now();
			if (remaining > 0) {
				session[3] = setTimeout(() => offerPending(router, tx), remaining);
				return;
			}
			session[2] = 0;
		}
		const offered = matches.map((match) => ({
			...match,
			_flight: void 0
		}));
		offered[index].status = "pending";
		const ack = session[4] = router.startTransition(() => router.stores.setMatches(offered), offered).then((rendered) => {
			if (rendered && router._pending === session && session[4] === ack && !session[2]) session[2] = Date.now() + min;
			return rendered;
		});
		return;
	}
}
/**
* Cancels pending UI timing unless the current successor can take over the
* same boundary that remains painted.
*/
function finishPending(router, tx) {
	const session = router._pending;
	if (router._tx === tx || !router._tx?.[3].some((match) => match.id === session?.[1])) {
		clearTimeout(session?.[3]);
		router._pending = void 0;
	}
}
async function awaitPendingMinimum(router, tx) {
	const session = router._pending;
	if (!session) return;
	clearTimeout(session[3]);
	const remaining = session[2] - Date.now();
	if (!session[4] || remaining <= 0 || !_getRenderedMatches(tx[3]).some((match) => match.id === session[1])) return;
	let timer;
	try {
		await waitFor$1(new Promise((resolve) => {
			timer = setTimeout(resolve, remaining);
		}), tx[0].signal);
	} catch {}
	clearTimeout(timer);
}
function publishMatches(router, matches) {
	router._committed = matches;
	router.stores.setMatches(matches);
}
function commitMatches(router, tx, matches, resolvedPrefix) {
	const previous = router._committed;
	const previousEnd = router._lifecycleEnd;
	const previousCached = router._cache;
	for (const match of matches) {
		match.preload = false;
		if (resolvedPrefix) match._assetEnd = void 0;
	}
	const cut = _getRenderedMatches(matches).length;
	const cached = /* @__PURE__ */ new Map();
	if (!tx[6]) {
		const now = Date.now();
		const superseded = /* @__PURE__ */ new Set();
		for (let index = 0; index < matches.length; index++) {
			const match = matches[index];
			if (index < cut || match.status === "success") superseded.add(match.id);
		}
		for (const match of [...previous, ...previousCached.values()]) {
			if (match.status !== "success" || superseded.has(match.id)) continue;
			const route = getRoute$1(router, match);
			if (!route.options.loader || now - match.updatedAt >= (match.preload ? route.options.preloadGcTime ?? router.options.defaultPreloadGcTime ?? 3e5 : route.options.gcTime ?? router.options.defaultGcTime ?? 3e5)) continue;
			cached.set(match.id, previousCached.get(match.id) === match ? match : {
				...match,
				_flight: void 0,
				isFetching: false,
				context: {}
			});
		}
	}
	tx[3] = [];
	router._cache = cached;
	const nextEnd = router._lifecycleEnd = lifecycleEnd(matches);
	publishMatches(router, matches);
	transferMatchResources(router, [...previousCached.values(), ...previous].filter((match) => match._flight && cached.get(match.id) !== match), matches);
	{
		const handoff = tx[6]?.[0];
		if (handoff && router._handoff === handoff) handoff[1]();
	}
	runRouteLifecycle(router, previous, matches, previousEnd, nextEnd, tx);
}
/**
* Resolve once the router has settled on a transaction other than `owner`.
* Each transaction's completion follows its current successor, so all waiters
* share the same chain instead of polling every successor independently.
*/
async function awaitCurrent(router, owner) {
	let current = router._tx;
	while (current && current !== owner) {
		owner = current;
		await current[5];
		current = router._tx;
	}
}
function followRedirect(router, tx, outcome) {
	const options = outcome[1].options;
	const location = outcome[2];
	if (!location) return router.navigate({
		...options,
		replace: true,
		ignoreBlocker: true
	});
	if (options.reloadDocument) return router.navigate({
		href: (location.maskedLocation ?? location).publicHref,
		reloadDocument: true,
		replace: true,
		ignoreBlocker: true
	});
	location._redirects = tx[1] + 1;
	router._pendingLocation = location;
	const committed = router.commitLocation({
		...location,
		viewTransition: options.viewTransition,
		replace: true,
		resetScroll: options.resetScroll,
		hashScrollIntoView: options.hashScrollIntoView,
		ignoreBlocker: true
	});
	queueMicrotask(() => {
		if (router._pendingLocation === location) router._pendingLocation = void 0;
	});
	return committed;
}
async function runBackground(router, tx, base, tasks, settlement) {
	const next = base.map((match) => ({ ...match }));
	acquireMatchResources(next);
	for (const task of tasks) {
		releaseFlight(router, next[task[0]]);
		next[task[0]] = task[3];
	}
	const lane = [tx[2], next];
	let reduced;
	try {
		reduced = await reduceLane(router, lane, tasks, tx[0], settlement);
	} catch (cause) {
		transferMatchResources(router, next);
		throw cause;
	}
	if (isControl(reduced)) {
		transferMatchResources(router, next);
		if (reduced[0] === REDIRECTED$1 && router._tx === tx && router._committed === base) await followRedirect(router, tx, reduced);
		return;
	}
	await projectLane$1(router, reduced, tx[0].signal);
	if (router._tx !== tx || router._committed !== base) {
		transferMatchResources(router, next);
		return;
	}
	for (const match of next) {
		const cached = router._cache.get(match.id);
		if (cached?._flight && cached._flight === match._flight) {
			router._cache.delete(match.id);
			releaseFlight(router, cached);
		}
	}
	publishMatches(router, next);
	transferMatchResources(router, base, next);
}
async function runClientTransaction(router, tx, forceStaleReload, onReady, sync, resolvedPrefix) {
	const result = await executeClientLane(router, tx[2], tx[3], [
		tx[0],
		tx[1],
		router._committed,
		void 0,
		sync,
		forceStaleReload,
		resolvedPrefix,
		onReady
	]);
	if (isControl(result)) {
		const follow = result[0] === REDIRECTED$1 && router._tx === tx;
		if (!follow || result[1].options.reloadDocument) finishPending(router, tx);
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		if (!follow) return;
		if (router._tx !== tx) {
			finishPending(router, tx);
			return;
		}
		if (tx[6]) router._refreshNextLoad = true;
		await followRedirect(router, tx, result);
		return;
	}
	const matches = result[1];
	if (router._tx === tx) await awaitPendingMinimum(router, tx);
	if (router._tx !== tx) {
		finishPending(router, tx);
		transferMatchResources(router, matches);
		discardBackground(router, result);
		return;
	}
	const toLocation = tx[2];
	const changeInfo = getLocationChangeInfo(toLocation, router.stores.resolvedLocation.get());
	const background = result[2];
	await router.startViewTransition(async () => {
		if (router._tx === tx) await awaitPendingMinimum(router, tx);
		if (router._tx !== tx) {
			finishPending(router, tx);
			transferMatchResources(router, matches);
			discardBackground(router, result);
			return;
		}
		const commit = () => {
			finishPending(router, tx);
			commitMatches(router, tx, matches, resolvedPrefix);
			if (router._tx !== tx) return;
			router.emit({
				type: "onLoad",
				...changeInfo
			});
			if (router._tx === tx) router.emit({
				type: "onBeforeRouteMount",
				...changeInfo
			});
		};
		const rendered = await router.startTransition(commit, matches);
		if (tx[6]) tx[6] = void 0;
		if (router._tx !== tx) {
			discardBackground(router, result);
			return;
		}
		if (background?.length) runBackground(router, tx, matches, background, result[3]).catch(console.error);
		router.batch(() => {
			router.stores.resolvedLocation.set(toLocation);
			router.stores.status.set("idle");
			if (router._tx === tx) router.emit({
				type: "onResolved",
				...changeInfo
			});
			if (rendered && router._tx === tx) router.emit({
				type: "onRendered",
				...changeInfo
			});
		});
		if (router._tx !== tx) return;
		router._commitPromise?.resolve();
		router._commitPromise = void 0;
	});
}
async function loadClientRoute(router, opts) {
	let rematerialize = false;
	rematerialize = !!router._refreshNextLoad || !!router._tx?.[6];
	const previousOwner = router._tx;
	const resolvedLocation = router.stores.resolvedLocation.get();
	const previousLocation = resolvedLocation ?? router.stores.location.get();
	const location = router.latestLocation;
	const pendingLocation = router._pendingLocation;
	const redirects = pendingLocation?.href === location.href ? pendingLocation._redirects ?? 0 : 0;
	const handoff = router._handoff;
	const hydrationController = rematerialize ? void 0 : handoff?.[0]();
	const preflight = new AbortController();
	const previousPreflight = router._preflight;
	router._preflight = preflight;
	if (!rematerialize && !hydrationController) handoff?.[1]();
	previousPreflight?.abort();
	if (!preflight.signal.aborted) {
		const changeInfo = getLocationChangeInfo(location, resolvedLocation);
		router.emit({
			type: "onBeforeNavigate",
			...changeInfo
		});
		if (!preflight.signal.aborted) router.emit({
			type: "onBeforeLoad",
			...changeInfo
		});
	}
	if (preflight.signal.aborted) {
		await awaitCurrent(router, previousOwner);
		return;
	}
	const sameHref = previousLocation.href === location.href;
	let controller = preflight;
	const matches = rematerialize ? router.matchRoutes(location, {
		_controller: preflight,
		_rematerialize: true
	}) : router.matchRoutes(location, { _controller: preflight });
	acquireMatchResources(matches);
	const resolvedPrefix = hydrationController ? handoff[1](matches) : void 0;
	if (resolvedPrefix) controller = hydrationController;
	else hydrationController?.abort();
	if (preflight.signal.aborted) {
		transferMatchResources(router, matches);
		await awaitCurrent(router, previousOwner);
		return;
	}
	router._preflight = void 0;
	let settle;
	const run = () => runClientTransaction(router, tx, sameHref, () => offerPending(router, tx), opts?.sync, resolvedPrefix);
	const done = opts?.sync ? new Promise((resolve) => settle = resolve) : Promise.resolve().then(run);
	const tx = [
		controller,
		redirects,
		location,
		matches,
		Date.now(),
		done.then(() => awaitCurrent(router, tx))
	];
	if (rematerialize) {
		tx[6] = [handoff];
		router._refreshNextLoad = void 0;
	}
	router._tx = tx;
	if (previousOwner) {
		for (const match of router.stores.matches.get()) {
			if (router._tx !== tx) break;
			if (match.isFetching) setFetching(router, match, false);
		}
		previousOwner[0].abort();
		transferMatchResources(router, previousOwner[3], tx[3], true);
	}
	if (router._tx !== tx) {
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		settle?.();
		await awaitCurrent(router, tx);
		return;
	}
	router.batch(() => {
		router.stores.status.set("pending");
		router.stores.location.set(location);
	});
	if (resolvedPrefix || !router._committed.length && matches[0]?.status !== "success" && !matches.some((match) => match._notFound)) offerPending(router, tx);
	settle?.(run());
	await tx[5];
}
async function refreshClientRoute(router) {
	const pending = router._tx;
	if (pending && !pending[6] && router.stores.status.get() === "pending") {
		await pending[5];
		if (router._tx !== pending) await awaitCurrent(router, pending);
	}
	router._flights?.clear();
	router.clearCache();
	router._refreshNextLoad = true;
	await loadClientRoute(router, { sync: true });
}
async function preloadClientRoute(router, opts) {
	if (router._refreshNextLoad || router._tx?.[6]) return;
	let location = router.buildLocation(opts);
	for (let redirects = 0;; redirects++) {
		const base = router._committed;
		const controller = new AbortController();
		let matches;
		let active;
		let result;
		try {
			try {
				matches = router.matchRoutes(location, { _controller: controller });
				acquireMatchResources(matches);
				active = (router._preloads ??= /* @__PURE__ */ new Map()).set(controller, matches);
				result = await executeClientLane(router, location, matches, [
					controller,
					redirects,
					base,
					true
				]);
			} finally {
				if (active) {
					active = active.delete(controller);
					transferMatchResources(router, matches);
				}
				controller.abort();
			}
			if (!isControl(result)) return result[1];
			if (!active || result.length < 3 || router._refreshNextLoad || router._tx?.[6]) return;
			location = result[2];
		} catch (cause) {
			if (!isNotFound(cause)) console.error(cause);
			return;
		}
	}
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/await-signal.js
function observeLate(callback, value) {
	if (!callback) return;
	try {
		const result = callback(value);
		if (result !== void 0) Promise.resolve(result).catch(() => {});
	} catch {}
}
/**
* Await `value` unless `signal` aborts first. A result that settles after the
* abort is passed to `onLate` / `onLateError` instead.
*
* One abort listener per wait: SSR requests nest at most a few waits on one
* signal, so pooling them was measurably slower than this.
*/
function waitForReason(value, signal, onLate, onLateError) {
	const promise = Promise.resolve(value);
	if (signal.aborted) {
		promise.then((result) => observeLate(onLate, result), (error) => observeLate(onLateError, error));
		return Promise.reject(signal.reason);
	}
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal.reason);
		signal.addEventListener("abort", abort, { once: true });
		promise.then((result) => {
			signal.removeEventListener("abort", abort);
			if (signal.aborted) observeLate(onLate, result);
			else resolve(result);
		}, (error) => {
			signal.removeEventListener("abort", abort);
			if (signal.aborted) observeLate(onLateError, error);
			else reject(error);
		});
	});
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/load-server.js
var SUCCESS = 0;
var ERROR = 1;
var NOT_FOUND = 2;
var REDIRECTED = 3;
var SKIPPED = 4;
var MATCH_SETTLED_ABORT_REASON = Object.freeze({
	name: "AbortError",
	message: "TanStack Router aborted this server match because it settled."
});
var REDIRECT_ABORT_REASON = Object.freeze({
	name: "AbortError",
	message: "TanStack Router aborted this server match because of a redirect."
});
function getRoute(router, match) {
	return router.routesById[match.routeId];
}
function normalize(value, rejected) {
	if (isRedirect(value)) return [REDIRECTED, value];
	if (isNotFound(value)) return [NOT_FOUND, value];
	if (rejected && typeof value?.then === "function") value = new Error("A Promise was thrown", { cause: value });
	return rejected ? [ERROR, value] : [SUCCESS, value];
}
function normalizeError(router, lane, route, cause, signal, notify = true) {
	signal?.throwIfAborted();
	let outcome = normalize(cause, true);
	if (outcome[0] !== ERROR) return materializeRedirect(router, lane, route, outcome, signal, notify);
	try {
		route.options.onError?.(outcome[1]);
	} catch (onErrorCause) {
		outcome = normalize(onErrorCause, true);
	}
	signal?.throwIfAborted();
	return materializeRedirect(router, lane, route, outcome, signal, notify);
}
function materializeRedirect(router, lane, route, outcome, signal, notify = true) {
	if (outcome[0] !== REDIRECTED) return outcome;
	signal?.throwIfAborted();
	try {
		outcome[1].options._fromLocation = lane.location;
		router.resolveRedirect(outcome[1]);
		signal?.throwIfAborted();
		return outcome;
	} catch (cause) {
		signal?.throwIfAborted();
		return notify ? normalizeError(router, lane, route, cause, signal, false) : [ERROR, cause];
	}
}
function maybe(value, cause) {
	if (cause !== void 0) return {
		status: "error",
		error: cause
	};
	return {
		status: "success",
		value
	};
}
function navigateFrom(router, location) {
	return (options) => router.navigate({
		...options,
		_fromLocation: location
	});
}
function waitFor(value, signal) {
	return signal ? waitForReason(value, signal) : value;
}
function resolveSsr(router, lane, index) {
	const match = lane.matches[index];
	const route = getRoute(router, match);
	const parentSsr = lane.matches[index - 1]?.ssr;
	if (router.isShell()) return route.id === rootRouteId;
	if (parentSsr === false) return false;
	const inherit = (value) => {
		return value === true && parentSsr === "data-only" ? "data-only" : value;
	};
	const defaultSsr = router.options.defaultSsr ?? true;
	const inheritedDefault = inherit(defaultSsr);
	match.ssr = inheritedDefault;
	const option = route.options.ssr;
	if (option === void 0) return inheritedDefault;
	if (typeof option !== "function") return inherit(option);
	const context = {
		search: maybe(match.search, match.searchError),
		params: maybe(match.params, match.paramsError),
		location: lane.location,
		matches: lane.matches.map((candidate) => ({
			index: candidate.index,
			pathname: candidate.pathname,
			fullPath: candidate.fullPath,
			staticData: candidate.staticData,
			id: candidate.id,
			routeId: candidate.routeId,
			search: maybe(candidate.search, candidate.searchError),
			params: maybe(candidate.params, candidate.paramsError),
			ssr: candidate.ssr
		}))
	};
	try {
		return Promise.resolve(option(context)).then((value) => inherit(value ?? defaultSsr));
	} catch (cause) {
		return Promise.reject(cause);
	}
}
function stampNotFound(match, outcome) {
	if (outcome[0] === NOT_FOUND && !outcome[1].routeId) outcome[1].routeId = match.routeId;
	return outcome;
}
async function contextualize(router, lane, signal) {
	const globalBoundary = lane.matches.findIndex((match) => match._notFound);
	let end = globalBoundary < 0 ? lane.matches.length : globalBoundary + 1;
	let failure;
	let parentContext = { ...router.options.context ?? {} };
	for (let index = 0; index < end; index++) {
		const match = lane.matches[index];
		const route = getRoute(router, match);
		try {
			const ssr = resolveSsr(router, lane, index);
			match.ssr = ssr instanceof Promise ? await ssr : ssr;
		} catch (cause) {
			signal?.throwIfAborted();
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
		}
		signal?.throwIfAborted();
		if (failure?.[1][0] === REDIRECTED) break;
		match.__beforeLoadContext = void 0;
		let context = parentContext;
		try {
			let routeContext;
			if (route.options.context) {
				const routeContextOptions = {
					deps: match.loaderDeps,
					params: match.params,
					context: parentContext,
					location: lane.location,
					navigate: navigateFrom(router, lane.location),
					buildLocation: router.buildLocation,
					cause: match.cause,
					abortController: match.abortController,
					preload: false,
					matches: lane.matches,
					routeId: route.id
				};
				routeContext = route.options.context(routeContextOptions) ?? void 0;
			}
			context = {
				...parentContext,
				...routeContext
			};
			match.context = context;
		} catch (cause) {
			signal?.throwIfAborted();
			if (!failure) failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
			break;
		}
		signal?.throwIfAborted();
		if (failure) break;
		const validationError = match.paramsError ?? match.searchError;
		if (validationError !== void 0) {
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, validationError, signal))];
			end = index;
			break;
		}
		signal?.throwIfAborted();
		if (match.ssr === false || !route.options.beforeLoad) {
			parentContext = context;
			continue;
		}
		const abortController = match.abortController;
		const options = {
			search: match.search,
			abortController,
			params: match.params,
			preload: false,
			context,
			location: lane.location,
			navigate: navigateFrom(router, lane.location),
			buildLocation: router.buildLocation,
			cause: match.cause,
			matches: lane.matches,
			routeId: route.id,
			...router.options.additionalContext
		};
		try {
			const beforeLoadContext = await route.options.beforeLoad(options);
			signal?.throwIfAborted();
			const outcome = stampNotFound(match, materializeRedirect(router, lane, route, normalize(beforeLoadContext, false), signal));
			if (outcome[0] !== SUCCESS) {
				failure = [index, outcome];
				end = index;
				break;
			}
			match.__beforeLoadContext = beforeLoadContext;
			match.context = {
				...context,
				...beforeLoadContext
			};
			parentContext = match.context;
		} catch (cause) {
			signal?.throwIfAborted();
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
			break;
		}
	}
	return {
		location: lane.location,
		matches: lane.matches,
		end,
		failure
	};
}
function getLoaderContext(router, lane, match, route, index, tasks) {
	return {
		params: match.params,
		deps: match.loaderDeps,
		preload: false,
		parentMatchPromise: tasks[index - 1]?.match,
		abortController: match.abortController,
		context: match.context,
		location: lane.location,
		navigate: navigateFrom(router, lane.location),
		cause: match.cause,
		route,
		...router.options.additionalContext
	};
}
function createLoaderTask(router, lane, index, tasks, signal) {
	const match = lane.matches[index];
	const route = getRoute(router, match);
	let outcome;
	if (match.ssr === false) outcome = Promise.resolve([SKIPPED]);
	else {
		const routeLoader = route.options.loader;
		const loader = typeof routeLoader === "function" ? routeLoader : routeLoader?.handler;
		if (!loader) outcome = Promise.resolve([SUCCESS, void 0]);
		else outcome = Promise.resolve().then(() => loader(getLoaderContext(router, lane, match, route, index, tasks))).then((result) => normalize(result, false), (cause) => normalize(cause, true)).then((result) => {
			if (signal?.aborted || match.abortController.signal.reason === REDIRECT_ABORT_REASON) return [SKIPPED];
			if (result[0] === ERROR) result = normalizeError(router, lane, route, result[1], signal);
			else result = materializeRedirect(router, lane, route, result, signal);
			return stampNotFound(match, result);
		});
	}
	const parentMatch = outcome.then((result) => {
		const snapshot = { ...match };
		if (result[0] === SUCCESS) {
			snapshot.loaderData = result[1];
			snapshot.status = "success";
			snapshot.error = void 0;
			snapshot.invalid = false;
			snapshot.isFetching = false;
		} else if (result[0] === ERROR) {
			snapshot.status = "error";
			snapshot.error = result[1];
		} else if (result[0] === NOT_FOUND) {
			snapshot.status = "notFound";
			snapshot.error = result[1];
		}
		return snapshot;
	});
	return {
		index,
		outcome,
		match: parentMatch
	};
}
async function getNotFoundBoundary(router, matches, indexed, signal, fallback = 0) {
	const cause = indexed?.[1][1];
	let index = cause?.routeId ? matches.findIndex((match) => match.routeId === cause.routeId) : indexed?.[0] ?? matches.length - 1;
	if (index < 0) index = 0;
	for (let candidate = index; candidate >= 0; candidate--) {
		const route = getRoute(router, matches[candidate]);
		try {
			const loading = loadRouteChunk(route, false);
			if (loading) await loading;
		} catch {
			signal?.throwIfAborted();
		}
		signal?.throwIfAborted();
		if (route.options.notFoundComponent) return candidate;
	}
	return cause?.routeId ? index : fallback;
}
function abortMatches(matches, start = 0, reason = MATCH_SETTLED_ABORT_REASON) {
	for (let index = start; index < matches.length; index++) matches[index].abortController.abort(reason);
}
async function applyFailure(router, lane, indexed, signal) {
	if (!indexed) {
		const boundary = lane.matches.findIndex((match) => match._notFound);
		if (boundary >= 0) {
			abortMatches(lane.matches, boundary + 1);
			return {
				status: 404,
				boundary,
				kind: NOT_FOUND
			};
		}
		return { status: 200 };
	}
	const [index, outcome] = indexed;
	if (outcome[0] === ERROR) {
		const match = lane.matches[index];
		match._notFound = void 0;
		match.status = "error";
		match.error = outcome[1];
		match.isFetching = false;
		abortMatches(lane.matches, index + 1);
		return {
			status: 500,
			boundary: index,
			kind: ERROR
		};
	}
	const boundary = indexed[2] ?? await getNotFoundBoundary(router, lane.matches, indexed, signal);
	const match = lane.matches[boundary];
	const cause = outcome[1];
	cause.routeId = match.routeId;
	match._notFound = void 0;
	if (match.routeId === router.routeTree.id) {
		match.status = "success";
		match._notFound = true;
		match.error = cause;
	} else {
		match.status = "notFound";
		match.error = cause;
	}
	match.isFetching = false;
	abortMatches(lane.matches, boundary + 1);
	return {
		status: 404,
		boundary,
		kind: NOT_FOUND
	};
}
async function loadNormalChunks(router, lane, end, signal) {
	const chunks = [];
	for (let index = 0; index < lane.matches.length; index++) {
		const match = lane.matches[index];
		if (index >= end || match.ssr !== true || match.status !== "success") continue;
		const route = getRoute(router, match);
		try {
			const loading = loadRouteChunk(route);
			if (loading) {
				const chunk = loading.then(() => {
					signal?.throwIfAborted();
				}, (cause) => {
					signal?.throwIfAborted();
					return [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
				});
				chunk.catch(() => {});
				chunks.push(chunk);
			}
		} catch (cause) {
			signal?.throwIfAborted();
			chunks.push([index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))]);
		}
	}
	for (const chunk of chunks) {
		const indexed = Array.isArray(chunk) ? chunk : await chunk;
		if (indexed) return indexed;
	}
}
async function projectLane(router, lane, signal) {
	for (const match of lane.matches) {
		const routeOptions = getRoute(router, match).options;
		if (routeOptions.head || routeOptions.scripts || routeOptions.headers) {
			const context = {
				ssr: router.options.ssr,
				matches: lane.matches,
				match,
				params: match.params,
				loaderData: match.loaderData
			};
			try {
				const [head, scripts, headers] = await Promise.all([
					routeOptions.head?.(context),
					routeOptions.scripts?.(context),
					routeOptions.headers?.(context)
				]);
				signal?.throwIfAborted();
				match.meta = head?.meta;
				match.links = head?.links;
				match.headScripts = head?.scripts;
				match.styles = head?.styles;
				match.scripts = scripts;
				match.headers = headers;
			} catch (cause) {
				signal?.throwIfAborted();
				console.error(cause);
			}
		}
		if (match.ssr === false || match.status !== "success" || match._notFound) break;
	}
}
async function executeServerLane(router, location, matchedMatches, signal) {
	const matched = {
		location,
		matches: matchedMatches.map((match) => ({
			...match,
			__beforeLoadContext: void 0,
			context: {},
			isFetching: false,
			abortController: new AbortController()
		}))
	};
	const abortLane = () => abortMatches(matched.matches, 0, signal?.reason ?? MATCH_SETTLED_ABORT_REASON);
	if (signal?.aborted) {
		abortLane();
		signal.throwIfAborted();
	}
	signal?.addEventListener("abort", abortLane, { once: true });
	try {
		const plannedGlobalBoundary = matched.matches.findIndex((match) => match._notFound);
		if (router.options.notFoundMode !== "root" && plannedGlobalBoundary >= 0) {
			const boundary = await getNotFoundBoundary(router, matched.matches, void 0, signal, plannedGlobalBoundary);
			if (boundary !== plannedGlobalBoundary) {
				matched.matches[plannedGlobalBoundary]._notFound = void 0;
				matched.matches[boundary]._notFound = true;
			}
		}
		const lane = await contextualize(router, matched, signal);
		signal?.throwIfAborted();
		let loaderEnd = lane.end;
		if (lane.failure?.[1][0] === REDIRECTED) loaderEnd = 0;
		else if (lane.failure?.[1][0] === NOT_FOUND) {
			lane.failure[2] = await getNotFoundBoundary(router, lane.matches, lane.failure, signal);
			loaderEnd = Math.min(loaderEnd, lane.failure[2] + 1);
		}
		const tasks = [];
		for (let index = 0; index < loaderEnd; index++) {
			const task = createLoaderTask(router, lane, index, tasks, signal);
			tasks.push(task);
		}
		let loaderFailure;
		let control = lane.failure?.[1][0] === REDIRECTED ? lane.failure : void 0;
		try {
			await Promise.all(tasks.map((task) => task.outcome.then((loadedOutcome) => {
				const match = lane.matches[task.index];
				const outcome = loadedOutcome;
				if (outcome[0] === SUCCESS) {
					match.loaderData = outcome[1];
					match.status = "success";
					match.error = void 0;
					match.invalid = false;
					match.isFetching = false;
					match.updatedAt = Date.now();
				} else if (outcome[0] === REDIRECTED) {
					control = [task.index, outcome];
					throw control;
				} else {
					if (match.ssr !== false) {
						match.status = "success";
						match.error = void 0;
						match.invalid = true;
						match.isFetching = false;
					}
					if (!loaderFailure && outcome[0] !== SKIPPED) loaderFailure = [task.index, outcome];
				}
			})));
		} catch (cause) {
			if (!Array.isArray(cause)) throw cause;
			control = cause;
		}
		signal?.throwIfAborted();
		if (control?.[1][0] === REDIRECTED) {
			abortMatches(lane.matches, 0, REDIRECT_ABORT_REASON);
			return {
				type: "redirect",
				redirect: control[1][1]
			};
		}
		let failure = lane.failure ?? loaderFailure;
		const plannedBoundary = lane.matches.findIndex((match) => match._notFound);
		let readinessEnd;
		if (failure) {
			const outcomeEnd = failure[2] ??= failure[1][0] === NOT_FOUND ? await getNotFoundBoundary(router, lane.matches, failure, signal) : failure[0];
			for (const task of tasks) {
				if (task.index >= outcomeEnd) break;
				const outcome = await task.outcome;
				if (outcome[0] !== SUCCESS && outcome[0] < REDIRECTED && !("loaderData" in lane.matches[task.index])) {
					failure = [task.index, outcome];
					failure[2] = outcome[0] === NOT_FOUND ? await getNotFoundBoundary(router, lane.matches, failure, signal) : task.index;
					break;
				}
			}
			readinessEnd = failure[2];
		} else readinessEnd = plannedBoundary < 0 ? lane.matches.length : plannedBoundary;
		const requiredFailure = await loadNormalChunks(router, lane, readinessEnd, signal);
		signal?.throwIfAborted();
		if (requiredFailure) {
			if (requiredFailure[1][0] === REDIRECTED) {
				abortMatches(lane.matches, 0, REDIRECT_ABORT_REASON);
				return {
					type: "redirect",
					redirect: requiredFailure[1][1]
				};
			}
			failure = requiredFailure;
		}
		const terminal = await applyFailure(router, lane, failure, signal);
		if (terminal.boundary !== void 0) {
			const match = lane.matches[terminal.boundary];
			if (match.ssr === true) {
				const route = getRoute(router, match);
				try {
					if (terminal.kind === ERROR) await loadRouteChunk(route, "errorComponent");
					else if (match._notFound) await Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]);
					else await loadRouteChunk(route, "notFoundComponent");
				} catch {}
				signal?.throwIfAborted();
			}
		}
		signal?.throwIfAborted();
		await projectLane(router, {
			location: lane.location,
			matches: lane.matches
		}, signal);
		signal?.throwIfAborted();
		router.serverSsr?.onCleanup((settled) => {
			if (!settled) abortLane();
		});
		return {
			type: "render",
			status: terminal.status,
			matches: lane.matches
		};
	} finally {
		signal?.removeEventListener("abort", abortLane);
	}
}
async function loadServerRoute(router, opts) {
	router.updateLatestLocation();
	const next = router.latestLocation;
	const previous = router._committed;
	const previousEnd = router._lifecycleEnd;
	let result;
	try {
		const canonical = router.buildLocation({
			to: next.pathname,
			search: true,
			params: true,
			hash: true,
			state: true,
			_includeValidateSearch: true
		});
		if (next.publicHref !== canonical.publicHref) throw redirect({ href: canonical.publicHref || "/" });
		const changeInfo = getLocationChangeInfo(next, router.stores.resolvedLocation.get());
		router.emit({
			type: "onBeforeNavigate",
			...changeInfo
		});
		router.emit({
			type: "onBeforeLoad",
			...changeInfo
		});
		opts?._signal?.throwIfAborted();
		result = await waitFor(executeServerLane(router, next, router.matchRoutes(next), opts?._signal), opts?._signal);
		opts?._signal?.throwIfAborted();
	} catch (cause) {
		opts?._signal?.throwIfAborted();
		if (!isRedirect(cause)) throw cause;
		cause.options._fromLocation = next;
		result = {
			type: "redirect",
			redirect: router.resolveRedirect(cause)
		};
	}
	router._serverResult = result;
	let nextEnd = 0;
	router.batch(() => {
		router.stores.location.set(next);
		router.stores.status.set("idle");
		if (result.type === "render") {
			router._committed = result.matches;
			nextEnd = router._lifecycleEnd = lifecycleEnd(result.matches);
			router.stores.setMatches(result.matches);
			router.stores.resolvedLocation.set(next);
		}
	});
	if (result.type === "render") runRouteLifecycle(router, previous, result.matches, previousEnd, nextEnd);
	router._commitPromise?.resolve();
	router._commitPromise = void 0;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/utils.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* React.use if available (React 19+), undefined otherwise.
* Use dynamic lookup to avoid Webpack compilation errors with React 18.
*/
var reactUse = import_react.use;
var useLayoutEffect = typeof window === "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/defer.js
/**
* Well-known symbol used by {@link defer} to tag a promise with
* its deferred state. Consumers can read `promise[TSR_DEFERRED_PROMISE]`
* to access `status`, `data`, or `error`.
*/
var TSR_DEFERRED_PROMISE = Symbol.for("TSR_DEFERRED_PROMISE");
/**
* Wrap a promise with a deferred state for use with `<Await>` and `useAwaited`.
*
* The returned promise is augmented with internal state (status/data/error)
* so UI can read progress or suspend until it settles.
*
* @param _promise The promise to wrap.
* @param options Optional config. Provide `serializeError` to customize how
* errors are serialized for transfer.
* @returns The same promise with attached deferred metadata.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/deferFunction
*/
function defer(_promise, options) {
	const promise = _promise;
	if (promise[TSR_DEFERRED_PROMISE]) return promise;
	promise[TSR_DEFERRED_PROMISE] = { status: "pending" };
	promise.then((data) => {
		promise[TSR_DEFERRED_PROMISE].status = "success";
		promise[TSR_DEFERRED_PROMISE].data = data;
	}).catch((error) => {
		promise[TSR_DEFERRED_PROMISE].status = "error";
		promise[TSR_DEFERRED_PROMISE].error = {
			data: (options?.serializeError ?? defaultSerializeError)(error),
			__isServerError: true
		};
	});
	return promise;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/link.js
var preloadWarning = "Error preloading route! ☝️";
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/manifest.js
var DEV_STYLES_ATTR = "data-tanstack-router-dev-styles";
function getAssetCrossOrigin(assetCrossOrigin, kind) {
	if (!assetCrossOrigin) return;
	if (typeof assetCrossOrigin === "string") return assetCrossOrigin;
	return assetCrossOrigin[kind];
}
function getManifestScriptFormat(manifest) {
	return manifest?.scriptFormat ?? "module";
}
function getScriptPreloadAttrs(manifest, link, assetCrossOrigin) {
	const preloadLink = resolveManifestAssetLink(link);
	const crossOrigin = getAssetCrossOrigin(assetCrossOrigin, "script") ?? preloadLink.crossOrigin;
	return {
		...getManifestScriptFormat(manifest) === "iife" ? {
			rel: "preload",
			as: "script"
		} : { rel: "modulepreload" },
		href: preloadLink.href,
		...crossOrigin ? { crossOrigin } : {}
	};
}
function resolveManifestAssetLink(link) {
	if (typeof link === "string") return {
		href: link,
		crossOrigin: void 0
	};
	return link;
}
function appendUniqueUserTags(target, tags) {
	if (tags.length === 0) return;
	if (tags.length === 1) {
		target.push(tags[0]);
		return;
	}
	const seen = /* @__PURE__ */ new Set();
	for (const tag of tags) {
		const key = JSON.stringify(tag);
		if (seen.has(key)) continue;
		seen.add(key);
		target.push(tag);
	}
}
function resolveManifestCssLink(link) {
	if (typeof link === "string") return {
		href: link,
		crossOrigin: void 0
	};
	return link;
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/Matches.js
/**
* Narrows matches based on a path
* @experimental
*/
var isMatch = (match, path) => {
	const parts = path.split(".");
	let part;
	let i = 0;
	let value = match;
	while ((part = parts[i++]) != null && value != null) value = value[part];
	return value != null;
};
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/ssr/bodyScripts.js
function getSsrBodyScriptParts(matches, manifest, nonce, routeScriptAttrs) {
	const assetMatches = _getAssetMatches(matches);
	const routeScripts = [];
	const manifestScripts = [];
	for (const match of assetMatches) for (const script of Array.isArray(match.scripts) ? match.scripts : []) {
		if (!script) continue;
		const { children, ...attrs } = script;
		routeScripts.push({
			tag: "script",
			attrs: {
				...attrs,
				...routeScriptAttrs,
				nonce
			},
			children
		});
	}
	if (manifest) for (const match of assetMatches) for (const asset of manifest.routes[match.routeId]?.scripts ?? []) manifestScripts.push({
		tag: "script",
		attrs: {
			...asset.attrs,
			nonce
		},
		children: asset.children
	});
	return [routeScripts, manifestScripts];
}
function composeSsrBodyScripts([routeScripts, manifestScripts], initialHydrationScripts) {
	if (!initialHydrationScripts) return [...routeScripts, ...manifestScripts];
	return [
		...initialHydrationScripts.before,
		...routeScripts,
		...manifestScripts,
		initialHydrationScripts.boundary
	];
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/route.js
var BaseRoute = class {
	get to() {
		return this._to;
	}
	get id() {
		return this._id;
	}
	get path() {
		return this._path;
	}
	get fullPath() {
		return this._fullPath;
	}
	constructor(options) {
		this.init = (originalIndex) => {
			this.originalIndex = originalIndex;
			this._branch = void 0;
			const options = this.options;
			const isRoot = !options?.path && !options?.id;
			this.parentRoute = this.options.getParentRoute?.();
			if (isRoot) this._path = rootRouteId;
			else if (!this.parentRoute) throw new Error(`Invariant failed: Child Route instances must pass a 'getParentRoute: () => ParentRoute' option that returns a Route instance.`);
			let path = isRoot ? rootRouteId : options?.path;
			if (path && path !== "/") path = trimPathLeft(path);
			const customId = options?.id || path;
			const id = isRoot ? rootRouteId : cleanPath((this.parentRoute.id === "__root__" ? "" : this.parentRoute.id) + "/" + (customId ?? ""));
			if (path === "__root__") path = "/";
			const fullPath = id === "__root__" ? "/" : path === void 0 ? this.parentRoute.fullPath : cleanPath(this.parentRoute.fullPath + "/" + path);
			this._path = path;
			this._id = id;
			this._fullPath = fullPath;
			this._to = trimPathRight(fullPath);
		};
		this.addChildren = (children) => {
			return this._addFileChildren(children);
		};
		this._addFileChildren = (children) => {
			if (Array.isArray(children)) this.children = children;
			if (typeof children === "object" && children !== null) this.children = Object.values(children);
			return this;
		};
		this._addFileTypes = () => {
			return this;
		};
		this.updateLoader = (options) => {
			Object.assign(this.options, options);
			return this;
		};
		this.update = (options) => {
			Object.assign(this.options, options);
			return this;
		};
		this.lazy = (lazyFn) => {
			this.lazyFn = lazyFn;
			return this;
		};
		this.redirect = (opts) => redirect({
			from: this.fullPath,
			...opts
		});
		this.options = options || {};
		this.isRoot = !options?.getParentRoute;
		if (options?.id && options?.path) throw new Error(`Route cannot have both an 'id' and a 'path' option.`);
	}
};
var BaseRouteApi = class {
	constructor({ id }) {
		this.notFound = (opts) => {
			return notFound({
				routeId: this.id,
				...opts
			});
		};
		this.redirect = (opts) => redirect({
			from: this.id,
			...opts
		});
		this.id = id;
	}
};
var BaseRootRoute = class extends BaseRoute {
	constructor(options) {
		super(options);
	}
};
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/config.js
var createRouterConfig = (options) => {
	return {
		serializationAdapters: options.serializationAdapters,
		defaultSsr: options.defaultSsr
	};
};
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/searchMiddleware.js
/**
* Retain specified search params across navigations.
*
* If `keys` is `true`, retain all current params. Otherwise, copy only the
* listed keys from the current search into the next search.
*
* @param keys `true` to retain all, or a list of keys to retain.
* @returns A search middleware suitable for route `search.middlewares`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/retainSearchParamsFunction
*/
function retainSearchParams(keys) {
	return ({ search, next }) => {
		const { search: resultSearch, meta } = next(search, true);
		if (keys === true) {
			const copy = {
				...search,
				...resultSearch
			};
			const removed = meta.removed;
			const explicit = meta.explicit;
			for (const key of removed?.keys() || []) if (explicit && hasOwn.call(explicit, key) || deepEqual(search[key], removed.get(key))) delete copy[key];
			for (const key of meta.removedAny || []) delete copy[key];
			for (const key of meta.defaulted?.keys() || []) if (key in search && !meta.removedAny?.has(key) && !(meta.removed?.has(key) && (explicit && hasOwn.call(explicit, key) || deepEqual(search[key], meta.removed.get(key))))) copy[key] = search[key];
			return copy;
		}
		const copy = { ...resultSearch };
		const explicit = meta.explicit;
		for (const key of keys) {
			const stringKey = key;
			if (!(meta.removedAny?.has(stringKey) || meta.removed?.has(stringKey) && (explicit && hasOwn.call(explicit, stringKey) || deepEqual(search[key], meta.removed.get(stringKey)))) && (!(key in copy) || key in search && meta.defaulted?.has(stringKey) && deepEqual(copy[key], meta.defaulted.get(stringKey)))) copy[key] = search[key];
		}
		return copy;
	};
}
/**
* Remove optional or default-valued search params from navigations.
*
* - Pass `true` (only if there are no required search params) to strip all.
* - Pass an array to always remove those optional keys.
* - Pass an object of default values; keys equal (deeply) to the defaults are removed.
*
* @returns A search middleware suitable for route `search.middlewares`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/stripSearchParamsFunction
*/
function stripSearchParams(input) {
	return (({ search, next, meta }) => {
		if (input === true) {
			Object.keys(search).forEach((key) => {
				if (meta) (meta.removedAny ||= /* @__PURE__ */ new Set()).add(key);
			});
			return {};
		}
		const result = { ...next(search) };
		if (Array.isArray(input)) input.forEach((key) => {
			delete result[key];
			if (meta) (meta.removedAny ||= /* @__PURE__ */ new Set()).add(key);
		});
		else Object.entries(input).forEach(([key, value]) => {
			if (deepEqual(result[key], value)) {
				delete result[key];
				if (meta) (meta.removed ||= /* @__PURE__ */ new Map()).set(key, value);
			}
		});
		return result;
	});
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/ssr/serializer/transformer.js
/**
* Create a strongly-typed serialization adapter for SSR hydration.
* Use to register custom types with the router serializer.
*/
function createSerializationAdapter(opts) {
	if (!opts.key || /[\0"\\<\b\t\f\r\n\u2028\u2029\uD800-\uDFFF]/.test(opts.key)) throw new Error(`createSerializationAdapter: key ${JSON.stringify(opts.key)} is invalid. Serialization adapter keys must be non-empty and not contain NUL, ", \\, <, backspace, tab, form feed, line terminators, or UTF-16 surrogate code units.`);
	return opts;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/awaited.js
var import_jsx_runtime = require_jsx_runtime();
/** Suspend until a deferred promise resolves or rejects and return its data. */
function useAwaited({ promise: _promise }) {
	if (reactUse) return reactUse(_promise);
	const promise = defer(_promise);
	if (promise[TSR_DEFERRED_PROMISE].status === "pending") throw promise;
	if (promise[TSR_DEFERRED_PROMISE].status === "error") throw promise[TSR_DEFERRED_PROMISE].error;
	return promise[TSR_DEFERRED_PROMISE].data;
}
/**
* Component that suspends on a deferred promise and renders its child with
* the resolved value. Optionally provides a Suspense fallback.
*/
function Await(props) {
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AwaitInner, { ...props });
	if (props.fallback) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: props.fallback,
		children: inner
	});
	return inner;
}
function AwaitInner(props) {
	const data = useAwaited(props);
	return props.children(data);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/nonRouteComponentContext.js
var nonRouteComponentContext = import_react.createContext(void 0);
function wrapInNonRouteComponentContext(element, component) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(nonRouteComponentContext.Provider, {
		value: component,
		children: element
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/CatchBoundary.js
var CatchBoundary = class extends import_react.Component {
	constructor(..._args) {
		super(..._args);
		this.state = { error: 0 };
		this.reset = () => {
			this.setState({ error: 0 });
		};
	}
	static getDerivedStateFromProps(props, state) {
		const resetKey = props.getResetKey();
		if (state.error && state.resetKey !== resetKey) return {
			resetKey,
			error: 0
		};
		return { resetKey };
	}
	static getDerivedStateFromError(error) {
		return { error: [error] };
	}
	componentDidCatch(error, errorInfo) {
		this.props.onCatch?.(error, errorInfo);
	}
	render() {
		const error = this.state.error;
		if (error) return wrapInNonRouteComponentContext(import_react.createElement(this.props.errorComponent ?? ErrorComponent, {
			error: error[0],
			reset: this.reset
		}), "errorComponent");
		return this.props.children;
	}
};
function ErrorComponent({ error }) {
	const [show, setShow] = import_react.useState(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			padding: ".5rem",
			maxWidth: "100%"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: ".5rem"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					style: { fontSize: "1rem" },
					children: "Something went wrong!"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					style: {
						appearance: "none",
						fontSize: ".6em",
						border: "1px solid currentColor",
						padding: ".1rem .2rem",
						fontWeight: "bold",
						borderRadius: ".25rem"
					},
					onClick: () => setShow((d) => !d),
					children: show ? "Hide Error" : "Show Error"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { height: ".25rem" } }),
			show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				style: {
					fontSize: ".7em",
					border: "1px solid red",
					borderRadius: ".25rem",
					padding: ".3rem",
					color: "red",
					overflow: "auto"
				},
				children: error?.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: error.message }) : null
			}) }) : null
		]
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/ClientOnly.js
var getSnapshot = () => true;
var getServerSnapshot = () => false;
/**
* Render the children only after the JS has loaded client-side. Use an optional
* fallback component if the JS is not yet loaded.
*
* @example
* Render a Chart component if JS loads, renders a simple FakeChart
* component server-side or if there is no JS. The FakeChart can have only the
* UI without the behavior or be a loading spinner or skeleton.
*
* ```tsx
* return (
*   <ClientOnly fallback={<FakeChart />}>
*     <Chart />
*   </ClientOnly>
* )
* ```
*/
function ClientOnly({ children, fallback = null }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: useHydrated() ? children : fallback });
}
/** @internal */
function useHydrated(enabled = true) {
	return import_react.useSyncExternalStore(subscribe, getSnapshot, enabled ? getServerSnapshot : getSnapshot);
}
function subscribe() {
	return () => {};
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/routerContext.js
var routerContext = import_react.createContext(null);
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useRouter.js
/**
* Access the current TanStack Router instance from React context.
* Must be used within a `RouterProvider`.
*
* Options:
* - `warn`: Log a warning if no router context is found (default: true).
*
* @returns The registered router instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useRouterHook
*/
function useRouter(opts) {
	const value = import_react.useContext(routerContext);
	if (!value) warnMissingRouter(opts);
	return value;
}
function warnMissingRouter(opts) {
	if (opts?.warn ?? true) console.warn("Warning: useRouter must be used inside a <RouterProvider> component!");
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/matchContext.js
var matchContext = import_react.createContext(void 0);
var dummyMatchContext = import_react.createContext(void 0);
//#endregion
//#region node_modules/@tanstack/store/dist/alien.js
/* @__NO_SIDE_EFFECTS__ */
function createReactiveSystem({ update, notify, unwatched }) {
	return {
		link,
		unlink,
		propagate,
		checkDirty,
		shallowPropagate
	};
	function link(dep, sub, version) {
		const prevDep = sub.depsTail;
		if (prevDep !== void 0 && prevDep.dep === dep) return;
		const nextDep = prevDep !== void 0 ? prevDep.nextDep : sub.deps;
		if (nextDep !== void 0 && nextDep.dep === dep) {
			nextDep.version = version;
			sub.depsTail = nextDep;
			return;
		}
		const prevSub = dep.subsTail;
		if (prevSub !== void 0 && prevSub.version === version && prevSub.sub === sub) return;
		const newLink = sub.depsTail = dep.subsTail = {
			version,
			dep,
			sub,
			prevDep,
			nextDep,
			prevSub,
			nextSub: void 0
		};
		if (nextDep !== void 0) nextDep.prevDep = newLink;
		if (prevDep !== void 0) prevDep.nextDep = newLink;
		else sub.deps = newLink;
		if (prevSub !== void 0) prevSub.nextSub = newLink;
		else dep.subs = newLink;
	}
	function unlink(link, sub = link.sub) {
		const dep = link.dep;
		const prevDep = link.prevDep;
		const nextDep = link.nextDep;
		const nextSub = link.nextSub;
		const prevSub = link.prevSub;
		if (nextDep !== void 0) nextDep.prevDep = prevDep;
		else sub.depsTail = prevDep;
		if (prevDep !== void 0) prevDep.nextDep = nextDep;
		else sub.deps = nextDep;
		if (nextSub !== void 0) nextSub.prevSub = prevSub;
		else dep.subsTail = prevSub;
		if (prevSub !== void 0) prevSub.nextSub = nextSub;
		else if ((dep.subs = nextSub) === void 0) unwatched(dep);
		return nextDep;
	}
	function propagate(link) {
		let next = link.nextSub;
		let stack;
		top: do {
			const sub = link.sub;
			let flags = sub.flags;
			if (!(flags & 60)) sub.flags = flags | 32;
			else if (!(flags & 12)) flags = 0;
			else if (!(flags & 4)) sub.flags = flags & -9 | 32;
			else if (!(flags & 48) && isValidLink(link, sub)) {
				sub.flags = flags | 40;
				flags &= 1;
			} else flags = 0;
			if (flags & 2) notify(sub);
			if (flags & 1) {
				const subSubs = sub.subs;
				if (subSubs !== void 0) {
					const nextSub = (link = subSubs).nextSub;
					if (nextSub !== void 0) {
						stack = {
							value: next,
							prev: stack
						};
						next = nextSub;
					}
					continue;
				}
			}
			if ((link = next) !== void 0) {
				next = link.nextSub;
				continue;
			}
			while (stack !== void 0) {
				link = stack.value;
				stack = stack.prev;
				if (link !== void 0) {
					next = link.nextSub;
					continue top;
				}
			}
			break;
		} while (true);
	}
	function checkDirty(link, sub) {
		let stack;
		let checkDepth = 0;
		let dirty = false;
		top: do {
			const dep = link.dep;
			const flags = dep.flags;
			if (sub.flags & 16) dirty = true;
			else if ((flags & 17) === 17) {
				if (update(dep)) {
					const subs = dep.subs;
					if (subs.nextSub !== void 0) shallowPropagate(subs);
					dirty = true;
				}
			} else if ((flags & 33) === 33) {
				if (link.nextSub !== void 0 || link.prevSub !== void 0) stack = {
					value: link,
					prev: stack
				};
				link = dep.deps;
				sub = dep;
				++checkDepth;
				continue;
			}
			if (!dirty) {
				const nextDep = link.nextDep;
				if (nextDep !== void 0) {
					link = nextDep;
					continue;
				}
			}
			while (checkDepth--) {
				const firstSub = sub.subs;
				const hasMultipleSubs = firstSub.nextSub !== void 0;
				if (hasMultipleSubs) {
					link = stack.value;
					stack = stack.prev;
				} else link = firstSub;
				if (dirty) {
					if (update(sub)) {
						if (hasMultipleSubs) shallowPropagate(firstSub);
						sub = link.sub;
						continue;
					}
					dirty = false;
				} else sub.flags &= -33;
				sub = link.sub;
				const nextDep = link.nextDep;
				if (nextDep !== void 0) {
					link = nextDep;
					continue top;
				}
			}
			return dirty;
		} while (true);
	}
	function shallowPropagate(link) {
		do {
			const sub = link.sub;
			const flags = sub.flags;
			if ((flags & 48) === 32) {
				sub.flags = flags | 16;
				if ((flags & 6) === 2) notify(sub);
			}
		} while ((link = link.nextSub) !== void 0);
	}
	function isValidLink(checkLink, sub) {
		let link = sub.depsTail;
		while (link !== void 0) {
			if (link === checkLink) return true;
			link = link.prevDep;
		}
		return false;
	}
}
//#endregion
//#region node_modules/@tanstack/store/dist/atom.js
function toObserver(nextHandler, errorHandler, completionHandler) {
	const isObserver = typeof nextHandler === "object";
	const self = isObserver ? nextHandler : void 0;
	return {
		next: (isObserver ? nextHandler.next : nextHandler)?.bind(self),
		error: (isObserver ? nextHandler.error : errorHandler)?.bind(self),
		complete: (isObserver ? nextHandler.complete : completionHandler)?.bind(self)
	};
}
var queuedEffects = [];
var cycle = 0;
var { link, unlink, propagate, checkDirty, shallowPropagate } = /* @__PURE__ */ createReactiveSystem({
	update(atom) {
		return atom._update();
	},
	notify(effect) {
		queuedEffects[queuedEffectsLength++] = effect;
		effect.flags &= -3;
	},
	unwatched(atom) {
		if (atom.depsTail !== void 0) {
			atom.depsTail = void 0;
			atom.flags = 17;
			purgeDeps(atom);
		}
	}
});
var notifyIndex = 0;
var queuedEffectsLength = 0;
var activeSub;
var batchDepth = 0;
function batch(fn) {
	try {
		++batchDepth;
		fn();
	} finally {
		if (!--batchDepth) flush();
	}
}
function purgeDeps(sub) {
	const depsTail = sub.depsTail;
	let dep = depsTail !== void 0 ? depsTail.nextDep : sub.deps;
	while (dep !== void 0) dep = unlink(dep, sub);
}
function flush() {
	if (batchDepth > 0) return;
	while (notifyIndex < queuedEffectsLength) {
		const effect = queuedEffects[notifyIndex];
		queuedEffects[notifyIndex++] = void 0;
		effect.notify();
	}
	notifyIndex = 0;
	queuedEffectsLength = 0;
}
function createAtom(valueOrFn, options) {
	const isComputed = typeof valueOrFn === "function";
	const getter = valueOrFn;
	const atom = {
		_snapshot: isComputed ? void 0 : valueOrFn,
		subs: void 0,
		subsTail: void 0,
		deps: void 0,
		depsTail: void 0,
		flags: isComputed ? 0 : 1,
		get() {
			if (activeSub !== void 0) link(atom, activeSub, cycle);
			return atom._snapshot;
		},
		subscribe(observerOrFn) {
			const obs = toObserver(observerOrFn);
			const observed = { current: false };
			const e = effect(() => {
				atom.get();
				if (!observed.current) observed.current = true;
				else {
					activeSub = void 0;
					obs.next?.(atom._snapshot);
				}
			});
			return { unsubscribe: () => {
				e.stop();
			} };
		},
		_update(getValue) {
			const prevSub = activeSub;
			const compare = options?.compare ?? Object.is;
			if (isComputed) {
				activeSub = atom;
				++cycle;
				atom.depsTail = void 0;
			} else if (getValue === void 0) return false;
			if (isComputed) atom.flags = 5;
			try {
				const oldValue = atom._snapshot;
				const newValue = typeof getValue === "function" ? getValue(oldValue) : getValue === void 0 && isComputed ? getter(oldValue) : getValue;
				if (oldValue === void 0 || !compare(oldValue, newValue)) {
					atom._snapshot = newValue;
					return true;
				}
				return false;
			} finally {
				activeSub = prevSub;
				if (isComputed) atom.flags &= -5;
				purgeDeps(atom);
			}
		}
	};
	if (isComputed) {
		atom.flags = 17;
		atom.get = function() {
			const flags = atom.flags;
			if (flags & 16 || flags & 32 && checkDirty(atom.deps, atom)) {
				if (atom._update()) {
					const subs = atom.subs;
					if (subs !== void 0) shallowPropagate(subs);
				}
			} else if (flags & 32) atom.flags = flags & -33;
			if (activeSub !== void 0) link(atom, activeSub, cycle);
			return atom._snapshot;
		};
	} else atom.set = function(valueOrFn) {
		if (atom._update(valueOrFn)) {
			const subs = atom.subs;
			if (subs !== void 0) {
				propagate(subs);
				shallowPropagate(subs);
				flush();
			}
		}
	};
	return atom;
}
function effect(fn) {
	const run = () => {
		const prevSub = activeSub;
		activeSub = effectObj;
		++cycle;
		effectObj.depsTail = void 0;
		effectObj.flags = 6;
		try {
			return fn();
		} finally {
			activeSub = prevSub;
			effectObj.flags &= -5;
			purgeDeps(effectObj);
		}
	};
	const effectObj = {
		deps: void 0,
		depsTail: void 0,
		subs: void 0,
		subsTail: void 0,
		flags: 6,
		notify() {
			const flags = this.flags;
			if (flags & 16 || flags & 32 && checkDirty(this.deps, this)) run();
			else this.flags = 2;
		},
		stop() {
			this.flags = 0;
			this.depsTail = void 0;
			purgeDeps(this);
		}
	};
	run();
	return effectObj;
}
//#endregion
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
/**
* @license React
* use-sync-external-store-shim.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_use_sync_external_store_shim_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		function useSyncExternalStore$2(subscribe, getSnapshot) {
			didWarnOld18Alpha || void 0 === React.startTransition || (didWarnOld18Alpha = !0, console.error("You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."));
			var value = getSnapshot();
			if (!didWarnUncachedGetSnapshot) {
				var cachedValue = getSnapshot();
				objectIs(value, cachedValue) || (console.error("The result of getSnapshot should be cached to avoid an infinite loop"), didWarnUncachedGetSnapshot = !0);
			}
			cachedValue = useState({ inst: {
				value,
				getSnapshot
			} });
			var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
			useLayoutEffect(function() {
				inst.value = value;
				inst.getSnapshot = getSnapshot;
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
			}, [
				subscribe,
				value,
				getSnapshot
			]);
			useEffect(function() {
				checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				return subscribe(function() {
					checkIfSnapshotChanged(inst) && forceUpdate({ inst });
				});
			}, [subscribe]);
			useDebugValue(value);
			return value;
		}
		function checkIfSnapshotChanged(inst) {
			var latestGetSnapshot = inst.getSnapshot;
			inst = inst.value;
			try {
				var nextValue = latestGetSnapshot();
				return !objectIs(inst, nextValue);
			} catch (error) {
				return !0;
			}
		}
		function useSyncExternalStore$1(subscribe, getSnapshot) {
			return getSnapshot();
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is, useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue, didWarnOld18Alpha = !1, didWarnUncachedGetSnapshot = !1, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
		exports.useSyncExternalStore = void 0 !== React.useSyncExternalStore ? React.useSyncExternalStore : shim;
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/use-sync-external-store/shim/index.js
var require_shim = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_use_sync_external_store_shim_development();
}));
//#endregion
//#region node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js
/**
* @license React
* use-sync-external-store-shim/with-selector.development.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_with_selector_development = /* @__PURE__ */ __commonJSMin(((exports) => {
	(function() {
		function is(x, y) {
			return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
		}
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
		var React = require_react(), shim = require_shim(), objectIs = "function" === typeof Object.is ? Object.is : is, useSyncExternalStore = shim.useSyncExternalStore, useRef = React.useRef, useEffect = React.useEffect, useMemo = React.useMemo, useDebugValue = React.useDebugValue;
		exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
			var instRef = useRef(null);
			if (null === instRef.current) {
				var inst = {
					hasValue: !1,
					value: null
				};
				instRef.current = inst;
			} else inst = instRef.current;
			instRef = useMemo(function() {
				function memoizedSelector(nextSnapshot) {
					if (!hasMemo) {
						hasMemo = !0;
						memoizedSnapshot = nextSnapshot;
						nextSnapshot = selector(nextSnapshot);
						if (void 0 !== isEqual && inst.hasValue) {
							var currentSelection = inst.value;
							if (isEqual(currentSelection, nextSnapshot)) return memoizedSelection = currentSelection;
						}
						return memoizedSelection = nextSnapshot;
					}
					currentSelection = memoizedSelection;
					if (objectIs(memoizedSnapshot, nextSnapshot)) return currentSelection;
					var nextSelection = selector(nextSnapshot);
					if (void 0 !== isEqual && isEqual(currentSelection, nextSelection)) return memoizedSnapshot = nextSnapshot, currentSelection;
					memoizedSnapshot = nextSnapshot;
					return memoizedSelection = nextSelection;
				}
				var hasMemo = !1, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
				return [function() {
					return memoizedSelector(getSnapshot());
				}, null === maybeGetServerSnapshot ? void 0 : function() {
					return memoizedSelector(maybeGetServerSnapshot());
				}];
			}, [
				getSnapshot,
				getServerSnapshot,
				selector,
				isEqual
			]);
			var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
			useEffect(function() {
				inst.hasValue = !0;
				inst.value = value;
			}, [value]);
			useDebugValue(value);
			return value;
		};
		"undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
	})();
}));
//#endregion
//#region node_modules/@tanstack/react-store/dist/useSelector.js
var import_with_selector = (/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_with_selector_development();
})))();
function defaultCompare(a, b) {
	return a === b;
}
/**
* Selects a slice of state from an atom or store and subscribes the component
* to that selection.
*
* This is the primary React read hook for TanStack Store. It works with any
* source that exposes `get()` and `subscribe()`, including atoms, readonly
* atoms, stores, and readonly stores.
*
* Omit the selector to subscribe to the whole value.
*
* @example
* ```tsx
* const count = useSelector(counterStore, (state) => state.count)
* ```
*
* @example
* ```tsx
* const value = useSelector(countAtom)
* ```
*/
function useSelector(source, selector = (s) => s, options) {
	const compare = options?.compare ?? defaultCompare;
	const subscribe = (0, import_react.useCallback)((handleStoreChange) => {
		const { unsubscribe } = source.subscribe(handleStoreChange);
		return unsubscribe;
	}, [source]);
	const getSnapshot = (0, import_react.useCallback)(() => source.get(), [source]);
	return (0, import_with_selector.useSyncExternalStoreWithSelector)(subscribe, getSnapshot, getSnapshot, selector, compare);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useMatch.js
var dummyMatch = {};
function useStructuralSharing(opts, router) {
	const previousResult = import_react.useRef();
	return (slice) => {
		const selected = opts?.select ? opts.select(slice) : slice;
		if (opts?.structuralSharing ?? router.options.defaultStructuralSharing) return previousResult.current = replaceEqualDeep(previousResult.current, selected);
		return selected;
	};
}
/**
* Read and select the nearest or targeted route match.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useMatchHook
*/
function useMatch(opts) {
	const router = useRouter();
	const nearestRouteId = import_react.useContext(opts.from ? dummyMatchContext : matchContext);
	const routeId = opts.from ?? nearestRouteId;
	const matchStore = router.stores.getMatchStore(routeId);
	if (router.isServer) {
		const match = matchStore.get();
		if (!match) {
			if (opts.shouldThrow ?? true) throw new Error(`Invariant failed: Could not find ${opts.from ? `an active match from "${opts.from}"` : "a nearest match!"}`);
			return;
		}
		return opts.select ? opts.select(match) : match;
	}
	const selector = useStructuralSharing(opts, router);
	const matchSelection = useSelector(matchStore, (match) => match ? selector(match) : dummyMatch);
	if (matchSelection !== dummyMatch) return matchSelection;
	if (opts.shouldThrow ?? true) throw new Error(`Invariant failed: Could not find ${opts.from ? `an active match from "${opts.from}"` : "a nearest match!"}`);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useLoaderData.js
/**
* Read and select the current route's loader data with type‑safety.
*
* Options:
* - `from`/`strict`: Choose which route's data to read and strictness
* - `select`: Map the loader data to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The loader data (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLoaderDataHook
*/
function useLoaderData(opts) {
	return useMatch({
		from: opts.from,
		strict: opts.strict,
		structuralSharing: opts.structuralSharing,
		select: (match) => {
			return opts.select ? opts.select(match.loaderData) : match.loaderData;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useLoaderDeps.js
/**
* Read and select the current route's loader dependencies object.
*
* Options:
* - `from`: Choose which route's loader deps to read
* - `select`: Map the deps to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The loader deps (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLoaderDepsHook
*/
function useLoaderDeps(opts) {
	const { select, ...rest } = opts;
	return useMatch({
		...rest,
		select: (match) => {
			return select ? select(match.loaderDeps) : match.loaderDeps;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useParams.js
/**
* Access the current route's path parameters with type-safety.
*
* Options:
* - `from`/`strict`: Specify the matched route and whether to enforce strict typing
* - `select`: Project the params object to a derived value for memoized renders
* - `structuralSharing`: Enable structural sharing for stable references
* - `shouldThrow`: Throw if the route is not found in strict contexts
*
* @returns The params object (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useParamsHook
*/
function useParams(opts) {
	return useMatch({
		from: opts.from,
		shouldThrow: opts.shouldThrow,
		structuralSharing: opts.structuralSharing,
		strict: opts.strict,
		select: (match) => {
			const params = opts.strict === false ? match.params : match._strictParams;
			return opts.select ? opts.select(params) : params;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useSearch.js
/**
* Read and select the current route's search parameters with type-safety.
*
* Options:
* - `from`/`strict`: Control which route's search is read and how strictly it's typed
* - `select`: Map the search object to a derived value for render optimization
* - `structuralSharing`: Enable structural sharing for stable references
* - `shouldThrow`: Throw when the route is not found (strict contexts)
*
* @returns The search object (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useSearchHook
*/
function useSearch(opts) {
	return useMatch({
		from: opts.from,
		strict: opts.strict,
		shouldThrow: opts.shouldThrow,
		structuralSharing: opts.structuralSharing,
		select: (match) => {
			return opts.select ? opts.select(match.search) : match.search;
		}
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useNavigate.js
/**
* Imperative navigation hook.
*
* Returns a stable `navigate(options)` function to change the current location
* programmatically. Prefer the `Link` component for user-initiated navigation,
* and use this hook from effects, callbacks, or handlers where imperative
* navigation is required.
*
* Options:
* - `from`: Optional route base used to resolve relative `to` paths.
*
* @returns A function that accepts `NavigateOptions`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useNavigateHook
*/
function useNavigate(_defaultOpts) {
	const router = useRouter();
	return import_react.useCallback((options) => {
		return router.navigate({
			...options,
			from: options.from ?? _defaultOpts?.from
		});
	}, [_defaultOpts?.from, router]);
}
/**
* Component that triggers a navigation when rendered. Navigation executes
* in an effect after mount/update.
*
* Props are the same as `NavigateOptions` used by `navigate()`.
*
* @returns null
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/navigateComponent
*/
function Navigate(props) {
	const router = useRouter();
	const navigate = useNavigate();
	const previousPropsRef = import_react.useRef(null);
	useLayoutEffect(() => {
		if (previousPropsRef.current !== props) {
			navigate(props);
			previousPropsRef.current = props;
		}
	}, [
		router,
		props,
		navigate
	]);
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useRouteContext.js
function useRouteContext(opts) {
	return useMatch({
		...opts,
		select: (match) => opts.select ? opts.select(match.context) : match.context
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/link.js
function useStableValues(...values) {
	const ref = import_react.useRef(values);
	const stable = ref.current;
	values.forEach((value, index) => {
		if (!deepEqual(stable[index], value, false, true)) stable[index] = value;
	});
	return ref.current;
}
function preloadLink(router, options) {
	router.preloadRoute(options).catch((err) => {
		console.warn(err);
		console.warn(preloadWarning);
	});
}
var LINK_SELECTOR_OPTIONS = { compare: (a, b) => a[0] === b[0] && a[1] === b[1] };
function resolveExternalLink(to, protocolAllowlist) {
	const scheme = typeof to === "string" && getUrlScheme(to);
	if (!scheme) return;
	if (!protocolAllowlist.has(scheme)) {
		console.warn(`Blocked Link with dangerous protocol: ${to}`);
		return null;
	}
	return to;
}
function resolveIsActive(location, next, activeOptions, basepath, isHydrated) {
	const currentPath = removeTrailingSlash(location.pathname, basepath);
	const nextPath = removeTrailingSlash(next.pathname, basepath);
	if (activeOptions?.exact ? currentPath !== nextPath : !(currentPath.startsWith(nextPath) && (currentPath.length === nextPath.length || currentPath[nextPath.length] === "/"))) return false;
	if (activeOptions?.includeSearch ?? true) {
		if (!deepEqual(location.search, next.search, !activeOptions?.exact, activeOptions?.explicitUndefined)) return false;
	}
	if (activeOptions?.includeHash) return isHydrated && location.hash === next.hash;
	return true;
}
function useLinkProps(options, forwardedRef, host) {
	const router = useRouter();
	if (router.isServer) return getServerLinkProps(router, options, forwardedRef, host);
	const innerRef = import_react.useRef(null);
	const mergedRef = import_react.useCallback((element) => {
		innerRef.current = element;
		if (typeof forwardedRef === "function") return forwardedRef(element);
		if (forwardedRef) forwardedRef.current = element;
	}, [forwardedRef]);
	const { activeOptions, to, preload: userPreload, preloadDelay: userPreloadDelay, hashScrollIntoView, replace, startTransition, resetScroll, viewTransition, ignoreBlocker, disabled, target, onClick, onBlur, onFocus, onMouseEnter, onMouseLeave, onTouchStart } = options;
	const isHydrated = useHydrated(!!activeOptions?.includeHash);
	const [stableSearch, stableParams, stableActiveOptions] = useStableValues(options.search, options.params, activeOptions);
	const [_options, dest] = import_react.useMemo(() => [options, { ...options }], [
		router,
		options.from,
		options._fromLocation,
		options.hash,
		options.to,
		stableSearch,
		stableParams,
		options.state,
		options.mask,
		options.unsafeRelative
	]);
	const selectLinkState = import_react.useMemo(() => {
		const directExternalLink = resolveExternalLink(to, router.protocolAllowlist);
		if (directExternalLink !== void 0) {
			const state = [directExternalLink ?? void 0];
			return () => state;
		}
		let inactive;
		let active;
		return (location) => {
			if (!_options._fromLocation) dest._fromLocation = location;
			const next = router.buildLocation(dest);
			const href = getHrefOption(next, router, disabled);
			if (!inactive || inactive[0] !== href) {
				inactive = [href, !(disabled || href && !getUrlScheme(href)) && void 0];
				active = [href, true];
			}
			return inactive[1] !== void 0 && resolveIsActive(location, next, stableActiveOptions, router.basepath, isHydrated) ? active : inactive;
		};
	}, [
		stableActiveOptions,
		disabled,
		isHydrated,
		_options,
		dest,
		router,
		to
	]);
	const [href, isActive] = useSelector(router.stores.location, selectLinkState, LINK_SELECTOR_OPTIONS);
	const externalLink = isActive === void 0 && href;
	const linkDisabled = disabled || href === void 0;
	const hasRenderFetched = import_react.useRef(false);
	const preload = options.reloadDocument || externalLink || linkDisabled ? false : userPreload ?? router.options.defaultPreload;
	const preloadDelay = userPreloadDelay ?? router.options.defaultPreloadDelay ?? 0;
	const enqueuePreload = import_react.useCallback((e) => {
		const isIntersecting = e?.isIntersecting;
		if (!(isIntersecting ?? preload === "intent")) {
			if (isIntersecting === false) cancelPreload(innerRef);
			return;
		}
		if (!preloadDelay) {
			preloadLink(router, _options);
			return;
		}
		if (timeoutMap.has(innerRef)) return;
		timeoutMap.set(innerRef, setTimeout(() => {
			timeoutMap.delete(innerRef);
			preloadLink(router, _options);
		}, preloadDelay));
	}, [
		router,
		_options,
		innerRef,
		preload,
		preloadDelay
	]);
	import_react.useEffect(() => {
		if (!preload) return;
		if (preload === "render" && !hasRenderFetched.current) {
			hasRenderFetched.current = true;
			preloadLink(router, _options);
		}
		let active = true;
		let observer;
		if (preload === "viewport" && innerRef.current && typeof IntersectionObserver === "function") {
			observer = new IntersectionObserver((entries) => {
				if (active) enqueuePreload(entries.pop());
			}, { rootMargin: "100px" });
			observer.observe(innerRef.current);
		}
		return () => {
			active = false;
			observer?.disconnect();
			cancelPreload(innerRef);
		};
	}, [
		router,
		_options,
		preload,
		enqueuePreload,
		innerRef
	]);
	const props = collectElementProps(options, host);
	props.ref = forwardedRef ? mergedRef : innerRef;
	if (externalLink) {
		props.href = externalLink;
		return props;
	}
	const handleClick = (e) => {
		const effectiveTarget = target ?? e.currentTarget.getAttribute("target");
		if (!linkDisabled && !(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && (!effectiveTarget || effectiveTarget === "_self") && e.button === 0) {
			e.preventDefault();
			router.navigate({
				..._options,
				replace,
				resetScroll,
				hashScrollIntoView,
				startTransition,
				viewTransition,
				ignoreBlocker
			});
		}
	};
	const handleTouchStart = () => {
		if (preload === "intent") preloadLink(router, _options);
	};
	const handleLeave = () => {
		if (preload === "intent") cancelPreload(innerRef);
	};
	props.onClick = composeHandlers(onClick, handleClick);
	props.onBlur = composeHandlers(onBlur, handleLeave);
	props.onFocus = composeHandlers(onFocus, enqueuePreload);
	props.onMouseEnter = composeHandlers(onMouseEnter, enqueuePreload);
	props.onMouseLeave = composeHandlers(onMouseLeave, handleLeave);
	props.onTouchStart = composeHandlers(onTouchStart, handleTouchStart);
	return applyLinkState(props, options, isActive, href, linkDisabled, host);
}
var STATIC_EMPTY_OBJECT = {};
var STATIC_ACTIVE_OBJECT = { className: "active" };
var ROUTER_OPTION_KEYS = /* @__PURE__ */ new Set([
	"to",
	"params",
	"search",
	"hash",
	"state",
	"mask",
	"from",
	"unsafeRelative",
	"_fromLocation",
	"reloadDocument",
	"preload",
	"preloadDelay",
	"preloadIntentProximity",
	"hashScrollIntoView",
	"replace",
	"startTransition",
	"resetScroll",
	"viewTransition",
	"ignoreBlocker",
	"activeProps",
	"inactiveProps",
	"activeOptions",
	"_asChild"
]);
function collectElementProps(options, host) {
	const props = {};
	for (const key in options) {
		if (ROUTER_OPTION_KEYS.has(key) || key === "type" && host !== void 0 || key === "disabled" && host === "a") continue;
		props[key] = options[key];
	}
	return props;
}
function applyLinkState(props, options, isActive, href, linkDisabled, host) {
	const { activeProps, inactiveProps, className, style, target } = options;
	const stateProps = functionalUpdate(isActive ? activeProps : inactiveProps, {}) ?? (isActive ? STATIC_ACTIVE_OBJECT : STATIC_EMPTY_OBJECT);
	Object.assign(props, stateProps);
	props.href = href;
	if (host !== "a") props.disabled = linkDisabled;
	props.target = target;
	const stateStyle = stateProps.style;
	if (style || stateStyle) props.style = style && stateStyle ? {
		...style,
		...stateStyle
	} : style || stateStyle;
	const stateClassName = stateProps.className;
	if (className || stateClassName) props.className = className ? stateClassName ? `${className} ${stateClassName}` : className : stateClassName;
	if (linkDisabled) {
		props.role = "link";
		props["aria-disabled"] = true;
	}
	if (isActive) {
		props["data-status"] = "active";
		props["aria-current"] = "page";
	}
	return props;
}
function getServerLinkProps(router, options, forwardedRef, host) {
	const { to, disabled, activeOptions } = options;
	const directExternalLink = resolveExternalLink(to, router.protocolAllowlist);
	const next = directExternalLink === void 0 ? router.buildLocation(options) : void 0;
	const hrefOption = next ? getHrefOption(next, router, disabled) : directExternalLink ?? void 0;
	const linkDisabled = disabled || !hrefOption;
	const externalLink = directExternalLink ?? (hrefOption && getUrlScheme(hrefOption) ? hrefOption : void 0);
	const props = collectElementProps(options, host);
	props.ref = forwardedRef;
	if (externalLink) {
		props.href = externalLink;
		return props;
	}
	return applyLinkState(props, options, !!next && !(!disabled && !hrefOption) && resolveIsActive(router.stores.location.get(), next, activeOptions, router.basepath, false), hrefOption, linkDisabled, host);
}
var timeoutMap = /* @__PURE__ */ new WeakMap();
var cancelPreload = (eventTarget) => {
	clearTimeout(timeoutMap.get(eventTarget));
	timeoutMap.delete(eventTarget);
};
var composeHandlers = (first, second) => {
	if (!first) return second;
	return (event) => event.defaultPrevented || (first(event), event.defaultPrevented || second(event));
};
function getHrefOption(next, router, disabled) {
	if (disabled) return;
	const location = next.maskedLocation ?? next;
	const href = location.external ? location.publicHref : router.history.createHref(location.publicHref) || "/";
	if ((location.external || href !== location.publicHref) && isDangerousProtocol(href, router.protocolAllowlist)) {
		console.warn(`Blocked Link with dangerous protocol: ${href}`);
		return;
	}
	return href;
}
/**
* Creates a typed Link-like component that preserves TanStack Router's
* navigation semantics and type-safety while delegating rendering to the
* provided host component.
*
* Useful for integrating design system anchors/buttons while keeping
* router-aware props (eg. `to`, `params`, `search`, `preload`).
*
* @param Comp The host component to render (eg. a design-system Link/Button)
* @returns A router-aware component with the same API as `Link`.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-link
*/
function createLink(Comp) {
	return import_react.forwardRef(function CreatedLink(props, ref) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			...props,
			_asChild: Comp,
			ref
		});
	});
}
/**
* A strongly-typed anchor component for declarative navigation.
* Handles path, search, hash and state updates with optional route preloading
* and active-state styling.
*
* Props:
* - `preload`: Controls route preloading (eg. 'intent', 'render', 'viewport', true/false)
* - `preloadDelay`: Delay in ms before preloading on focus, hover, or viewport entry
* - `activeProps`/`inactiveProps`: Additional props merged when link is active/inactive
* - `resetScroll`/`hashScrollIntoView`: Control scroll behavior on navigation
* - `viewTransition`/`startTransition`: Use View Transitions/React transitions for navigation
* - `ignoreBlocker`: Bypass registered blockers
*
* @returns An anchor-like element that navigates without full page reloads.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/linkComponent
*/
var Link = import_react.memo(import_react.forwardRef((props, ref) => {
	const host = props._asChild || "a";
	const linkProps = useLinkProps(props, ref, host);
	const children = typeof props.children === "function" ? props.children({ isActive: linkProps["data-status"] === "active" }) : props.children;
	return import_react.createElement(host, linkProps, children);
}), areLinkPropsEqual);
function areLinkPropsEqual(prev, next) {
	let extraKeys = 0;
	for (const key in next) {
		extraKeys++;
		if (prev[key] === next[key]) continue;
		if (!ROUTER_OPTION_KEYS.has(key) || !deepEqual(prev[key], next[key], false, true)) return false;
	}
	for (const _key in prev) extraKeys--;
	return extraKeys === 0;
}
/**
* Validate and reuse navigation options for `Link`, `navigate` or `redirect`.
* Accepts a literal options object and returns it typed for later spreading.
* @example
* const opts = linkOptions({ to: '/dashboard', search: { tab: 'home' } })
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/linkOptions
*/
var linkOptions = (options) => {
	return options;
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/route.js
/**
* Returns a route-specific API that exposes type-safe hooks pre-bound
* to a single route ID. Useful for consuming a route's APIs from files
* where the route object isn't directly imported (e.g. code-split files).
*
* @param id Route ID string literal for the target route.
* @returns A `RouteApi` instance bound to the given route ID.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/getRouteApiFunction
*/
function getRouteApi(id) {
	return new RouteApi({ id });
}
var RouteApi = class extends BaseRouteApi {
	/**
	* @deprecated Use the `getRouteApi` function instead.
	*/
	constructor({ id }) {
		super({ id });
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id,
				strict: false
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id,
				strict: false
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: useRouter().routesById[this.id].fullPath });
		};
		this.notFound = (opts) => {
			return notFound({
				routeId: this.id,
				...opts
			});
		};
		this.Link = import_react.forwardRef((props, ref) => {
			const fullPath = useRouter().routesById[this.id].fullPath;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: fullPath,
				...props
			});
		});
	}
};
var Route = class extends BaseRoute {
	/**
	* @deprecated Use the `createRoute` function instead.
	*/
	constructor(options) {
		super(options);
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: this.fullPath });
		};
		this.Link = import_react.forwardRef((props, ref) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: this.fullPath,
				...props
			});
		});
	}
};
/**
* Creates a non-root Route instance for code-based routing.
*
* Use this to define a route that will be composed into a route tree
* (typically via a parent route's `addChildren`). If you're using file-based
* routing, prefer `createFileRoute`.
*
* @param options Route options (path, component, loader, context, etc.).
* @returns A Route instance to be attached to the route tree.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouteFunction
*/
function createRoute(options) {
	return new Route(options);
}
/**
* Creates a root route factory that requires a router context type.
*
* Use when your root route expects `context` to be provided to `createRouter`.
* The returned function behaves like `createRootRoute` but enforces a context type.
*
* @returns A factory function to configure and return a root route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRootRouteWithContextFunction
*/
function createRootRouteWithContext() {
	return (options) => {
		return createRootRoute(options);
	};
}
/**
* @deprecated Use the `createRootRouteWithContext` function instead.
*/
var rootRouteWithContext = createRootRouteWithContext;
var RootRoute = class extends BaseRootRoute {
	/**
	* @deprecated `RootRoute` is now an internal implementation detail. Use `createRootRoute()` instead.
	*/
	constructor(options) {
		super(options);
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: this.fullPath });
		};
		this.Link = import_react.forwardRef((props, ref) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: this.fullPath,
				...props
			});
		});
	}
};
/**
* Creates a root Route instance used to build your route tree.
*
* Typically paired with `createRouter({ routeTree })`. If you need to require
* a typed router context, use `createRootRouteWithContext` instead.
*
* @param options Root route options (component, error, pending, etc.).
* @returns A root route instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRootRouteFunction
*/
function createRootRoute(options) {
	return new RootRoute(options);
}
function createRouteMask(opts) {
	return opts;
}
var NotFoundRoute = class extends Route {
	constructor(options) {
		super({
			...options,
			id: "404"
		});
	}
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/fileRoute.js
/**
* Creates a file-based Route factory for a given path.
*
* Used by TanStack Router's file-based routing to associate a file with a
* route. The returned function accepts standard route options. In normal usage
* the `path` string is inserted and maintained by the `tsr` generator.
*
* @param path File path literal for the route (usually auto-generated).
* @returns A function that accepts Route options and returns a Route instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createFileRouteFunction
*/
function createFileRoute(path) {
	return (options) => {
		const route = createRoute(options);
		route.isRoot = false;
		return route;
	};
}
/** 
@deprecated It's no longer recommended to use the `FileRoute` class directly.
Instead, use `createFileRoute('/path/to/file')(options)` to create a file route.
*/
var FileRoute = class {
	constructor(path, _opts) {
		this.path = path;
		this.createRoute = (options) => {
			if (!this.silent) console.warn("Warning: FileRoute is deprecated and will be removed in the next major version. Use the createFileRoute(path)(options) function instead.");
			const route = createRoute(options);
			route.isRoot = false;
			return route;
		};
		this.silent = _opts?.silent;
	}
};
/**
@deprecated It's recommended not to split loaders into separate files.
Instead, place the loader function in the main route file via `createFileRoute`.
*/
function FileRouteLoader(_path) {
	console.warn(`Warning: FileRouteLoader is deprecated and will be removed in the next major version. Please place the loader function in the main route file, inside the \`createFileRoute('/path/to/file')(options)\` options`);
	return (loaderFn) => loaderFn;
}
var LazyRoute = class {
	constructor(opts) {
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.options.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.options.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.options.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.options.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.options.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.options.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: useRouter().routesById[this.options.id].fullPath });
		};
		this.options = opts;
	}
};
/**
* Creates a lazily-configurable code-based route stub by ID.
*
* Use this for code-splitting with code-based routes. The returned function
* accepts only non-critical route options like `component`, `pendingComponent`,
* `errorComponent`, and `notFoundComponent` which are applied when the route
* is matched.
*
* @param id Route ID string literal to associate with the lazy route.
* @returns A function that accepts lazy route options and returns a `LazyRoute`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createLazyRouteFunction
*/
function createLazyRoute(id) {
	return (opts) => {
		return new LazyRoute({
			id,
			...opts
		});
	};
}
/**
* Creates a lazily-configurable file-based route stub by file path.
*
* Use this for code-splitting with file-based routes (eg. `.lazy.tsx` files).
* The returned function accepts only non-critical route options like
* `component`, `pendingComponent`, `errorComponent`, and `notFoundComponent`.
*
* @param id File path literal for the route file.
* @returns A function that accepts lazy route options and returns a `LazyRoute`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createLazyFileRouteFunction
*/
function createLazyFileRoute(id) {
	if (typeof id === "object") return new LazyRoute(id);
	return (opts) => new LazyRoute({
		id,
		...opts
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/lazyRouteComponent.js
/**
* Wrap a dynamic import to create a route component that supports
* `.preload()` and friendly reload-on-module-missing behavior.
*
* @param importer Function returning a module promise
* @param exportName Named export to use (default: `default`)
* @returns A lazy route component compatible with TanStack Router
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/lazyRouteComponentFunction
*/
function lazyRouteComponent(importer, exportName) {
	let loadPromise;
	let comp;
	let error;
	const load = () => {
		if (!loadPromise) {
			error = void 0;
			loadPromise = importer().then((res) => {
				if (!(typeof window === "undefined")) {
					loadPromise = void 0;
					lazyComp.preload = void 0;
				}
				comp = res[exportName ?? "default"];
			}).catch((err) => {
				loadPromise = void 0;
				error = err;
			});
		}
		return loadPromise;
	};
	const lazyComp = function Lazy(props) {
		if (error) {
			if (isModuleNotFoundError(error) && !(typeof window === "undefined") && typeof sessionStorage !== "undefined") {
				const storageKey = `tanstack_router_reload:${error.message}`;
				if (!sessionStorage.getItem(storageKey)) {
					sessionStorage.setItem(storageKey, "1");
					window.location.reload();
					throw new Promise(() => {});
				}
			}
			throw error;
		}
		if (!comp) if (reactUse) reactUse(load());
		else throw load();
		return import_react.createElement(comp, props);
	};
	lazyComp.preload = load;
	return lazyComp;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/not-found.js
function CatchNotFound(props) {
	const router = useRouter();
	if (router.isServer) {
		const resetKey = `not-found-${router.stores.location.get().pathname}-${router.stores.status.get()}`;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
			getResetKey: () => resetKey,
			onCatch: (error, errorInfo) => {
				if (isNotFound(error)) props.onCatch?.(error, errorInfo);
				else throw error;
			},
			errorComponent: ({ error }) => {
				if (isNotFound(error)) return props.fallback?.(error);
				else throw error;
			},
			children: props.children
		});
	}
	const resetKey = `not-found-${useSelector(router.stores.location, (location) => location.pathname)}-${useSelector(router.stores.status)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => resetKey,
		onCatch: (error, errorInfo) => {
			if (isNotFound(error)) props.onCatch?.(error, errorInfo);
			else throw error;
		},
		errorComponent: ({ error }) => {
			if (isNotFound(error)) return props.fallback?.(error);
			else throw error;
		},
		children: props.children
	});
}
function DefaultGlobalNotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Not Found" });
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/ScriptOnce.js
/**
* Server-only helper to emit a script tag exactly once during SSR.
*/
function ScriptOnce({ children }) {
	const router = useRouter();
	if (!router.isServer) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		nonce: router.options.ssr?.nonce,
		dangerouslySetInnerHTML: { __html: children + ";document.currentScript.remove()" }
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/renderRouteNotFound.js
/**
* Renders a not found component for a route when no matching route is found.
*
* @param router - The router instance containing the route configuration
* @param route - The route that triggered the not found state
* @param data - Additional data to pass to the not found component
* @returns The rendered not found component or a default fallback component
*/
function renderRouteNotFound(router, route, data) {
	if (!route.options.notFoundComponent) {
		if (router.options.defaultNotFoundComponent) return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.defaultNotFoundComponent, { ...data }), "notFoundComponent");
		if (!route.options.notFoundComponent) console.warn(`Warning: A notFoundError was encountered on the route with ID "${route.id}", but a notFoundComponent option was not configured, nor was a router level defaultNotFoundComponent configured. Consider configuring at least one of these to avoid TanStack Router's overly generic defaultNotFoundComponent (<p>Not Found</p>)`);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DefaultGlobalNotFound, {});
	}
	return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(route.options.notFoundComponent, { ...data }), "notFoundComponent");
}
//#endregion
//#region node_modules/@tanstack/router-core/dist/esm/scroll-restoration-script/client.js
function getScrollRestorationScriptForRouter(_router) {
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/scroll-restoration.js
function ScrollRestoration$1() {
	const script = getScrollRestorationScriptForRouter(useRouter());
	if (!script) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptOnce, { children: script });
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Match.js
function renderPending(router, route) {
	const PendingComponent = route?.options.pendingComponent ?? router.options.defaultPendingComponent;
	if (!PendingComponent) return null;
	return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingComponent, {}), "pendingComponent");
}
var outletMatchSelectionEqual = (a, b) => a[0] === b[0] && a[1] === b[1];
var canWrapInSuspense = (router, route, ssr) => !route.isRoot || route.options.shellComponent || route.options.wrapInSuspense || ssr === false || ssr === "data-only" || !(router.isServer || router.ssr);
var Match = import_react.memo(function MatchImpl({ routeId }) {
	const router = useRouter();
	if (router.isServer) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchView, {
		router,
		match: router.stores.byRoute.get(routeId).get()
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchView, {
		router,
		match: useSelector(router.stores.getMatchStore(routeId))
	});
});
function MatchView({ router, match }) {
	const route = router.routesById[match.routeId];
	const pendingElement = renderPending(router, route);
	const routeErrorComponent = route.options.errorComponent ?? router.options.defaultErrorComponent;
	const routeOnCatch = route.options.onCatch ?? router.options.defaultOnCatch;
	const routeNotFoundComponent = route.isRoot ? route.options.notFoundComponent ?? router.options.notFoundRoute?.options.component : route.options.notFoundComponent;
	const resolvedNoSsr = match.ssr === false || match.ssr === "data-only";
	const wrapInSuspense = canWrapInSuspense(router, route, match.ssr) && (route.options.wrapInSuspense ?? pendingElement ?? (route.options.errorComponent?.preload || resolvedNoSsr));
	let content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchInner, { match });
	if (resolvedNoSsr) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientOnly, {
		fallback: pendingElement,
		children: content
	});
	if (routeNotFoundComponent) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchNotFound, {
		fallback: (error) => {
			error.routeId ??= match.routeId;
			if (error.routeId !== match.routeId) throw error;
			return wrapInNonRouteComponentContext(import_react.createElement(routeNotFoundComponent, error), "notFoundComponent");
		},
		children: content
	});
	if (routeErrorComponent) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => match,
		errorComponent: routeErrorComponent,
		onCatch: (error, errorInfo) => {
			if (isNotFound(error)) {
				error.routeId ??= match.routeId;
				throw error;
			}
			console.warn(`Warning: Error in route match: ${match.id}`);
			routeOnCatch?.(error, errorInfo);
		},
		children: content
	});
	if (wrapInSuspense) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: pendingElement,
		children: content
	});
	const scrollRestoration = router.isServer && route.parentRoute?.id === "__root__" && router.options.scrollRestoration ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollRestoration$1, {}) : null;
	const ShellComponent = route.isRoot ? route.options.shellComponent : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(matchContext.Provider, {
		value: match.routeId,
		children: ShellComponent ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ShellComponent, { children: [content, scrollRestoration] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [content, scrollRestoration] })
	});
}
var MatchInner = import_react.memo(function MatchInnerImpl({ match }) {
	const router = useRouter();
	const routeId = match.routeId;
	const route = router.routesById[routeId];
	const key = import_react.useMemo(() => {
		const remountDeps = (route.options.remountDeps ?? router.options.defaultRemountDeps)?.({
			routeId,
			loaderDeps: match.loaderDeps,
			params: match._strictParams,
			search: match._strictSearch
		});
		return remountDeps ? JSON.stringify(remountDeps) : void 0;
	}, [
		routeId,
		match.loaderDeps,
		match._strictParams,
		match._strictSearch,
		route.options.remountDeps,
		router.options.defaultRemountDeps
	]);
	const out = import_react.useMemo(() => {
		const Comp = route.options.component ?? router.options.defaultComponent;
		return Comp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, {}, key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	}, [
		key,
		route.options.component,
		router.options.defaultComponent
	]);
	if (match.status === "pending") {
		if (router.ssr && !canWrapInSuspense(router, route, match.ssr)) return out;
		if (router._tx) throw router._tx[5];
		return renderPending(router, route);
	}
	if (match.status === "notFound") return renderRouteNotFound(router, route, match.error);
	if (match.status === "error") {
		if (router.isServer) return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)((route.options.errorComponent ?? router.options.defaultErrorComponent) || ErrorComponent, {
			error: match.error,
			reset: void 0,
			info: { componentStack: "" }
		}), "errorComponent");
		throw match.error;
	}
	return out;
});
/**
* Render the next child match in the route tree. Typically used inside
* a route component to render nested routes.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/outletComponent
*/
var Outlet = import_react.memo(function OutletImpl() {
	{
		const nonRouteComponent = import_react.useContext(nonRouteComponentContext);
		if (nonRouteComponent) console.warn(`Warning: An <Outlet /> was rendered inside a ${nonRouteComponent}. <Outlet /> should only be rendered inside a route component.`);
	}
	const router = useRouter();
	const routeId = import_react.useContext(matchContext);
	let parentGlobalNotFound;
	let parentNotFoundError;
	let childRouteId;
	if (router.isServer) {
		const matches = router.stores.matches.get();
		const parentIndex = matches.findIndex((match) => match.routeId === routeId);
		const parentMatch = matches[parentIndex];
		parentGlobalNotFound = !!parentMatch._notFound;
		parentNotFoundError = parentMatch.error;
		childRouteId = matches[parentIndex + 1]?.routeId;
	} else {
		const parentMatchStore = router.stores.getMatchStore(routeId);
		[parentGlobalNotFound, parentNotFoundError] = useSelector(parentMatchStore, (match) => [!!match._notFound, match.error], { compare: outletMatchSelectionEqual });
		childRouteId = useSelector(router.stores.ids, (ids) => {
			return ids[ids.indexOf(routeId) + 1];
		});
	}
	if (parentGlobalNotFound) return renderRouteNotFound(router, router.routesById[routeId], parentNotFoundError);
	if (!childRouteId) return null;
	const nextMatch = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, { routeId: childRouteId });
	if (routeId === "__root__") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: renderPending(router),
		children: nextMatch
	});
	return nextMatch;
});
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Transitioner.js
function settleOwner(owner, rendered) {
	const settle = owner[1];
	owner.length = 0;
	settle?.(rendered);
}
function Transitioner({ t }) {
	const router = useRouter();
	const acknowledgement = router._rendered ??= [];
	const mounted = import_react.useRef(false);
	router.startTransition = (fn, expected) => new Promise((resolve) => {
		settleOwner(acknowledgement, false);
		acknowledgement.push(expected, resolve);
		t(router);
		import_react.startTransition(fn);
	});
	useLayoutEffect(() => {
		const unsub = router.history.subscribe(router.load);
		if (mounted?.current) return unsub;
		if (mounted) mounted.current = true;
		router.updateLatestLocation();
		const location = router.latestLocation;
		const nextLocation = router.buildLocation({
			to: location.pathname,
			search: true,
			params: true,
			hash: true,
			state: true,
			_includeValidateSearch: true
		});
		if (trimPathRight(location.publicHref) !== trimPathRight(nextLocation.publicHref)) {
			router.commitLocation({
				...nextLocation,
				replace: true,
				ignoreBlocker: true
			});
			return unsub;
		}
		const resolvedLocation = router.stores.resolvedLocation.get();
		if (resolvedLocation?.href === location.href && resolvedLocation.state.__TSR_key === location.state.__TSR_key) acknowledgement.push(router.stores.matches.get(), (rendered) => {
			if (rendered) router.emit({
				type: "onRendered",
				...getLocationChangeInfo(resolvedLocation, resolvedLocation)
			});
		});
		else if (!router._tx) router.load({ sync: true }).catch(console.error);
		return unsub;
	}, [router, router.history]);
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Matches.js
/**
* Internal component that renders the router's active match tree with
* suspense, error, and not-found boundaries. Rendered by `RouterProvider`.
*/
function Matches() {
	const router = useRouter();
	const rootRoute = router.routesById[rootRouteId];
	const pendingElement = renderPending(router, rootRoute);
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!router.isServer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transitioner, { t: import_react.useState()[1] }), router.isServer || router.ssr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchesInner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: pendingElement,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchesInner, {})
	})] });
	return router.options.InnerWrap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.InnerWrap, { children: inner }) : inner;
}
function MatchesInner() {
	const router = useRouter();
	const acknowledgement = router._rendered;
	const matches = router.isServer ? router.stores.matches.get() : useSelector(router.stores.matches, (value) => acknowledgement[0] ?? value);
	const match = matches[0];
	const routeId = match?.routeId;
	useLayoutEffect(() => {
		if (acknowledgement[0] === matches) settleOwner(acknowledgement, true);
	}, [acknowledgement, matches]);
	const matchComponent = routeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, { routeId }) : null;
	return router.options.disableGlobalCatchBoundary ? matchComponent : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => match,
		onCatch: (error) => {
			console.warn(`Warning: The following error wasn't caught by any route! At the very least, consider setting an 'errorComponent' in your RootRoute!`);
			console.warn("Warning:", error);
		},
		children: matchComponent
	});
}
/**
* Create a matcher function for testing locations against route definitions.
*
* The returned function accepts standard navigation options (`to`, `params`,
* `search`, etc.) and returns either `false` (no match) or the matched params
* object when the route matches the current or pending location.
*
* Useful for conditional rendering and active UI states because it subscribes
* the component to the router state used for matching. The returned function's
* identity changes when that state changes. For imperative checks in event
* handlers, get the router with `useRouter` and call `router.matchRoute(...)`
* to avoid that subscription.
*
* @returns A `matchRoute(options)` function that returns `false` or params.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useMatchRouteHook
*/
function useMatchRoute() {
	const router = useRouter();
	if (router.isServer) return (opts) => {
		const { pending, caseSensitive, fuzzy, includeSearch, ...rest } = opts;
		return router.matchRoute(rest, {
			pending,
			caseSensitive,
			fuzzy,
			includeSearch
		});
	};
	return import_react.useCallback((opts) => {
		const { pending, caseSensitive, fuzzy, includeSearch, ...rest } = opts;
		return router.matchRoute(rest, {
			pending,
			caseSensitive,
			fuzzy,
			includeSearch
		});
	}, [
		router,
		useSelector(router.stores.location, (location) => location.href),
		useSelector(router.stores.resolvedLocation, (location) => location?.href),
		useSelector(router.stores.status)
	]);
}
/**
* Component that conditionally renders its children based on whether a route
* matches the provided `from`/`to` options. If `children` is a function, it
* receives the matched params object.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/matchRouteComponent
*/
function MatchRoute(props) {
	const params = useMatchRoute()(props);
	if (typeof props.children === "function") return props.children(params);
	return params ? props.children : null;
}
function useMatches(opts) {
	const router = useRouter();
	if (router.isServer) {
		const matches = router.stores.matches.get();
		return opts?.select ? opts.select(matches) : matches;
	}
	return useSelector(router.stores.matches, useStructuralSharing(opts, router));
}
/**
* Read the presented route matches above the current match, or select a
* derived value from them.
*/
function useParentMatches(opts) {
	const contextRouteId = import_react.useContext(matchContext);
	return useMatches({
		select: (matches) => {
			matches = matches.slice(0, matches.findIndex((d) => d.routeId === contextRouteId));
			return opts?.select ? opts.select(matches) : matches;
		},
		structuralSharing: opts?.structuralSharing
	});
}
/**
* Read the presented route matches below the current match, or select a
* derived value from them.
*/
function useChildMatches(opts) {
	const contextRouteId = import_react.useContext(matchContext);
	return useMatches({
		select: (matches) => {
			matches = matches.slice(matches.findIndex((d) => d.routeId === contextRouteId) + 1);
			return opts?.select ? opts.select(matches) : matches;
		},
		structuralSharing: opts?.structuralSharing
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/routerStores.js
var getStoreFactory = (opts) => {
	if (opts.isServer) return {
		createMutableStore: createNonReactiveMutableStore,
		createReadonlyStore: createNonReactiveReadonlyStore,
		batch: (fn) => fn()
	};
	return {
		createMutableStore: createAtom,
		createReadonlyStore: createAtom,
		batch
	};
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/router.js
/**
* Creates a new Router instance for React.
*
* Pass the returned router to `RouterProvider` to enable routing.
* Notable options: `routeTree` (your route definitions) and `context`
* (required if the root route was created with `createRootRouteWithContext`).
*
* @param options Router options used to configure the router.
* @returns A Router instance to be provided to `RouterProvider`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouterFunction
*/
var createRouter = (options) => {
	return new Router(options);
};
var Router = class extends RouterCore {
	constructor(options) {
		super(options, getStoreFactory);
	}
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/RouterProvider.js
/**
* Low-level provider that places the router into React context and optionally
* updates router options from props. Most apps should use `RouterProvider`.
*/
function RouterContextProvider({ router, children, ...rest }) {
	if (hasKeys(rest)) router.update({
		...router.options,
		...rest,
		context: {
			...router.options.context,
			...rest.context
		}
	});
	const provider = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(routerContext.Provider, {
		value: router,
		children
	});
	if (router.options.Wrap) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.Wrap, { children: provider });
	return provider;
}
/**
* Renders the current match presentation and provides the router to the React
* tree via context.
*
* Accepts mutable router options via props. Configure initialization-only
* options with `createRouter`.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouterFunction
*/
function RouterProvider({ router, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouterContextProvider, {
		router,
		...rest,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matches, {})
	});
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/ScrollRestoration.js
function useScrollRestoration() {
	setupScrollRestoration(useRouter(), true);
}
/**
* @deprecated Use the `scrollRestoration` router option instead.
*/
function ScrollRestoration(_props) {
	useScrollRestoration();
	console.warn("The ScrollRestoration component is deprecated. Use createRouter's `scrollRestoration` option instead.");
	return null;
}
function useElementScrollRestoration(options) {
	useScrollRestoration();
	return getElementScrollRestorationEntry(useRouter(), options);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useBlocker.js
function _resolveBlockerOpts(opts, condition) {
	if (opts === void 0) return {
		shouldBlockFn: () => true,
		withResolver: false
	};
	if ("shouldBlockFn" in opts) return opts;
	if (typeof opts === "function") {
		const shouldBlock = Boolean(condition ?? true);
		const _customBlockerFn = async () => {
			if (shouldBlock) return await opts();
			return false;
		};
		return {
			shouldBlockFn: _customBlockerFn,
			enableBeforeUnload: shouldBlock,
			withResolver: false
		};
	}
	const shouldBlock = Boolean(opts.condition ?? true);
	const fn = opts.blockerFn;
	const _customBlockerFn = async () => {
		if (shouldBlock && fn !== void 0) return await fn();
		return shouldBlock;
	};
	return {
		shouldBlockFn: _customBlockerFn,
		enableBeforeUnload: shouldBlock,
		withResolver: fn === void 0
	};
}
function useBlocker(opts, condition) {
	const { shouldBlockFn, enableBeforeUnload = true, disabled = false, withResolver = false } = _resolveBlockerOpts(opts, condition);
	const router = useRouter();
	const { history } = router;
	const [resolver, setResolver] = import_react.useState({
		status: "idle",
		current: void 0,
		next: void 0,
		action: void 0,
		proceed: void 0,
		reset: void 0
	});
	import_react.useEffect(() => {
		const blockerFnComposed = async (blockerFnArgs) => {
			function getLocation(location) {
				const parsedLocation = router.parseLocation(location);
				const [, rawParams, foundRoute] = router.getMatchedRoutes(parsedLocation.pathname);
				if (foundRoute === void 0) return {
					routeId: "__notFound__",
					fullPath: parsedLocation.pathname,
					pathname: parsedLocation.pathname,
					params: rawParams,
					search: router.options.parseSearch(location.search)
				};
				return {
					routeId: foundRoute.id,
					fullPath: foundRoute.fullPath,
					pathname: parsedLocation.pathname,
					params: rawParams,
					search: router.options.parseSearch(location.search)
				};
			}
			const current = getLocation(blockerFnArgs.currentLocation);
			const next = getLocation(blockerFnArgs.nextLocation);
			if (current.routeId === "__notFound__" && next.routeId !== "__notFound__") return false;
			const shouldBlock = await shouldBlockFn({
				action: blockerFnArgs.action,
				current,
				next
			});
			if (!withResolver) return shouldBlock;
			if (!shouldBlock) return false;
			const canNavigateAsync = await new Promise((resolve) => {
				setResolver({
					status: "blocked",
					current,
					next,
					action: blockerFnArgs.action,
					proceed: () => resolve(false),
					reset: () => resolve(true)
				});
			});
			setResolver({
				status: "idle",
				current: void 0,
				next: void 0,
				action: void 0,
				proceed: void 0,
				reset: void 0
			});
			return canNavigateAsync;
		};
		return disabled ? void 0 : history.block({
			blockerFn: blockerFnComposed,
			enableBeforeUnload
		});
	}, [
		shouldBlockFn,
		enableBeforeUnload,
		disabled,
		withResolver,
		history,
		router
	]);
	return resolver;
}
var _resolvePromptBlockerArgs = (props) => {
	if ("shouldBlockFn" in props) return { ...props };
	const shouldBlock = Boolean(props.condition ?? true);
	const fn = props.blockerFn;
	const _customBlockerFn = async () => {
		if (shouldBlock && fn !== void 0) return await fn();
		return shouldBlock;
	};
	return {
		shouldBlockFn: _customBlockerFn,
		enableBeforeUnload: shouldBlock,
		withResolver: fn === void 0
	};
};
function Block(opts) {
	const { children, ...rest } = opts;
	const resolver = useBlocker(_resolvePromptBlockerArgs(rest));
	return children ? typeof children === "function" ? children(resolver) : children : null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useRouterState.js
/**
* Subscribe to the router's state store with optional selection and
* structural sharing for render optimization.
*
* Options:
* - `select`: Project the full router state to a derived slice
* - `structuralSharing`: Replace-equal semantics for stable references
* - `router`: Read state from a specific router instance instead of context
*
* @returns The selected router state (or the full state by default).
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useRouterStateHook
*/
function useRouterState(opts) {
	const contextRouter = useRouter({ warn: opts?.router === void 0 });
	const router = opts?.router || contextRouter;
	if (router.isServer) {
		const state = router.stores.__store.get();
		return opts?.select ? opts.select(state) : state;
	}
	return useSelector(router.stores.__store, useStructuralSharing(opts, router));
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useLocation.js
/**
* Read the current location from the router state with optional selection.
* Useful for subscribing to just the pieces of location you care about.
*
* Options:
* - `select`: Project the `location` object to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The current location (or selected value).
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLocationHook
*/
function useLocation(opts) {
	const router = useRouter();
	if (router.isServer) {
		const location = router.stores.location.get();
		return opts?.select ? opts.select(location) : location;
	}
	return useSelector(router.stores.location, useStructuralSharing(opts, router));
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/useCanGoBack.js
function useCanGoBack() {
	const router = useRouter();
	if (router.isServer) return router.stores.location.get().state.__TSR_index !== 0;
	return useSelector(router.stores.location, (location) => location.state.__TSR_index !== 0);
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Asset.js
var INLINE_CSS_HYDRATION_ATTR = "data-tsr-inline-css";
var noopScriptHandler = () => {};
function setScriptAttrs(script, attrs) {
	if (!attrs) return;
	for (const [key, value] of Object.entries(attrs)) if (key !== "suppressHydrationWarning" && value !== void 0 && value !== false) script.setAttribute(key, typeof value === "boolean" ? "" : String(value));
}
function Asset(asset) {
	const { attrs, children, nonce, preventScriptHoist } = asset;
	const innerHTML = import_react.useMemo(() => children === void 0 ? void 0 : { __html: children }, [children]);
	switch (asset.tag) {
		case "title": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", {
			...attrs,
			suppressHydrationWarning: true,
			children
		});
		case "meta": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			...attrs,
			suppressHydrationWarning: true
		});
		case "link": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("link", {
			...attrs,
			precedence: attrs?.precedence ?? (attrs?.rel === "stylesheet" ? "default" : void 0),
			nonce,
			suppressHydrationWarning: true
		});
		case "style":
			if (asset.inlineCss && (process.env.TSS_INLINE_CSS_ENABLED === "true" || process.env.TSS_INLINE_CSS_ENABLED === void 0 && void 0)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineCssStyle, {
				attrs,
				nonce,
				children
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
				...attrs,
				dangerouslySetInnerHTML: innerHTML,
				nonce
			});
		case "script": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Script, {
			attrs,
			preventScriptHoist,
			children
		});
		default: return null;
	}
}
function InlineCssStyle({ attrs, children, nonce }) {
	const isInlineCssPlaceholder = children === void 0;
	const [hydratedInlineCss] = import_react.useState(() => {
		if (!isInlineCssPlaceholder || typeof document === "undefined") return;
		return document.querySelector(`style[${INLINE_CSS_HYDRATION_ATTR}]`)?.textContent ?? void 0;
	});
	const html = isInlineCssPlaceholder ? hydratedInlineCss ?? "" : children ?? "";
	const innerHTML = import_react.useMemo(() => ({ __html: html }), [html]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
		...attrs,
		[INLINE_CSS_HYDRATION_ATTR]: "",
		dangerouslySetInnerHTML: innerHTML,
		nonce,
		suppressHydrationWarning: true
	});
}
function Script({ attrs, children, preventScriptHoist }) {
	const router = useRouter();
	const hydrated = useHydrated();
	const innerHTML = import_react.useMemo(() => children === void 0 ? void 0 : { __html: children }, [children]);
	const dataScript = typeof attrs?.type === "string" && attrs.type !== "" && attrs.type !== "text/javascript" && attrs.type !== "module";
	if (attrs?.src && typeof children === "string" && children.trim().length) console.warn("[TanStack Router] <Script> received both `src` and `children`. The `children` content will be ignored. Remove `children` or remove `src`.");
	import_react.useEffect(() => {
		if (dataScript) return;
		if (attrs?.src) {
			const link = document.createElement("a");
			link.href = attrs.src;
			const normSrc = link.href;
			for (const el of document.scripts) if (el.src === normSrc) return;
			const script = document.createElement("script");
			setScriptAttrs(script, attrs);
			document.head.appendChild(script);
			return () => script.remove();
		}
		if (typeof children === "string") {
			const typeAttr = typeof attrs?.type === "string" ? attrs.type : "text/javascript";
			const nonceAttr = typeof attrs?.nonce === "string" ? attrs.nonce : void 0;
			for (const el of document.scripts) {
				if (el.hasAttribute("src")) continue;
				const sType = el.getAttribute("type") ?? "text/javascript";
				const sNonce = el.getAttribute("nonce") ?? void 0;
				if (el.textContent === children && sType === typeAttr && sNonce === nonceAttr) return;
			}
			const script = document.createElement("script");
			script.textContent = children;
			setScriptAttrs(script, attrs);
			document.head.appendChild(script);
			return () => script.remove();
		}
	}, [
		attrs,
		children,
		dataScript
	]);
	if (router.isServer) {
		if (attrs?.src) {
			if (!preventScriptHoist) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				...attrs,
				suppressHydrationWarning: true
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				...attrs,
				onLoad: noopScriptHandler,
				suppressHydrationWarning: true
			});
		}
		if (typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			dangerouslySetInnerHTML: innerHTML,
			suppressHydrationWarning: true
		});
		return null;
	}
	if (dataScript && typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		...attrs,
		suppressHydrationWarning: true,
		dangerouslySetInnerHTML: innerHTML
	});
	if (!hydrated) {
		if (attrs?.src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			suppressHydrationWarning: true
		});
		if (typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			dangerouslySetInnerHTML: innerHTML,
			suppressHydrationWarning: true
		});
	}
	return null;
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/headContentUtils.js
function buildTagsFromMatches(router, nonce, matches, assetCrossOrigin) {
	matches = _getAssetMatches(matches);
	const routeMeta = matches.map((match) => match.meta).filter((meta) => meta !== void 0);
	const resultMeta = [];
	const metaByAttribute = {};
	let title;
	for (let i = routeMeta.length - 1; i >= 0; i--) {
		const metas = routeMeta[i];
		for (let j = metas.length - 1; j >= 0; j--) {
			const m = metas[j];
			if (!m) continue;
			if (m.title) {
				if (!title) title = {
					tag: "title",
					children: m.title
				};
			} else if ("script:ld+json" in m) try {
				const json = JSON.stringify(m["script:ld+json"]);
				resultMeta.push({
					tag: "script",
					attrs: { type: "application/ld+json" },
					children: escapeHtml(json)
				});
			} catch {}
			else {
				const attribute = m.name ?? m.property;
				if (attribute) if (metaByAttribute[attribute]) continue;
				else metaByAttribute[attribute] = true;
				resultMeta.push({
					tag: "meta",
					attrs: {
						...m,
						nonce
					}
				});
			}
		}
	}
	if (title) resultMeta.push(title);
	if (nonce) resultMeta.push({
		tag: "meta",
		attrs: {
			property: "csp-nonce",
			content: nonce
		}
	});
	resultMeta.reverse();
	const constructedLinks = matches.flatMap((match) => match.links ?? []).filter((link) => link !== void 0).map((link) => ({
		tag: "link",
		attrs: {
			...link,
			nonce
		}
	}));
	const manifest = router.ssr?.manifest;
	const manifestCssTags = [];
	if (manifest) {
		matches.forEach((match) => {
			(manifest.routes[match.routeId]?.css)?.forEach((link) => {
				const resolvedLink = resolveManifestCssLink(link);
				manifestCssTags.push({
					tag: "link",
					attrs: {
						rel: "stylesheet",
						...resolvedLink,
						crossOrigin: getAssetCrossOrigin(assetCrossOrigin, "stylesheet") ?? resolvedLink.crossOrigin,
						suppressHydrationWarning: true,
						nonce
					}
				});
			});
		});
		if (manifest.inlineStyle) manifestCssTags.push({
			tag: "style",
			attrs: {
				...manifest.inlineStyle.attrs,
				nonce
			},
			children: manifest.inlineStyle.children,
			inlineCss: true
		});
	}
	const preloadLinks = [];
	if (manifest) matches.forEach((match) => {
		manifest.routes[match.routeId]?.preloads?.forEach((preload) => {
			preloadLinks.push({
				tag: "link",
				attrs: {
					...getScriptPreloadAttrs(manifest, preload, assetCrossOrigin),
					nonce
				}
			});
		});
	});
	const styles = matches.flatMap((match) => match.styles ?? []).filter((style) => style !== void 0).map(({ children, ...attrs }) => ({
		tag: "style",
		attrs: {
			...attrs,
			nonce
		},
		children
	}));
	const headScripts = matches.flatMap((match) => match.headScripts ?? []).filter((script) => script !== void 0).map(({ children, ...script }) => ({
		tag: "script",
		attrs: {
			...script,
			nonce
		},
		children
	}));
	const tags = [];
	appendUniqueUserTags(tags, resultMeta);
	tags.push(...preloadLinks);
	appendUniqueUserTags(tags, constructedLinks);
	tags.push(...manifestCssTags);
	appendUniqueUserTags(tags, styles);
	appendUniqueUserTags(tags, headScripts);
	return tags;
}
/**
* Build the head/link/meta/script tags from the renderable presented prefix.
* Used internally by `HeadContent`.
*/
var useTags = (assetCrossOrigin) => {
	const router = useRouter();
	const nonce = router.options.ssr?.nonce;
	if (router.isServer) return buildTagsFromMatches(router, nonce, router.stores.matches.get(), assetCrossOrigin);
	const selectTags = import_react.useCallback((matches) => buildTagsFromMatches(router, nonce, matches, assetCrossOrigin), [
		assetCrossOrigin,
		nonce,
		router
	]);
	return useSelector(router.stores.matches, selectTags, { compare: deepEqual });
};
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/Scripts.js
var routeScriptAttrs = { suppressHydrationWarning: true };
/**
* Render body script tags collected from route matches and SSR manifests.
* During streaming SSR, `<Scripts>` marks where late hydration scripts may
* begin to be inserted.
*/
var Scripts = () => {
	const router = useRouter();
	const nonce = router.options.ssr?.nonce;
	const getParts = (matches) => {
		const parts = getSsrBodyScriptParts(matches, router.ssr?.manifest, nonce, routeScriptAttrs);
		for (const script of parts[1]) if (typeof script.attrs?.src === "string") {
			const scriptWithHoist = script;
			scriptWithHoist.preventScriptHoist = true;
		}
		return parts;
	};
	const getScripts = (matches) => {
		return composeSsrBodyScripts(getParts(matches));
	};
	if (router.isServer) return renderScripts(composeSsrBodyScripts(getParts(router.stores.matches.get()), router.serverSsr?.takeInitialHydrationScriptTags()));
	return renderScripts(useSelector(router.stores.matches, getScripts, { compare: deepEqual }));
};
function renderScripts(scripts) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: scripts.map((asset, i) => /* @__PURE__ */ (0, import_react.createElement)(Asset, {
		...asset,
		key: `tsr-scripts-${asset.tag}-${i}`
	})) });
}
//#endregion
//#region node_modules/@tanstack/react-router/dist/esm/HeadContent.dev.js
/**
* Render route-managed head tags (title, meta, links, styles, head scripts).
* Place inside the document head of your app shell.
*
* Development version: filters out dev styles link after hydration and
* includes a fallback cleanup effect for hydration mismatch cases.
*
* @link https://tanstack.com/router/latest/docs/framework/react/guide/document-head-management
*/
function HeadContent(props) {
	const tags = useTags(props.assetCrossOrigin);
	const nonce = useRouter().options.ssr?.nonce;
	const hydrated = useHydrated();
	import_react.useEffect(() => {
		if (hydrated) document.querySelectorAll(`link[${DEV_STYLES_ATTR}]`).forEach((el) => el.remove());
	}, [hydrated]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: (hydrated ? tags.filter((tag) => tag.tag !== "link" || tag.attrs?.["data-tanstack-router-dev-styles"] !== true) : tags).map((tag) => /* @__PURE__ */ (0, import_react.createElement)(Asset, {
		...tag,
		key: `tsr-meta-${JSON.stringify(tag)}`,
		nonce
	})) });
}
//#endregion
export { Asset, Await, Block, CatchBoundary, CatchNotFound, ClientOnly, DEFAULT_PROTOCOL_ALLOWLIST, DefaultGlobalNotFound, ErrorComponent, FileRoute, FileRouteLoader, HeadContent, LazyRoute, Link, Match, MatchRoute, Matches, Navigate, NotFoundRoute, Outlet, RootRoute, Route, RouteApi, Router, RouterContextProvider, RouterProvider, ScriptOnce, Scripts, ScrollRestoration, SearchParamError, cleanPath, composeRewrites, createBrowserHistory, createControlledPromise, createFileRoute, createHashHistory, createHistory, createLazyFileRoute, createLazyRoute, createLink, createMemoryHistory, createRootRoute, createRootRouteWithContext, createRoute, createRouteMask, createRouter, createRouterConfig, createSerializationAdapter, deepEqual, defaultParseSearch, defaultStringifySearch, defer, functionalUpdate, getRouteApi, interpolatePath, isMatch, isNotFound, isRedirect, joinPaths, lazyFn, lazyRouteComponent, linkOptions, notFound, parseSearchWith, reactUse, redirect, replaceEqualDeep, resolvePath, retainSearchParams, rootRouteId, rootRouteWithContext, stringifySearchWith, stripSearchParams, trimPath, trimPathLeft, trimPathRight, useAwaited, useBlocker, useCanGoBack, useChildMatches, useElementScrollRestoration, useHydrated, useLayoutEffect, useLinkProps, useLoaderData, useLoaderDeps, useLocation, useMatch, useMatchRoute, useMatches, useNavigate, useParams, useParentMatches, useRouteContext, useRouter, useRouterState, useSearch, useTags };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXJvdXRlci5qcyIsIm5hbWVzIjpbIm5vcm1hbGl6ZSIsIlNVQ0NFU1MiLCJFUlJPUiIsIk5PVF9GT1VORCIsIlJFRElSRUNURUQiLCJ3YWl0Rm9yIiwiZ2V0Um91dGUiLCJub3JtYWxpemUiLCJub3JtYWxpemVFcnJvciIsIm1hdGVyaWFsaXplUmVkaXJlY3QiLCJjb250ZXh0dWFsaXplIiwiZ2V0TG9hZGVyQ29udGV4dCIsImNyZWF0ZUxvYWRlclRhc2siLCJnZXROb3RGb3VuZEJvdW5kYXJ5IiwicHJvamVjdExhbmUiLCJcInVzZVwiIiwidXNlQ2FsbGJhY2siLCJ1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvciIsIlNjcm9sbFJlc3RvcmF0aW9uIiwianN4IiwiU2Nyb2xsUmVzdG9yYXRpb24iLCJGcmFnbWVudCIsIkZyYWdtZW50IiwiRnJhZ21lbnQiLCJGcmFnbWVudCJdLCJzb3VyY2VzIjpbIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9ub3QtZm91bmQuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcm9vdC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9yZWRpcmVjdC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS91dGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9wYXRoLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3NpZXZlLWNhY2hlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL25ldy1wcm9jZXNzLXJvdXRlLXRyZWUuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc2Nyb2xsLXJlc3RvcmF0aW9uLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Fzcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zZWFyY2hQYXJhbXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcmV3cml0ZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zdG9yZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svaGlzdG9yeS9kaXN0L2VzbS9pbmRleC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9yb3V0ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vbG9hZC1jbGllbnQuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vYXdhaXQtc2lnbmFsLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL2xvYWQtc2VydmVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91dGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9kZWZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9saW5rLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL21hbmlmZXN0LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL01hdGNoZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc3NyL2JvZHlTY3JpcHRzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3JvdXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL2NvbmZpZy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zZWFyY2hNaWRkbGV3YXJlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Nzci9zZXJpYWxpemVyL3RyYW5zZm9ybWVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9hd2FpdGVkLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9ub25Sb3V0ZUNvbXBvbmVudENvbnRleHQuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL0NhdGNoQm91bmRhcnkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL0NsaWVudE9ubHkuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3JvdXRlckNvbnRleHQuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZVJvdXRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vbWF0Y2hDb250ZXh0LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3N0b3JlL2Rpc3QvYWxpZW4uanMiLCIuLi8uLi9AdGFuc3RhY2svc3RvcmUvZGlzdC9hdG9tLmpzIiwiLi4vLi4vdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXNoaW0uZGV2ZWxvcG1lbnQuanMiLCIuLi8uLi91c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltL2luZGV4LmpzIiwiLi4vLi4vdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXNoaW0vd2l0aC1zZWxlY3Rvci5kZXZlbG9wbWVudC5qcyIsIi4uLy4uL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlL3NoaW0vd2l0aC1zZWxlY3Rvci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1zdG9yZS9kaXN0L3VzZVNlbGVjdG9yLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VNYXRjaC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlTG9hZGVyRGF0YS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlTG9hZGVyRGVwcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlUGFyYW1zLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VTZWFyY2guanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZU5hdmlnYXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VSb3V0ZUNvbnRleHQuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL2xpbmsuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3JvdXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9maWxlUm91dGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL2xhenlSb3V0ZUNvbXBvbmVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vbm90LWZvdW5kLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9TY3JpcHRPbmNlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9yZW5kZXJSb3V0ZU5vdEZvdW5kLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Njcm9sbC1yZXN0b3JhdGlvbi1zY3JpcHQvY2xpZW50LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9zY3JvbGwtcmVzdG9yYXRpb24uanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL01hdGNoLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9UcmFuc2l0aW9uZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL01hdGNoZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3JvdXRlclN0b3Jlcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vcm91dGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9Sb3V0ZXJQcm92aWRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vU2Nyb2xsUmVzdG9yYXRpb24uanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZUJsb2NrZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZVJvdXRlclN0YXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VMb2NhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlQ2FuR29CYWNrLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9Bc3NldC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vaGVhZENvbnRlbnRVdGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vU2NyaXB0cy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vSGVhZENvbnRlbnQuZGV2LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vI3JlZ2lvbiBzcmMvbm90LWZvdW5kLnRzXG4vKipcbiogQ3JlYXRlIGEgbm90LWZvdW5kIGVycm9yIG9iamVjdCByZWNvZ25pemVkIGJ5IFRhblN0YWNrIFJvdXRlci5cbipcbiogVGhyb3cgdGhpcyBmcm9tIGxvYWRlcnMvYWN0aW9ucyB0byB0cmlnZ2VyIHRoZSBuZWFyZXN0IGBub3RGb3VuZENvbXBvbmVudGAuXG4qIFVzZSBgcm91dGVJZGAgdG8gdGFyZ2V0IGEgc3BlY2lmaWMgcm91dGUncyBub3QtZm91bmQgYm91bmRhcnkuIElmIGB0aHJvd2BcbiogaXMgdHJ1ZSwgdGhlIGVycm9yIGlzIHRocm93biBpbnN0ZWFkIG9mIHJldHVybmVkLlxuKlxuKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25hbCBzZXR0aW5ncyBpbmNsdWRpbmcgYHJvdXRlSWRgLCBgaGVhZGVyc2AsIGFuZCBgdGhyb3dgLlxuKiBAcmV0dXJucyBBIG5vdC1mb3VuZCBlcnJvciBvYmplY3QgdGhhdCBjYW4gYmUgdGhyb3duIG9yIHJldHVybmVkLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3Mvcm91dGVyL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL25vdEZvdW5kRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBub3RGb3VuZChvcHRpb25zID0ge30pIHtcblx0b3B0aW9ucy5pc05vdEZvdW5kID0gdHJ1ZTtcblx0aWYgKG9wdGlvbnMudGhyb3cpIHRocm93IG9wdGlvbnM7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLyoqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgVGFuU3RhY2sgUm91dGVyIG5vdC1mb3VuZCBlcnJvci4gKi9cbmZ1bmN0aW9uIGlzTm90Rm91bmQob2JqKSB7XG5cdHJldHVybiBvYmo/LmlzTm90Rm91bmQgPT09IHRydWU7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzTm90Rm91bmQsIG5vdEZvdW5kIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vdC1mb3VuZC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3Jvb3QudHNcbi8qKiBTdGFibGUgaWRlbnRpZmllciB1c2VkIGZvciB0aGUgcm9vdCByb3V0ZSBpbiBhIHJvdXRlIHRyZWUuICovXG5jb25zdCByb290Um91dGVJZCA9IFwiX19yb290X19cIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcm9vdFJvdXRlSWQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm9vdC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3JlZGlyZWN0LnRzXG4vKipcbiogQ3JlYXRlIGEgcmVkaXJlY3QgUmVzcG9uc2UgdW5kZXJzdG9vZCBieSBUYW5TdGFjayBSb3V0ZXIuXG4qXG4qIFVzZSBmcm9tIHJvdXRlIGBsb2FkZXJgL2BiZWZvcmVMb2FkYCBvciBzZXJ2ZXIgZnVuY3Rpb25zIHRvIHRyaWdnZXIgYVxuKiBuYXZpZ2F0aW9uLiBJZiBgdGhyb3c6IHRydWVgIGlzIHNldCwgdGhlIHJlZGlyZWN0IGlzIHRocm93biBpbnN0ZWFkIG9mXG4qIHJldHVybmVkLiBFeHRlcm5hbCBgaHJlZmAgdmFsdWVzIGFyZSBjbGFzc2lmaWVkIGFzIGZ1bGwtZG9jdW1lbnRcbiogbmF2aWdhdGlvbnMgd2hlbiB0aGUgcm91dGVyIHJlc29sdmVzIHRoZSByZWRpcmVjdC5cbipcbiogQHBhcmFtIG9wdHMgT3B0aW9ucyBmb3IgdGhlIHJlZGlyZWN0LiBDb21tb24gZmllbGRzOlxuKiAtIGBocmVmYDogYWJzb2x1dGUgVVJMIGZvciBleHRlcm5hbCByZWRpcmVjdHMuXG4qIC0gYHN0YXR1c0NvZGVgOiBIVFRQIHN0YXR1cyBjb2RlIHRvIHVzZSAoZGVmYXVsdHMgdG8gMzA3KS5cbiogLSBgaGVhZGVyc2A6IGFkZGl0aW9uYWwgaGVhZGVycyB0byBpbmNsdWRlIG9uIHRoZSBSZXNwb25zZS5cbiogLSBTdGFuZGFyZCBuYXZpZ2F0aW9uIG9wdGlvbnMgbGlrZSBgdG9gLCBgcGFyYW1zYCwgYHNlYXJjaGAsIGByZXBsYWNlYCxcbiogICBhbmQgYHJlbG9hZERvY3VtZW50YCBmb3IgaW50ZXJuYWwgcmVkaXJlY3RzLlxuKiBAcmV0dXJucyBBIFJlc3BvbnNlIGF1Z21lbnRlZCB3aXRoIHJvdXRlciBuYXZpZ2F0aW9uIG9wdGlvbnMuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9yZWRpcmVjdEZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gcmVkaXJlY3Qob3B0cykge1xuXHRvcHRzLnN0YXR1c0NvZGUgPSBvcHRzLnN0YXR1c0NvZGUgfHwgb3B0cy5jb2RlIHx8IDMwNztcblx0Y29uc3QgaGVhZGVycyA9IG5ldyBIZWFkZXJzKG9wdHMuaGVhZGVycyk7XG5cdGlmIChvcHRzLmhyZWYgJiYgaGVhZGVycy5nZXQoXCJMb2NhdGlvblwiKSA9PT0gbnVsbCkgaGVhZGVycy5zZXQoXCJMb2NhdGlvblwiLCBvcHRzLmhyZWYpO1xuXHRjb25zdCByZXNwb25zZSA9IG5ldyBSZXNwb25zZShudWxsLCB7XG5cdFx0c3RhdHVzOiBvcHRzLnN0YXR1c0NvZGUsXG5cdFx0aGVhZGVyc1xuXHR9KTtcblx0cmVzcG9uc2Uub3B0aW9ucyA9IG9wdHM7XG5cdGlmIChvcHRzLnRocm93KSB0aHJvdyByZXNwb25zZTtcblx0cmV0dXJuIHJlc3BvbnNlO1xufVxuLyoqIENoZWNrIHdoZXRoZXIgYSB2YWx1ZSBpcyBhIFRhblN0YWNrIFJvdXRlciByZWRpcmVjdCBSZXNwb25zZS4gKi9cbmZ1bmN0aW9uIGlzUmVkaXJlY3Qob2JqKSB7XG5cdHJldHVybiBvYmogaW5zdGFuY2VvZiBSZXNwb25zZSAmJiAhIW9iai5vcHRpb25zO1xufVxuLyoqIFRydWUgaWYgdmFsdWUgaXMgYSByZWRpcmVjdCB3aXRoIGEgcmVzb2x2ZWQgYGhyZWZgIGxvY2F0aW9uLiAqL1xuZnVuY3Rpb24gaXNSZXNvbHZlZFJlZGlyZWN0KG9iaikge1xuXHRyZXR1cm4gaXNSZWRpcmVjdChvYmopICYmICEhb2JqLm9wdGlvbnMuaHJlZjtcbn1cbi8qKiBQYXJzZSBhIHNlcmlhbGl6ZWQgcmVkaXJlY3Qgb2JqZWN0IGJhY2sgaW50byBhIHJlZGlyZWN0IFJlc3BvbnNlLiAqL1xuZnVuY3Rpb24gcGFyc2VSZWRpcmVjdChvYmopIHtcblx0aWYgKG9iaiAhPT0gbnVsbCAmJiB0eXBlb2Ygb2JqID09PSBcIm9iamVjdFwiICYmIG9iai5pc1NlcmlhbGl6ZWRSZWRpcmVjdCkgcmV0dXJuIHJlZGlyZWN0KG9iaik7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzUmVkaXJlY3QsIGlzUmVzb2x2ZWRSZWRpcmVjdCwgcGFyc2VSZWRpcmVjdCwgcmVkaXJlY3QgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVkaXJlY3QuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzLnRzXG4vKipcbiogUmV0dXJuIHRoZSBsYXN0IGVsZW1lbnQgb2YgYW4gYXJyYXkuXG4qIEludGVuZGVkIGZvciBub24tZW1wdHkgYXJyYXlzIHVzZWQgd2l0aGluIHJvdXRlciBpbnRlcm5hbHMuXG4qL1xuZnVuY3Rpb24gbGFzdChhcnIpIHtcblx0cmV0dXJuIGFyclthcnIubGVuZ3RoIC0gMV07XG59XG4vKipcbiogQXBwbHkgYSB2YWx1ZS1vci11cGRhdGVyIHRvIGEgcHJldmlvdXMgdmFsdWUuXG4qIEFjY2VwdHMgZWl0aGVyIGEgbGl0ZXJhbCB2YWx1ZSBvciBhIGZ1bmN0aW9uIG9mIHRoZSBwcmV2aW91cyB2YWx1ZS5cbiovXG5mdW5jdGlvbiBmdW5jdGlvbmFsVXBkYXRlKHVwZGF0ZXIsIHByZXZpb3VzKSB7XG5cdGlmICh0eXBlb2YgdXBkYXRlciA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gdXBkYXRlcihwcmV2aW91cyk7XG5cdHJldHVybiB1cGRhdGVyO1xufVxuY29uc3QgaGFzT3duID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbmZ1bmN0aW9uIGhhc0tleXMob2JqKSB7XG5cdGZvciAoY29uc3Qga2V5IGluIG9iaikgaWYgKGhhc093bi5jYWxsKG9iaiwga2V5KSkgcmV0dXJuIHRydWU7XG5cdHJldHVybiBmYWxzZTtcbn1cbmNvbnN0IGNyZWF0ZU51bGwgPSAoKSA9PiBPYmplY3QuY3JlYXRlKG51bGwpO1xuY29uc3QgbnVsbFJlcGxhY2VFcXVhbERlZXAgPSAocHJldiwgbmV4dCkgPT4gcmVwbGFjZUVxdWFsRGVlcChwcmV2LCBuZXh0LCB0cnVlKTtcbmZ1bmN0aW9uIHJlcGxhY2VFcXVhbERlZXAocHJldiwgbmV4dCwgX251bGxQcm90bywgX2RlcHRoID0gMCkge1xuXHRpZiAoaXNTZXJ2ZXIpIHJldHVybiBuZXh0O1xuXHRpZiAocHJldiA9PT0gbmV4dCkgcmV0dXJuIHByZXY7XG5cdGlmIChfZGVwdGgrKyA+IDUwMCkgcmV0dXJuIG5leHQ7XG5cdGNvbnN0IGFycmF5ID0gQXJyYXkuaXNBcnJheShwcmV2KSAmJiBBcnJheS5pc0FycmF5KG5leHQpO1xuXHRpZiAoIWFycmF5ICYmICEoaXNQbGFpbk9iamVjdChwcmV2KSAmJiBpc1BsYWluT2JqZWN0KG5leHQpKSkgcmV0dXJuIG5leHQ7XG5cdGNvbnN0IHByZXZLZXlzID0gT2JqZWN0LmtleXMocHJldik7XG5cdGNvbnN0IHByZXZpb3VzQ291bnQgPSBwcmV2S2V5cy5sZW5ndGg7XG5cdGNvbnN0IG5leHRLZXlzID0gT2JqZWN0LmtleXMobmV4dCk7XG5cdGNvbnN0IGxlbmd0aCA9IG5leHRLZXlzLmxlbmd0aDtcblx0aWYgKGFycmF5ID8gcHJldmlvdXNDb3VudCAhPT0gcHJldi5sZW5ndGggfHwgbGVuZ3RoICE9PSBuZXh0Lmxlbmd0aCB8fCBwcmV2aW91c0NvdW50ICYmIGxhc3QocHJldktleXMpICE9PSBgJHtwcmV2aW91c0NvdW50IC0gMX1gIHx8IGxlbmd0aCAmJiBsYXN0KG5leHRLZXlzKSAhPT0gYCR7bGVuZ3RoIC0gMX1gIDogcHJldmlvdXNDb3VudCAhPT0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMocHJldikubGVuZ3RoIHx8IGxlbmd0aCAhPT0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMobmV4dCkubGVuZ3RoIHx8IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMobmV4dCkubGVuZ3RoKSByZXR1cm4gbmV4dDtcblx0bGV0IGkgPSAwO1xuXHRsZXQgY2hpbGQ7XG5cdGxldCBwcmV2aW91cztcblx0bGV0IGtleTtcblx0aWYgKGFycmF5KSB7XG5cdFx0Zm9yICg7IGkgPCBsZW5ndGg7IGkrKykge1xuXHRcdFx0a2V5ID0gaTtcblx0XHRcdHByZXZpb3VzID0gcHJldltrZXldO1xuXHRcdFx0Y2hpbGQgPSBuZXh0W2tleV07XG5cdFx0XHRjaGlsZCA9IHByZXZpb3VzID09PSBjaGlsZCA/IHByZXZpb3VzIDogdHlwZW9mIHByZXZpb3VzID09PSBcIm9iamVjdFwiID8gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91cywgY2hpbGQsIF9udWxsUHJvdG8sIF9kZXB0aCkgOiBjaGlsZDtcblx0XHRcdGlmIChjaGlsZCAhPT0gcHJldmlvdXMpIGJyZWFrO1xuXHRcdH1cblx0XHRpZiAoaSA9PT0gbGVuZ3RoICYmIHByZXZpb3VzQ291bnQgPT09IGxlbmd0aCkgcmV0dXJuIHByZXY7XG5cdH0gZWxzZSB7XG5cdFx0bGV0IGVxdWFsID0gcHJldmlvdXNDb3VudCA9PT0gbGVuZ3RoO1xuXHRcdGxldCB1bmNoYW5nZWQgPSB0cnVlO1xuXHRcdGZvciAoOyBpIDwgbGVuZ3RoOyBpKyspIHtcblx0XHRcdGtleSA9IG5leHRLZXlzW2ldO1xuXHRcdFx0cHJldmlvdXMgPSBwcmV2W2tleV07XG5cdFx0XHRjb25zdCBpbmNvbWluZyA9IG5leHRba2V5XTtcblx0XHRcdGNoaWxkID0gcHJldmlvdXMgPT09IGluY29taW5nID8gcHJldmlvdXMgOiB0eXBlb2YgcHJldmlvdXMgPT09IFwib2JqZWN0XCIgPyByZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzLCBpbmNvbWluZywgX251bGxQcm90bywgX2RlcHRoKSA6IGluY29taW5nO1xuXHRcdFx0ZXF1YWwgJiY9IGNoaWxkID09PSBwcmV2aW91cyAmJiAocHJldktleXNbaV0gPT09IGtleSB8fCBoYXNPd24uY2FsbChwcmV2LCBrZXkpKTtcblx0XHRcdHVuY2hhbmdlZCAmJj0gT2JqZWN0LmlzKGNoaWxkLCBpbmNvbWluZyk7XG5cdFx0XHRwcmV2S2V5c1tpXSA9IGNoaWxkO1xuXHRcdH1cblx0XHRpZiAoZXF1YWwpIHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHByZXYpLmxlbmd0aCA/IG5leHQgOiBwcmV2O1xuXHRcdGlmICh1bmNoYW5nZWQpIHJldHVybiBuZXh0O1xuXHR9XG5cdGNvbnN0IGNvcHkgPSBhcnJheSA/IG5leHRLZXlzLmZpbGwoMCkgOiBfbnVsbFByb3RvID8gY3JlYXRlTnVsbCgpIDoge307XG5cdGZvciAobGV0IGogPSAwOyBqIDwgbGVuZ3RoOyBqKyspIHtcblx0XHRrZXkgPSBhcnJheSA/IGogOiBuZXh0S2V5c1tqXTtcblx0XHRpZiAoYXJyYXkpIHtcblx0XHRcdHByZXZpb3VzID0gcHJldltrZXldO1xuXHRcdFx0aWYgKGogPiBpKSB7XG5cdFx0XHRcdGNoaWxkID0gbmV4dFtrZXldO1xuXHRcdFx0XHRjaGlsZCA9IHByZXZpb3VzID09PSBjaGlsZCA/IHByZXZpb3VzIDogdHlwZW9mIHByZXZpb3VzID09PSBcIm9iamVjdFwiID8gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91cywgY2hpbGQsIF9udWxsUHJvdG8sIF9kZXB0aCkgOiBjaGlsZDtcblx0XHRcdH1cblx0XHRcdGNvcHlba2V5XSA9IGogPCBpID8gcHJldmlvdXMgOiBjaGlsZDtcblx0XHR9IGVsc2UgY29weVtrZXldID0gcHJldktleXNbal07XG5cdH1cblx0cmV0dXJuIGNvcHk7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KG8pIHtcblx0aWYgKCFvIHx8IHR5cGVvZiBvICE9PSBcIm9iamVjdFwiKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pPy5jb25zdHJ1Y3RvciA/PyBPYmplY3QpID09PSBPYmplY3Q7XG59XG4vKipcbiogUGVyZm9ybSBhIGRlZXAgZXF1YWxpdHkgY2hlY2sgb3B0aW1pemVkIGZvciByb3V0ZXIgc3RhdGUgY29tcGFyaXNvbnMuXG4qXG4qIC0gYHBhcnRpYWxgOiBgYmAgbWF5IG9taXQga2V5cyB0aGF0IGBhYCBoYXMgKGFycmF5cyBzdGF5IGxlbmd0aC1leGFjdCkuXG4qIC0gYGV4cGxpY2l0VW5kZWZpbmVkYDoga2V5cyBob2xkaW5nIGB1bmRlZmluZWRgIHRha2UgcGFydCBpbiB0aGUgY29tcGFyaXNvblxuKiAgIGluc3RlYWQgb2YgYmVpbmcgaWdub3JlZC5cbipcbiogSW50ZXJuYWw6IHRoZSBmbGFncyBhcmUgcG9zaXRpb25hbCBzbyBob3QgY2FsbGVycyBwYXNzIG5vIG9wdGlvbnMgb2JqZWN0LlxuKi9cbmZ1bmN0aW9uIGRlZXBFcXVhbChhLCBiLCBwYXJ0aWFsLCBleHBsaWNpdFVuZGVmaW5lZCkge1xuXHRpZiAoYSA9PT0gYikgcmV0dXJuIHRydWU7XG5cdGlmIChBcnJheS5pc0FycmF5KGEpICYmIEFycmF5LmlzQXJyYXkoYikpIHtcblx0XHRpZiAoYS5sZW5ndGggIT09IGIubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG5cdFx0Zm9yIChsZXQgaSA9IDAsIGwgPSBhLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuXHRcdFx0Y29uc3QgYXYgPSBhW2ldO1xuXHRcdFx0Y29uc3QgYnYgPSBiW2ldO1xuXHRcdFx0aWYgKGF2ICE9PSBidiAmJiAhZGVlcEVxdWFsKGF2LCBidiwgcGFydGlhbCwgZXhwbGljaXRVbmRlZmluZWQpKSByZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdGlmIChpc1BsYWluT2JqZWN0KGEpICYmIGlzUGxhaW5PYmplY3QoYikpIHtcblx0XHRpZiAocGFydGlhbCkge1xuXHRcdFx0Zm9yIChjb25zdCBrIGluIGIpIGlmIChleHBsaWNpdFVuZGVmaW5lZCB8fCBiW2tdICE9PSB2b2lkIDApIHtcblx0XHRcdFx0aWYgKCFkZWVwRXF1YWwoYVtrXSwgYltrXSwgcGFydGlhbCwgZXhwbGljaXRVbmRlZmluZWQpKSByZXR1cm4gZmFsc2U7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0bGV0IGFDb3VudCA9IDA7XG5cdFx0aWYgKGV4cGxpY2l0VW5kZWZpbmVkKSBhQ291bnQgPSBPYmplY3Qua2V5cyhhKS5sZW5ndGg7XG5cdFx0ZWxzZSBmb3IgKGNvbnN0IGsgaW4gYSkgaWYgKGFba10gIT09IHZvaWQgMCkgYUNvdW50Kys7XG5cdFx0Zm9yIChjb25zdCBrIGluIGIpIGlmIChleHBsaWNpdFVuZGVmaW5lZCB8fCBiW2tdICE9PSB2b2lkIDApIHtcblx0XHRcdGlmIChhQ291bnQtLSA9PT0gMCB8fCAhZGVlcEVxdWFsKGFba10sIGJba10sIHBhcnRpYWwsIGV4cGxpY2l0VW5kZWZpbmVkKSkgcmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHRyZXR1cm4gYUNvdW50ID09PSAwO1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn1cbi8qKlxuKiBDcmVhdGUgYSBwcm9taXNlIHdpdGggZXhwb3NlZCByZXNvbHZlL3JlamVjdCBhbmQgc3RhdHVzIGZpZWxkcy5cbiogVXNlZnVsIGZvciBjb29yZGluYXRpbmcgYXN5bmMgcm91dGVyIGxpZmVjeWNsZSBvcGVyYXRpb25zLlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUNvbnRyb2xsZWRQcm9taXNlKG9uUmVzb2x2ZSkge1xuXHRsZXQgcmVzb2x2ZUxvYWRQcm9taXNlO1xuXHRsZXQgcmVqZWN0TG9hZFByb21pc2U7XG5cdGNvbnN0IGNvbnRyb2xsZWRQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdHJlc29sdmVMb2FkUHJvbWlzZSA9IHJlc29sdmU7XG5cdFx0cmVqZWN0TG9hZFByb21pc2UgPSByZWplY3Q7XG5cdH0pO1xuXHRjb250cm9sbGVkUHJvbWlzZS5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0Y29udHJvbGxlZFByb21pc2UucmVzb2x2ZSA9ICh2YWx1ZSkgPT4ge1xuXHRcdGNvbnRyb2xsZWRQcm9taXNlLnN0YXR1cyA9IFwicmVzb2x2ZWRcIjtcblx0XHRjb250cm9sbGVkUHJvbWlzZS52YWx1ZSA9IHZhbHVlO1xuXHRcdHJlc29sdmVMb2FkUHJvbWlzZSh2YWx1ZSk7XG5cdFx0b25SZXNvbHZlPy4odmFsdWUpO1xuXHR9O1xuXHRjb250cm9sbGVkUHJvbWlzZS5yZWplY3QgPSAoZSkgPT4ge1xuXHRcdGNvbnRyb2xsZWRQcm9taXNlLnN0YXR1cyA9IFwicmVqZWN0ZWRcIjtcblx0XHRyZWplY3RMb2FkUHJvbWlzZShlKTtcblx0fTtcblx0cmV0dXJuIGNvbnRyb2xsZWRQcm9taXNlO1xufVxuLyoqXG4qIEhldXJpc3RpY2FsbHkgZGV0ZWN0IGR5bmFtaWMgaW1wb3J0IFwibW9kdWxlIG5vdCBmb3VuZFwiIGVycm9yc1xuKiBhY3Jvc3MgbWFqb3IgYnJvd3NlcnMgZm9yIGxhenkgcm91dGUgY29tcG9uZW50IGhhbmRsaW5nLlxuKi9cbmZ1bmN0aW9uIGlzTW9kdWxlTm90Rm91bmRFcnJvcihlcnJvcikge1xuXHRpZiAodHlwZW9mIGVycm9yPy5tZXNzYWdlICE9PSBcInN0cmluZ1wiKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBlcnJvci5tZXNzYWdlLnN0YXJ0c1dpdGgoXCJGYWlsZWQgdG8gZmV0Y2ggZHluYW1pY2FsbHkgaW1wb3J0ZWQgbW9kdWxlXCIpIHx8IGVycm9yLm1lc3NhZ2Uuc3RhcnRzV2l0aChcImVycm9yIGxvYWRpbmcgZHluYW1pY2FsbHkgaW1wb3J0ZWQgbW9kdWxlXCIpIHx8IGVycm9yLm1lc3NhZ2Uuc3RhcnRzV2l0aChcIkltcG9ydGluZyBhIG1vZHVsZSBzY3JpcHQgZmFpbGVkXCIpO1xufVxuZnVuY3Rpb24gaXNQcm9taXNlKHZhbHVlKSB7XG5cdHJldHVybiBCb29sZWFuKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUudGhlbiA9PT0gXCJmdW5jdGlvblwiKTtcbn1cbmZ1bmN0aW9uIGZpbmRMYXN0KGFycmF5LCBwcmVkaWNhdGUpIHtcblx0Zm9yIChsZXQgaSA9IGFycmF5Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0Y29uc3QgaXRlbSA9IGFycmF5W2ldO1xuXHRcdGlmIChwcmVkaWNhdGUoaXRlbSkpIHJldHVybiBpdGVtO1xuXHR9XG59XG4vKipcbiogUmUtZW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBhcmUgdW5zYWZlIGluIFVSTCBwYXRocy5cbiogSW5jbHVkZXMgQVNDSUkgY29udHJvbCBjaGFyYWN0ZXJzICgweDAwLTB4MUYsIDB4N0YpIGFuZCBhIHN1YnNldCBvZiB0aGVcbiogV0hBVFdHIFVSTCBcInBhdGggcGVyY2VudC1lbmNvZGUgc2V0XCIgKFwiLCA8LCA+LCBgLCB7LCB9KS5cbipcbiogU3BhY2UgKDB4MjApIGlzIGludGVudGlvbmFsbHkgZXhjbHVkZWQg4oCUIGRlY29kZVVSSSBkZWNvZGVzICUyMCB0byBzcGFjZVxuKiBhbmQgdGhlIHJvdXRlciBzdG9yZXMgZGVjb2RlZCBzcGFjZXMgaW4gbG9jYXRpb24ucGF0aG5hbWUuIFRoZSBleGlzdGluZ1xuKiBlbmNvZGVQYXRoTGlrZVVybCBhbHJlYWR5IGhhbmRsZXMgcmUtZW5jb2Rpbmcgc3BhY2VzIGZvciBvdXRnb2luZyBVUkxzLlxuKlxuKiBUaGVzZSBjaGFyYWN0ZXJzIGFyZSBkZWNvZGVkIGJ5IGRlY29kZVVSSSBidXQgbXVzdCByZW1haW4gcGVyY2VudC1lbmNvZGVkXG4qIGluIHBhdGhzIHRvIG1hdGNoIGhvdyB1cHN0cmVhbSBsYXllcnMgKENETnMsIGVkZ2UgbWlkZGxld2FyZSwgYnJvd3NlcnMpXG4qIGludGVycHJldCB0aGUgVVJMLCBwcmV2ZW50aW5nIGluZmluaXRlIHJlZGlyZWN0IGxvb3BzIGFuZCBwYXRoIG1pc21hdGNoZXMuXG4qL1xuY29uc3QgUEFUSF9VTlNBRkVfUkUgPSAvW1xceDAwLVxceDFmXFx4N2ZcIjw+YHt9XS9nO1xuZnVuY3Rpb24gc2FuaXRpemVQYXRoU2VnbWVudChzZWdtZW50KSB7XG5cdHJldHVybiBzZWdtZW50LnJlcGxhY2UoUEFUSF9VTlNBRkVfUkUsIChjaCkgPT4gXCIlXCIgKyBjaC5jaGFyQ29kZUF0KDApLnRvU3RyaW5nKDE2KS50b1VwcGVyQ2FzZSgpLnBhZFN0YXJ0KDIsIFwiMFwiKSk7XG59XG5mdW5jdGlvbiBkZWNvZGVTZWdtZW50KHNlZ21lbnQpIHtcblx0bGV0IGRlY29kZWQ7XG5cdHRyeSB7XG5cdFx0ZGVjb2RlZCA9IGRlY29kZVVSSShzZWdtZW50KTtcblx0fSBjYXRjaCB7XG5cdFx0ZGVjb2RlZCA9IHNlZ21lbnQucmVwbGFjZUFsbCgvJVswLTlBLUZdezJ9L2dpLCAobWF0Y2gpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJldHVybiBkZWNvZGVVUkkobWF0Y2gpO1xuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdHJldHVybiBtYXRjaDtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gc2FuaXRpemVQYXRoU2VnbWVudChkZWNvZGVkKTtcbn1cbi8qKlxuKiBEZWZhdWx0IGxpc3Qgb2YgVVJMIHByb3RvY29scyB0byBhbGxvdyBpbiBsaW5rcywgcmVkaXJlY3RzLCBhbmQgbmF2aWdhdGlvbi5cbiogQW55IGFic29sdXRlIFVSTCBwcm90b2NvbCBub3QgaW4gdGhpcyBsaXN0IGlzIHRyZWF0ZWQgYXMgZGFuZ2Vyb3VzIGJ5IGRlZmF1bHQuXG4qL1xuY29uc3QgREVGQVVMVF9QUk9UT0NPTF9BTExPV0xJU1QgPSBbXG5cdFwiaHR0cDpcIixcblx0XCJodHRwczpcIixcblx0XCJtYWlsdG86XCIsXG5cdFwidGVsOlwiXG5dO1xuLyoqXG4qIEV4dHJhY3QgdGhlIGV4cGxpY2l0IFVSTCBzY2hlbWUsIGluY2x1ZGluZyBpdHMgY29sb24sIHVzaW5nIFdIQVRXR1xuKiBub3JtYWxpemF0aW9uIHJ1bGVzLiBUaGlzIGRvZXMgbm90IHZhbGlkYXRlIHRoZSByZXN0IG9mIHRoZSBVUkwuXG4qXG4qIFJldHVybmluZyBgdW5kZWZpbmVkYCBtZWFucyBcIm5vIGV4cGxpY2l0IHNjaGVtZVwiLCBub3QgXCJzYWZlIFVSTFwiO1xuKiBwcm90b2NvbC1yZWxhdGl2ZSBVUkxzIHN1Y2ggYXMgXCIvL2V2aWwuZXhhbXBsZVwiIHJlcXVpcmUgYSBzZXBhcmF0ZSBjaGVjay5cbiovXG5mdW5jdGlvbiBnZXRVcmxTY2hlbWUodXJsKSB7XG5cdGlmICh1cmxbMF0gPT09IFwiL1wiKSByZXR1cm47XG5cdGlmICghdXJsLmluY2x1ZGVzKFwiOlwiKSkgcmV0dXJuO1xuXHRyZXR1cm4gL15bXFx4MDAtXFx4MjBdKihbYS16XVthLXpcXGQrLlxcdFxcblxcci1dKjopL2kuZXhlYyh1cmwpPy5bMV0/LnJlcGxhY2UoL1tcXHRcXG5cXHJdL2csIFwiXCIpLnRvTG93ZXJDYXNlKCk7XG59XG5jb25zdCBwcm90b2NvbFJlbGF0aXZlUHJlZml4UmVnZXggPSAvXltcXHgwMC1cXHgyMF0qW1xcXFwvXVtcXHRcXG5cXHJdKltcXFxcL10vO1xuLyoqXG4qIENoZWNrIGlmIGEgVVJMIHN0cmluZyB1c2VzIGEgcHJvdG9jb2wgdGhhdCBpcyBub3QgaW4gdGhlIGFsbG93bGlzdCBvciBpc1xuKiBwcm90b2NvbC1yZWxhdGl2ZSAoZS5nLiBcIi8vZXZpbC5leGFtcGxlXCIpLCB3aGljaCBjYW4gbmF2aWdhdGUgdG8gYW5vdGhlciBob3N0LlxuKiBSZXR1cm5zIHRydWUgZm9yIGJsb2NrZWQgcHJvdG9jb2xzIGxpa2UgamF2YXNjcmlwdDosIGJsb2I6LCBhbmQgZGF0YTosIGFzXG4qIHdlbGwgYXMgc2xhc2gvYmFja3NsYXNoIHZhcmlhbnRzIG9mIHByb3RvY29sLXJlbGF0aXZlIFVSTHMuXG4qXG4qIFNjaGVtZSBwYXJzaW5nIG5vcm1hbGl6ZXM6XG4qIC0gTWl4ZWQgY2FzZSAoSmF2YVNjcmlwdDog4oaSIGphdmFzY3JpcHQ6KVxuKiAtIFdoaXRlc3BhY2UvY29udHJvbCBjaGFyYWN0ZXJzIChqYXZhXFxuc2NyaXB0OiDihpIgamF2YXNjcmlwdDopXG4qIC0gTGVhZGluZyB3aGl0ZXNwYWNlXG4qXG4qIEZvciByZWxhdGl2ZSBVUkxzIHdpdGhvdXQgYSBwcm90b2NvbC1yZWxhdGl2ZSBwcmVmaXgsIHJldHVybnMgZmFsc2UuXG4qXG4qIEBwYXJhbSB1cmwgLSBUaGUgVVJMIHN0cmluZyB0byBjaGVja1xuKiBAcGFyYW0gYWxsb3dsaXN0IC0gU2V0IG9mIHByb3RvY29scyB0byBhbGxvd1xuKiBAcmV0dXJucyB0cnVlIGlmIHRoZSBVUkwgdXNlcyBhIHByb3RvY29sIHRoYXQgaXMgbm90IGFsbG93ZWQgb3IgY2FuIGVzY2FwZVxuKiB0aGUgY3VycmVudCBvcmlnaW4gdGhyb3VnaCBhIHByb3RvY29sLXJlbGF0aXZlIFVSTFxuKi9cbmZ1bmN0aW9uIGlzRGFuZ2Vyb3VzUHJvdG9jb2wodXJsLCBhbGxvd2xpc3QpIHtcblx0aWYgKCF1cmwpIHJldHVybiBmYWxzZTtcblx0aWYgKHByb3RvY29sUmVsYXRpdmVQcmVmaXhSZWdleC50ZXN0KHVybCkpIHJldHVybiB0cnVlO1xuXHRjb25zdCBzY2hlbWUgPSBnZXRVcmxTY2hlbWUodXJsKTtcblx0cmV0dXJuIHNjaGVtZSA/ICFhbGxvd2xpc3QuaGFzKHNjaGVtZSkgOiBmYWxzZTtcbn1cbmNvbnN0IEhUTUxfRVNDQVBFX0xPT0tVUCA9IHtcblx0XCImXCI6IFwiXFxcXHUwMDI2XCIsXG5cdFwiPlwiOiBcIlxcXFx1MDAzZVwiLFxuXHRcIjxcIjogXCJcXFxcdTAwM2NcIixcblx0XCJcXHUyMDI4XCI6IFwiXFxcXHUyMDI4XCIsXG5cdFwiXFx1MjAyOVwiOiBcIlxcXFx1MjAyOVwiXG59O1xuY29uc3QgSFRNTF9FU0NBUEVfUkVHRVggPSAvWyY+PFxcdTIwMjhcXHUyMDI5XS9nO1xuLyoqXG4qIEVzY2FwZSBIVE1MIHNwZWNpYWwgY2hhcmFjdGVycyBpbiBhIHN0cmluZyB0byBwcmV2ZW50IFhTUyBhdHRhY2tzXG4qIHdoZW4gZW1iZWRkaW5nIHN0cmluZ3MgaW4gc2NyaXB0IHRhZ3MgZHVyaW5nIFNTUi5cbipcbiogVGhpcyBpcyBlc3NlbnRpYWwgZm9yIHByZXZlbnRpbmcgWFNTIHZ1bG5lcmFiaWxpdGllcyB3aGVuIHVzZXItY29udHJvbGxlZFxuKiBjb250ZW50IGlzIGVtYmVkZGVkIGluIGlubGluZSBzY3JpcHRzLlxuKi9cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoc3RyKSB7XG5cdHJldHVybiBzdHIucmVwbGFjZShIVE1MX0VTQ0FQRV9SRUdFWCwgKG1hdGNoKSA9PiBIVE1MX0VTQ0FQRV9MT09LVVBbbWF0Y2hdKTtcbn1cbmZ1bmN0aW9uIGRlY29kZVBhdGgocGF0aCkge1xuXHRpZiAoIXBhdGgpIHJldHVybiBwYXRoO1xuXHRsZXQgcmVzdWx0ID0gcGF0aDtcblx0aWYgKC9bJVxcXFxcXHgwMC1cXHgxZlxceDdmXS8udGVzdChwYXRoKSkge1xuXHRcdGNvbnN0IHJlID0gLyUyNXwlNUMvZ2k7XG5cdFx0bGV0IGN1cnNvciA9IDA7XG5cdFx0bGV0IG1hdGNoO1xuXHRcdHJlc3VsdCA9IFwiXCI7XG5cdFx0d2hpbGUgKG51bGwgIT09IChtYXRjaCA9IHJlLmV4ZWMocGF0aCkpKSB7XG5cdFx0XHRyZXN1bHQgKz0gZGVjb2RlU2VnbWVudChwYXRoLnNsaWNlKGN1cnNvciwgbWF0Y2guaW5kZXgpKSArIG1hdGNoWzBdO1xuXHRcdFx0Y3Vyc29yID0gcmUubGFzdEluZGV4O1xuXHRcdH1cblx0XHRyZXN1bHQgKz0gZGVjb2RlU2VnbWVudChjdXJzb3IgPyBwYXRoLnNsaWNlKGN1cnNvcikgOiBwYXRoKTtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4qIEVuY29kZXMgYSBwYXRoIHRoZSBzYW1lIHdheSBgbmV3IFVSTCgpYCB3b3VsZCwgYnV0IHdpdGhvdXQgdGhlIG92ZXJoZWFkIG9mIGZ1bGwgVVJMIHBhcnNpbmcuXG4qXG4qIFRoaXMgZnVuY3Rpb24gZW5jb2RlczpcbiogLSBXaGl0ZXNwYWNlIGNoYXJhY3RlcnMgKHNwYWNlcyDihpIgJTIwLCB0YWJzIOKGkiAlMDksIGV0Yy4pXG4qIC0gTm9uLUFTQ0lJL1VuaWNvZGUgY2hhcmFjdGVycyAoZW1vamlzLCBhY2NlbnRlZCBjaGFyYWN0ZXJzLCBldGMuKVxuKlxuKiBJdCBwcmVzZXJ2ZXM6XG4qIC0gQWxyZWFkeSBwZXJjZW50LWVuY29kZWQgc2VxdWVuY2VzICh3b24ndCBkb3VibGUtZW5jb2RlICUyRiwgJTI1LCBldGMuKVxuKiAtIEFTQ0lJIHNwZWNpYWwgY2hhcmFjdGVycyB2YWxpZCBpbiBVUkwgcGF0aHMgKEAsICQsICYsICssIGV0Yy4pXG4qIC0gRm9yd2FyZCBzbGFzaGVzIGFzIHBhdGggc2VwYXJhdG9yc1xuKlxuKiBVc2VkIHRvIGdlbmVyYXRlIHByb3BlciBocmVmIHZhbHVlcyBmb3IgU1NSIHdpdGhvdXQgY29uc3RydWN0aW5nIFVSTCBvYmplY3RzLlxuKlxuKiBAZXhhbXBsZVxuKiBlbmNvZGVQYXRoTGlrZVVybCgnL3BhdGgvZmlsZSBuYW1lLnBkZicpIC8vICcvcGF0aC9maWxlJTIwbmFtZS5wZGYnXG4qIGVuY29kZVBhdGhMaWtlVXJsKCcvcGF0aC/ml6XmnKzoqp4nKSAvLyAnL3BhdGgvJUU2JTk3JUE1JUU2JTlDJUFDJUU4JUFBJTlFJ1xuKiBlbmNvZGVQYXRoTGlrZVVybCgnL3BhdGgvYWxyZWFkeSUyMGVuY29kZWQnKSAvLyAnL3BhdGgvYWxyZWFkeSUyMGVuY29kZWQnIChwcmVzZXJ2ZWQpXG4qL1xuZnVuY3Rpb24gZW5jb2RlUGF0aExpa2VVcmwocGF0aCkge1xuXHRpZiAoIS9bXFxzXFx1MDA4MC1cXHVGRkZGXS8udGVzdChwYXRoKSkgcmV0dXJuIHBhdGg7XG5cdHJldHVybiBwYXRoLnJlcGxhY2UoL1xcc3xbXlxcdTAwMDAtXFx1MDA3Rl0vZ3UsIGVuY29kZVVSSUNvbXBvbmVudCk7XG59XG4vKipcbiogQnVpbGRzIHRoZSBkZXYtbW9kZSBDU1Mgc3R5bGVzIFVSTCBmb3Igcm91dGUtc2NvcGVkIENTUyBjb2xsZWN0aW9uLlxuKiBVc2VkIGJ5IEhlYWRDb250ZW50IGNvbXBvbmVudHMgaW4gYWxsIGZyYW1ld29yayBpbXBsZW1lbnRhdGlvbnMgdG8gY29uc3RydWN0XG4qIHRoZSBVUkwgZm9yIHRoZSBgL0B0YW5zdGFjay1zdGFydC9zdHlsZXMuY3NzYCBlbmRwb2ludC5cbipcbiogQHBhcmFtIGJhc2VwYXRoIC0gVGhlIHJvdXRlcidzIGJhc2VwYXRoIChtYXkgb3IgbWF5IG5vdCBoYXZlIGxlYWRpbmcgc2xhc2gpXG4qIEBwYXJhbSByb3V0ZUlkcyAtIEFycmF5IG9mIG1hdGNoZWQgcm91dGUgSURzIHRvIGluY2x1ZGUgaW4gdGhlIENTUyBjb2xsZWN0aW9uXG4qIEByZXR1cm5zIFRoZSBmdWxsIFVSTCBwYXRoIGZvciB0aGUgZGV2IHN0eWxlcyBDU1MgZW5kcG9pbnRcbiovXG5mdW5jdGlvbiBidWlsZERldlN0eWxlc1VybChiYXNlcGF0aCwgcm91dGVJZHMpIHtcblx0Y29uc3QgdHJpbW1lZEJhc2VwYXRoID0gYmFzZXBhdGgucmVwbGFjZSgvXlxcLyt8XFwvKyQvZywgXCJcIik7XG5cdHJldHVybiBgJHt0cmltbWVkQmFzZXBhdGggPT09IFwiXCIgPyBcIlwiIDogYC8ke3RyaW1tZWRCYXNlcGF0aH1gfS9AdGFuc3RhY2stc3RhcnQvc3R5bGVzLmNzcz9yb3V0ZXM9JHtlbmNvZGVVUklDb21wb25lbnQocm91dGVJZHMuam9pbihcIixcIikpfWA7XG59XG5mdW5jdGlvbiBhcnJheXNFcXVhbChhLCBiKSB7XG5cdGlmIChhID09PSBiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKGEubGVuZ3RoICE9PSBiLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGEubGVuZ3RoOyBpKyspIGlmIChhW2ldICE9PSBiW2ldKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBERUZBVUxUX1BST1RPQ09MX0FMTE9XTElTVCwgYXJyYXlzRXF1YWwsIGJ1aWxkRGV2U3R5bGVzVXJsLCBjcmVhdGVDb250cm9sbGVkUHJvbWlzZSwgY3JlYXRlTnVsbCwgZGVjb2RlUGF0aCwgZGVlcEVxdWFsLCBlbmNvZGVQYXRoTGlrZVVybCwgZXNjYXBlSHRtbCwgZmluZExhc3QsIGZ1bmN0aW9uYWxVcGRhdGUsIGdldFVybFNjaGVtZSwgaGFzS2V5cywgaGFzT3duLCBpc0Rhbmdlcm91c1Byb3RvY29sLCBpc01vZHVsZU5vdEZvdW5kRXJyb3IsIGlzUHJvbWlzZSwgbGFzdCwgbnVsbFJlcGxhY2VFcXVhbERlZXAsIHByb3RvY29sUmVsYXRpdmVQcmVmaXhSZWdleCwgcmVwbGFjZUVxdWFsRGVlcCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5qcy5tYXAiLCJpbXBvcnQgeyBsYXN0IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcGF0aC50c1xuLyoqIEpvaW4gcGF0aCBzZWdtZW50cywgY2xlYW5pbmcgZHVwbGljYXRlIHNsYXNoZXMgYmV0d2VlbiBwYXJ0cy4gKi9cbmZ1bmN0aW9uIGpvaW5QYXRocyhwYXRocykge1xuXHRyZXR1cm4gY2xlYW5QYXRoKHBhdGhzLmZpbHRlcigodmFsKSA9PiB7XG5cdFx0cmV0dXJuIHZhbCAhPT0gdm9pZCAwO1xuXHR9KS5qb2luKFwiL1wiKSk7XG59XG4vKiogUmVtb3ZlIHJlcGVhdGVkIHNsYXNoZXMgZnJvbSBhIHBhdGggc3RyaW5nLiAqL1xuZnVuY3Rpb24gY2xlYW5QYXRoKHBhdGgpIHtcblx0cmV0dXJuIHBhdGgucmVwbGFjZSgvXFwvezIsfS9nLCBcIi9cIik7XG59XG4vKiogVHJpbSBsZWFkaW5nIHNsYXNoZXMgKGV4Y2VwdCBwcmVzZXJ2aW5nIHJvb3QgJy8nKS4gKi9cbmZ1bmN0aW9uIHRyaW1QYXRoTGVmdChwYXRoKSB7XG5cdHJldHVybiBwYXRoID09PSBcIi9cIiA/IHBhdGggOiBwYXRoLnJlcGxhY2UoL15cXC8rLywgXCJcIik7XG59XG4vKiogVHJpbSB0cmFpbGluZyBzbGFzaGVzIChleGNlcHQgcHJlc2VydmluZyByb290ICcvJykuICovXG5mdW5jdGlvbiB0cmltUGF0aFJpZ2h0KHBhdGgpIHtcblx0Y29uc3QgbGVuID0gcGF0aC5sZW5ndGg7XG5cdHJldHVybiBsZW4gPiAxICYmIHBhdGhbbGVuIC0gMV0gPT09IFwiL1wiID8gcGF0aC5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpIDogcGF0aDtcbn1cbi8qKiBUcmltIGJvdGggbGVhZGluZyBhbmQgdHJhaWxpbmcgc2xhc2hlcy4gKi9cbmZ1bmN0aW9uIHRyaW1QYXRoKHBhdGgpIHtcblx0cmV0dXJuIHRyaW1QYXRoUmlnaHQodHJpbVBhdGhMZWZ0KHBhdGgpKTtcbn1cbi8qKiBSZW1vdmUgYSB0cmFpbGluZyBzbGFzaCBmcm9tIHZhbHVlIHdoZW4gYXBwcm9wcmlhdGUgZm9yIGNvbXBhcmlzb25zLiAqL1xuZnVuY3Rpb24gcmVtb3ZlVHJhaWxpbmdTbGFzaCh2YWx1ZSwgYmFzZXBhdGgpIHtcblx0aWYgKHZhbHVlPy5lbmRzV2l0aChcIi9cIikgJiYgdmFsdWUgIT09IFwiL1wiICYmIHZhbHVlICE9PSBgJHtiYXNlcGF0aH0vYCkgcmV0dXJuIHZhbHVlLnNsaWNlKDAsIC0xKTtcblx0cmV0dXJuIHZhbHVlO1xufVxuLyoqXG4qIENvbXBhcmUgdHdvIHBhdGhuYW1lcyBmb3IgZXhhY3QgZXF1YWxpdHkgYWZ0ZXIgbm9ybWFsaXppbmcgdHJhaWxpbmcgc2xhc2hlc1xuKiByZWxhdGl2ZSB0byB0aGUgcHJvdmlkZWQgYGJhc2VwYXRoYC5cbiovXG5mdW5jdGlvbiBleGFjdFBhdGhUZXN0KHBhdGhOYW1lMSwgcGF0aE5hbWUyLCBiYXNlcGF0aCkge1xuXHRyZXR1cm4gcmVtb3ZlVHJhaWxpbmdTbGFzaChwYXRoTmFtZTEsIGJhc2VwYXRoKSA9PT0gcmVtb3ZlVHJhaWxpbmdTbGFzaChwYXRoTmFtZTIsIGJhc2VwYXRoKTtcbn1cbi8qKlxuKiBSZXNvbHZlIGEgZGVzdGluYXRpb24gcGF0aCBhZ2FpbnN0IGEgYmFzZSwgaG9ub3JpbmcgdHJhaWxpbmctc2xhc2ggcG9saWN5XG4qIGFuZCBzdXBwb3J0aW5nIHJlbGF0aXZlIHNlZ21lbnRzIChgLmAvYC4uYCkgYW5kIGFic29sdXRlIGB0b2AgdmFsdWVzLlxuKlxuKiBJbnRlcm5hbDogcGFyYW1ldGVycyBhcmUgcG9zaXRpb25hbCBzbyB0aGUgcm91dGVyJ3MgaG90IGNhbGxlcnMgcGFzcyBub1xuKiBvcHRpb25zIG9iamVjdC5cbiovXG5mdW5jdGlvbiByZXNvbHZlUGF0aChiYXNlLCB0bywgdHJhaWxpbmdTbGFzaCA9IFwibmV2ZXJcIiwgY2FjaGUpIHtcblx0aWYgKHRvLmluY2x1ZGVzKFwiLy9cIikpIHRvID0gY2xlYW5QYXRoKHRvKTtcblx0aWYgKHRvLnN0YXJ0c1dpdGgoXCIvXCIpKSB7XG5cdFx0aWYgKHRvLmxlbmd0aCA9PT0gMSB8fCB0cmFpbGluZ1NsYXNoID09PSBcInByZXNlcnZlXCIpIHJldHVybiB0bztcblx0XHRpZiAodHJhaWxpbmdTbGFzaCA9PT0gXCJhbHdheXNcIikgcmV0dXJuIHRvLmVuZHNXaXRoKFwiL1wiKSA/IHRvIDogYCR7dG99L2A7XG5cdFx0cmV0dXJuIHRvLmVuZHNXaXRoKFwiL1wiKSA/IHRvLnNsaWNlKDAsIC0xKSA6IHRvO1xuXHR9XG5cdGNvbnN0IGlzQmFzZSA9IHRvID09PSBcIi5cIjtcblx0bGV0IGtleTtcblx0aWYgKGNhY2hlKSB7XG5cdFx0a2V5ID0gaXNCYXNlID8gYmFzZSA6IGJhc2UgKyBcIlxcMFwiICsgdG87XG5cdFx0Y29uc3QgY2FjaGVkID0gY2FjaGUuZ2V0KGtleSk7XG5cdFx0aWYgKGNhY2hlZCkgcmV0dXJuIGNhY2hlZDtcblx0fVxuXHRsZXQgYmFzZVNlZ21lbnRzO1xuXHRpZiAoaXNCYXNlKSBiYXNlU2VnbWVudHMgPSBiYXNlLnNwbGl0KFwiL1wiKTtcblx0ZWxzZSB7XG5cdFx0aWYgKGJhc2UuaW5jbHVkZXMoXCIvL1wiKSkgYmFzZSA9IGNsZWFuUGF0aChiYXNlKTtcblx0XHRiYXNlU2VnbWVudHMgPSBiYXNlLnNwbGl0KFwiL1wiKTtcblx0XHR3aGlsZSAoYmFzZVNlZ21lbnRzLmxlbmd0aCA+IDEgJiYgbGFzdChiYXNlU2VnbWVudHMpID09PSBcIlwiKSBiYXNlU2VnbWVudHMucG9wKCk7XG5cdFx0Y29uc3QgdG9TZWdtZW50cyA9IHRvLnNwbGl0KFwiL1wiKTtcblx0XHRmb3IgKGxldCBpbmRleCA9IDAsIGxlbmd0aCA9IHRvU2VnbWVudHMubGVuZ3RoOyBpbmRleCA8IGxlbmd0aDsgaW5kZXgrKykge1xuXHRcdFx0Y29uc3QgdmFsdWUgPSB0b1NlZ21lbnRzW2luZGV4XTtcblx0XHRcdGlmICh2YWx1ZSA9PT0gXCJcIikge1xuXHRcdFx0XHRpZiAoIWluZGV4KSBiYXNlU2VnbWVudHMgPSBbdmFsdWVdO1xuXHRcdFx0XHRlbHNlIGlmIChpbmRleCA9PT0gbGVuZ3RoIC0gMSkgYmFzZVNlZ21lbnRzLnB1c2godmFsdWUpO1xuXHRcdFx0fSBlbHNlIGlmICh2YWx1ZSA9PT0gXCIuLlwiKSBpZiAoYmFzZVNlZ21lbnRzLmxlbmd0aCA+IDEpIGJhc2VTZWdtZW50cy5wb3AoKTtcblx0XHRcdGVsc2UgYmFzZVNlZ21lbnRzID0gW1wiXCJdO1xuXHRcdFx0ZWxzZSBpZiAodmFsdWUgPT09IFwiLlwiKSB7fSBlbHNlIGJhc2VTZWdtZW50cy5wdXNoKHZhbHVlKTtcblx0XHR9XG5cdH1cblx0aWYgKGJhc2VTZWdtZW50cy5sZW5ndGggPiAxKSB7XG5cdFx0aWYgKGxhc3QoYmFzZVNlZ21lbnRzKSA9PT0gXCJcIikge1xuXHRcdFx0aWYgKHRyYWlsaW5nU2xhc2ggPT09IFwibmV2ZXJcIikgYmFzZVNlZ21lbnRzLnBvcCgpO1xuXHRcdH0gZWxzZSBpZiAodHJhaWxpbmdTbGFzaCA9PT0gXCJhbHdheXNcIikgYmFzZVNlZ21lbnRzLnB1c2goXCJcIik7XG5cdH1cblx0Y29uc3Qgam9pbmVkID0gYmFzZVNlZ21lbnRzLmpvaW4oXCIvXCIpO1xuXHRjb25zdCByZXN1bHQgPSAoaXNCYXNlID8gY2xlYW5QYXRoKGpvaW5lZCkgOiBqb2luZWQpIHx8IFwiL1wiO1xuXHRpZiAoa2V5ICYmIGNhY2hlKSBjYWNoZS5zZXQoa2V5LCByZXN1bHQpO1xuXHRyZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4qIENyZWF0ZSBhIHByZS1jb21waWxlZCBkZWNvZGUgY29uZmlnIGZyb20gYWxsb3dlZCBjaGFyYWN0ZXJzLlxuKiBDcmVhdGVkIG9uY2UgZm9yIHRoZSByb3V0ZXIncyBmaXhlZCBlbmNvZGluZyBjb25maWd1cmF0aW9uLlxuKi9cbmZ1bmN0aW9uIGNvbXBpbGVEZWNvZGVDaGFyTWFwKHBhdGhQYXJhbXNBbGxvd2VkQ2hhcmFjdGVycykge1xuXHRjb25zdCBjaGFyTWFwID0gbmV3IE1hcChwYXRoUGFyYW1zQWxsb3dlZENoYXJhY3RlcnMubWFwKChjaGFyKSA9PiBbZW5jb2RlVVJJQ29tcG9uZW50KGNoYXIpLCBjaGFyXSkpO1xuXHRjb25zdCByZWdleCA9IG5ldyBSZWdFeHAoWy4uLmNoYXJNYXAua2V5cygpXS5qb2luKFwifFwiKS5yZXBsYWNlKC9bLiooKV0vZywgXCJcXFxcJCZcIiksIFwiZ1wiKTtcblx0cmV0dXJuIChlbmNvZGVkKSA9PiBlbmNvZGVkLnJlcGxhY2UocmVnZXgsIChtYXRjaCkgPT4gY2hhck1hcC5nZXQobWF0Y2gpID8/IG1hdGNoKTtcbn1cbmZ1bmN0aW9uIGdldFJvdXRlU2VnbWVudHMocm91dGUpIHtcblx0cmV0dXJuIHJvdXRlLl9pbnRlcnBvbGF0aW9uO1xufVxuLyoqIEEgc3BsYXQgaXMgbWlzc2luZyB3aGVuIGl0IGhhcyBubyB2YWx1ZTsgYDBgIGFuZCBgZmFsc2VgIGFyZSBzdHJpbmdpZmllZCBsaWtlIGFueSBvdGhlciBwYXJhbS4gKi9cbmZ1bmN0aW9uIGlzTWlzc2luZ1NwbGF0KHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZSA9PSBudWxsIHx8IHZhbHVlID09PSBcIlwiO1xufVxuLyoqIERldnRvb2xzIGNoZWNrcyBuYXZpZ2F0aW9uIGF2YWlsYWJpbGl0eSBzZXBhcmF0ZWx5IGZyb20gdGhlIGhvdCBmb3JtYXR0ZXIuICovXG5mdW5jdGlvbiBoYXNNaXNzaW5nUGF0aFBhcmFtcyhzZWdtZW50cywgcGFyYW1zKSB7XG5cdHJldHVybiBzZWdtZW50cy5zb21lKChwYXJ0KSA9PiB7XG5cdFx0aWYgKHR5cGVvZiBwYXJ0ID09PSBcInN0cmluZ1wiKSByZXR1cm4gZmFsc2U7XG5cdFx0Y29uc3QgW2tpbmQsIGtleV0gPSBwYXJ0O1xuXHRcdHJldHVybiBraW5kID09PSAyID8gaXNNaXNzaW5nU3BsYXQocGFyYW1zW2tleV0pIDoga2luZCA9PT0gMSAmJiAhKGtleSBpbiBwYXJhbXMpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGVuY29kZVBhcmFtKGtleSwgdmFsdWUsIGRlY29kZXIpIHtcblx0aWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJzdHJpbmdcIikgcmV0dXJuIFwiXCIgKyAodmFsdWUgPz8gdm9pZCAwKTtcblx0Y29uc3Qgc3BsYXQgPSBrZXkgPT09IFwiX3NwbGF0XCI7XG5cdGlmIChzcGxhdCAmJiAoIXZhbHVlIHx8IC9eW2EtekEtWjAtOVxcLS5ffiEvXSokLy50ZXN0KHZhbHVlKSkpIHJldHVybiB2YWx1ZTtcblx0bGV0IGVuY29kZWQgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpO1xuXHRpZiAoc3BsYXQpIGVuY29kZWQgPSBlbmNvZGVkLnJlcGxhY2VBbGwoXCIlMkZcIiwgXCIvXCIpO1xuXHRyZXR1cm4gZGVjb2RlciA/IGRlY29kZXIoZW5jb2RlZCkgOiBlbmNvZGVkO1xufVxuLyoqIFN1YnN0aXR1dGUgY3VycmVudCB2YWx1ZXMgaW50byBwYXJzZWQgc2VnbWVudHMsIG9wdGlvbmFsbHkgY29sbGVjdGluZyByYXcgcGFyYW1zLiAqL1xuZnVuY3Rpb24gaW50ZXJwb2xhdGVQYXRoKHBhdGgsIHNlZ21lbnRzLCBwYXJhbXMsIGRlY29kZXIsIHVzZWRQYXJhbXMpIHtcblx0Y29uc3QgdHJhaWxpbmdTbGFzaCA9IHBhdGguZW5kc1dpdGgoXCIvXCIpID8gXCIvXCIgOiBcIlwiO1xuXHRsZXQgam9pbmVkID0gXCJcIjtcblx0Zm9yIChjb25zdCBwYXJ0IG9mIHNlZ21lbnRzKSB7XG5cdFx0aWYgKHR5cGVvZiBwYXJ0ID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRqb2luZWQgKz0gcGFydDtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCBba2luZCwga2V5LCBwcmVmaXgsIHJhd1N1ZmZpeF0gPSBwYXJ0O1xuXHRcdGNvbnN0IHNwbGF0ID0ga2luZCA9PT0gMjtcblx0XHRjb25zdCBzdWZmaXggPSBzcGxhdCAmJiByYXdTdWZmaXggIT09IHZvaWQgMCA/IHJhd1N1ZmZpeCArIHRyYWlsaW5nU2xhc2ggOiByYXdTdWZmaXg7XG5cdFx0bGV0IHBhcmFtVmFsdWUgPSBwYXJhbXNba2V5XTtcblx0XHRpZiAoa2luZCA9PT0gMyAmJiBwYXJhbVZhbHVlID09IG51bGwpIGNvbnRpbnVlO1xuXHRcdGlmICh1c2VkUGFyYW1zKSB7XG5cdFx0XHR1c2VkUGFyYW1zW2tleV0gPSBwYXJhbVZhbHVlO1xuXHRcdFx0aWYgKHNwbGF0KSB1c2VkUGFyYW1zW1wiKlwiXSA9IHBhcmFtVmFsdWU7XG5cdFx0fVxuXHRcdGlmIChzcGxhdCAmJiBpc01pc3NpbmdTcGxhdChwYXJhbVZhbHVlKSkge1xuXHRcdFx0aWYgKHByZWZpeCA9PT0gXCIvXCIgJiYgIXN1ZmZpeCkgY29udGludWU7XG5cdFx0XHRwYXJhbVZhbHVlID0gXCJcIjtcblx0XHR9XG5cdFx0am9pbmVkICs9IHByZWZpeCArIGVuY29kZVBhcmFtKGtleSwgcGFyYW1WYWx1ZSwgZGVjb2RlcikgKyAoc3VmZml4IHx8IFwiXCIpO1xuXHR9XG5cdHJldHVybiBqb2luZWQgKyB0cmFpbGluZ1NsYXNoIHx8IFwiL1wiO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjbGVhblBhdGgsIGNvbXBpbGVEZWNvZGVDaGFyTWFwLCBleGFjdFBhdGhUZXN0LCBnZXRSb3V0ZVNlZ21lbnRzLCBoYXNNaXNzaW5nUGF0aFBhcmFtcywgaW50ZXJwb2xhdGVQYXRoLCBqb2luUGF0aHMsIHJlbW92ZVRyYWlsaW5nU2xhc2gsIHJlc29sdmVQYXRoLCB0cmltUGF0aCwgdHJpbVBhdGhMZWZ0LCB0cmltUGF0aFJpZ2h0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhdGguanMubWFwIiwiLy8jcmVnaW9uIHNyYy9zaWV2ZS1jYWNoZS50c1xuLyoqXG4qIEEgZml4ZWQtY2FwYWNpdHkgY2FjaGUgdXNpbmcgdGhlIFNJRVZFIGV2aWN0aW9uIGFsZ29yaXRobVxuKiAoaHR0cHM6Ly9jYWNoZW1vbi5naXRodWIuaW8vU0lFVkUtd2Vic2l0ZS8pLlxuKlxuKiBFbnRyaWVzIGxpdmUgaW4gdGhlIE1hcCdzIEZJRk8gaW5zZXJ0aW9uIG9yZGVyOyBhIGhpdCBvbmx5IGZsaXBzIGEgYHZpc2l0ZWRgXG4qIGJpdCBpbnN0ZWFkIG9mIHJlbGlua2luZyB0aGUgZW50cnksIHdoaWNoIG1ha2VzIGBnZXRgIChieSBmYXIgdGhlIGhvdHRlc3Rcbiogb3BlcmF0aW9uIGhlcmUpIG9uZSBgTWFwLmdldGAgcGx1cyBhIGJvb2xlYW4gc3RvcmUuIEV2aWN0aW9uIHN3ZWVwcyBhIGBoYW5kYFxuKiBmcm9tIHRoZSBvbGRlc3QgZW50cnkgdG93YXJkcyB0aGUgbmV3ZXN0LCBjbGVhcmluZyBgdmlzaXRlZGAgYml0cyB1bnRpbCBpdFxuKiBmaW5kcyBhbiB1bnZpc2l0ZWQgZW50cnkgdG8gZHJvcCwgc28gZW50cmllcyB0b3VjaGVkIHNpbmNlIHRoZSBsYXN0IHN3ZWVwXG4qIHN1cnZpdmUgb25lIG1vcmUgcm91bmQuIFRoaXMga2VlcHMgTFJVLWxpa2UgaGl0IHJhdGlvcyB3aGlsZSBiZWluZ1xuKiBzY2FuLXJlc2lzdGFudC5cbiovXG5mdW5jdGlvbiBjcmVhdGVTaWV2ZUNhY2hlKG1heCkge1xuXHRjb25zdCBjYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGxldCBoYW5kO1xuXHRsZXQgbmV3ZXN0O1xuXHRyZXR1cm4ge1xuXHRcdGdldChrZXkpIHtcblx0XHRcdGNvbnN0IGVudHJ5ID0gY2FjaGUuZ2V0KGtleSk7XG5cdFx0XHRpZiAoIWVudHJ5KSByZXR1cm47XG5cdFx0XHRlbnRyeS52aXNpdGVkID0gdHJ1ZTtcblx0XHRcdHJldHVybiBlbnRyeS52YWx1ZTtcblx0XHR9LFxuXHRcdHNldChrZXksIHZhbHVlKSB7XG5cdFx0XHRjb25zdCBleGlzdGluZyA9IGNhY2hlLmdldChrZXkpO1xuXHRcdFx0aWYgKGV4aXN0aW5nKSB7XG5cdFx0XHRcdGV4aXN0aW5nLnZhbHVlID0gdmFsdWU7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGlmIChjYWNoZS5zaXplID49IG1heCkge1xuXHRcdFx0XHRsZXQgbm9kZSA9IGhhbmQ/Lm5leHQoKS52YWx1ZTtcblx0XHRcdFx0d2hpbGUgKCFub2RlIHx8IG5vZGUudmlzaXRlZCkge1xuXHRcdFx0XHRcdGlmIChub2RlKSBub2RlLnZpc2l0ZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRlbHNlIGhhbmQgPSBjYWNoZS52YWx1ZXMoKTtcblx0XHRcdFx0XHRub2RlID0gaGFuZC5uZXh0KCkudmFsdWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5vZGUgPT09IG5ld2VzdCkgaGFuZCA9IHZvaWQgMDtcblx0XHRcdFx0Y2FjaGUuZGVsZXRlKG5vZGUua2V5KTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGVudHJ5ID0ge1xuXHRcdFx0XHRrZXksXG5cdFx0XHRcdHZhbHVlLFxuXHRcdFx0XHR2aXNpdGVkOiBmYWxzZVxuXHRcdFx0fTtcblx0XHRcdG5ld2VzdCA9IGVudHJ5O1xuXHRcdFx0Y2FjaGUuc2V0KGtleSwgZW50cnkpO1xuXHRcdH0sXG5cdFx0Y2xlYXIoKSB7XG5cdFx0XHRjYWNoZS5jbGVhcigpO1xuXHRcdFx0aGFuZCA9IHZvaWQgMDtcblx0XHRcdG5ld2VzdCA9IHZvaWQgMDtcblx0XHR9XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZVNpZXZlQ2FjaGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2lldmUtY2FjaGUuanMubWFwIiwiaW1wb3J0IHsgbGFzdCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwiLi9pbnZhcmlhbnQuanNcIjtcbmltcG9ydCB7IHRyaW1QYXRoUmlnaHQgfSBmcm9tIFwiLi9wYXRoLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVTaWV2ZUNhY2hlIH0gZnJvbSBcIi4vc2lldmUtY2FjaGUuanNcIjtcbmNvbnN0IFNFR01FTlRfVFlQRV9JTkRFWCA9IDQ7XG5jb25zdCBTRUdNRU5UX1RZUEVfUEFUSExFU1MgPSA1O1xuZnVuY3Rpb24gZ2V0UGFyYW1OYW1lcyhkYXRhKSB7XG5cdGNvbnN0IGNhY2hlZCA9IGRhdGEubmFtZXM7XG5cdGlmIChjYWNoZWQpIHJldHVybiBjYWNoZWQ7XG5cdGNvbnN0IGtleXMgPSBbXTtcblx0Zm9yIChjb25zdCBzZWdtZW50IG9mIGRhdGEpIGlmICh0eXBlb2Ygc2VnbWVudCAhPT0gXCJzdHJpbmdcIikga2V5cy5wdXNoKHNlZ21lbnRbMV0pO1xuXHRyZXR1cm4gZGF0YS5uYW1lcyA9IGtleXM7XG59XG4vKiogUGFyc2Ugb25lIHNlZ21lbnQgZm9yIG1hdGNoaW5nIGFuZCByZXRhaW4gdGhlIHNhbWUgcmVjb3JkIGZvciBpbnRlcnBvbGF0aW9uLiAqL1xuZnVuY3Rpb24gcGFyc2VTZWdtZW50KHBhdGgsIHN0YXJ0LCBlbmQpIHtcblx0Y29uc3QgcGFydCA9IHBhdGguc3Vic3RyaW5nKHN0YXJ0LCBlbmQpO1xuXHRpZiAocGFydC5jaGFyQ29kZUF0KDApID09PSAzNikgcmV0dXJuIHBhcnQubGVuZ3RoID09PSAxID8gW1xuXHRcdDIsXG5cdFx0XCJfc3BsYXRcIixcblx0XHRcIlwiLFxuXHRcdHZvaWQgMFxuXHRdIDogW1xuXHRcdDEsXG5cdFx0cGFydC5zdWJzdHJpbmcoMSksXG5cdFx0XCJcIixcblx0XHRcIlwiXG5cdF07XG5cdGNvbnN0IG9wZW4gPSBwYXJ0LmluZGV4T2YoXCJ7XCIpO1xuXHRpZiAob3BlbiA+PSAwKSB7XG5cdFx0Y29uc3QgY2xvc2UgPSBwYXJ0LmluZGV4T2YoXCJ9XCIsIG9wZW4pO1xuXHRcdGNvbnN0IG9wdGlvbmFsID0gcGFydC5jaGFyQ29kZUF0KG9wZW4gKyAxKSA9PT0gNDU7XG5cdFx0Y29uc3QgbmFtZVN0YXJ0ID0gb3BlbiArIChvcHRpb25hbCA/IDMgOiAyKTtcblx0XHRpZiAoY2xvc2UgPj0gMCAmJiBwYXJ0LmNoYXJDb2RlQXQobmFtZVN0YXJ0IC0gMSkgPT09IDM2ICYmICghb3B0aW9uYWwgfHwgbmFtZVN0YXJ0IDwgY2xvc2UpKSB7XG5cdFx0XHRjb25zdCBrZXkgPSBwYXJ0LnN1YnN0cmluZyhuYW1lU3RhcnQsIGNsb3NlKTtcblx0XHRcdHJldHVybiBbXG5cdFx0XHRcdG9wdGlvbmFsID8gMyA6IGtleSA/IDEgOiAyLFxuXHRcdFx0XHRrZXkgfHwgXCJfc3BsYXRcIixcblx0XHRcdFx0cGFydC5zdWJzdHJpbmcoMCwgb3BlbiksXG5cdFx0XHRcdHBhdGguc3Vic3RyaW5nKHN0YXJ0ICsgY2xvc2UgKyAxLCBrZXkgPyBlbmQgOiBwYXRoLmxlbmd0aClcblx0XHRcdF07XG5cdFx0fVxuXHR9XG5cdHJldHVybiBwYXJ0O1xufVxuZnVuY3Rpb24gcGFyc2VTZWdtZW50cyhkZWZhdWx0Q2FzZVNlbnNpdGl2ZSwgcm91dGUsIHN0YXJ0LCBub2RlLCBkeW5hbWljTGlzdHNUb1NvcnQsIHBhcmVudEludGVycG9sYXRpb24pIHtcblx0bGV0IGN1cnNvciA9IHN0YXJ0O1xuXHRjb25zdCBwYXRoID0gcm91dGUuZnVsbFBhdGggPz8gcm91dGUuZnJvbTtcblx0Y29uc3Qgb3B0aW9ucyA9IHJvdXRlLm9wdGlvbnM7XG5cdGNvbnN0IGxlbmd0aCA9IHBhdGgubGVuZ3RoO1xuXHRjb25zdCBsaXRlcmFsRW5kID0gcGF0aC5lbmRzV2l0aChcIi9cIikgPyBsZW5ndGggLSAxIDogbGVuZ3RoO1xuXHRjb25zdCBjYXNlU2Vuc2l0aXZlID0gb3B0aW9ucz8uY2FzZVNlbnNpdGl2ZSA/PyBkZWZhdWx0Q2FzZVNlbnNpdGl2ZTtcblx0Y29uc3QgcGFyc2VQYXJhbXMgPSBvcHRpb25zPy5wYXJhbXM/LnBhcnNlID8/IG9wdGlvbnM/LnBhcnNlUGFyYW1zO1xuXHRsZXQgaW50ZXJwb2xhdGlvbjtcblx0bGV0IGxpdGVyYWxTdGFydCA9IHBhcmVudEludGVycG9sYXRpb24gPyBzdGFydCAtIDEgOiAwO1xuXHRpZiAoIW5vZGUgfHwgcGF0aC5pbmNsdWRlcyhcIiRcIikpIHtcblx0XHRpbnRlcnBvbGF0aW9uID0gcGFyZW50SW50ZXJwb2xhdGlvbj8uc2xpY2UoKSA/PyBbXTtcblx0XHRjb25zdCB0YWlsID0gbGFzdChpbnRlcnBvbGF0aW9uKTtcblx0XHRpZiAodGFpbCAmJiB0eXBlb2YgdGFpbCAhPT0gXCJzdHJpbmdcIiAmJiB0YWlsWzBdID09PSAyKSB7XG5cdFx0XHRpbnRlcnBvbGF0aW9uW2ludGVycG9sYXRpb24ubGVuZ3RoIC0gMV0gPSBbXG5cdFx0XHRcdHRhaWxbMF0sXG5cdFx0XHRcdHRhaWxbMV0sXG5cdFx0XHRcdHRhaWxbMl0sXG5cdFx0XHRcdHRhaWxbM10gPT09IHZvaWQgMCA/IHZvaWQgMCA6IHRhaWxbM10gKyBwYXRoLnN1YnN0cmluZyhzdGFydCAtIChwYXRoW3N0YXJ0IC0gMl0gPT09IFwiL1wiID8gMiA6IDEpLCBsaXRlcmFsRW5kKVxuXHRcdFx0XTtcblx0XHRcdGxpdGVyYWxTdGFydCA9IGxlbmd0aDtcblx0XHR9XG5cdH1cblx0d2hpbGUgKGN1cnNvciA8IGxlbmd0aCkge1xuXHRcdGNvbnN0IHN0YXJ0ID0gY3Vyc29yO1xuXHRcdGNvbnN0IG5leHQgPSBwYXRoLmluZGV4T2YoXCIvXCIsIHN0YXJ0KTtcblx0XHRsZXQgZW5kID0gbmV4dCA9PT0gLTEgPyBsZW5ndGggOiBuZXh0O1xuXHRcdGNvbnN0IHNlZ21lbnQgPSBwYXJzZVNlZ21lbnQocGF0aCwgc3RhcnQsIGVuZCk7XG5cdFx0Y3Vyc29yID0gZW5kICsgMTtcblx0XHRsZXQgbmV4dE5vZGU7XG5cdFx0aWYgKHR5cGVvZiBzZWdtZW50ID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRpZiAoIW5vZGUpIGNvbnRpbnVlO1xuXHRcdFx0bGV0IG5hbWUgPSBzZWdtZW50O1xuXHRcdFx0bGV0IHN0YXRpY0NoaWxkcmVuO1xuXHRcdFx0aWYgKGNhc2VTZW5zaXRpdmUpIHN0YXRpY0NoaWxkcmVuID0gbm9kZS5zdGF0aWMgPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0bmFtZSA9IHNlZ21lbnQudG9Mb3dlckNhc2UoKTtcblx0XHRcdFx0c3RhdGljQ2hpbGRyZW4gPSBub2RlLnN0YXRpY0luc2Vuc2l0aXZlID8/PSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgZXhpc3RpbmdOb2RlID0gc3RhdGljQ2hpbGRyZW4uZ2V0KG5hbWUpO1xuXHRcdFx0aWYgKGV4aXN0aW5nTm9kZSkgbmV4dE5vZGUgPSBleGlzdGluZ05vZGU7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0Y29uc3QgbmV4dCA9IGNyZWF0ZVNlZ21lbnROb2RlKG5vZGUpO1xuXHRcdFx0XHRuZXh0Tm9kZSA9IG5leHQ7XG5cdFx0XHRcdHN0YXRpY0NoaWxkcmVuLnNldChuYW1lLCBuZXh0KTtcblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3Qga2luZCA9IHNlZ21lbnRbMF07XG5cdFx0XHRsZXQgcHJlZml4ID0gc2VnbWVudFsyXTtcblx0XHRcdGxldCBzdWZmaXggPSBzZWdtZW50WzNdID8/IFwiXCI7XG5cdFx0XHRpZiAoa2luZCA9PT0gMikge1xuXHRcdFx0XHRlbmQgPSBsZW5ndGg7XG5cdFx0XHRcdGN1cnNvciA9IGVuZCArIDE7XG5cdFx0XHR9XG5cdFx0XHRpZiAoaW50ZXJwb2xhdGlvbiAmJiBsaXRlcmFsU3RhcnQgPCBlbmQpIHtcblx0XHRcdFx0aWYgKGxpdGVyYWxTdGFydCA8IHN0YXJ0IC0gMSkgaW50ZXJwb2xhdGlvbi5wdXNoKHBhdGguc3Vic3RyaW5nKGxpdGVyYWxTdGFydCwgc3RhcnQgLSAxKSk7XG5cdFx0XHRcdHNlZ21lbnRbMl0gPSBcIi9cIiArIHByZWZpeDtcblx0XHRcdFx0aWYgKGtpbmQgPT09IDIgJiYgc2VnbWVudFszXSAhPT0gdm9pZCAwICYmIGxpdGVyYWxFbmQgPCBsZW5ndGgpIHNlZ21lbnRbM10gPSBzdWZmaXguc2xpY2UoMCwgLTEpO1xuXHRcdFx0XHRpbnRlcnBvbGF0aW9uLnB1c2goc2VnbWVudCk7XG5cdFx0XHRcdGxpdGVyYWxTdGFydCA9IGVuZDtcblx0XHRcdH1cblx0XHRcdGlmICghbm9kZSkgY29udGludWU7XG5cdFx0XHRjb25zdCBhY3R1YWxseUNhc2VTZW5zaXRpdmUgPSBjYXNlU2Vuc2l0aXZlICYmICEhKHByZWZpeCB8fCBzdWZmaXgpO1xuXHRcdFx0aWYgKCFjYXNlU2Vuc2l0aXZlKSB7XG5cdFx0XHRcdHByZWZpeCA9IHByZWZpeC50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0XHRzdWZmaXggPSBzdWZmaXgudG9Mb3dlckNhc2UoKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHNpYmxpbmdzID0ga2luZCA9PT0gMSA/IG5vZGUuZHluYW1pYyA/Pz0gW10gOiBraW5kID09PSAzID8gbm9kZS5vcHRpb25hbCA/Pz0gW10gOiBub2RlLndpbGRjYXJkID8/PSBbXTtcblx0XHRcdGNvbnN0IGV4aXN0aW5nTm9kZSA9IGtpbmQgIT09IDIgJiYgIXBhcnNlUGFyYW1zICYmIHNpYmxpbmdzLmZpbmQoKHMpID0+ICFzLnBhcnNlICYmIHMuY2FzZVNlbnNpdGl2ZSA9PT0gYWN0dWFsbHlDYXNlU2Vuc2l0aXZlICYmIHMucHJlZml4ID09PSBwcmVmaXggJiYgcy5zdWZmaXggPT09IHN1ZmZpeCk7XG5cdFx0XHRpZiAoZXhpc3RpbmdOb2RlKSBuZXh0Tm9kZSA9IGV4aXN0aW5nTm9kZTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBuZXh0ID0gY3JlYXRlU2VnbWVudE5vZGUobm9kZSwga2luZCwgYWN0dWFsbHlDYXNlU2Vuc2l0aXZlLCBwcmVmaXgsIHN1ZmZpeCk7XG5cdFx0XHRcdG5leHROb2RlID0gbmV4dDtcblx0XHRcdFx0c2libGluZ3MucHVzaChuZXh0KTtcblx0XHRcdFx0aWYgKHNpYmxpbmdzLmxlbmd0aCA9PT0gMikgZHluYW1pY0xpc3RzVG9Tb3J0Py5wdXNoKHNpYmxpbmdzKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0bm9kZSA9IG5leHROb2RlO1xuXHR9XG5cdGlmIChpbnRlcnBvbGF0aW9uICYmIGxpdGVyYWxTdGFydCA8IGxpdGVyYWxFbmQpIGludGVycG9sYXRpb24ucHVzaChwYXRoLnN1YnN0cmluZyhsaXRlcmFsU3RhcnQsIGxpdGVyYWxFbmQpKTtcblx0Y29uc3Qgc2VnbWVudERhdGEgPSBpbnRlcnBvbGF0aW9uPy5zbGljZSgpO1xuXHRpZiAoIW5vZGUpIHJldHVybiBzZWdtZW50RGF0YTtcblx0aWYgKHBhcnNlUGFyYW1zICYmIHJvdXRlLmNoaWxkcmVuICYmICFyb3V0ZS5pc1Jvb3QgJiYgcm91dGUuaWQgJiYgcm91dGUuaWQuY2hhckNvZGVBdChyb3V0ZS5pZC5sYXN0SW5kZXhPZihcIi9cIikgKyAxKSA9PT0gOTUpIHtcblx0XHRjb25zdCBwYXRobGVzc05vZGUgPSBjcmVhdGVTZWdtZW50Tm9kZShub2RlLCBTRUdNRU5UX1RZUEVfUEFUSExFU1MpO1xuXHRcdChub2RlLnBhdGhsZXNzID8/PSBbXSkucHVzaChwYXRobGVzc05vZGUpO1xuXHRcdG5vZGUgPSBwYXRobGVzc05vZGU7XG5cdH1cblx0Y29uc3QgaXNMZWFmID0gKHJvdXRlLnBhdGggfHwgIXJvdXRlLmNoaWxkcmVuKSAmJiAhcm91dGUuaXNSb290O1xuXHRpZiAoaXNMZWFmICYmIGxpdGVyYWxFbmQgPCBsZW5ndGgpIHtcblx0XHRjb25zdCBpbmRleE5vZGUgPSBjcmVhdGVTZWdtZW50Tm9kZShub2RlLCBTRUdNRU5UX1RZUEVfSU5ERVgpO1xuXHRcdG5vZGUuaW5kZXggPSBpbmRleE5vZGU7XG5cdFx0bm9kZSA9IGluZGV4Tm9kZTtcblx0fVxuXHRub2RlLnBhcnNlID0gcGFyc2VQYXJhbXMgPz8gbnVsbDtcblx0bm9kZS5wcmlvcml0eSA9IG9wdGlvbnM/LnBhcmFtcz8ucHJpb3JpdHkgPz8gMDtcblx0aWYgKCFub2RlLnJvdXRlKSB7XG5cdFx0bm9kZS5kYXRhID0gc2VnbWVudERhdGE7XG5cdFx0aWYgKGlzTGVhZikgbm9kZS5yb3V0ZSA9IHJvdXRlO1xuXHR9XG5cdHJldHVybiBbXG5cdFx0bm9kZSxcblx0XHRjdXJzb3IsXG5cdFx0c2VnbWVudERhdGFcblx0XTtcbn1cbmZ1bmN0aW9uIHNvcnREeW5hbWljKGEsIGIpIHtcblx0aWYgKGEucGFyc2UgJiYgIWIucGFyc2UpIHJldHVybiAtMTtcblx0aWYgKCFhLnBhcnNlICYmIGIucGFyc2UpIHJldHVybiAxO1xuXHRpZiAoYS5wYXJzZSAmJiBiLnBhcnNlICYmIChhLnByaW9yaXR5IHx8IGIucHJpb3JpdHkpKSByZXR1cm4gYi5wcmlvcml0eSAtIGEucHJpb3JpdHk7XG5cdGlmIChhLnByZWZpeCAmJiBiLnByZWZpeCAmJiBhLnByZWZpeCAhPT0gYi5wcmVmaXgpIHtcblx0XHRpZiAoYS5wcmVmaXguc3RhcnRzV2l0aChiLnByZWZpeCkpIHJldHVybiAtMTtcblx0XHRpZiAoYi5wcmVmaXguc3RhcnRzV2l0aChhLnByZWZpeCkpIHJldHVybiAxO1xuXHR9XG5cdGlmIChhLnN1ZmZpeCAmJiBiLnN1ZmZpeCAmJiBhLnN1ZmZpeCAhPT0gYi5zdWZmaXgpIHtcblx0XHRpZiAoYS5zdWZmaXguZW5kc1dpdGgoYi5zdWZmaXgpKSByZXR1cm4gLTE7XG5cdFx0aWYgKGIuc3VmZml4LmVuZHNXaXRoKGEuc3VmZml4KSkgcmV0dXJuIDE7XG5cdH1cblx0aWYgKGEucHJlZml4ICYmICFiLnByZWZpeCkgcmV0dXJuIC0xO1xuXHRpZiAoIWEucHJlZml4ICYmIGIucHJlZml4KSByZXR1cm4gMTtcblx0aWYgKGEuc3VmZml4ICYmICFiLnN1ZmZpeCkgcmV0dXJuIC0xO1xuXHRpZiAoIWEuc3VmZml4ICYmIGIuc3VmZml4KSByZXR1cm4gMTtcblx0aWYgKGEuY2FzZVNlbnNpdGl2ZSAmJiAhYi5jYXNlU2Vuc2l0aXZlKSByZXR1cm4gLTE7XG5cdGlmICghYS5jYXNlU2Vuc2l0aXZlICYmIGIuY2FzZVNlbnNpdGl2ZSkgcmV0dXJuIDE7XG5cdHJldHVybiAwO1xufVxuZnVuY3Rpb24gY3JlYXRlU2VnbWVudE5vZGUocGFyZW50LCBraW5kID0gMCwgY2FzZVNlbnNpdGl2ZSwgcHJlZml4LCBzdWZmaXgpIHtcblx0cmV0dXJuIHtcblx0XHRraW5kLFxuXHRcdGRlcHRoOiBwYXJlbnQgPyBwYXJlbnQuZGVwdGggKyAxIDogMCxcblx0XHRwYXRobGVzczogbnVsbCxcblx0XHRpbmRleDogbnVsbCxcblx0XHRzdGF0aWM6IG51bGwsXG5cdFx0c3RhdGljSW5zZW5zaXRpdmU6IG51bGwsXG5cdFx0ZHluYW1pYzogbnVsbCxcblx0XHRvcHRpb25hbDogbnVsbCxcblx0XHR3aWxkY2FyZDogbnVsbCxcblx0XHRyb3V0ZTogbnVsbCxcblx0XHRkYXRhOiB2b2lkIDAsXG5cdFx0cGFyZW50LFxuXHRcdHBhcnNlOiBudWxsLFxuXHRcdHByaW9yaXR5OiAwLFxuXHRcdGNhc2VTZW5zaXRpdmUsXG5cdFx0cHJlZml4LFxuXHRcdHN1ZmZpeFxuXHR9O1xufVxuZnVuY3Rpb24gcHJvY2Vzc1JvdXRlTWFza3Mocm91dGVMaXN0LCBwcm9jZXNzZWRUcmVlKSB7XG5cdGNvbnN0IHNlZ21lbnRUcmVlID0gY3JlYXRlU2VnbWVudE5vZGUoKTtcblx0Y29uc3QgZHluYW1pY0xpc3RzVG9Tb3J0ID0gW107XG5cdGZ1bmN0aW9uIHZpc2l0KHJvdXRlLCBzdGFydCwgcGFyZW50Tm9kZSwgcGFyZW50SW50ZXJwb2xhdGlvbikge1xuXHRcdGNvbnN0IFtub2RlLCBjdXJzb3IsIHNlZ21lbnRzXSA9IHBhcnNlU2VnbWVudHMoZmFsc2UsIHJvdXRlLCBzdGFydCwgcGFyZW50Tm9kZSwgZHluYW1pY0xpc3RzVG9Tb3J0LCBwYXJlbnRJbnRlcnBvbGF0aW9uKTtcblx0XHRpZiAocm91dGUuY2hpbGRyZW4pIGZvciAoY29uc3QgY2hpbGQgb2Ygcm91dGUuY2hpbGRyZW4pIHZpc2l0KGNoaWxkLCBjdXJzb3IsIG5vZGUsIHNlZ21lbnRzKTtcblx0fVxuXHRmb3IgKGNvbnN0IHJvdXRlIG9mIHJvdXRlTGlzdCkgdmlzaXQocm91dGUsIDEsIHNlZ21lbnRUcmVlKTtcblx0Zm9yIChjb25zdCBub2RlcyBvZiBkeW5hbWljTGlzdHNUb1NvcnQpIG5vZGVzLnNvcnQoc29ydER5bmFtaWMpO1xuXHRwcm9jZXNzZWRUcmVlLm1hc2tzVHJlZSA9IHNlZ21lbnRUcmVlO1xuXHRwcm9jZXNzZWRUcmVlLmZsYXRDYWNoZSA9IGNyZWF0ZVNpZXZlQ2FjaGUoMWUzKTtcbn1cbi8qKlxuKiBUYWtlIGFuIGFyYml0cmFyeSBsaXN0IG9mIHJvdXRlcywgY3JlYXRlIGEgdHJlZSBmcm9tIHRoZW0gKGlmIGl0IGhhc24ndCBiZWVuIGNyZWF0ZWQgYWxyZWFkeSksIGFuZCBtYXRjaCBhIHBhdGggYWdhaW5zdCBpdC5cbiovXG5mdW5jdGlvbiBmaW5kRmxhdE1hdGNoKHBhdGgsIHByb2Nlc3NlZFRyZWUpIHtcblx0cGF0aCB8fD0gXCIvXCI7XG5cdGNvbnN0IGNhY2hlZCA9IHByb2Nlc3NlZFRyZWUuZmxhdENhY2hlLmdldChwYXRoKTtcblx0aWYgKGNhY2hlZCAhPT0gdm9pZCAwKSByZXR1cm4gY2FjaGVkO1xuXHRjb25zdCByZXN1bHQgPSBmaW5kTWF0Y2gocGF0aCwgcHJvY2Vzc2VkVHJlZS5tYXNrc1RyZWUpO1xuXHRwcm9jZXNzZWRUcmVlLmZsYXRDYWNoZS5zZXQocGF0aCwgcmVzdWx0KTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8qKlxuKiBAZGVwcmVjYXRlZCBrZWVwIHVudGlsIHYyIHNvIHRoYXQgYHJvdXRlci5tYXRjaFJvdXRlYCBjYW4ga2VlcCBub3QgY2FyaW5nIGFib3V0IHRoZSBhY3R1YWwgcm91dGUgdHJlZVxuKi9cbmZ1bmN0aW9uIGZpbmRTaW5nbGVNYXRjaChmcm9tLCBjYXNlU2Vuc2l0aXZlLCBmdXp6eSwgcGF0aCwgcHJvY2Vzc2VkVHJlZSkge1xuXHRmcm9tIHx8PSBcIi9cIjtcblx0cGF0aCB8fD0gXCIvXCI7XG5cdGNvbnN0IGtleSA9IGNhc2VTZW5zaXRpdmUgPyBgY2FzZVxcMCR7ZnJvbX1gIDogZnJvbTtcblx0bGV0IHRyZWUgPSBwcm9jZXNzZWRUcmVlLnNpbmdsZUNhY2hlLmdldChrZXkpO1xuXHRpZiAoIXRyZWUpIHtcblx0XHR0cmVlID0gY3JlYXRlU2VnbWVudE5vZGUoKTtcblx0XHRwYXJzZVNlZ21lbnRzKGNhc2VTZW5zaXRpdmUsIHsgZnJvbSB9LCAxLCB0cmVlKTtcblx0XHRwcm9jZXNzZWRUcmVlLnNpbmdsZUNhY2hlLnNldChrZXksIHRyZWUpO1xuXHR9XG5cdHJldHVybiBmaW5kTWF0Y2gocGF0aCwgdHJlZSwgZnV6enkpO1xufVxuZnVuY3Rpb24gZmluZFJvdXRlTWF0Y2gocGF0aCwgcHJvY2Vzc2VkVHJlZSwgZnV6enkgPSBmYWxzZSkge1xuXHRjb25zdCBrZXkgPSBmdXp6eSA/IHBhdGggOiBgbm9mdXp6XFwwJHtwYXRofWA7XG5cdGNvbnN0IGNhY2hlZCA9IHByb2Nlc3NlZFRyZWUubWF0Y2hDYWNoZS5nZXQoa2V5KTtcblx0aWYgKGNhY2hlZCAhPT0gdm9pZCAwKSByZXR1cm4gY2FjaGVkO1xuXHRwYXRoIHx8PSBcIi9cIjtcblx0bGV0IHJlc3VsdDtcblx0dHJ5IHtcblx0XHRyZXN1bHQgPSBmaW5kTWF0Y2gocGF0aCwgcHJvY2Vzc2VkVHJlZS5zZWdtZW50VHJlZSwgZnV6enkpO1xuXHR9IGNhdGNoIChlcnIpIHtcblx0XHRpZiAoZXJyIGluc3RhbmNlb2YgVVJJRXJyb3IpIHJlc3VsdCA9IG51bGw7XG5cdFx0ZWxzZSB0aHJvdyBlcnI7XG5cdH1cblx0aWYgKHJlc3VsdCkgcmVzdWx0LmJyYW5jaCA9IGJ1aWxkUm91dGVCcmFuY2gocmVzdWx0LnJvdXRlKTtcblx0cHJvY2Vzc2VkVHJlZS5tYXRjaENhY2hlLnNldChrZXksIHJlc3VsdCk7XG5cdHJldHVybiByZXN1bHQ7XG59XG4vKipcbiogUHJvY2Vzc2VzIGEgcm91dGUgdHJlZSBpbnRvIGEgc2VnbWVudCB0cmllIGZvciBlZmZpY2llbnQgcGF0aCBtYXRjaGluZy5cbiogQWxzbyBidWlsZHMgbG9va3VwIG1hcHMgZm9yIHJvdXRlcyBieSBJRCBhbmQgYnkgdHJpbW1lZCBmdWxsIHBhdGguXG4qL1xuZnVuY3Rpb24gcHJvY2Vzc1JvdXRlVHJlZShyb3V0ZVRyZWUsIGNhc2VTZW5zaXRpdmUgPSBmYWxzZSkge1xuXHRjb25zdCBzZWdtZW50VHJlZSA9IGNyZWF0ZVNlZ21lbnROb2RlKCk7XG5cdGNvbnN0IGR5bmFtaWNMaXN0c1RvU29ydCA9IFtdO1xuXHRjb25zdCByb3V0ZXNCeUlkID0ge307XG5cdGNvbnN0IHJvdXRlc0J5UGF0aCA9IHt9O1xuXHRsZXQgaW5kZXggPSAwO1xuXHRmdW5jdGlvbiB2aXNpdChyb3V0ZSwgc3RhcnQsIHBhcmVudE5vZGUsIHBhcmVudEludGVycG9sYXRpb24pIHtcblx0XHRyb3V0ZS5pbml0KGluZGV4KTtcblx0XHRpZiAocm91dGUuaWQgaW4gcm91dGVzQnlJZCkge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhyb3cgbmV3IEVycm9yKGBJbnZhcmlhbnQgZmFpbGVkOiBEdXBsaWNhdGUgcm91dGVzIGZvdW5kIHdpdGggaWQ6ICR7U3RyaW5nKHJvdXRlLmlkKX1gKTtcblx0XHRcdGludmFyaWFudCgpO1xuXHRcdH1cblx0XHRyb3V0ZXNCeUlkW3JvdXRlLmlkXSA9IHJvdXRlO1xuXHRcdGlmIChpbmRleCAhPT0gMCAmJiByb3V0ZS5wYXRoKSB7XG5cdFx0XHRjb25zdCB0cmltbWVkRnVsbFBhdGggPSB0cmltUGF0aFJpZ2h0KHJvdXRlLmZ1bGxQYXRoKTtcblx0XHRcdGlmICghcm91dGVzQnlQYXRoW3RyaW1tZWRGdWxsUGF0aF0gfHwgcm91dGUuZnVsbFBhdGguZW5kc1dpdGgoXCIvXCIpKSByb3V0ZXNCeVBhdGhbdHJpbW1lZEZ1bGxQYXRoXSA9IHJvdXRlO1xuXHRcdH1cblx0XHRpbmRleCsrO1xuXHRcdGNvbnN0IFtub2RlLCBjdXJzb3IsIHNlZ21lbnRzXSA9IHBhcnNlU2VnbWVudHMoY2FzZVNlbnNpdGl2ZSwgcm91dGUsIHN0YXJ0LCBwYXJlbnROb2RlLCBkeW5hbWljTGlzdHNUb1NvcnQsIHBhcmVudEludGVycG9sYXRpb24pO1xuXHRcdHJvdXRlLl9pbnRlcnBvbGF0aW9uID0gc2VnbWVudHM7XG5cdFx0aWYgKHJvdXRlLmNoaWxkcmVuKSBmb3IgKGNvbnN0IGNoaWxkIG9mIHJvdXRlLmNoaWxkcmVuKSB2aXNpdChjaGlsZCwgY3Vyc29yLCBub2RlLCBzZWdtZW50cyk7XG5cdH1cblx0dmlzaXQocm91dGVUcmVlLCAxLCBzZWdtZW50VHJlZSk7XG5cdGZvciAoY29uc3Qgbm9kZXMgb2YgZHluYW1pY0xpc3RzVG9Tb3J0KSBub2Rlcy5zb3J0KHNvcnREeW5hbWljKTtcblx0cmV0dXJuIHtcblx0XHRwcm9jZXNzZWRUcmVlOiB7XG5cdFx0XHRzZWdtZW50VHJlZSxcblx0XHRcdHNpbmdsZUNhY2hlOiBjcmVhdGVTaWV2ZUNhY2hlKDFlMyksXG5cdFx0XHRtYXRjaENhY2hlOiBjcmVhdGVTaWV2ZUNhY2hlKDFlMyksXG5cdFx0XHRmbGF0Q2FjaGU6IG51bGwsXG5cdFx0XHRtYXNrc1RyZWU6IG51bGxcblx0XHR9LFxuXHRcdHJvdXRlc0J5SWQsXG5cdFx0cm91dGVzQnlQYXRoXG5cdH07XG59XG5mdW5jdGlvbiBmaW5kTWF0Y2gocGF0aCwgc2VnbWVudFRyZWUsIGZ1enp5ID0gZmFsc2UpIHtcblx0Y29uc3QgcGFydHMgPSBwYXRoLnNwbGl0KFwiL1wiKTtcblx0Y29uc3QgbGVhZiA9IGdldE5vZGVNYXRjaChwYXRoLCBwYXJ0cywgc2VnbWVudFRyZWUsIGZ1enp5KTtcblx0aWYgKCFsZWFmKSByZXR1cm4gbnVsbDtcblx0Y29uc3QgW3Jhd1BhcmFtc10gPSBleHRyYWN0UGFyYW1zKHBhdGgsIHBhcnRzLCBsZWFmKTtcblx0cmV0dXJuIHtcblx0XHRyb3V0ZTogbGVhZi5ub2RlLnJvdXRlLFxuXHRcdHJhd1BhcmFtc1xuXHR9O1xufVxuLyoqXG4qIFRoaXMgZnVuY3Rpb24gaXMgXCJyZXN1bWFibGVcIjpcbiogLSB0aGUgYGxlYWZgIGlucHV0IGNhbiBjb250YWluIGBleHRyYWN0YCBhbmQgYHJhd1BhcmFtc2AgcHJvcGVydGllcyBmcm9tIGEgcHJldmlvdXMgYGV4dHJhY3RQYXJhbXNgIGNhbGxcbiogLSB0aGUgcmV0dXJuZWQgYHN0YXRlYCBjYW4gYmUgcGFzc2VkIGJhY2sgYXMgYGV4dHJhY3RgIGluIGEgZnV0dXJlIGNhbGwgdG8gY29udGludWUgZXh0cmFjdGluZyBwYXJhbXMgZnJvbSB3aGVyZSB3ZSBsZWZ0IG9mZlxuKlxuKiBJbnB1dHMgYXJlICpub3QqIG11dGF0ZWQuXG4qL1xuZnVuY3Rpb24gZXh0cmFjdFBhcmFtcyhwYXRoLCBwYXJ0cywgbGVhZikge1xuXHRjb25zdCBsaXN0ID0gYnVpbGRCcmFuY2gobGVhZi5ub2RlKTtcblx0Y29uc3QgbmFtZXMgPSBsZWFmLm5vZGUuZGF0YSAmJiBnZXRQYXJhbU5hbWVzKGxlYWYubm9kZS5kYXRhKTtcblx0Y29uc3QgcmF3UGFyYW1zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0LyoqIHdoaWNoIHNlZ21lbnQgb2YgdGhlIHBhdGggd2UncmUgY3VycmVudGx5IHByb2Nlc3NpbmcgKi9cblx0bGV0IHBhcnRJbmRleCA9IGxlYWYuZXh0cmFjdD8ucGFydCA/PyAwO1xuXHQvKiogd2hpY2ggbm9kZSBvZiB0aGUgcm91dGUgdHJlZSBicmFuY2ggd2UncmUgY3VycmVudGx5IHByb2Nlc3NpbmcgKi9cblx0bGV0IG5vZGVJbmRleCA9IGxlYWYuZXh0cmFjdD8ubm9kZSA/PyAwO1xuXHQvKiogaW5kZXggb2YgdGhlIDFzdCBjaGFyYWN0ZXIgb2YgdGhlIHNlZ21lbnQgd2UncmUgcHJvY2Vzc2luZyBpbiB0aGUgcGF0aCBzdHJpbmcgKi9cblx0bGV0IHBhdGhJbmRleCA9IGxlYWYuZXh0cmFjdD8ucGF0aCA/PyAwO1xuXHQvKiogTmV4dCBvcmlnaW5hbCBwYXJhbWV0ZXIgbmFtZSwgaW5kZXBlbmRlbnQgb2YgcGF0aGxlc3Mvc3RhdGljIG5vZGVzLiAqL1xuXHRsZXQgcGFyYW1JbmRleCA9IGxlYWYuZXh0cmFjdD8ucGFyYW0gPz8gMDtcblx0Zm9yICg7IG5vZGVJbmRleCA8IGxpc3QubGVuZ3RoOyBwYXJ0SW5kZXgrKywgbm9kZUluZGV4KyssIHBhdGhJbmRleCsrKSB7XG5cdFx0Y29uc3Qgbm9kZSA9IGxpc3Rbbm9kZUluZGV4XTtcblx0XHRpZiAobm9kZS5raW5kID09PSBTRUdNRU5UX1RZUEVfSU5ERVgpIGJyZWFrO1xuXHRcdGlmIChub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9QQVRITEVTUykge1xuXHRcdFx0cGFydEluZGV4LS07XG5cdFx0XHRwYXRoSW5kZXgtLTtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCBwYXJ0ID0gcGFydHNbcGFydEluZGV4XTtcblx0XHRjb25zdCBjdXJyZW50UGF0aEluZGV4ID0gcGF0aEluZGV4O1xuXHRcdGlmIChwYXJ0KSBwYXRoSW5kZXggKz0gcGFydC5sZW5ndGg7XG5cdFx0aWYgKG5vZGUua2luZCA9PT0gMSB8fCBub2RlLmtpbmQgPT09IDMpIHtcblx0XHRcdGNvbnN0IG5hbWUgPSBuYW1lc1twYXJhbUluZGV4KytdO1xuXHRcdFx0aWYgKG5vZGUua2luZCA9PT0gMyAmJiBsZWFmLnNraXBwZWQgJiAxIDw8IG5vZGVJbmRleCkge1xuXHRcdFx0XHRwYXJ0SW5kZXgtLTtcblx0XHRcdFx0cGF0aEluZGV4ID0gY3VycmVudFBhdGhJbmRleCAtIDE7XG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgdmFsdWUgPSBub2RlLnN1ZmZpeCB8fCBub2RlLnByZWZpeCA/IHBhcnQuc3Vic3RyaW5nKG5vZGUucHJlZml4Lmxlbmd0aCwgcGFydC5sZW5ndGggLSBub2RlLnN1ZmZpeC5sZW5ndGgpIDogcGFydDtcblx0XHRcdGlmICh2YWx1ZSB8fCBub2RlLmtpbmQgPT09IDEpIHJhd1BhcmFtc1tuYW1lXSA9IGRlY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG5cdFx0fSBlbHNlIGlmIChub2RlLmtpbmQgPT09IDIpIHtcblx0XHRcdGNvbnN0IG4gPSBub2RlO1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBwYXRoLnN1YnN0cmluZyhjdXJyZW50UGF0aEluZGV4ICsgbi5wcmVmaXgubGVuZ3RoLCBwYXRoLmxlbmd0aCAtIG4uc3VmZml4Lmxlbmd0aCk7XG5cdFx0XHRjb25zdCBzcGxhdCA9IGRlY29kZVVSSUNvbXBvbmVudCh2YWx1ZSk7XG5cdFx0XHRyYXdQYXJhbXNbXCIqXCJdID0gc3BsYXQ7XG5cdFx0XHRyYXdQYXJhbXMuX3NwbGF0ID0gc3BsYXQ7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdH1cblx0aWYgKGxlYWYucmF3UGFyYW1zKSBPYmplY3QuYXNzaWduKHJhd1BhcmFtcywgbGVhZi5yYXdQYXJhbXMpO1xuXHRyZXR1cm4gW3Jhd1BhcmFtcywge1xuXHRcdHBhcnQ6IHBhcnRJbmRleCxcblx0XHRub2RlOiBub2RlSW5kZXgsXG5cdFx0cGF0aDogcGF0aEluZGV4LFxuXHRcdHBhcmFtOiBwYXJhbUluZGV4XG5cdH1dO1xufVxuZnVuY3Rpb24gYnVpbGRSb3V0ZUJyYW5jaChyb3V0ZSkge1xuXHRjb25zdCBsaXN0ID0gW3JvdXRlXTtcblx0d2hpbGUgKHJvdXRlLnBhcmVudFJvdXRlKSB7XG5cdFx0cm91dGUgPSByb3V0ZS5wYXJlbnRSb3V0ZTtcblx0XHRsaXN0LnB1c2gocm91dGUpO1xuXHR9XG5cdGxpc3QucmV2ZXJzZSgpO1xuXHRyZXR1cm4gbGlzdDtcbn1cbmZ1bmN0aW9uIGJ1aWxkQnJhbmNoKG5vZGUpIHtcblx0Y29uc3QgbGlzdCA9IEFycmF5KG5vZGUuZGVwdGggKyAxKTtcblx0ZG8ge1xuXHRcdGxpc3Rbbm9kZS5kZXB0aF0gPSBub2RlO1xuXHRcdG5vZGUgPSBub2RlLnBhcmVudDtcblx0fSB3aGlsZSAobm9kZSk7XG5cdHJldHVybiBsaXN0O1xufVxuZnVuY3Rpb24gZ2V0Tm9kZU1hdGNoKHBhdGgsIHBhcnRzLCBzZWdtZW50VHJlZSwgZnV6enkpIHtcblx0aWYgKHBhdGggPT09IFwiL1wiICYmIHNlZ21lbnRUcmVlLmluZGV4KSByZXR1cm4ge1xuXHRcdG5vZGU6IHNlZ21lbnRUcmVlLmluZGV4LFxuXHRcdHNraXBwZWQ6IDBcblx0fTtcblx0Y29uc3QgdHJhaWxpbmdTbGFzaCA9ICFsYXN0KHBhcnRzKTtcblx0Y29uc3QgcGF0aElzSW5kZXggPSB0cmFpbGluZ1NsYXNoICYmIHBhdGggIT09IFwiL1wiO1xuXHRjb25zdCBwYXJ0c0xlbmd0aCA9IHBhcnRzLmxlbmd0aCAtICh0cmFpbGluZ1NsYXNoID8gMSA6IDApO1xuXHRjb25zdCBzdGFjayA9IFt7XG5cdFx0bm9kZTogc2VnbWVudFRyZWUsXG5cdFx0aW5kZXg6IDEsXG5cdFx0c2tpcHBlZDogMCxcblx0XHRzdGF0aWNzOiAwLFxuXHRcdGR5bmFtaWNzOiAwLFxuXHRcdG9wdGlvbmFsczogMFxuXHR9XTtcblx0bGV0IGJlc3RGdXp6eSA9IG51bGw7XG5cdGxldCBiZXN0TWF0Y2ggPSBudWxsO1xuXHR3aGlsZSAoc3RhY2subGVuZ3RoKSB7XG5cdFx0Y29uc3QgZnJhbWUgPSBzdGFjay5wb3AoKTtcblx0XHRjb25zdCB7IG5vZGUsIGluZGV4LCBza2lwcGVkLCBzdGF0aWNzLCBkeW5hbWljcywgb3B0aW9uYWxzIH0gPSBmcmFtZTtcblx0XHRsZXQgeyBleHRyYWN0LCByYXdQYXJhbXMgfSA9IGZyYW1lO1xuXHRcdGlmIChub2RlLmtpbmQgPT09IDIgJiYgbm9kZS5yb3V0ZSAmJiAhaXNGcmFtZU1vcmVTcGVjaWZpYyhiZXN0TWF0Y2gsIGZyYW1lKSkgY29udGludWU7XG5cdFx0aWYgKG5vZGUucGFyc2UpIHtcblx0XHRcdGlmICghdmFsaWRhdGVQYXJzZVBhcmFtcyhwYXRoLCBwYXJ0cywgZnJhbWUpKSBjb250aW51ZTtcblx0XHRcdHJhd1BhcmFtcyA9IGZyYW1lLnJhd1BhcmFtcztcblx0XHRcdGV4dHJhY3QgPSBmcmFtZS5leHRyYWN0O1xuXHRcdH1cblx0XHRpZiAoZnV6enkgJiYgbm9kZS5yb3V0ZSAmJiBub2RlLmtpbmQgIT09IFNFR01FTlRfVFlQRV9JTkRFWCAmJiBpc0ZyYW1lTW9yZVNwZWNpZmljKGJlc3RGdXp6eSwgZnJhbWUpKSBiZXN0RnV6enkgPSBmcmFtZTtcblx0XHRjb25zdCBpc0JleW9uZFBhdGggPSBpbmRleCA9PT0gcGFydHNMZW5ndGg7XG5cdFx0aWYgKGlzQmV5b25kUGF0aCkge1xuXHRcdFx0aWYgKG5vZGUucm91dGUgJiYgKCFwYXRoSXNJbmRleCB8fCBub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCB8fCBub2RlLmtpbmQgPT09IDIpICYmIGlzRnJhbWVNb3JlU3BlY2lmaWMoYmVzdE1hdGNoLCBmcmFtZSkpIGJlc3RNYXRjaCA9IGZyYW1lO1xuXHRcdFx0aWYgKCFub2RlLm9wdGlvbmFsICYmICFub2RlLndpbGRjYXJkICYmICFub2RlLmluZGV4ICYmICFub2RlLnBhdGhsZXNzKSBjb250aW51ZTtcblx0XHR9XG5cdFx0Y29uc3QgcGFydCA9IGlzQmV5b25kUGF0aCA/IHZvaWQgMCA6IHBhcnRzW2luZGV4XTtcblx0XHRsZXQgbG93ZXJQYXJ0O1xuXHRcdGlmIChpc0JleW9uZFBhdGggJiYgbm9kZS5pbmRleCkge1xuXHRcdFx0Y29uc3QgaW5kZXhGcmFtZSA9IHtcblx0XHRcdFx0bm9kZTogbm9kZS5pbmRleCxcblx0XHRcdFx0aW5kZXgsXG5cdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdHN0YXRpY3MsXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fTtcblx0XHRcdGxldCBpbmRleFZhbGlkID0gdHJ1ZTtcblx0XHRcdGlmIChub2RlLmluZGV4LnBhcnNlKSB7XG5cdFx0XHRcdGlmICghdmFsaWRhdGVQYXJzZVBhcmFtcyhwYXRoLCBwYXJ0cywgaW5kZXhGcmFtZSkpIGluZGV4VmFsaWQgPSBmYWxzZTtcblx0XHRcdH1cblx0XHRcdGlmIChpbmRleFZhbGlkKSB7XG5cdFx0XHRcdGlmICghZHluYW1pY3MgJiYgIW9wdGlvbmFscyAmJiAhc2tpcHBlZCAmJiBpc1BlcmZlY3RTdGF0aWNNYXRjaChzdGF0aWNzLCBwYXJ0c0xlbmd0aCkpIHJldHVybiBpbmRleEZyYW1lO1xuXHRcdFx0XHRpZiAoaXNGcmFtZU1vcmVTcGVjaWZpYyhiZXN0TWF0Y2gsIGluZGV4RnJhbWUpKSBiZXN0TWF0Y2ggPSBpbmRleEZyYW1lO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAobm9kZS53aWxkY2FyZCkgZm9yIChsZXQgaSA9IG5vZGUud2lsZGNhcmQubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRcdGNvbnN0IHNlZ21lbnQgPSBub2RlLndpbGRjYXJkW2ldO1xuXHRcdFx0Y29uc3QgeyBwcmVmaXgsIHN1ZmZpeCB9ID0gc2VnbWVudDtcblx0XHRcdGlmIChwcmVmaXgpIHtcblx0XHRcdFx0aWYgKGlzQmV5b25kUGF0aCkgY29udGludWU7XG5cdFx0XHRcdGlmICghKHNlZ21lbnQuY2FzZVNlbnNpdGl2ZSA/IHBhcnQgOiBsb3dlclBhcnQgPz89IHBhcnQudG9Mb3dlckNhc2UoKSkuc3RhcnRzV2l0aChwcmVmaXgpKSBjb250aW51ZTtcblx0XHRcdH1cblx0XHRcdGlmIChzdWZmaXgpIHtcblx0XHRcdFx0aWYgKGlzQmV5b25kUGF0aCkgY29udGludWU7XG5cdFx0XHRcdGNvbnN0IGVuZCA9IHBhcnRzLnNsaWNlKGluZGV4KS5qb2luKFwiL1wiKTtcblx0XHRcdFx0Y29uc3Qgc3VmZml4UGFydCA9IGVuZC5zbGljZSgtc3VmZml4Lmxlbmd0aCk7XG5cdFx0XHRcdGlmICgoc2VnbWVudC5jYXNlU2Vuc2l0aXZlID8gc3VmZml4UGFydCA6IHN1ZmZpeFBhcnQudG9Mb3dlckNhc2UoKSkgIT09IHN1ZmZpeCB8fCBlbmQubGVuZ3RoIC0gc3VmZml4Lmxlbmd0aCA8IHByZWZpeC5sZW5ndGgpIGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0c3RhY2sucHVzaCh7XG5cdFx0XHRcdG5vZGU6IHNlZ21lbnQsXG5cdFx0XHRcdGluZGV4OiBwYXJ0c0xlbmd0aCxcblx0XHRcdFx0c2tpcHBlZCxcblx0XHRcdFx0c3RhdGljcyxcblx0XHRcdFx0ZHluYW1pY3MsXG5cdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0ZXh0cmFjdCxcblx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0aWYgKG5vZGUub3B0aW9uYWwpIHtcblx0XHRcdGNvbnN0IG5leHRTa2lwcGVkID0gc2tpcHBlZCB8IDEgPDwgbm9kZS5kZXB0aCArIDE7XG5cdFx0XHRmb3IgKGxldCBpID0gbm9kZS5vcHRpb25hbC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0XHRjb25zdCBzZWdtZW50ID0gbm9kZS5vcHRpb25hbFtpXTtcblx0XHRcdFx0c3RhY2sucHVzaCh7XG5cdFx0XHRcdFx0bm9kZTogc2VnbWVudCxcblx0XHRcdFx0XHRpbmRleCxcblx0XHRcdFx0XHRza2lwcGVkOiBuZXh0U2tpcHBlZCxcblx0XHRcdFx0XHRzdGF0aWNzLFxuXHRcdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0XHRleHRyYWN0LFxuXHRcdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdGlmICghaXNCZXlvbmRQYXRoKSBmb3IgKGxldCBpID0gbm9kZS5vcHRpb25hbC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0XHRjb25zdCBzZWdtZW50ID0gbm9kZS5vcHRpb25hbFtpXTtcblx0XHRcdFx0Y29uc3QgeyBwcmVmaXgsIHN1ZmZpeCB9ID0gc2VnbWVudDtcblx0XHRcdFx0aWYgKHByZWZpeCB8fCBzdWZmaXgpIHtcblx0XHRcdFx0XHRjb25zdCBjYXNlUGFydCA9IHNlZ21lbnQuY2FzZVNlbnNpdGl2ZSA/IHBhcnQgOiBsb3dlclBhcnQgPz89IHBhcnQudG9Mb3dlckNhc2UoKTtcblx0XHRcdFx0XHRpZiAocHJlZml4ICYmICFjYXNlUGFydC5zdGFydHNXaXRoKHByZWZpeCkpIGNvbnRpbnVlO1xuXHRcdFx0XHRcdGlmIChzdWZmaXggJiYgY2FzZVBhcnQuaW5kZXhPZihzdWZmaXgsIGNhc2VQYXJ0Lmxlbmd0aCAtIHN1ZmZpeC5sZW5ndGgpIDwgcHJlZml4Lmxlbmd0aCkgY29udGludWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0c3RhY2sucHVzaCh7XG5cdFx0XHRcdFx0bm9kZTogc2VnbWVudCxcblx0XHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdFx0c3RhdGljcyxcblx0XHRcdFx0XHRkeW5hbWljcyxcblx0XHRcdFx0XHRvcHRpb25hbHM6IG9wdGlvbmFscyArIHNlZ21lbnRTY29yZShwYXJ0c0xlbmd0aCwgaW5kZXgpLFxuXHRcdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAoIWlzQmV5b25kUGF0aCAmJiBub2RlLmR5bmFtaWMgJiYgcGFydCkgZm9yIChsZXQgaSA9IG5vZGUuZHluYW1pYy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0Y29uc3Qgc2VnbWVudCA9IG5vZGUuZHluYW1pY1tpXTtcblx0XHRcdGNvbnN0IHsgcHJlZml4LCBzdWZmaXggfSA9IHNlZ21lbnQ7XG5cdFx0XHRpZiAocHJlZml4IHx8IHN1ZmZpeCkge1xuXHRcdFx0XHRjb25zdCBjYXNlUGFydCA9IHNlZ21lbnQuY2FzZVNlbnNpdGl2ZSA/IHBhcnQgOiBsb3dlclBhcnQgPz89IHBhcnQudG9Mb3dlckNhc2UoKTtcblx0XHRcdFx0aWYgKHByZWZpeCAmJiAhY2FzZVBhcnQuc3RhcnRzV2l0aChwcmVmaXgpKSBjb250aW51ZTtcblx0XHRcdFx0aWYgKHN1ZmZpeCAmJiBjYXNlUGFydC5pbmRleE9mKHN1ZmZpeCwgY2FzZVBhcnQubGVuZ3RoIC0gc3VmZml4Lmxlbmd0aCkgPCBwcmVmaXgubGVuZ3RoKSBjb250aW51ZTtcblx0XHRcdH1cblx0XHRcdHN0YWNrLnB1c2goe1xuXHRcdFx0XHRub2RlOiBzZWdtZW50LFxuXHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRza2lwcGVkLFxuXHRcdFx0XHRzdGF0aWNzLFxuXHRcdFx0XHRkeW5hbWljczogZHluYW1pY3MgKyBzZWdtZW50U2NvcmUocGFydHNMZW5ndGgsIGluZGV4KSxcblx0XHRcdFx0b3B0aW9uYWxzLFxuXHRcdFx0XHRleHRyYWN0LFxuXHRcdFx0XHRyYXdQYXJhbXNcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAoIWlzQmV5b25kUGF0aCAmJiBub2RlLnN0YXRpY0luc2Vuc2l0aXZlKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG5vZGUuc3RhdGljSW5zZW5zaXRpdmUuZ2V0KGxvd2VyUGFydCA/Pz0gcGFydC50b0xvd2VyQ2FzZSgpKTtcblx0XHRcdGlmIChtYXRjaCkgc3RhY2sucHVzaCh7XG5cdFx0XHRcdG5vZGU6IG1hdGNoLFxuXHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRza2lwcGVkLFxuXHRcdFx0XHRzdGF0aWNzOiBzdGF0aWNzICsgc2VnbWVudFNjb3JlKHBhcnRzTGVuZ3RoLCBpbmRleCksXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmICghaXNCZXlvbmRQYXRoICYmIG5vZGUuc3RhdGljKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG5vZGUuc3RhdGljLmdldChwYXJ0KTtcblx0XHRcdGlmIChtYXRjaCkgc3RhY2sucHVzaCh7XG5cdFx0XHRcdG5vZGU6IG1hdGNoLFxuXHRcdFx0XHRpbmRleDogaW5kZXggKyAxLFxuXHRcdFx0XHRza2lwcGVkLFxuXHRcdFx0XHRzdGF0aWNzOiBzdGF0aWNzICsgc2VnbWVudFNjb3JlKHBhcnRzTGVuZ3RoLCBpbmRleCksXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmIChub2RlLnBhdGhsZXNzKSBmb3IgKGxldCBpID0gbm9kZS5wYXRobGVzcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0Y29uc3Qgc2VnbWVudCA9IG5vZGUucGF0aGxlc3NbaV07XG5cdFx0XHRzdGFjay5wdXNoKHtcblx0XHRcdFx0bm9kZTogc2VnbWVudCxcblx0XHRcdFx0aW5kZXgsXG5cdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdHN0YXRpY3MsXG5cdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fSk7XG5cdFx0fVxuXHR9XG5cdGlmIChiZXN0TWF0Y2gpIHJldHVybiBiZXN0TWF0Y2g7XG5cdGlmIChmdXp6eSAmJiBiZXN0RnV6enkpIHtcblx0XHRsZXQgc2xpY2VJbmRleCA9IGJlc3RGdXp6eS5pbmRleDtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGJlc3RGdXp6eS5pbmRleDsgaSsrKSBzbGljZUluZGV4ICs9IHBhcnRzW2ldLmxlbmd0aDtcblx0XHRjb25zdCBzcGxhdCA9IHNsaWNlSW5kZXggPT09IHBhdGgubGVuZ3RoID8gXCIvXCIgOiBwYXRoLnNsaWNlKHNsaWNlSW5kZXgpO1xuXHRcdGJlc3RGdXp6eS5yYXdQYXJhbXMgPz89IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cdFx0YmVzdEZ1enp5LnJhd1BhcmFtc1tcIioqXCJdID0gZGVjb2RlVVJJQ29tcG9uZW50KHNwbGF0KTtcblx0XHRyZXR1cm4gYmVzdEZ1enp5O1xuXHR9XG5cdHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gc2VnbWVudFNjb3JlKHBhcnRzTGVuZ3RoLCBpbmRleCkge1xuXHRyZXR1cm4gMiAqKiAocGFydHNMZW5ndGggLSBpbmRleCAtIDEpO1xufVxuZnVuY3Rpb24gaXNQZXJmZWN0U3RhdGljTWF0Y2goc3RhdGljcywgcGFydHNMZW5ndGgpIHtcblx0cmV0dXJuIHN0YXRpY3MgPT09IDIgKiogKHBhcnRzTGVuZ3RoIC0gMSkgLSAxO1xufVxuZnVuY3Rpb24gdmFsaWRhdGVQYXJzZVBhcmFtcyhwYXRoLCBwYXJ0cywgZnJhbWUpIHtcblx0bGV0IHJhd1BhcmFtcztcblx0bGV0IHN0YXRlO1xuXHR0cnkge1xuXHRcdFtyYXdQYXJhbXMsIHN0YXRlXSA9IGV4dHJhY3RQYXJhbXMocGF0aCwgcGFydHMsIGZyYW1lKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cblx0ZnJhbWUucmF3UGFyYW1zID0gcmF3UGFyYW1zO1xuXHRmcmFtZS5leHRyYWN0ID0gc3RhdGU7XG5cdGlmICghZnJhbWUubm9kZS5wYXJzZSkgcmV0dXJuIHRydWU7XG5cdHRyeSB7XG5cdFx0aWYgKGZyYW1lLm5vZGUucGFyc2UocmF3UGFyYW1zKSA9PT0gZmFsc2UpIHJldHVybiBudWxsO1xuXHR9IGNhdGNoIHt9XG5cdHJldHVybiB0cnVlO1xufVxuZnVuY3Rpb24gaXNGcmFtZU1vcmVTcGVjaWZpYyhwcmV2LCBuZXh0KSB7XG5cdGlmICghcHJldikgcmV0dXJuIHRydWU7XG5cdHJldHVybiBuZXh0LnN0YXRpY3MgPiBwcmV2LnN0YXRpY3MgfHwgbmV4dC5zdGF0aWNzID09PSBwcmV2LnN0YXRpY3MgJiYgKG5leHQuZHluYW1pY3MgPiBwcmV2LmR5bmFtaWNzIHx8IG5leHQuZHluYW1pY3MgPT09IHByZXYuZHluYW1pY3MgJiYgKG5leHQub3B0aW9uYWxzID4gcHJldi5vcHRpb25hbHMgfHwgbmV4dC5vcHRpb25hbHMgPT09IHByZXYub3B0aW9uYWxzICYmICgobmV4dC5ub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCkgPiAocHJldi5ub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCkgfHwgbmV4dC5ub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCA9PT0gKHByZXYubm9kZS5raW5kID09PSBTRUdNRU5UX1RZUEVfSU5ERVgpICYmIG5leHQubm9kZS5kZXB0aCA+IHByZXYubm9kZS5kZXB0aCkpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYnVpbGRSb3V0ZUJyYW5jaCwgZmluZEZsYXRNYXRjaCwgZmluZFJvdXRlTWF0Y2gsIGZpbmRTaW5nbGVNYXRjaCwgcGFyc2VTZWdtZW50cywgcHJvY2Vzc1JvdXRlTWFza3MsIHByb2Nlc3NSb3V0ZVRyZWUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bmV3LXByb2Nlc3Mtcm91dGUtdHJlZS5qcy5tYXAiLCJpbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbi8vI3JlZ2lvbiBzcmMvc2Nyb2xsLXJlc3RvcmF0aW9uLnRzXG5mdW5jdGlvbiBnZXRTYWZlU2Vzc2lvblN0b3JhZ2UoKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIHNlc3Npb25TdG9yYWdlO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm47XG5cdH1cbn1cbmNvbnN0IHN0b3JhZ2VLZXkgPSBcInRzci1zY3JvbGwtcmVzdG9yYXRpb24tdjFfM1wiO1xuY29uc3Qgc2FmZVNlc3Npb25TdG9yYWdlID0gZ2V0U2FmZVNlc3Npb25TdG9yYWdlKCk7XG5mdW5jdGlvbiBjcmVhdGVTY3JvbGxSZXN0b3JhdGlvbkNhY2hlKCkge1xuXHR0cnkge1xuXHRcdHJldHVybiBKU09OLnBhcnNlKHNhZmVTZXNzaW9uU3RvcmFnZT8uZ2V0SXRlbShcInRzci1zY3JvbGwtcmVzdG9yYXRpb24tdjFfM1wiKSB8fCBcInt9XCIpO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4ge307XG5cdH1cbn1cbmNvbnN0IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlU2Nyb2xsUmVzdG9yYXRpb25DYWNoZSgpO1xuY29uc3Qgc2Nyb2xsUmVzdG9yYXRpb25JZEF0dHJpYnV0ZSA9IFwiZGF0YS1zY3JvbGwtcmVzdG9yYXRpb24taWRcIjtcbi8qKlxuKiBUaGUgZGVmYXVsdCBgZ2V0S2V5YCBmdW5jdGlvbiBmb3IgYHVzZVNjcm9sbFJlc3RvcmF0aW9uYC5cbiogSXQgcmV0dXJucyB0aGUgYGtleWAgZnJvbSB0aGUgbG9jYXRpb24gc3RhdGUgb3IgdGhlIGBocmVmYCBvZiB0aGUgbG9jYXRpb24uXG4qXG4qIFRoZSBgbG9jYXRpb24uaHJlZmAgaXMgdXNlZCBhcyBhIGZhbGxiYWNrIHRvIHN1cHBvcnQgdGhlIHVzZSBjYXNlIHdoZXJlIHRoZSBsb2NhdGlvbiBzdGF0ZSBpcyBub3QgYXZhaWxhYmxlIGxpa2UgdGhlIGluaXRpYWwgcmVuZGVyLlxuKi9cbmNvbnN0IGRlZmF1bHRHZXRTY3JvbGxSZXN0b3JhdGlvbktleSA9IChsb2NhdGlvbikgPT4ge1xuXHRyZXR1cm4gbG9jYXRpb24uc3RhdGUuX19UU1Jfa2V5IHx8IGxvY2F0aW9uLmhyZWY7XG59O1xuZnVuY3Rpb24gZ2V0U2Nyb2xsUmVzdG9yYXRpb25TZWxlY3RvcihlbGVtZW50KSB7XG5cdGNvbnN0IGF0dHJJZCA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKHNjcm9sbFJlc3RvcmF0aW9uSWRBdHRyaWJ1dGUpO1xuXHRpZiAoYXR0cklkKSByZXR1cm4gYFske3Njcm9sbFJlc3RvcmF0aW9uSWRBdHRyaWJ1dGV9PVwiJHthdHRySWR9XCJdYDtcblx0bGV0IHNlbGVjdG9yID0gXCJcIjtcblx0bGV0IGVsID0gZWxlbWVudDtcblx0bGV0IHBhcmVudDtcblx0d2hpbGUgKHBhcmVudCA9IGVsLnBhcmVudE5vZGUpIHtcblx0XHRsZXQgaW5kZXggPSAxO1xuXHRcdGxldCBzaWJsaW5nID0gZWw7XG5cdFx0d2hpbGUgKHNpYmxpbmcgPSBzaWJsaW5nLnByZXZpb3VzRWxlbWVudFNpYmxpbmcpIGluZGV4Kys7XG5cdFx0Y29uc3QgcGFydCA9IGAke2VsLmxvY2FsTmFtZX06bnRoLWNoaWxkKCR7aW5kZXh9KWA7XG5cdFx0c2VsZWN0b3IgPSBzZWxlY3RvciA/IGAke3BhcnR9ID4gJHtzZWxlY3Rvcn1gIDogcGFydDtcblx0XHRlbCA9IHBhcmVudDtcblx0fVxuXHRyZXR1cm4gc2VsZWN0b3I7XG59XG5mdW5jdGlvbiBnZXRFbGVtZW50U2Nyb2xsUmVzdG9yYXRpb25FbnRyeShyb3V0ZXIsIG9wdGlvbnMpIHtcblx0Y29uc3QgZW50cmllcyA9IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbKG9wdGlvbnMuZ2V0S2V5IHx8IGRlZmF1bHRHZXRTY3JvbGxSZXN0b3JhdGlvbktleSkocm91dGVyLmxhdGVzdExvY2F0aW9uKV07XG5cdGlmICghZW50cmllcykgcmV0dXJuO1xuXHRpZiAob3B0aW9ucy5pZCkgcmV0dXJuIGVudHJpZXNbYFske3Njcm9sbFJlc3RvcmF0aW9uSWRBdHRyaWJ1dGV9PVwiJHtvcHRpb25zLmlkfVwiXWBdO1xuXHRjb25zdCBlbGVtZW50ID0gb3B0aW9ucy5nZXRFbGVtZW50Py4oKTtcblx0aWYgKCFlbGVtZW50KSByZXR1cm47XG5cdHJldHVybiBlbnRyaWVzW2VsZW1lbnQgPT09IHdpbmRvdyA/IHdpbmRvd1Njcm9sbFRhcmdldCA6IGdldFNjcm9sbFJlc3RvcmF0aW9uU2VsZWN0b3IoZWxlbWVudCldO1xufVxubGV0IGlnbm9yZVNjcm9sbCA9IGZhbHNlO1xuY29uc3Qgd2luZG93U2Nyb2xsVGFyZ2V0ID0gXCJ3aW5kb3dcIjtcbmZ1bmN0aW9uIGdldEVsZW1lbnQoc2VsZWN0b3IpIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gdHlwZW9mIHNlbGVjdG9yID09PSBcImZ1bmN0aW9uXCIgPyBzZWxlY3RvcigpIDogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XG5cdH0gY2F0Y2gge31cbn1cbmZ1bmN0aW9uIGdldFNjcm9sbFRvVG9wRWxlbWVudHMoc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpIHtcblx0Y29uc3QgZWxlbWVudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRmb3IgKGNvbnN0IHNlbGVjdG9yIG9mIHNjcm9sbFRvVG9wU2VsZWN0b3JzKSB7XG5cdFx0aWYgKHNlbGVjdG9yID09PSB3aW5kb3dTY3JvbGxUYXJnZXQpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IGVsZW1lbnQgPSBnZXRFbGVtZW50KHNlbGVjdG9yKTtcblx0XHRpZiAoZWxlbWVudCkgZWxlbWVudHMuYWRkKGVsZW1lbnQpO1xuXHR9XG5cdHJldHVybiBlbGVtZW50cztcbn1cbmZ1bmN0aW9uIHNldHVwU2Nyb2xsUmVzdG9yYXRpb24ocm91dGVyLCBmb3JjZSkge1xuXHRjb25zdCBzaG91bGRTZXR1cFNjcm9sbFJlc3RvcmF0aW9uID0gZm9yY2UgPz8gcm91dGVyLm9wdGlvbnMuc2Nyb2xsUmVzdG9yYXRpb247XG5cdGNvbnN0IHNjcm9sbCA9IHJvdXRlci5fc2Nyb2xsO1xuXHRpZiAoc2hvdWxkU2V0dXBTY3JvbGxSZXN0b3JhdGlvbikgc2Nyb2xsLmUgPSB0cnVlO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSByZXR1cm47XG5cdGNvbnN0IGdldEtleSA9IHJvdXRlci5vcHRpb25zLmdldFNjcm9sbFJlc3RvcmF0aW9uS2V5IHx8IGRlZmF1bHRHZXRTY3JvbGxSZXN0b3JhdGlvbktleTtcblx0Y29uc3QgdHJhY2tlZFNjcm9sbFRhcmdldHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRjb25zdCBzbmFwc2hvdEN1cnJlbnRTY3JvbGxUYXJnZXRzID0gKHJlc3RvcmVLZXkpID0+IHtcblx0XHRjb25zdCBrZXlFbnRyeSA9IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbcmVzdG9yZUtleV0gfHw9IHt9O1xuXHRcdGZvciAoY29uc3QgdGFyZ2V0IG9mIHRyYWNrZWRTY3JvbGxUYXJnZXRzKSBpZiAodGFyZ2V0ID09PSBkb2N1bWVudCkga2V5RW50cnlbd2luZG93U2Nyb2xsVGFyZ2V0XSA9IHtcblx0XHRcdHNjcm9sbFgsXG5cdFx0XHRzY3JvbGxZXG5cdFx0fTtcblx0XHRlbHNlIGlmICh0YXJnZXQuaXNDb25uZWN0ZWQpIGtleUVudHJ5W2dldFNjcm9sbFJlc3RvcmF0aW9uU2VsZWN0b3IodGFyZ2V0KV0gPSB7XG5cdFx0XHRzY3JvbGxYOiB0YXJnZXQuc2Nyb2xsTGVmdCxcblx0XHRcdHNjcm9sbFk6IHRhcmdldC5zY3JvbGxUb3Bcblx0XHR9O1xuXHR9O1xuXHRpZiAoc2hvdWxkU2V0dXBTY3JvbGxSZXN0b3JhdGlvbiAmJiAhc2Nyb2xsLnMpIHtcblx0XHRzY3JvbGwucyA9IHRydWU7XG5cdFx0aWdub3JlU2Nyb2xsID0gZmFsc2U7XG5cdFx0aGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwibWFudWFsXCI7XG5cdFx0ZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcInNjcm9sbFwiLCAoZXZlbnQpID0+IHtcblx0XHRcdGlmIChpZ25vcmVTY3JvbGwpIHJldHVybjtcblx0XHRcdHRyYWNrZWRTY3JvbGxUYXJnZXRzLmFkZChldmVudC50YXJnZXQpO1xuXHRcdH0sIHRydWUpO1xuXHRcdHJvdXRlci5zdWJzY3JpYmUoXCJvbkJlZm9yZUxvYWRcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRpZiAoZXZlbnQuZnJvbUxvY2F0aW9uKSBzbmFwc2hvdEN1cnJlbnRTY3JvbGxUYXJnZXRzKGdldEtleShldmVudC5mcm9tTG9jYXRpb24pKTtcblx0XHRcdHRyYWNrZWRTY3JvbGxUYXJnZXRzLmNsZWFyKCk7XG5cdFx0fSk7XG5cdFx0YWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VoaWRlXCIsICgpID0+IHtcblx0XHRcdGhpc3Rvcnkuc2Nyb2xsUmVzdG9yYXRpb24gPSBcImF1dG9cIjtcblx0XHRcdHNuYXBzaG90Q3VycmVudFNjcm9sbFRhcmdldHMoZ2V0S2V5KHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5nZXQoKSA/PyByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpKSk7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRzYWZlU2Vzc2lvblN0b3JhZ2U/LnNldEl0ZW0oc3RvcmFnZUtleSwgSlNPTi5zdHJpbmdpZnkoc2Nyb2xsUmVzdG9yYXRpb25DYWNoZSkpO1xuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihcIlt0cy1yb3V0ZXJdIENvdWxkIG5vdCBwZXJzaXN0IHNjcm9sbCByZXN0b3JhdGlvbiBzdGF0ZSB0byBzZXNzaW9uU3RvcmFnZS5cIik7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0YWRkRXZlbnRMaXN0ZW5lcihcInBhZ2VzaG93XCIsIChldmVudCkgPT4ge1xuXHRcdFx0aWYgKGV2ZW50LnBlcnNpc3RlZCkgaGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwibWFudWFsXCI7XG5cdFx0fSk7XG5cdH1cblx0aWYgKHNjcm9sbC5yKSByZXR1cm47XG5cdHNjcm9sbC5yID0gdHJ1ZTtcblx0cm91dGVyLnN1YnNjcmliZShcIm9uUmVuZGVyZWRcIiwgKGV2ZW50KSA9PiB7XG5cdFx0Y29uc3QgYmVoYXZpb3IgPSByb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbkJlaGF2aW9yO1xuXHRcdGNvbnN0IHNjcm9sbFRvVG9wU2VsZWN0b3JzID0gcm91dGVyLm9wdGlvbnMuc2Nyb2xsVG9Ub3BTZWxlY3RvcnM7XG5cdFx0Y29uc3Qgc2hvdWxkUmVzZXRTY3JvbGwgPSBzY3JvbGwubjtcblx0XHRjb25zdCBoYXNoTmF2aWdhdGlvbiA9IHNjcm9sbC5oO1xuXHRcdGxldCBzY3JvbGxUb1RvcEVsZW1lbnRzO1xuXHRcdHRyYWNrZWRTY3JvbGxUYXJnZXRzLmNsZWFyKCk7XG5cdFx0c2Nyb2xsLm4gPSB0cnVlO1xuXHRcdHNjcm9sbC5oID0gZmFsc2U7XG5cdFx0aWYgKHR5cGVvZiByb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbiA9PT0gXCJmdW5jdGlvblwiICYmICFyb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbih7IGxvY2F0aW9uOiByb3V0ZXIubGF0ZXN0TG9jYXRpb24gfSkpIHJldHVybjtcblx0XHRjb25zdCBjYWNoZUtleSA9IGdldEtleShldmVudC50b0xvY2F0aW9uKTtcblx0XHRjb25zdCBmcm9tQ2FjaGVLZXkgPSBldmVudC5mcm9tTG9jYXRpb24gJiYgZ2V0S2V5KGV2ZW50LmZyb21Mb2NhdGlvbik7XG5cdFx0aWYgKHNjcm9sbC5lICYmIGZyb21DYWNoZUtleSAmJiBmcm9tQ2FjaGVLZXkgIT09IGNhY2hlS2V5KSB7XG5cdFx0XHRjb25zdCBmcm9tRWxlbWVudEVudHJpZXMgPSBzY3JvbGxSZXN0b3JhdGlvbkNhY2hlW2Zyb21DYWNoZUtleV07XG5cdFx0XHRpZiAoZnJvbUVsZW1lbnRFbnRyaWVzKSB7XG5cdFx0XHRcdGxldCB0b0VsZW1lbnRFbnRyaWVzID0gc2Nyb2xsUmVzdG9yYXRpb25DYWNoZVtjYWNoZUtleV07XG5cdFx0XHRcdGZvciAoY29uc3QgZWxlbWVudFNlbGVjdG9yIGluIGZyb21FbGVtZW50RW50cmllcykge1xuXHRcdFx0XHRcdGlmIChlbGVtZW50U2VsZWN0b3IgPT09IHdpbmRvd1Njcm9sbFRhcmdldCkge1xuXHRcdFx0XHRcdFx0aWYgKHNob3VsZFJlc2V0U2Nyb2xsKSBjb250aW51ZTtcblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0Y29uc3QgZWxlbWVudCA9IGdldEVsZW1lbnQoZWxlbWVudFNlbGVjdG9yKTtcblx0XHRcdFx0XHRcdGlmICghZWxlbWVudCkgY29udGludWU7XG5cdFx0XHRcdFx0XHRpZiAoc2hvdWxkUmVzZXRTY3JvbGwgJiYgc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpIHtcblx0XHRcdFx0XHRcdFx0c2Nyb2xsVG9Ub3BFbGVtZW50cyA/Pz0gZ2V0U2Nyb2xsVG9Ub3BFbGVtZW50cyhzY3JvbGxUb1RvcFNlbGVjdG9ycyk7XG5cdFx0XHRcdFx0XHRcdGlmIChzY3JvbGxUb1RvcEVsZW1lbnRzLmhhcyhlbGVtZW50KSkgY29udGludWU7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghdG9FbGVtZW50RW50cmllcykgdG9FbGVtZW50RW50cmllcyA9IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbY2FjaGVLZXldID0ge307XG5cdFx0XHRcdFx0dG9FbGVtZW50RW50cmllc1tlbGVtZW50U2VsZWN0b3JdID8/PSBmcm9tRWxlbWVudEVudHJpZXNbZWxlbWVudFNlbGVjdG9yXTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0XHRpZ25vcmVTY3JvbGwgPSB0cnVlO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBoYXNoID0gZXZlbnQudG9Mb2NhdGlvbi5oYXNoO1xuXHRcdFx0Y29uc3QgaGFzaFNjcm9sbEludG9WaWV3T3B0aW9ucyA9IGV2ZW50LnRvTG9jYXRpb24uc3RhdGUuX19oYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zID8/IHRydWU7XG5cdFx0XHRsZXQgd2luZG93UmVzdG9yZWQgPSBmYWxzZTtcblx0XHRcdGlmIChzaG91bGRSZXNldFNjcm9sbCkge1xuXHRcdFx0XHRpZiAoIWhhc2ggJiYgc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpIHNjcm9sbFRvVG9wRWxlbWVudHMgPz89IGdldFNjcm9sbFRvVG9wRWxlbWVudHMoc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpO1xuXHRcdFx0XHRjb25zdCBza2lwV2luZG93UmVzdG9yZSA9IGhhc2ggJiYgaGFzaFNjcm9sbEludG9WaWV3T3B0aW9ucyAmJiBoYXNoTmF2aWdhdGlvbjtcblx0XHRcdFx0Y29uc3QgZWxlbWVudEVudHJpZXMgPSBzY3JvbGwuZSA/IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbY2FjaGVLZXldIDogdm9pZCAwO1xuXHRcdFx0XHRpZiAoZWxlbWVudEVudHJpZXMpIGZvciAoY29uc3QgZWxlbWVudFNlbGVjdG9yIGluIGVsZW1lbnRFbnRyaWVzKSB7XG5cdFx0XHRcdFx0Y29uc3QgeyBzY3JvbGxYLCBzY3JvbGxZIH0gPSBlbGVtZW50RW50cmllc1tlbGVtZW50U2VsZWN0b3JdO1xuXHRcdFx0XHRcdGlmIChlbGVtZW50U2VsZWN0b3IgPT09IHdpbmRvd1Njcm9sbFRhcmdldCkge1xuXHRcdFx0XHRcdFx0aWYgKHNraXBXaW5kb3dSZXN0b3JlKSBjb250aW51ZTtcblx0XHRcdFx0XHRcdHNjcm9sbFRvKHtcblx0XHRcdFx0XHRcdFx0dG9wOiBzY3JvbGxZLFxuXHRcdFx0XHRcdFx0XHRsZWZ0OiBzY3JvbGxYLFxuXHRcdFx0XHRcdFx0XHRiZWhhdmlvclxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHR3aW5kb3dSZXN0b3JlZCA9IHRydWU7XG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGNvbnN0IGVsZW1lbnQgPSBnZXRFbGVtZW50KGVsZW1lbnRTZWxlY3Rvcik7XG5cdFx0XHRcdFx0XHRpZiAoZWxlbWVudCkge1xuXHRcdFx0XHRcdFx0XHRlbGVtZW50LnNjcm9sbExlZnQgPSBzY3JvbGxYO1xuXHRcdFx0XHRcdFx0XHRlbGVtZW50LnNjcm9sbFRvcCA9IHNjcm9sbFk7XG5cdFx0XHRcdFx0XHRcdHNjcm9sbFRvVG9wRWxlbWVudHM/LmRlbGV0ZShlbGVtZW50KTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKCFoYXNoKSB7XG5cdFx0XHRcdFx0Y29uc3Qgc2Nyb2xsT3B0aW9ucyA9IHtcblx0XHRcdFx0XHRcdHRvcDogMCxcblx0XHRcdFx0XHRcdGxlZnQ6IDAsXG5cdFx0XHRcdFx0XHRiZWhhdmlvclxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0aWYgKCF3aW5kb3dSZXN0b3JlZCkgc2Nyb2xsVG8oc2Nyb2xsT3B0aW9ucyk7XG5cdFx0XHRcdFx0aWYgKHNjcm9sbFRvVG9wRWxlbWVudHMpIGZvciAoY29uc3QgZWxlbWVudCBvZiBzY3JvbGxUb1RvcEVsZW1lbnRzKSBlbGVtZW50LnNjcm9sbFRvKHNjcm9sbE9wdGlvbnMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoIXdpbmRvd1Jlc3RvcmVkICYmIGhhc2ggJiYgaGFzaFNjcm9sbEludG9WaWV3T3B0aW9ucykgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoaGFzaCk/LnNjcm9sbEludG9WaWV3KGhhc2hTY3JvbGxJbnRvVmlld09wdGlvbnMpO1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRpZ25vcmVTY3JvbGwgPSBmYWxzZTtcblx0XHR9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWZhdWx0R2V0U2Nyb2xsUmVzdG9yYXRpb25LZXksIGdldEVsZW1lbnRTY3JvbGxSZXN0b3JhdGlvbkVudHJ5LCBzZXR1cFNjcm9sbFJlc3RvcmF0aW9uLCBzdG9yYWdlS2V5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNjcm9sbC1yZXN0b3JhdGlvbi5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3Fzcy50c1xuLyoqXG4qIFByb2dyYW0gaXMgYSByZWltcGxlbWVudGF0aW9uIG9mIHRoZSBgcXNzYCBwYWNrYWdlOlxuKiBDb3B5cmlnaHQgKGMpIEx1a2UgRWR3YXJkcyBsdWtlLmVkd2FyZHMwNUBnbWFpbC5jb20sIE1JVCBMaWNlbnNlXG4qIGh0dHBzOi8vZ2l0aHViLmNvbS9sdWtlZWQvcXNzL2Jsb2IvbWFzdGVyL2xpY2Vuc2UubWRcbipcbiogVGhpcyByZWltcGxlbWVudGF0aW9uIHVzZXMgbW9kZXJuIGJyb3dzZXIgQVBJc1xuKiAobmFtZWx5IFVSTFNlYXJjaFBhcmFtcykgYW5kIFR5cGVTY3JpcHQgd2hpbGUgc3RpbGxcbiogbWFpbnRhaW5pbmcgdGhlIG9yaWdpbmFsIGZ1bmN0aW9uYWxpdHkgYW5kIGludGVyZmFjZS5cbipcbiogVXBkYXRlOiB0aGlzIGltcGxlbWVudGF0aW9uIGhhcyBhbHNvIGJlZW4gbWFuZ2xlZCB0b1xuKiBmaXQgZXhhY3RseSBvdXIgdXNlLWNhc2UgKHNpbmdsZSB2YWx1ZSBwZXIga2V5IGluIGVuY29kaW5nKS5cbiovXG4vKipcbiogRW5jb2RlcyBhbiBvYmplY3QgaW50byBhIHF1ZXJ5IHN0cmluZy5cbiogQHBhcmFtIG9iaiAtIFRoZSBvYmplY3QgdG8gZW5jb2RlIGludG8gYSBxdWVyeSBzdHJpbmcuXG4qIEBwYXJhbSBzdHJpbmdpZnkgLSBBbiBvcHRpb25hbCBjdXN0b20gc3RyaW5naWZ5IGZ1bmN0aW9uLlxuKiBAcmV0dXJucyBUaGUgZW5jb2RlZCBxdWVyeSBzdHJpbmcuXG4qIEBleGFtcGxlXG4qIGBgYFxuKiAvLyBFeGFtcGxlIGlucHV0OiBlbmNvZGUoeyB0b2tlbjogJ2ZvbycsIGtleTogJ3ZhbHVlJyB9KVxuKiAvLyBFeHBlY3RlZCBvdXRwdXQ6IFwidG9rZW49Zm9vJmtleT12YWx1ZVwiXG4qIGBgYFxuKi9cbmZ1bmN0aW9uIGVuY29kZShvYmosIHN0cmluZ2lmeSA9IFN0cmluZykge1xuXHRsZXQgcmVzdWx0O1xuXHRmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcblx0XHRjb25zdCB2YWwgPSBvYmpba2V5XTtcblx0XHRpZiAodmFsICE9PSB2b2lkIDApIChyZXN1bHQgfHw9IG5ldyBVUkxTZWFyY2hQYXJhbXMoKSkuc2V0KGtleSwgc3RyaW5naWZ5KHZhbCkpO1xuXHR9XG5cdHJldHVybiByZXN1bHQgPyByZXN1bHQudG9TdHJpbmcoKSA6IFwiXCI7XG59XG4vKipcbiogQ29udmVydHMgYSBzdHJpbmcgdmFsdWUgdG8gaXRzIGFwcHJvcHJpYXRlIHR5cGUgKHN0cmluZywgbnVtYmVyLCBib29sZWFuKS5cbiogQHBhcmFtIG1peCAtIFRoZSBzdHJpbmcgdmFsdWUgdG8gY29udmVydC5cbiogQHJldHVybnMgVGhlIGNvbnZlcnRlZCB2YWx1ZS5cbiogQGV4YW1wbGVcbiogLy8gRXhhbXBsZSBpbnB1dDogdG9WYWx1ZShcIjEyM1wiKVxuKiAvLyBFeHBlY3RlZCBvdXRwdXQ6IDEyM1xuKi9cbmZ1bmN0aW9uIHRvVmFsdWUoc3RyKSB7XG5cdGlmICghc3RyKSByZXR1cm4gXCJcIjtcblx0aWYgKHN0ciA9PT0gXCJmYWxzZVwiKSByZXR1cm4gZmFsc2U7XG5cdGlmIChzdHIgPT09IFwidHJ1ZVwiKSByZXR1cm4gdHJ1ZTtcblx0cmV0dXJuICtzdHIgKiAwID09PSAwICYmICtzdHIgKyBcIlwiID09PSBzdHIgPyArc3RyIDogc3RyO1xufVxuLyoqXG4qIERlY29kZXMgYSBxdWVyeSBzdHJpbmcgaW50byBhbiBvYmplY3QuXG4qIEBwYXJhbSBzdHIgLSBUaGUgcXVlcnkgc3RyaW5nIHRvIGRlY29kZS5cbiogQHJldHVybnMgVGhlIGRlY29kZWQga2V5LXZhbHVlIHBhaXJzIGluIGFuIG9iamVjdCBmb3JtYXQuXG4qIEBleGFtcGxlXG4qIC8vIEV4YW1wbGUgaW5wdXQ6IGRlY29kZShcInRva2VuPWZvbyZrZXk9dmFsdWVcIilcbiogLy8gRXhwZWN0ZWQgb3V0cHV0OiB7IFwidG9rZW5cIjogXCJmb29cIiwgXCJrZXlcIjogXCJ2YWx1ZVwiIH1cbiovXG5mdW5jdGlvbiBkZWNvZGUoc3RyKSB7XG5cdGNvbnN0IHNlYXJjaFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoc3RyKTtcblx0Y29uc3QgcmVzdWx0ID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0Zm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2Ygc2VhcmNoUGFyYW1zLmVudHJpZXMoKSkge1xuXHRcdGNvbnN0IHByZXZpb3VzVmFsdWUgPSByZXN1bHRba2V5XTtcblx0XHRpZiAocHJldmlvdXNWYWx1ZSA9PSBudWxsKSByZXN1bHRba2V5XSA9IHRvVmFsdWUodmFsdWUpO1xuXHRcdGVsc2UgaWYgKEFycmF5LmlzQXJyYXkocHJldmlvdXNWYWx1ZSkpIHByZXZpb3VzVmFsdWUucHVzaCh0b1ZhbHVlKHZhbHVlKSk7XG5cdFx0ZWxzZSByZXN1bHRba2V5XSA9IFtwcmV2aW91c1ZhbHVlLCB0b1ZhbHVlKHZhbHVlKV07XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVjb2RlLCBlbmNvZGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cXNzLmpzLm1hcCIsImltcG9ydCB7IGRlY29kZSwgZW5jb2RlIH0gZnJvbSBcIi4vcXNzLmpzXCI7XG4vLyNyZWdpb24gc3JjL3NlYXJjaFBhcmFtcy50c1xuY29uc3QganNvblN0YXJ0ID0gL14oPzpcXHN8W1wiW3tcXGQtXXxmYXxudXx0cikvO1xuLyoqIERlZmF1bHQgYHBhcnNlU2VhcmNoYCB0aGF0IHN0cmlwcyBsZWFkaW5nICc/JyBhbmQgSlNPTi1wYXJzZXMgdmFsdWVzLiAqL1xuY29uc3QgZGVmYXVsdFBhcnNlU2VhcmNoID0gcGFyc2VTZWFyY2hXaXRoKEpTT04ucGFyc2UpO1xuLyoqIERlZmF1bHQgYHN0cmluZ2lmeVNlYXJjaGAgdXNpbmcgSlNPTi5zdHJpbmdpZnkgZm9yIGNvbXBsZXggdmFsdWVzLiAqL1xuY29uc3QgZGVmYXVsdFN0cmluZ2lmeVNlYXJjaCA9IHN0cmluZ2lmeVNlYXJjaFdpdGgoSlNPTi5zdHJpbmdpZnksIEpTT04ucGFyc2UpO1xuLyoqXG4qIEJ1aWxkIGEgYHBhcnNlU2VhcmNoYCBmdW5jdGlvbiB1c2luZyBhIHByb3ZpZGVkIEpTT04tbGlrZSBwYXJzZXIuXG4qXG4qIFRoZSByZXR1cm5lZCBmdW5jdGlvbiBzdHJpcHMgYSBsZWFkaW5nIGA/YCwgZGVjb2RlcyB2YWx1ZXMsIGFuZCBhdHRlbXB0cyB0b1xuKiBKU09OLXBhcnNlIHN0cmluZyB2YWx1ZXMgdXNpbmcgdGhlIGdpdmVuIGBwYXJzZXJgLlxuKlxuKiBAcGFyYW0gcGFyc2VyIEZ1bmN0aW9uIHRvIHBhcnNlIGEgc3RyaW5nIHZhbHVlIChlLmcuIGBKU09OLnBhcnNlYCkuXG4qIEByZXR1cm5zIEEgYHBhcnNlU2VhcmNoYCBmdW5jdGlvbiBjb21wYXRpYmxlIHdpdGggYFJvdXRlcmAgb3B0aW9ucy5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9jdXN0b20tc2VhcmNoLXBhcmFtLXNlcmlhbGl6YXRpb25cbiovXG5mdW5jdGlvbiBwYXJzZVNlYXJjaFdpdGgocGFyc2VyKSB7XG5cdGNvbnN0IGlzSnNvblBhcnNlciA9IHBhcnNlciA9PT0gSlNPTi5wYXJzZTtcblx0cmV0dXJuIChzZWFyY2hTdHIpID0+IHtcblx0XHRpZiAoc2VhcmNoU3RyWzBdID09PSBcIj9cIikgc2VhcmNoU3RyID0gc2VhcmNoU3RyLnN1YnN0cmluZygxKTtcblx0XHRjb25zdCBxdWVyeSA9IGRlY29kZShzZWFyY2hTdHIpO1xuXHRcdGZvciAoY29uc3Qga2V5IGluIHF1ZXJ5KSB7XG5cdFx0XHRjb25zdCB2YWx1ZSA9IHF1ZXJ5W2tleV07XG5cdFx0XHRpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRcdGlmIChpc0pzb25QYXJzZXIgJiYgIWpzb25TdGFydC50ZXN0KHZhbHVlKSkgY29udGludWU7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0cXVlcnlba2V5XSA9IHBhcnNlcih2YWx1ZSk7XG5cdFx0XHRcdH0gY2F0Y2ggKF9lcnIpIHt9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBxdWVyeTtcblx0fTtcbn1cbi8qKlxuKiBCdWlsZCBhIGBzdHJpbmdpZnlTZWFyY2hgIGZ1bmN0aW9uIHVzaW5nIGEgcHJvdmlkZWQgc2VyaWFsaXplci5cbipcbiogTm9uLXByaW1pdGl2ZSB2YWx1ZXMgYXJlIHNlcmlhbGl6ZWQgd2l0aCBgc3RyaW5naWZ5YC4gSWYgYSBgcGFyc2VyYCBpc1xuKiBzdXBwbGllZCwgc3RyaW5nIHZhbHVlcyB0aGF0IGFyZSBwYXJzZWFibGUgYXJlIHJlLXNlcmlhbGl6ZWQgdG8gZW5zdXJlXG4qIHN5bW1ldHJ5IHdpdGggYHBhcnNlU2VhcmNoYC5cbipcbiogQHBhcmFtIHN0cmluZ2lmeSBGdW5jdGlvbiB0byBzZXJpYWxpemUgYSB2YWx1ZSAoZS5nLiBgSlNPTi5zdHJpbmdpZnlgKS5cbiogQHBhcmFtIHBhcnNlciBPcHRpb25hbCBwYXJzZXIgdG8gZGV0ZWN0IHBhcnNlYWJsZSBzdHJpbmdzLlxuKiBAcmV0dXJucyBBIGBzdHJpbmdpZnlTZWFyY2hgIGZ1bmN0aW9uIGNvbXBhdGlibGUgd2l0aCBgUm91dGVyYCBvcHRpb25zLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL2N1c3RvbS1zZWFyY2gtcGFyYW0tc2VyaWFsaXphdGlvblxuKi9cbmZ1bmN0aW9uIHN0cmluZ2lmeVNlYXJjaFdpdGgoc3RyaW5naWZ5LCBwYXJzZXIpIHtcblx0Y29uc3QgaXNKc29uUGFyc2VyID0gcGFyc2VyID09PSBKU09OLnBhcnNlO1xuXHRmdW5jdGlvbiBzdHJpbmdpZnlWYWx1ZSh2YWwpIHtcblx0XHRpZiAodmFsICYmIHR5cGVvZiB2YWwgPT09IFwib2JqZWN0XCIpIHRyeSB7XG5cdFx0XHRyZXR1cm4gc3RyaW5naWZ5KHZhbCk7XG5cdFx0fSBjYXRjaCAoX2Vycikge31cblx0XHRlbHNlIGlmIChwYXJzZXIgJiYgdHlwZW9mIHZhbCA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0aWYgKGlzSnNvblBhcnNlciAmJiAhanNvblN0YXJ0LnRlc3QodmFsKSkgcmV0dXJuIHZhbDtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHBhcnNlcih2YWwpO1xuXHRcdFx0XHRyZXR1cm4gc3RyaW5naWZ5KHZhbCk7XG5cdFx0XHR9IGNhdGNoIChfZXJyKSB7fVxuXHRcdH1cblx0XHRyZXR1cm4gdmFsO1xuXHR9XG5cdHJldHVybiAoc2VhcmNoKSA9PiB7XG5cdFx0Y29uc3Qgc2VhcmNoU3RyID0gZW5jb2RlKHNlYXJjaCwgc3RyaW5naWZ5VmFsdWUpO1xuXHRcdHJldHVybiBzZWFyY2hTdHIgPyBgPyR7c2VhcmNoU3RyfWAgOiBcIlwiO1xuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWZhdWx0UGFyc2VTZWFyY2gsIGRlZmF1bHRTdHJpbmdpZnlTZWFyY2gsIHBhcnNlU2VhcmNoV2l0aCwgc3RyaW5naWZ5U2VhcmNoV2l0aCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zZWFyY2hQYXJhbXMuanMubWFwIiwiaW1wb3J0IHsgY2xlYW5QYXRoLCB0cmltUGF0aCB9IGZyb20gXCIuL3BhdGguanNcIjtcbi8vI3JlZ2lvbiBzcmMvcmV3cml0ZS50c1xuLyoqIENvbXBvc2UgbXVsdGlwbGUgcmV3cml0ZSBwYWlycyBpbnRvIGEgc2luZ2xlIGluL291dCByZXdyaXRlLiAqL1xuZnVuY3Rpb24gY29tcG9zZVJld3JpdGVzKHJld3JpdGVzKSB7XG5cdHJldHVybiB7XG5cdFx0aW5wdXQ6ICh7IHVybCB9KSA9PiB7XG5cdFx0XHRmb3IgKGNvbnN0IHJld3JpdGUgb2YgcmV3cml0ZXMpIHVybCA9IGV4ZWN1dGVSZXdyaXRlSW5wdXQocmV3cml0ZSwgdXJsKTtcblx0XHRcdHJldHVybiB1cmw7XG5cdFx0fSxcblx0XHRvdXRwdXQ6ICh7IHVybCB9KSA9PiB7XG5cdFx0XHRmb3IgKGxldCBpID0gcmV3cml0ZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHVybCA9IGV4ZWN1dGVSZXdyaXRlT3V0cHV0KHJld3JpdGVzW2ldLCB1cmwpO1xuXHRcdFx0cmV0dXJuIHVybDtcblx0XHR9XG5cdH07XG59XG4vKiogQ3JlYXRlIGEgcmV3cml0ZSBwYWlyIHRoYXQgc3RyaXBzL2FkZHMgYSBiYXNlcGF0aCBvbiBpbnB1dC9vdXRwdXQuICovXG5mdW5jdGlvbiByZXdyaXRlQmFzZXBhdGgoYmFzZXBhdGgsIGNhc2VTZW5zaXRpdmUsIHJld3JpdGUpIHtcblx0Y29uc3QgdHJpbW1lZEJhc2VwYXRoID0gdHJpbVBhdGgoYmFzZXBhdGgpO1xuXHRjb25zdCBub3JtYWxpemVkQmFzZXBhdGggPSBgLyR7dHJpbW1lZEJhc2VwYXRofWA7XG5cdGNvbnN0IGNoZWNrQmFzZXBhdGggPSBjYXNlU2Vuc2l0aXZlID8gbm9ybWFsaXplZEJhc2VwYXRoIDogbm9ybWFsaXplZEJhc2VwYXRoLnRvTG93ZXJDYXNlKCk7XG5cdGNvbnN0IGNoZWNrQmFzZXBhdGhXaXRoU2xhc2ggPSBgJHtjaGVja0Jhc2VwYXRofS9gO1xuXHRjb25zdCBiYXNlcGF0aFJld3JpdGUgPSB7XG5cdFx0aW5wdXQ6ICh7IHVybCB9KSA9PiB7XG5cdFx0XHRjb25zdCBwYXRobmFtZSA9IGNhc2VTZW5zaXRpdmUgPyB1cmwucGF0aG5hbWUgOiB1cmwucGF0aG5hbWUudG9Mb3dlckNhc2UoKTtcblx0XHRcdGlmIChwYXRobmFtZSA9PT0gY2hlY2tCYXNlcGF0aCkgdXJsLnBhdGhuYW1lID0gXCIvXCI7XG5cdFx0XHRlbHNlIGlmIChwYXRobmFtZS5zdGFydHNXaXRoKGNoZWNrQmFzZXBhdGhXaXRoU2xhc2gpKSB1cmwucGF0aG5hbWUgPSB1cmwucGF0aG5hbWUuc2xpY2Uobm9ybWFsaXplZEJhc2VwYXRoLmxlbmd0aCk7XG5cdFx0XHRyZXR1cm4gdXJsO1xuXHRcdH0sXG5cdFx0b3V0cHV0OiAoeyB1cmwgfSkgPT4ge1xuXHRcdFx0dXJsLnBhdGhuYW1lID0gY2xlYW5QYXRoKGAvJHt0cmltbWVkQmFzZXBhdGh9JHt1cmwucGF0aG5hbWV9YCk7XG5cdFx0XHRyZXR1cm4gdXJsO1xuXHRcdH1cblx0fTtcblx0cmV0dXJuIHJld3JpdGUgPyB7XG5cdFx0aW5wdXQ6ICh7IHVybCB9KSA9PiBleGVjdXRlUmV3cml0ZUlucHV0KHJld3JpdGUsIGJhc2VwYXRoUmV3cml0ZS5pbnB1dCh7IHVybCB9KSksXG5cdFx0b3V0cHV0OiAoeyB1cmwgfSkgPT4gYmFzZXBhdGhSZXdyaXRlLm91dHB1dCh7IHVybDogZXhlY3V0ZVJld3JpdGVPdXRwdXQocmV3cml0ZSwgdXJsKSB9KVxuXHR9IDogYmFzZXBhdGhSZXdyaXRlO1xufVxuLyoqIEV4ZWN1dGUgYSBsb2NhdGlvbiBpbnB1dCByZXdyaXRlIGlmIHByb3ZpZGVkLiAqL1xuZnVuY3Rpb24gZXhlY3V0ZVJld3JpdGVJbnB1dChyZXdyaXRlLCB1cmwpIHtcblx0Y29uc3QgcmVzID0gcmV3cml0ZT8uaW5wdXQ/Lih7IHVybCB9KTtcblx0aWYgKHJlcykge1xuXHRcdGlmICh0eXBlb2YgcmVzID09PSBcInN0cmluZ1wiKSByZXR1cm4gbmV3IFVSTChyZXMpO1xuXHRcdGVsc2UgaWYgKHJlcyBpbnN0YW5jZW9mIFVSTCkgcmV0dXJuIHJlcztcblx0fVxuXHRyZXR1cm4gdXJsO1xufVxuLyoqIEV4ZWN1dGUgYSBsb2NhdGlvbiBvdXRwdXQgcmV3cml0ZSBpZiBwcm92aWRlZC4gKi9cbmZ1bmN0aW9uIGV4ZWN1dGVSZXdyaXRlT3V0cHV0KHJld3JpdGUsIHVybCkge1xuXHRjb25zdCByZXMgPSByZXdyaXRlPy5vdXRwdXQ/Lih7IHVybCB9KTtcblx0aWYgKHJlcykge1xuXHRcdGlmICh0eXBlb2YgcmVzID09PSBcInN0cmluZ1wiKSByZXR1cm4gbmV3IFVSTChyZXMpO1xuXHRcdGVsc2UgaWYgKHJlcyBpbnN0YW5jZW9mIFVSTCkgcmV0dXJuIHJlcztcblx0fVxuXHRyZXR1cm4gdXJsO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjb21wb3NlUmV3cml0ZXMsIGV4ZWN1dGVSZXdyaXRlSW5wdXQsIGV4ZWN1dGVSZXdyaXRlT3V0cHV0LCByZXdyaXRlQmFzZXBhdGggfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmV3cml0ZS5qcy5tYXAiLCJpbXBvcnQgeyBhcnJheXNFcXVhbCwgZnVuY3Rpb25hbFVwZGF0ZSB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL3N0b3Jlcy50c1xuLyoqIFNTUiBub24tcmVhY3RpdmUgY3JlYXRlTXV0YWJsZVN0b3JlICovXG5mdW5jdGlvbiBjcmVhdGVOb25SZWFjdGl2ZU11dGFibGVTdG9yZShpbml0aWFsVmFsdWUpIHtcblx0bGV0IHZhbHVlID0gaW5pdGlhbFZhbHVlO1xuXHRyZXR1cm4ge1xuXHRcdGdldCgpIHtcblx0XHRcdHJldHVybiB2YWx1ZTtcblx0XHR9LFxuXHRcdHNldChuZXh0T3JVcGRhdGVyKSB7XG5cdFx0XHR2YWx1ZSA9IGZ1bmN0aW9uYWxVcGRhdGUobmV4dE9yVXBkYXRlciwgdmFsdWUpO1xuXHRcdH1cblx0fTtcbn1cbi8qKiBTU1Igbm9uLXJlYWN0aXZlIGNyZWF0ZVJlYWRvbmx5U3RvcmUgKi9cbmZ1bmN0aW9uIGNyZWF0ZU5vblJlYWN0aXZlUmVhZG9ubHlTdG9yZShyZWFkKSB7XG5cdHJldHVybiB7IGdldCgpIHtcblx0XHRyZXR1cm4gcmVhZCgpO1xuXHR9IH07XG59XG5mdW5jdGlvbiBjcmVhdGVSb3V0ZXJTdG9yZXMoaW5pdGlhbExvY2F0aW9uLCBjb25maWcpIHtcblx0Y29uc3QgeyBjcmVhdGVNdXRhYmxlU3RvcmUsIGNyZWF0ZVJlYWRvbmx5U3RvcmUsIGJhdGNoIH0gPSBjb25maWc7XG5cdGNvbnN0IGJ5Um91dGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRjb25zdCBzdGF0dXMgPSBjcmVhdGVNdXRhYmxlU3RvcmUoXCJpZGxlXCIpO1xuXHRjb25zdCBsb2NhdGlvbiA9IGNyZWF0ZU11dGFibGVTdG9yZShpbml0aWFsTG9jYXRpb24pO1xuXHRjb25zdCByZXNvbHZlZExvY2F0aW9uID0gY3JlYXRlTXV0YWJsZVN0b3JlKHZvaWQgMCk7XG5cdGNvbnN0IGlkcyA9IGNyZWF0ZU11dGFibGVTdG9yZShbXSk7XG5cdGNvbnN0IG1hdGNoZXMgPSBjcmVhdGVSZWFkb25seVN0b3JlKCgpID0+IGlkcy5nZXQoKS5tYXAoKGlkKSA9PiBieVJvdXRlLmdldChpZCkuZ2V0KCkpKTtcblx0Y29uc3QgX19zdG9yZSA9IGNyZWF0ZVJlYWRvbmx5U3RvcmUoKCkgPT4gKHtcblx0XHRzdGF0dXM6IHN0YXR1cy5nZXQoKSxcblx0XHRpc0xvYWRpbmc6IHN0YXR1cy5nZXQoKSA9PT0gXCJwZW5kaW5nXCIsXG5cdFx0bWF0Y2hlczogbWF0Y2hlcy5nZXQoKSxcblx0XHRsb2NhdGlvbjogbG9jYXRpb24uZ2V0KCksXG5cdFx0cmVzb2x2ZWRMb2NhdGlvbjogcmVzb2x2ZWRMb2NhdGlvbi5nZXQoKVxuXHR9KSk7XG5cdGZ1bmN0aW9uIGdldE1hdGNoU3RvcmUocm91dGVJZCkge1xuXHRcdGxldCBtYXRjaFN0b3JlID0gYnlSb3V0ZS5nZXQocm91dGVJZCk7XG5cdFx0aWYgKCFtYXRjaFN0b3JlKSB7XG5cdFx0XHRtYXRjaFN0b3JlID0gY3JlYXRlTXV0YWJsZVN0b3JlKHZvaWQgMCk7XG5cdFx0XHRieVJvdXRlLnNldChyb3V0ZUlkLCBtYXRjaFN0b3JlKTtcblx0XHR9XG5cdFx0cmV0dXJuIG1hdGNoU3RvcmU7XG5cdH1cblx0Y29uc3Qgc3RvcmUgPSB7XG5cdFx0c3RhdHVzLFxuXHRcdGxvY2F0aW9uLFxuXHRcdHJlc29sdmVkTG9jYXRpb24sXG5cdFx0aWRzLFxuXHRcdG1hdGNoZXMsXG5cdFx0YnlSb3V0ZSxcblx0XHRfX3N0b3JlLFxuXHRcdGdldE1hdGNoU3RvcmUsXG5cdFx0c2V0TWF0Y2hlc1xuXHR9O1xuXHRmdW5jdGlvbiBzZXRNYXRjaGVzKG5leHRNYXRjaGVzKSB7XG5cdFx0Y29uc3QgcHJldmlvdXNJZHMgPSBpZHMuZ2V0KCk7XG5cdFx0Y29uc3QgbmV4dElkcyA9IG5leHRNYXRjaGVzLm1hcCgobWF0Y2gpID0+IG1hdGNoLnJvdXRlSWQpO1xuXHRcdGJhdGNoKCgpID0+IHtcblx0XHRcdGlmICghYXJyYXlzRXF1YWwocHJldmlvdXNJZHMsIG5leHRJZHMpKSBpZHMuc2V0KG5leHRJZHMpO1xuXHRcdFx0Zm9yIChjb25zdCBpZCBvZiBwcmV2aW91c0lkcykgaWYgKCFuZXh0SWRzLmluY2x1ZGVzKGlkKSkgYnlSb3V0ZS5nZXQoaWQpLnNldCgoKSA9PiB2b2lkIDApO1xuXHRcdFx0Zm9yIChjb25zdCBuZXh0TWF0Y2ggb2YgbmV4dE1hdGNoZXMpIHtcblx0XHRcdFx0Y29uc3QgbWF0Y2hTdG9yZSA9IGdldE1hdGNoU3RvcmUobmV4dE1hdGNoLnJvdXRlSWQpO1xuXHRcdFx0XHRpZiAobWF0Y2hTdG9yZS5nZXQoKSAhPT0gbmV4dE1hdGNoKSBtYXRjaFN0b3JlLnNldChuZXh0TWF0Y2gpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiBzdG9yZTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY3JlYXRlTm9uUmVhY3RpdmVNdXRhYmxlU3RvcmUsIGNyZWF0ZU5vblJlYWN0aXZlUmVhZG9ubHlTdG9yZSwgY3JlYXRlUm91dGVyU3RvcmVzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXN0b3Jlcy5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL2luZGV4LnRzXG52YXIgc3RhdGVJbmRleEtleSA9IFwiX19UU1JfaW5kZXhcIjtcbnZhciBwb3BTdGF0ZUV2ZW50ID0gXCJwb3BzdGF0ZVwiO1xudmFyIGJlZm9yZVVubG9hZEV2ZW50ID0gXCJiZWZvcmV1bmxvYWRcIjtcbi8qKlxuKiBUdXJuIHByb3RvY29sLXJlbGF0aXZlIGlucHV0cyBzdWNoIGFzIFwiLy9ldmlsLmV4YW1wbGVcIiBpbnRvIHBhdGhzXG4qIHN1Y2ggYXMgXCIvZXZpbC5leGFtcGxlXCIsIGtlZXBpbmcgbmF2aWdhdGlvbiBvbiB0aGUgY3VycmVudCBvcmlnaW4uXG4qXG4qIEZvciBIVFRQKFMpIFVSTHMsIFdIQVRXRyBwYXJzaW5nIGlnbm9yZXMgbGVhZGluZyBDMCBjb250cm9scyBhbmQgc3BhY2VzLFxuKiByZW1vdmVzIHRhYnMvbmV3bGluZXMsIGFuZCB0cmVhdHMgYmFja3NsYXNoZXMgYXMgc2xhc2hlcywgc28gaW5wdXRzIGxpa2VcbiogXCIvXFxldmlsLmV4YW1wbGVcIiBhbHNvIG5lZWQgbm9ybWFsaXphdGlvbi4gVGhpcyBvbmx5IGFsbG9jYXRlcyB3aGVuIHRob3NlXG4qIHJ1bGVzIHdvdWxkIG1ha2UgdGhlIGlucHV0IHByb3RvY29sLXJlbGF0aXZlLlxuKi9cbnZhciBwcm90b2NvbFJlbGF0aXZlUHJlZml4ID0gL15bXFx4MDAtXFx4MjBdKig/OltcXFxcL11bXFx0XFxuXFxyXSopezIsfS87XG5mdW5jdGlvbiBub3JtYWxpemVQcm90b2NvbFJlbGF0aXZlKHVybCkge1xuXHRjb25zdCBtYXRjaCA9IHByb3RvY29sUmVsYXRpdmVQcmVmaXguZXhlYyh1cmwpO1xuXHRyZXR1cm4gbWF0Y2ggPyBcIi9cIiArIHVybC5zbGljZShtYXRjaFswXS5sZW5ndGgpIDogdXJsO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplSHJlZihocmVmKSB7XG5cdGlmICgvW1xceDAwLVxceDFmXFx4N2ZdLy50ZXN0KGhyZWYpKSBocmVmID0gaHJlZi5yZXBsYWNlKC9bXFx4MDAtXFx4MWZcXHg3Zl0vZywgKGNoYXJhY3RlcikgPT4gXCJcdFxcblxcclwiLmluY2x1ZGVzKGNoYXJhY3RlcikgPyBcIlwiIDogZW5jb2RlVVJJQ29tcG9uZW50KGNoYXJhY3RlcikpO1xuXHRyZXR1cm4gbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZShocmVmKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUhpc3Rvcnkob3B0cykge1xuXHRsZXQgbG9jYXRpb24gPSBvcHRzLmdldExvY2F0aW9uKCk7XG5cdGNvbnN0IHN1YnNjcmliZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Y29uc3Qgbm90aWZ5ID0gKGFjdGlvbikgPT4ge1xuXHRcdGxvY2F0aW9uID0gb3B0cy5nZXRMb2NhdGlvbigpO1xuXHRcdHN1YnNjcmliZXJzLmZvckVhY2goKHN1YnNjcmliZXIpID0+IHN1YnNjcmliZXIoe1xuXHRcdFx0bG9jYXRpb24sXG5cdFx0XHRhY3Rpb25cblx0XHR9KSk7XG5cdH07XG5cdGNvbnN0IGhhbmRsZUluZGV4Q2hhbmdlID0gKGFjdGlvbikgPT4ge1xuXHRcdGlmIChvcHRzLm5vdGlmeU9uSW5kZXhDaGFuZ2UgPz8gdHJ1ZSkgbm90aWZ5KGFjdGlvbik7XG5cdFx0ZWxzZSBsb2NhdGlvbiA9IG9wdHMuZ2V0TG9jYXRpb24oKTtcblx0fTtcblx0Y29uc3QgdHJ5TmF2aWdhdGlvbiA9IGFzeW5jICh7IHRhc2ssIG5hdmlnYXRlT3B0cywgLi4uYWN0aW9uSW5mbyB9KSA9PiB7XG5cdFx0aWYgKG5hdmlnYXRlT3B0cz8uaWdub3JlQmxvY2tlciA/PyBmYWxzZSkge1xuXHRcdFx0dGFzaygpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRjb25zdCBibG9ja2VycyA9IG9wdHMuZ2V0QmxvY2tlcnM/LigpID8/IFtdO1xuXHRcdGNvbnN0IGlzUHVzaE9yUmVwbGFjZSA9IGFjdGlvbkluZm8udHlwZSA9PT0gXCJQVVNIXCIgfHwgYWN0aW9uSW5mby50eXBlID09PSBcIlJFUExBQ0VcIjtcblx0XHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIGJsb2NrZXJzLmxlbmd0aCAmJiBpc1B1c2hPclJlcGxhY2UpIGZvciAoY29uc3QgYmxvY2tlciBvZiBibG9ja2Vycykge1xuXHRcdFx0Y29uc3QgbmV4dExvY2F0aW9uID0gcGFyc2VIcmVmKGFjdGlvbkluZm8ucGF0aCwgYWN0aW9uSW5mby5zdGF0ZSk7XG5cdFx0XHRpZiAoYXdhaXQgYmxvY2tlci5ibG9ja2VyRm4oe1xuXHRcdFx0XHRjdXJyZW50TG9jYXRpb246IGxvY2F0aW9uLFxuXHRcdFx0XHRuZXh0TG9jYXRpb24sXG5cdFx0XHRcdGFjdGlvbjogYWN0aW9uSW5mby50eXBlXG5cdFx0XHR9KSkge1xuXHRcdFx0XHRvcHRzLm9uQmxvY2tlZD8uKCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHR9XG5cdFx0dGFzaygpO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdGdldCBsb2NhdGlvbigpIHtcblx0XHRcdHJldHVybiBsb2NhdGlvbjtcblx0XHR9LFxuXHRcdGdldCBsZW5ndGgoKSB7XG5cdFx0XHRyZXR1cm4gb3B0cy5nZXRMZW5ndGgoKTtcblx0XHR9LFxuXHRcdHN1YnNjcmliZXJzLFxuXHRcdHN1YnNjcmliZTogKGNiKSA9PiB7XG5cdFx0XHRzdWJzY3JpYmVycy5hZGQoY2IpO1xuXHRcdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdFx0c3Vic2NyaWJlcnMuZGVsZXRlKGNiKTtcblx0XHRcdH07XG5cdFx0fSxcblx0XHRwdXNoOiAocGF0aCwgc3RhdGUsIG5hdmlnYXRlT3B0cykgPT4ge1xuXHRcdFx0Y29uc3QgY3VycmVudEluZGV4ID0gbG9jYXRpb24uc3RhdGVbc3RhdGVJbmRleEtleV07XG5cdFx0XHRzdGF0ZSA9IGFzc2lnbktleUFuZEluZGV4KGN1cnJlbnRJbmRleCArIDEsIHN0YXRlKTtcblx0XHRcdHRyeU5hdmlnYXRpb24oe1xuXHRcdFx0XHR0YXNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0b3B0cy5wdXNoU3RhdGUocGF0aCwgc3RhdGUpO1xuXHRcdFx0XHRcdG5vdGlmeSh7IHR5cGU6IFwiUFVTSFwiIH0pO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRuYXZpZ2F0ZU9wdHMsXG5cdFx0XHRcdHR5cGU6IFwiUFVTSFwiLFxuXHRcdFx0XHRwYXRoLFxuXHRcdFx0XHRzdGF0ZVxuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHRyZXBsYWNlOiAocGF0aCwgc3RhdGUsIG5hdmlnYXRlT3B0cykgPT4ge1xuXHRcdFx0Y29uc3QgY3VycmVudEluZGV4ID0gbG9jYXRpb24uc3RhdGVbc3RhdGVJbmRleEtleV07XG5cdFx0XHRzdGF0ZSA9IGFzc2lnbktleUFuZEluZGV4KGN1cnJlbnRJbmRleCwgc3RhdGUpO1xuXHRcdFx0dHJ5TmF2aWdhdGlvbih7XG5cdFx0XHRcdHRhc2s6ICgpID0+IHtcblx0XHRcdFx0XHRvcHRzLnJlcGxhY2VTdGF0ZShwYXRoLCBzdGF0ZSk7XG5cdFx0XHRcdFx0bm90aWZ5KHsgdHlwZTogXCJSRVBMQUNFXCIgfSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdmlnYXRlT3B0cyxcblx0XHRcdFx0dHlwZTogXCJSRVBMQUNFXCIsXG5cdFx0XHRcdHBhdGgsXG5cdFx0XHRcdHN0YXRlXG5cdFx0XHR9KTtcblx0XHR9LFxuXHRcdGdvOiAoaW5kZXgsIG5hdmlnYXRlT3B0cykgPT4ge1xuXHRcdFx0dHJ5TmF2aWdhdGlvbih7XG5cdFx0XHRcdHRhc2s6ICgpID0+IHtcblx0XHRcdFx0XHRvcHRzLmdvKGluZGV4LCBuYXZpZ2F0ZU9wdHM/Lmlnbm9yZUJsb2NrZXIgPz8gZmFsc2UpO1xuXHRcdFx0XHRcdGhhbmRsZUluZGV4Q2hhbmdlKHtcblx0XHRcdFx0XHRcdHR5cGU6IFwiR09cIixcblx0XHRcdFx0XHRcdGluZGV4XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdmlnYXRlT3B0cyxcblx0XHRcdFx0dHlwZTogXCJHT1wiXG5cdFx0XHR9KTtcblx0XHR9LFxuXHRcdGJhY2s6IChuYXZpZ2F0ZU9wdHMpID0+IHtcblx0XHRcdHRyeU5hdmlnYXRpb24oe1xuXHRcdFx0XHR0YXNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0b3B0cy5iYWNrKG5hdmlnYXRlT3B0cz8uaWdub3JlQmxvY2tlciA/PyBmYWxzZSk7XG5cdFx0XHRcdFx0aGFuZGxlSW5kZXhDaGFuZ2UoeyB0eXBlOiBcIkJBQ0tcIiB9KTtcblx0XHRcdFx0fSxcblx0XHRcdFx0bmF2aWdhdGVPcHRzLFxuXHRcdFx0XHR0eXBlOiBcIkJBQ0tcIlxuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHRmb3J3YXJkOiAobmF2aWdhdGVPcHRzKSA9PiB7XG5cdFx0XHR0cnlOYXZpZ2F0aW9uKHtcblx0XHRcdFx0dGFzazogKCkgPT4ge1xuXHRcdFx0XHRcdG9wdHMuZm9yd2FyZChuYXZpZ2F0ZU9wdHM/Lmlnbm9yZUJsb2NrZXIgPz8gZmFsc2UpO1xuXHRcdFx0XHRcdGhhbmRsZUluZGV4Q2hhbmdlKHsgdHlwZTogXCJGT1JXQVJEXCIgfSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdmlnYXRlT3B0cyxcblx0XHRcdFx0dHlwZTogXCJGT1JXQVJEXCJcblx0XHRcdH0pO1xuXHRcdH0sXG5cdFx0Y2FuR29CYWNrOiAoKSA9PiBsb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XSAhPT0gMCxcblx0XHRjcmVhdGVIcmVmOiAoc3RyKSA9PiBvcHRzLmNyZWF0ZUhyZWYoc3RyKSxcblx0XHRibG9jazogKGJsb2NrZXIpID0+IHtcblx0XHRcdGlmICghb3B0cy5zZXRCbG9ja2VycykgcmV0dXJuICgpID0+IHt9O1xuXHRcdFx0Y29uc3QgYmxvY2tlcnMgPSBvcHRzLmdldEJsb2NrZXJzPy4oKSA/PyBbXTtcblx0XHRcdG9wdHMuc2V0QmxvY2tlcnMoWy4uLmJsb2NrZXJzLCBibG9ja2VyXSk7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBibG9ja2VycyA9IG9wdHMuZ2V0QmxvY2tlcnM/LigpID8/IFtdO1xuXHRcdFx0XHRvcHRzLnNldEJsb2NrZXJzPy4oYmxvY2tlcnMuZmlsdGVyKChiKSA9PiBiICE9PSBibG9ja2VyKSk7XG5cdFx0XHR9O1xuXHRcdH0sXG5cdFx0Zmx1c2g6ICgpID0+IG9wdHMuZmx1c2g/LigpLFxuXHRcdGRlc3Ryb3k6ICgpID0+IG9wdHMuZGVzdHJveT8uKCksXG5cdFx0bm90aWZ5LFxuXHRcdF9nZXRCbG9ja2VyczogKCkgPT4gb3B0cy5nZXRCbG9ja2Vycz8uKCkgPz8gW11cblx0fTtcbn1cbmZ1bmN0aW9uIGFzc2lnbktleUFuZEluZGV4KGluZGV4LCBzdGF0ZSkge1xuXHRjb25zdCBrZXkgPSBjcmVhdGVSYW5kb21LZXkoKTtcblx0cmV0dXJuIHtcblx0XHQuLi5zdGF0ZSxcblx0XHRrZXksXG5cdFx0X19UU1Jfa2V5OiBrZXksXG5cdFx0W3N0YXRlSW5kZXhLZXldOiBpbmRleFxuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYSBoaXN0b3J5IG9iamVjdCB0aGF0IGNhbiBiZSB1c2VkIHRvIGludGVyYWN0IHdpdGggdGhlIGJyb3dzZXInc1xuKiBuYXZpZ2F0aW9uLiBUaGlzIGlzIGEgbGlnaHR3ZWlnaHQgQVBJIHdyYXBwaW5nIHRoZSBicm93c2VyJ3MgbmF0aXZlIG1ldGhvZHMuXG4qIEl0IGlzIGRlc2lnbmVkIHRvIHdvcmsgd2l0aCBUYW5TdGFjayBSb3V0ZXIsIGJ1dCBjb3VsZCBiZSB1c2VkIGFzIGEgc3RhbmRhbG9uZSBBUEkgYXMgd2VsbC5cbiogSU1QT1JUQU5UOiBUaGlzIEFQSSBpbXBsZW1lbnRzIGhpc3RvcnkgdGhyb3R0bGluZyB2aWEgYSBtaWNyb3Rhc2sgdG8gcHJldmVudFxuKiBleGNlc3NpdmUgY2FsbHMgdG8gdGhlIGhpc3RvcnkgQVBJLiBJbiBzb21lIGJyb3dzZXJzLCBjYWxsaW5nIGhpc3RvcnkucHVzaFN0YXRlIG9yXG4qIGhpc3RvcnkucmVwbGFjZVN0YXRlIGluIHF1aWNrIHN1Y2Nlc3Npb24gY2FuIGNhdXNlIHRoZSBicm93c2VyIHRvIGlnbm9yZSBzdWJzZXF1ZW50XG4qIGNhbGxzLiBUaGlzIEFQSSBzbW9vdGhzIG91dCB0aG9zZSBkaWZmZXJlbmNlcyBhbmQgZW5zdXJlcyB0aGF0IHlvdXIgYXBwbGljYXRpb25cbiogc3RhdGUgd2lsbCAqZXZlbnR1YWxseSogbWF0Y2ggdGhlIGJyb3dzZXIgc3RhdGUuIEluIG1vc3QgY2FzZXMsIHRoaXMgaXMgbm90IGEgcHJvYmxlbSxcbiogYnV0IGlmIHlvdSBuZWVkIHRvIGVuc3VyZSB0aGF0IHRoZSBicm93c2VyIHN0YXRlIGlzIHVwIHRvIGRhdGUsIHlvdSBjYW4gdXNlIHRoZVxuKiBgaGlzdG9yeS5mbHVzaGAgbWV0aG9kIHRvIGltbWVkaWF0ZWx5IGZsdXNoIGFsbCBwZW5kaW5nIHN0YXRlIGNoYW5nZXMgdG8gdGhlIGJyb3dzZXIgVVJMLlxuKiBAcGFyYW0gb3B0c1xuKiBAcGFyYW0gb3B0cy5nZXRIcmVmIEEgZnVuY3Rpb24gdGhhdCByZXR1cm5zIHRoZSBjdXJyZW50IGhyZWYgKHBhdGggKyBzZWFyY2ggKyBoYXNoKVxuKiBAcGFyYW0gb3B0cy5jcmVhdGVIcmVmIEEgZnVuY3Rpb24gdGhhdCB0YWtlcyBhIHBhdGggYW5kIHJldHVybnMgYSBocmVmIChwYXRoICsgc2VhcmNoICsgaGFzaClcbiogQHJldHVybnMgQSBoaXN0b3J5IGluc3RhbmNlXG4qL1xuZnVuY3Rpb24gY3JlYXRlQnJvd3Nlckhpc3Rvcnkob3B0cykge1xuXHRjb25zdCB3aW4gPSBvcHRzPy53aW5kb3cgPz8gKHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHZvaWQgMCk7XG5cdGNvbnN0IG9yaWdpbmFsUHVzaFN0YXRlID0gd2luLmhpc3RvcnkucHVzaFN0YXRlO1xuXHRjb25zdCBvcmlnaW5hbFJlcGxhY2VTdGF0ZSA9IHdpbi5oaXN0b3J5LnJlcGxhY2VTdGF0ZTtcblx0bGV0IGJsb2NrZXJzID0gW107XG5cdGNvbnN0IF9nZXRCbG9ja2VycyA9ICgpID0+IGJsb2NrZXJzO1xuXHRjb25zdCBfc2V0QmxvY2tlcnMgPSAobmV3QmxvY2tlcnMpID0+IGJsb2NrZXJzID0gbmV3QmxvY2tlcnM7XG5cdGNvbnN0IGNyZWF0ZUhyZWYgPSAocGF0aCkgPT4gbm9ybWFsaXplSHJlZihvcHRzPy5jcmVhdGVIcmVmID8gb3B0cy5jcmVhdGVIcmVmKHBhdGgpIDogcGF0aCk7XG5cdGNvbnN0IHBhcnNlTG9jYXRpb24gPSBvcHRzPy5wYXJzZUxvY2F0aW9uID8/ICgoKSA9PiBwYXJzZUhyZWYoYCR7d2luLmxvY2F0aW9uLnBhdGhuYW1lfSR7d2luLmxvY2F0aW9uLnNlYXJjaH0ke3dpbi5sb2NhdGlvbi5oYXNofWAsIHdpbi5oaXN0b3J5LnN0YXRlKSk7XG5cdGlmICghd2luLmhpc3Rvcnkuc3RhdGU/Ll9fVFNSX2tleSAmJiAhd2luLmhpc3Rvcnkuc3RhdGU/LmtleSkge1xuXHRcdGNvbnN0IGFkZGVkS2V5ID0gY3JlYXRlUmFuZG9tS2V5KCk7XG5cdFx0d2luLmhpc3RvcnkucmVwbGFjZVN0YXRlKHtcblx0XHRcdFtzdGF0ZUluZGV4S2V5XTogMCxcblx0XHRcdGtleTogYWRkZWRLZXksXG5cdFx0XHRfX1RTUl9rZXk6IGFkZGVkS2V5XG5cdFx0fSwgXCJcIik7XG5cdH1cblx0bGV0IGN1cnJlbnRMb2NhdGlvbiA9IHBhcnNlTG9jYXRpb24oKTtcblx0bGV0IHJvbGxiYWNrTG9jYXRpb247XG5cdGxldCBuZXh0UG9wSXNHbyA9IGZhbHNlO1xuXHRsZXQgaWdub3JlTmV4dFBvcCA9IGZhbHNlO1xuXHRsZXQgc2tpcEJsb2NrZXJOZXh0UG9wID0gZmFsc2U7XG5cdGxldCBpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2U7XG5cdGNvbnN0IGdldExvY2F0aW9uID0gKCkgPT4gY3VycmVudExvY2F0aW9uO1xuXHRsZXQgbmV4dDtcblx0Y29uc3QgZmx1c2ggPSAoKSA9PiB7XG5cdFx0aWYgKCFuZXh0KSByZXR1cm47XG5cdFx0aGlzdG9yeS5faWdub3JlU3Vic2NyaWJlcnMgPSB0cnVlO1xuXHRcdChuZXh0WzJdID8gd2luLmhpc3RvcnkucHVzaFN0YXRlIDogd2luLmhpc3RvcnkucmVwbGFjZVN0YXRlKShuZXh0WzFdLCBcIlwiLCBuZXh0WzBdKTtcblx0XHRoaXN0b3J5Ll9pZ25vcmVTdWJzY3JpYmVycyA9IGZhbHNlO1xuXHRcdG5leHQgPSB2b2lkIDA7XG5cdFx0cm9sbGJhY2tMb2NhdGlvbiA9IHZvaWQgMDtcblx0fTtcblx0Y29uc3QgcXVldWVIaXN0b3J5QWN0aW9uID0gKGlzUHVzaCwgZGVzdEhyZWYsIHN0YXRlKSA9PiB7XG5cdFx0Y29uc3QgaHJlZiA9IG9wdHM/LmNyZWF0ZUhyZWYgPyBjcmVhdGVIcmVmKGRlc3RIcmVmKSA6IHZvaWQgMDtcblx0XHRjb25zdCBoYXNQZW5kaW5nQWN0aW9uID0gISFuZXh0O1xuXHRcdGlmICghaGFzUGVuZGluZ0FjdGlvbikgcm9sbGJhY2tMb2NhdGlvbiA9IGN1cnJlbnRMb2NhdGlvbjtcblx0XHRjdXJyZW50TG9jYXRpb24gPSBwYXJzZUhyZWYoZGVzdEhyZWYsIHN0YXRlKTtcblx0XHRuZXh0ID0gW1xuXHRcdFx0aHJlZiA/PyBjdXJyZW50TG9jYXRpb24uaHJlZixcblx0XHRcdHN0YXRlLFxuXHRcdFx0bmV4dD8uWzJdIHx8IGlzUHVzaFxuXHRcdF07XG5cdFx0aWYgKCFoYXNQZW5kaW5nQWN0aW9uKSBxdWV1ZU1pY3JvdGFzaygoKSA9PiBmbHVzaCgpKTtcblx0fTtcblx0Y29uc3Qgb25QdXNoUG9wID0gKHR5cGUpID0+IHtcblx0XHRjdXJyZW50TG9jYXRpb24gPSBwYXJzZUxvY2F0aW9uKCk7XG5cdFx0aGlzdG9yeS5ub3RpZnkoeyB0eXBlIH0pO1xuXHR9O1xuXHRjb25zdCBvblB1c2hQb3BFdmVudCA9IGFzeW5jICgpID0+IHtcblx0XHRpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gZmFsc2U7XG5cdFx0aWYgKGlnbm9yZU5leHRQb3ApIHtcblx0XHRcdGlnbm9yZU5leHRQb3AgPSBmYWxzZTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgbmV4dExvY2F0aW9uID0gcGFyc2VMb2NhdGlvbigpO1xuXHRcdGNvbnN0IGRlbHRhID0gbmV4dExvY2F0aW9uLnN0YXRlW3N0YXRlSW5kZXhLZXldIC0gY3VycmVudExvY2F0aW9uLnN0YXRlW3N0YXRlSW5kZXhLZXldO1xuXHRcdGNvbnN0IGlzRm9yd2FyZCA9IGRlbHRhID09PSAxO1xuXHRcdGNvbnN0IGlzQmFjayA9IGRlbHRhID09PSAtMTtcblx0XHRjb25zdCBpc0dvID0gIWlzRm9yd2FyZCAmJiAhaXNCYWNrIHx8IG5leHRQb3BJc0dvO1xuXHRcdG5leHRQb3BJc0dvID0gZmFsc2U7XG5cdFx0Y29uc3QgYWN0aW9uID0gaXNHbyA/IFwiR09cIiA6IGlzQmFjayA/IFwiQkFDS1wiIDogXCJGT1JXQVJEXCI7XG5cdFx0Y29uc3Qgbm90aWZ5ID0gaXNHbyA/IHtcblx0XHRcdHR5cGU6IFwiR09cIixcblx0XHRcdGluZGV4OiBkZWx0YVxuXHRcdH0gOiB7IHR5cGU6IGlzQmFjayA/IFwiQkFDS1wiIDogXCJGT1JXQVJEXCIgfTtcblx0XHRpZiAoc2tpcEJsb2NrZXJOZXh0UG9wKSBza2lwQmxvY2tlck5leHRQb3AgPSBmYWxzZTtcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGJsb2NrZXJzID0gX2dldEJsb2NrZXJzKCk7XG5cdFx0XHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIGJsb2NrZXJzLmxlbmd0aCkge1xuXHRcdFx0XHRmb3IgKGNvbnN0IGJsb2NrZXIgb2YgYmxvY2tlcnMpIGlmIChhd2FpdCBibG9ja2VyLmJsb2NrZXJGbih7XG5cdFx0XHRcdFx0Y3VycmVudExvY2F0aW9uLFxuXHRcdFx0XHRcdG5leHRMb2NhdGlvbixcblx0XHRcdFx0XHRhY3Rpb25cblx0XHRcdFx0fSkpIHtcblx0XHRcdFx0XHRpZ25vcmVOZXh0UG9wID0gdHJ1ZTtcblx0XHRcdFx0XHR3aW4uaGlzdG9yeS5nbygtZGVsdGEpO1xuXHRcdFx0XHRcdGhpc3Rvcnkubm90aWZ5KG5vdGlmeSk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGN1cnJlbnRMb2NhdGlvbiA9IHBhcnNlTG9jYXRpb24oKTtcblx0XHRoaXN0b3J5Lm5vdGlmeShub3RpZnkpO1xuXHR9O1xuXHRjb25zdCBvbkJlZm9yZVVubG9hZCA9IChlKSA9PiB7XG5cdFx0aWYgKGlnbm9yZU5leHRCZWZvcmVVbmxvYWQpIHtcblx0XHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSBmYWxzZTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0bGV0IHNob3VsZEJsb2NrID0gZmFsc2U7XG5cdFx0Y29uc3QgYmxvY2tlcnMgPSBfZ2V0QmxvY2tlcnMoKTtcblx0XHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIGJsb2NrZXJzLmxlbmd0aCkgZm9yIChjb25zdCBibG9ja2VyIG9mIGJsb2NrZXJzKSB7XG5cdFx0XHRjb25zdCBzaG91bGRIYXZlQmVmb3JlVW5sb2FkID0gYmxvY2tlci5lbmFibGVCZWZvcmVVbmxvYWQgPz8gdHJ1ZTtcblx0XHRcdGlmIChzaG91bGRIYXZlQmVmb3JlVW5sb2FkID09PSB0cnVlKSB7XG5cdFx0XHRcdHNob3VsZEJsb2NrID0gdHJ1ZTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0XHRpZiAodHlwZW9mIHNob3VsZEhhdmVCZWZvcmVVbmxvYWQgPT09IFwiZnVuY3Rpb25cIiAmJiBzaG91bGRIYXZlQmVmb3JlVW5sb2FkKCkgPT09IHRydWUpIHtcblx0XHRcdFx0c2hvdWxkQmxvY2sgPSB0cnVlO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKHNob3VsZEJsb2NrKSB7XG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRyZXR1cm4gZS5yZXR1cm5WYWx1ZSA9IFwiXCI7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBoaXN0b3J5ID0gY3JlYXRlSGlzdG9yeSh7XG5cdFx0Z2V0TG9jYXRpb24sXG5cdFx0Z2V0TGVuZ3RoOiAoKSA9PiB3aW4uaGlzdG9yeS5sZW5ndGgsXG5cdFx0cHVzaFN0YXRlOiAoaHJlZiwgc3RhdGUpID0+IHF1ZXVlSGlzdG9yeUFjdGlvbih0cnVlLCBocmVmLCBzdGF0ZSksXG5cdFx0cmVwbGFjZVN0YXRlOiAoaHJlZiwgc3RhdGUpID0+IHF1ZXVlSGlzdG9yeUFjdGlvbihmYWxzZSwgaHJlZiwgc3RhdGUpLFxuXHRcdGJhY2s6IChpZ25vcmVCbG9ja2VyKSA9PiB7XG5cdFx0XHRpZiAoaWdub3JlQmxvY2tlcikge1xuXHRcdFx0XHRza2lwQmxvY2tlck5leHRQb3AgPSB0cnVlO1xuXHRcdFx0XHRpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB3aW4uaGlzdG9yeS5iYWNrKCk7XG5cdFx0fSxcblx0XHRmb3J3YXJkOiAoaWdub3JlQmxvY2tlcikgPT4ge1xuXHRcdFx0aWYgKGlnbm9yZUJsb2NrZXIpIHtcblx0XHRcdFx0c2tpcEJsb2NrZXJOZXh0UG9wID0gdHJ1ZTtcblx0XHRcdFx0aWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IHRydWU7XG5cdFx0XHR9XG5cdFx0XHR3aW4uaGlzdG9yeS5mb3J3YXJkKCk7XG5cdFx0fSxcblx0XHRnbzogKG4sIGlnbm9yZUJsb2NrZXIpID0+IHtcblx0XHRcdG5leHRQb3BJc0dvID0gdHJ1ZTtcblx0XHRcdGlmIChpZ25vcmVCbG9ja2VyKSB7XG5cdFx0XHRcdHNraXBCbG9ja2VyTmV4dFBvcCA9IHRydWU7XG5cdFx0XHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdFx0d2luLmhpc3RvcnkuZ28obik7XG5cdFx0fSxcblx0XHRjcmVhdGVIcmVmOiAoaHJlZikgPT4gY3JlYXRlSHJlZihocmVmKSxcblx0XHRmbHVzaCxcblx0XHRkZXN0cm95OiAoKSA9PiB7XG5cdFx0XHR3aW4uaGlzdG9yeS5wdXNoU3RhdGUgPSBvcmlnaW5hbFB1c2hTdGF0ZTtcblx0XHRcdHdpbi5oaXN0b3J5LnJlcGxhY2VTdGF0ZSA9IG9yaWdpbmFsUmVwbGFjZVN0YXRlO1xuXHRcdFx0d2luLnJlbW92ZUV2ZW50TGlzdGVuZXIoYmVmb3JlVW5sb2FkRXZlbnQsIG9uQmVmb3JlVW5sb2FkLCB7IGNhcHR1cmU6IHRydWUgfSk7XG5cdFx0XHR3aW4ucmVtb3ZlRXZlbnRMaXN0ZW5lcihwb3BTdGF0ZUV2ZW50LCBvblB1c2hQb3BFdmVudCk7XG5cdFx0fSxcblx0XHRvbkJsb2NrZWQ6ICgpID0+IHtcblx0XHRcdGlmIChyb2xsYmFja0xvY2F0aW9uICYmIGN1cnJlbnRMb2NhdGlvbiAhPT0gcm9sbGJhY2tMb2NhdGlvbikgY3VycmVudExvY2F0aW9uID0gcm9sbGJhY2tMb2NhdGlvbjtcblx0XHR9LFxuXHRcdGdldEJsb2NrZXJzOiBfZ2V0QmxvY2tlcnMsXG5cdFx0c2V0QmxvY2tlcnM6IF9zZXRCbG9ja2Vycyxcblx0XHRub3RpZnlPbkluZGV4Q2hhbmdlOiBmYWxzZVxuXHR9KTtcblx0aGlzdG9yeS5faWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IChocmVmKSA9PiB7XG5cdFx0aWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IGZhbHNlO1xuXHRcdHRyeSB7XG5cdFx0XHRocmVmID0gbmV3IFVSTChocmVmLCB3aW4uZG9jdW1lbnQuYmFzZVVSSSkuaHJlZjtcblx0XHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSAvXmh0dHBzPzovLnRlc3QoaHJlZikgJiYgKCFocmVmLmluY2x1ZGVzKFwiI1wiKSB8fCBocmVmLnNwbGl0KFwiI1wiKVswXSAhPT0gd2luLmxvY2F0aW9uLmhyZWYuc3BsaXQoXCIjXCIpWzBdKTtcblx0XHR9IGNhdGNoIHt9XG5cdH07XG5cdHdpbi5hZGRFdmVudExpc3RlbmVyKGJlZm9yZVVubG9hZEV2ZW50LCBvbkJlZm9yZVVubG9hZCwgeyBjYXB0dXJlOiB0cnVlIH0pO1xuXHR3aW4uYWRkRXZlbnRMaXN0ZW5lcihwb3BTdGF0ZUV2ZW50LCBvblB1c2hQb3BFdmVudCk7XG5cdHdpbi5oaXN0b3J5LnB1c2hTdGF0ZSA9IGZ1bmN0aW9uKC4uLmFyZ3MpIHtcblx0XHRjb25zdCByZXMgPSBvcmlnaW5hbFB1c2hTdGF0ZS5hcHBseSh3aW4uaGlzdG9yeSwgYXJncyk7XG5cdFx0aWYgKCFoaXN0b3J5Ll9pZ25vcmVTdWJzY3JpYmVycykgb25QdXNoUG9wKFwiUFVTSFwiKTtcblx0XHRyZXR1cm4gcmVzO1xuXHR9O1xuXHR3aW4uaGlzdG9yeS5yZXBsYWNlU3RhdGUgPSBmdW5jdGlvbiguLi5hcmdzKSB7XG5cdFx0Y29uc3QgcmVzID0gb3JpZ2luYWxSZXBsYWNlU3RhdGUuYXBwbHkod2luLmhpc3RvcnksIGFyZ3MpO1xuXHRcdGlmICghaGlzdG9yeS5faWdub3JlU3Vic2NyaWJlcnMpIG9uUHVzaFBvcChcIlJFUExBQ0VcIik7XG5cdFx0cmV0dXJuIHJlcztcblx0fTtcblx0cmV0dXJuIGhpc3Rvcnk7XG59XG4vKipcbiogQ3JlYXRlIGEgaGFzaC1iYXNlZCBoaXN0b3J5IGltcGxlbWVudGF0aW9uLlxuKiBVc2VmdWwgZm9yIHN0YXRpYyBob3N0cyBvciBlbnZpcm9ubWVudHMgd2l0aG91dCBzZXJ2ZXIgVVJMIHJld3JpdGluZy5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9oaXN0b3J5LXR5cGVzXG4qL1xuZnVuY3Rpb24gY3JlYXRlSGFzaEhpc3Rvcnkob3B0cykge1xuXHRjb25zdCB3aW4gPSBvcHRzPy53aW5kb3cgPz8gKHR5cGVvZiBkb2N1bWVudCAhPT0gXCJ1bmRlZmluZWRcIiA/IHdpbmRvdyA6IHZvaWQgMCk7XG5cdHJldHVybiBjcmVhdGVCcm93c2VySGlzdG9yeSh7XG5cdFx0d2luZG93OiB3aW4sXG5cdFx0cGFyc2VMb2NhdGlvbjogKCkgPT4ge1xuXHRcdFx0Y29uc3QgaGFzaFNwbGl0ID0gd2luLmxvY2F0aW9uLmhhc2guc3BsaXQoXCIjXCIpLnNsaWNlKDEpO1xuXHRcdFx0Y29uc3QgcGF0aFBhcnQgPSBoYXNoU3BsaXRbMF0gPz8gXCIvXCI7XG5cdFx0XHRjb25zdCBzZWFyY2hQYXJ0ID0gd2luLmxvY2F0aW9uLnNlYXJjaDtcblx0XHRcdGNvbnN0IGhhc2hFbnRyaWVzID0gaGFzaFNwbGl0LnNsaWNlKDEpO1xuXHRcdFx0cmV0dXJuIHBhcnNlSHJlZihgJHtwYXRoUGFydH0ke3NlYXJjaFBhcnR9JHtoYXNoRW50cmllcy5sZW5ndGggPT09IDAgPyBcIlwiIDogYCMke2hhc2hFbnRyaWVzLmpvaW4oXCIjXCIpfWB9YCwgd2luLmhpc3Rvcnkuc3RhdGUpO1xuXHRcdH0sXG5cdFx0Y3JlYXRlSHJlZjogKGhyZWYpID0+IGAke3dpbi5sb2NhdGlvbi5wYXRobmFtZX0ke3dpbi5sb2NhdGlvbi5zZWFyY2h9IyR7aHJlZn1gXG5cdH0pO1xufVxuLyoqXG4qIENyZWF0ZSBhbiBpbi1tZW1vcnkgaGlzdG9yeSBpbXBsZW1lbnRhdGlvbi5cbiogSWRlYWwgZm9yIHNlcnZlciByZW5kZXJpbmcsIHRlc3RzLCBhbmQgbm9uLURPTSBlbnZpcm9ubWVudHMuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGUvaGlzdG9yeS10eXBlc1xuKi9cbmZ1bmN0aW9uIGNyZWF0ZU1lbW9yeUhpc3Rvcnkob3B0cyA9IHsgaW5pdGlhbEVudHJpZXM6IFtcIi9cIl0gfSkge1xuXHRjb25zdCBlbnRyaWVzID0gb3B0cy5pbml0aWFsRW50cmllcztcblx0bGV0IGluZGV4ID0gb3B0cy5pbml0aWFsSW5kZXggPyBNYXRoLm1pbihNYXRoLm1heChvcHRzLmluaXRpYWxJbmRleCwgMCksIGVudHJpZXMubGVuZ3RoIC0gMSkgOiBlbnRyaWVzLmxlbmd0aCAtIDE7XG5cdGNvbnN0IHN0YXRlcyA9IGVudHJpZXMubWFwKChfZW50cnksIGluZGV4KSA9PiBhc3NpZ25LZXlBbmRJbmRleChpbmRleCwgdm9pZCAwKSk7XG5cdGNvbnN0IGdldExvY2F0aW9uID0gKCkgPT4gcGFyc2VIcmVmKGVudHJpZXNbaW5kZXhdLCBzdGF0ZXNbaW5kZXhdKTtcblx0bGV0IGJsb2NrZXJzID0gW107XG5cdGNvbnN0IF9nZXRCbG9ja2VycyA9ICgpID0+IGJsb2NrZXJzO1xuXHRjb25zdCBfc2V0QmxvY2tlcnMgPSAobmV3QmxvY2tlcnMpID0+IGJsb2NrZXJzID0gbmV3QmxvY2tlcnM7XG5cdHJldHVybiBjcmVhdGVIaXN0b3J5KHtcblx0XHRnZXRMb2NhdGlvbixcblx0XHRnZXRMZW5ndGg6ICgpID0+IGVudHJpZXMubGVuZ3RoLFxuXHRcdHB1c2hTdGF0ZTogKHBhdGgsIHN0YXRlKSA9PiB7XG5cdFx0XHRpbmRleCA9IGluZGV4IDwgZW50cmllcy5sZW5ndGggLSAxID8gaW5kZXggKyAxIDogZW50cmllcy5sZW5ndGg7XG5cdFx0XHRzdGF0ZXNbaW5kZXhdID0gc3RhdGU7XG5cdFx0XHRlbnRyaWVzW2luZGV4XSA9IHBhdGg7XG5cdFx0XHRpZiAoaW5kZXggPCBlbnRyaWVzLmxlbmd0aCAtIDEpIHtcblx0XHRcdFx0ZW50cmllcy5sZW5ndGggPSBpbmRleCArIDE7XG5cdFx0XHRcdHN0YXRlcy5sZW5ndGggPSBpbmRleCArIDE7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHRyZXBsYWNlU3RhdGU6IChwYXRoLCBzdGF0ZSkgPT4ge1xuXHRcdFx0c3RhdGVzW2luZGV4XSA9IHN0YXRlO1xuXHRcdFx0ZW50cmllc1tpbmRleF0gPSBwYXRoO1xuXHRcdH0sXG5cdFx0YmFjazogKCkgPT4ge1xuXHRcdFx0aW5kZXggPSBNYXRoLm1heChpbmRleCAtIDEsIDApO1xuXHRcdH0sXG5cdFx0Zm9yd2FyZDogKCkgPT4ge1xuXHRcdFx0aW5kZXggPSBNYXRoLm1pbihpbmRleCArIDEsIGVudHJpZXMubGVuZ3RoIC0gMSk7XG5cdFx0fSxcblx0XHRnbzogKG4pID0+IHtcblx0XHRcdGluZGV4ID0gTWF0aC5taW4oTWF0aC5tYXgoaW5kZXggKyBuLCAwKSwgZW50cmllcy5sZW5ndGggLSAxKTtcblx0XHR9LFxuXHRcdGNyZWF0ZUhyZWY6IG5vcm1hbGl6ZUhyZWYsXG5cdFx0Z2V0QmxvY2tlcnM6IF9nZXRCbG9ja2Vycyxcblx0XHRzZXRCbG9ja2VyczogX3NldEJsb2NrZXJzXG5cdH0pO1xufVxudmFyIG5vb3AgPSAoKSA9PiB7fTtcbnZhciBTZXJ2ZXJIaXN0b3J5ID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3Rvcihsb2NhdGlvbikge1xuXHRcdHRoaXMubG9jYXRpb24gPSBsb2NhdGlvbjtcblx0fVxuXHRnZXQgbGVuZ3RoKCkge1xuXHRcdHJldHVybiAxO1xuXHR9XG5cdGdldCBzdWJzY3JpYmVycygpIHtcblx0XHRyZXR1cm4gdGhpcy5fc3Vic2NyaWJlcnMgPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdH1cblx0c3Vic2NyaWJlKCkge1xuXHRcdHJldHVybiBub29wO1xuXHR9XG5cdHB1c2goKSB7fVxuXHRyZXBsYWNlKCkge31cblx0Z28oKSB7fVxuXHRiYWNrKCkge31cblx0Zm9yd2FyZCgpIHt9XG5cdGNhbkdvQmFjaygpIHtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cblx0Y3JlYXRlSHJlZihocmVmKSB7XG5cdFx0cmV0dXJuIG5vcm1hbGl6ZUhyZWYoaHJlZik7XG5cdH1cblx0YmxvY2soKSB7XG5cdFx0cmV0dXJuIG5vb3A7XG5cdH1cblx0Zmx1c2goKSB7fVxuXHRkZXN0cm95KCkge31cblx0bm90aWZ5KCkge31cblx0X2dldEJsb2NrZXJzKCkge1xuXHRcdHJldHVybiBbXTtcblx0fVxufTtcbi8qKiBBIGZpeGVkIHJlcXVlc3QgbG9jYXRpb247IHNlcnZlciBuYXZpZ2F0aW9uIGlzIGEgbm8tb3AuICovXG5mdW5jdGlvbiBjcmVhdGVTZXJ2ZXJIaXN0b3J5KGhyZWYpIHtcblx0cmV0dXJuIG5ldyBTZXJ2ZXJIaXN0b3J5KHBhcnNlSHJlZihocmVmLCB2b2lkIDApKTtcbn1cbmZ1bmN0aW9uIHBhcnNlSHJlZihocmVmLCBzdGF0ZSkge1xuXHRjb25zdCBzYW5pdGl6ZWRIcmVmID0gbm9ybWFsaXplSHJlZihocmVmKTtcblx0Y29uc3QgaGFzaEluZGV4ID0gc2FuaXRpemVkSHJlZi5pbmRleE9mKFwiI1wiKTtcblx0Y29uc3Qgc2VhcmNoSW5kZXggPSBzYW5pdGl6ZWRIcmVmLmluZGV4T2YoXCI/XCIpO1xuXHRpZiAoIXN0YXRlKSB7XG5cdFx0Y29uc3Qga2V5ID0gY3JlYXRlUmFuZG9tS2V5KCk7XG5cdFx0c3RhdGUgPSB7XG5cdFx0XHRbc3RhdGVJbmRleEtleV06IDAsXG5cdFx0XHRrZXksXG5cdFx0XHRfX1RTUl9rZXk6IGtleVxuXHRcdH07XG5cdH1cblx0cmV0dXJuIHtcblx0XHRocmVmOiBzYW5pdGl6ZWRIcmVmLFxuXHRcdHBhdGhuYW1lOiBzYW5pdGl6ZWRIcmVmLnN1YnN0cmluZygwLCBoYXNoSW5kZXggPiAwID8gc2VhcmNoSW5kZXggPiAwID8gTWF0aC5taW4oaGFzaEluZGV4LCBzZWFyY2hJbmRleCkgOiBoYXNoSW5kZXggOiBzZWFyY2hJbmRleCA+IDAgPyBzZWFyY2hJbmRleCA6IHNhbml0aXplZEhyZWYubGVuZ3RoKSxcblx0XHRoYXNoOiBoYXNoSW5kZXggPiAtMSA/IHNhbml0aXplZEhyZWYuc3Vic3RyaW5nKGhhc2hJbmRleCkgOiBcIlwiLFxuXHRcdHNlYXJjaDogc2VhcmNoSW5kZXggPiAtMSA/IHNhbml0aXplZEhyZWYuc2xpY2Uoc2VhcmNoSW5kZXgsIGhhc2hJbmRleCA9PT0gLTEgPyB2b2lkIDAgOiBoYXNoSW5kZXgpIDogXCJcIixcblx0XHRzdGF0ZVxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlUmFuZG9tS2V5KCkge1xuXHRyZXR1cm4gKE1hdGgucmFuZG9tKCkgKyAxKS50b1N0cmluZygzNikuc3Vic3RyaW5nKDcpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVCcm93c2VySGlzdG9yeSwgY3JlYXRlSGFzaEhpc3RvcnksIGNyZWF0ZUhpc3RvcnksIGNyZWF0ZU1lbW9yeUhpc3RvcnksIGNyZWF0ZVNlcnZlckhpc3RvcnksIG5vcm1hbGl6ZVByb3RvY29sUmVsYXRpdmUsIHBhcnNlSHJlZiB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBERUZBVUxUX1BST1RPQ09MX0FMTE9XTElTVCwgY3JlYXRlTnVsbCwgZGVjb2RlUGF0aCwgZGVlcEVxdWFsLCBlbmNvZGVQYXRoTGlrZVVybCwgZmluZExhc3QsIGZ1bmN0aW9uYWxVcGRhdGUsIGdldFVybFNjaGVtZSwgaGFzS2V5cywgaGFzT3duLCBpc0Rhbmdlcm91c1Byb3RvY29sLCBsYXN0LCBudWxsUmVwbGFjZUVxdWFsRGVlcCwgcHJvdG9jb2xSZWxhdGl2ZVByZWZpeFJlZ2V4LCByZXBsYWNlRXF1YWxEZWVwIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IGNvbXBpbGVEZWNvZGVDaGFyTWFwLCBpbnRlcnBvbGF0ZVBhdGgsIHJlc29sdmVQYXRoLCB0cmltUGF0aCwgdHJpbVBhdGhSaWdodCB9IGZyb20gXCIuL3BhdGguanNcIjtcbmltcG9ydCB7IGNyZWF0ZVNpZXZlQ2FjaGUgfSBmcm9tIFwiLi9zaWV2ZS1jYWNoZS5qc1wiO1xuaW1wb3J0IHsgYnVpbGRSb3V0ZUJyYW5jaCwgZmluZEZsYXRNYXRjaCwgZmluZFJvdXRlTWF0Y2gsIGZpbmRTaW5nbGVNYXRjaCwgcGFyc2VTZWdtZW50cywgcHJvY2Vzc1JvdXRlTWFza3MsIHByb2Nlc3NSb3V0ZVRyZWUgfSBmcm9tIFwiLi9uZXctcHJvY2Vzcy1yb3V0ZS10cmVlLmpzXCI7XG5pbXBvcnQgeyBpc05vdEZvdW5kIH0gZnJvbSBcIi4vbm90LWZvdW5kLmpzXCI7XG5pbXBvcnQgeyBzZXR1cFNjcm9sbFJlc3RvcmF0aW9uIH0gZnJvbSBcIi4vc2Nyb2xsLXJlc3RvcmF0aW9uLmpzXCI7XG5pbXBvcnQgeyBkZWZhdWx0UGFyc2VTZWFyY2gsIGRlZmF1bHRTdHJpbmdpZnlTZWFyY2ggfSBmcm9tIFwiLi9zZWFyY2hQYXJhbXMuanNcIjtcbmltcG9ydCB7IHJvb3RSb3V0ZUlkIH0gZnJvbSBcIi4vcm9vdC5qc1wiO1xuaW1wb3J0IHsgaXNSZWRpcmVjdCB9IGZyb20gXCIuL3JlZGlyZWN0LmpzXCI7XG5pbXBvcnQgeyBsb2FkQ2xpZW50Um91dGUsIGxvYWRSb3V0ZUNodW5rLCBwcmVsb2FkQ2xpZW50Um91dGUsIHJlZnJlc2hDbGllbnRSb3V0ZSwgcmVwbGFjZVJvdXRlQ2h1bmsgfSBmcm9tIFwiLi9sb2FkLWNsaWVudC5qc1wiO1xuaW1wb3J0IHsgZXhlY3V0ZVJld3JpdGVJbnB1dCwgZXhlY3V0ZVJld3JpdGVPdXRwdXQsIHJld3JpdGVCYXNlcGF0aCB9IGZyb20gXCIuL3Jld3JpdGUuanNcIjtcbmltcG9ydCB7IGNyZWF0ZVJvdXRlclN0b3JlcyB9IGZyb20gXCIuL3N0b3Jlcy5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQnJvd3Nlckhpc3RvcnksIG5vcm1hbGl6ZVByb3RvY29sUmVsYXRpdmUsIHBhcnNlSHJlZiB9IGZyb20gXCJAdGFuc3RhY2svaGlzdG9yeVwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIsIGxvYWRTZXJ2ZXJSb3V0ZSB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbi8vI3JlZ2lvbiBzcmMvcm91dGVyLnRzXG5mdW5jdGlvbiBpc0V4dGVybmFsVXJsKHVybCwgb3JpZ2luKSB7XG5cdHJldHVybiB1cmwucHJvdG9jb2wgIT09IFwiaHR0cDpcIiAmJiB1cmwucHJvdG9jb2wgIT09IFwiaHR0cHM6XCIgfHwgdXJsLm9yaWdpbiAhPT0gb3JpZ2luIHx8ICEhdXJsLnVzZXJuYW1lIHx8ICEhdXJsLnBhc3N3b3JkO1xufVxuZnVuY3Rpb24gZ2V0VXJsUGF0aCh1cmwpIHtcblx0cmV0dXJuIHVybC5wYXRobmFtZSArIHVybC5zZWFyY2ggKyB1cmwuaGFzaDtcbn1cbmZ1bmN0aW9uIHJvdXRlTmVlZHNMb2FkKHJvdXRlKSB7XG5cdHJldHVybiByb3V0ZS5vcHRpb25zLmxvYWRlciB8fCByb3V0ZS5vcHRpb25zLmJlZm9yZUxvYWQgfHwgcm91dGUubGF6eUZuIHx8IHJvdXRlLm9wdGlvbnMuY29tcG9uZW50Py5wcmVsb2FkIHx8IHJvdXRlLm9wdGlvbnMucGVuZGluZ0NvbXBvbmVudD8ucHJlbG9hZDtcbn1cbi8qKlxuKiBDb252ZXJ0IGFuIHVua25vd24gZXJyb3IgaW50byBhIG1pbmltYWwsIHNlcmlhbGl6YWJsZSBvYmplY3QuXG4qIEluY2x1ZGVzIG5hbWUgYW5kIG1lc3NhZ2UgKGFuZCBzdGFjayBpbiBkZXZlbG9wbWVudCkuXG4qL1xuZnVuY3Rpb24gZGVmYXVsdFNlcmlhbGl6ZUVycm9yKGVycikge1xuXHRpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHtcblx0XHRjb25zdCBvYmogPSB7XG5cdFx0XHRuYW1lOiBlcnIubmFtZSxcblx0XHRcdG1lc3NhZ2U6IGVyci5tZXNzYWdlXG5cdFx0fTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwiZGV2ZWxvcG1lbnRcIikgb2JqLnN0YWNrID0gZXJyLnN0YWNrO1xuXHRcdHJldHVybiBvYmo7XG5cdH1cblx0cmV0dXJuIHsgZGF0YTogZXJyIH07XG59XG4vKiogT3B0aW9ucyBmb3IgY29uZmlndXJpbmcgdHJhaWxpbmctc2xhc2ggYmVoYXZpb3IuICovXG5jb25zdCB0cmFpbGluZ1NsYXNoT3B0aW9ucyA9IHtcblx0YWx3YXlzOiBcImFsd2F5c1wiLFxuXHRuZXZlcjogXCJuZXZlclwiLFxuXHRwcmVzZXJ2ZTogXCJwcmVzZXJ2ZVwiXG59O1xuLyoqXG4qIENvbXB1dGUgd2hldGhlciBwYXRoLCBocmVmIG9yIGhhc2ggY2hhbmdlZCBiZXR3ZWVuIHByZXZpb3VzIGFuZCBjdXJyZW50XG4qIHJlc29sdmVkIGxvY2F0aW9ucy5cbiovXG5mdW5jdGlvbiBnZXRMb2NhdGlvbkNoYW5nZUluZm8obG9jYXRpb24sIHJlc29sdmVkTG9jYXRpb24pIHtcblx0cmV0dXJuIHtcblx0XHRmcm9tTG9jYXRpb246IHJlc29sdmVkTG9jYXRpb24sXG5cdFx0dG9Mb2NhdGlvbjogbG9jYXRpb24sXG5cdFx0cGF0aENoYW5nZWQ6IHJlc29sdmVkTG9jYXRpb24/LnBhdGhuYW1lICE9PSBsb2NhdGlvbi5wYXRobmFtZSxcblx0XHRocmVmQ2hhbmdlZDogcmVzb2x2ZWRMb2NhdGlvbj8uaHJlZiAhPT0gbG9jYXRpb24uaHJlZixcblx0XHRoYXNoQ2hhbmdlZDogcmVzb2x2ZWRMb2NhdGlvbj8uaGFzaCAhPT0gbG9jYXRpb24uaGFzaFxuXHR9O1xufVxuLyoqXG4qIFJldHVybiBvbmx5IHN0YXRlIG93bmVkIGJ5IHRoZSBhcHBsaWNhdGlvbiwgZXhjbHVkaW5nIHZvbGF0aWxlIGhpc3RvcnlcbiogYm9va2tlZXBpbmcuIE1hc2sgcGF5bG9hZHMgKGBfX3RlbXBMb2NhdGlvbmAvYF9fdGVtcEtleWApIGFyZSBrZXB0OiB0aGV5XG4qIGRpc3Rpbmd1aXNoIG90aGVyd2lzZS1pZGVudGljYWwgbG9jYXRpb25zLlxuKi9cbmZ1bmN0aW9uIF9nZXRVc2VySGlzdG9yeVN0YXRlKHsga2V5OiBfa2V5LCBfX1RTUl9rZXk6IF90c3JLZXksIF9fVFNSX2luZGV4OiBfdHNySW5kZXgsIF9faGFzaFNjcm9sbEludG9WaWV3T3B0aW9uczogX2hhc2hTY3JvbGwsIC4uLnN0YXRlIH0pIHtcblx0cmV0dXJuIHN0YXRlO1xufVxuZnVuY3Rpb24gbGlmZWN5Y2xlRW5kKG1hdGNoZXMpIHtcblx0cmV0dXJuIG1hdGNoZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guc3RhdHVzID09PSBcImVycm9yXCIgfHwgbWF0Y2guc3RhdHVzID09PSBcIm5vdEZvdW5kXCIgfHwgbWF0Y2guX25vdEZvdW5kKSArIDE7XG59XG4vKiogUnVuIHJvdXRlIGxpZmVjeWNsZSBjYWxsYmFja3MgaW4gbGVhdmUvZW50ZXIvc3RheSBwaGFzZXMuICovXG5mdW5jdGlvbiBydW5Sb3V0ZUxpZmVjeWNsZShyb3V0ZXIsIHByZXZpb3VzLCBtYXRjaGVzLCBwcmV2aW91c0VuZCwgbmV4dEVuZCwgb3duZXIpIHtcblx0aWYgKHByZXZpb3VzRW5kKSBwcmV2aW91cyA9IHByZXZpb3VzLnNsaWNlKDAsIHByZXZpb3VzRW5kKTtcblx0aWYgKG5leHRFbmQpIG1hdGNoZXMgPSBtYXRjaGVzLnNsaWNlKDAsIG5leHRFbmQpO1xuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIHByZXZpb3VzKSB7XG5cdFx0aWYgKG93bmVyICYmIHJvdXRlci5fdHggIT09IG93bmVyKSByZXR1cm47XG5cdFx0aWYgKCFtYXRjaGVzLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLnJvdXRlSWQgPT09IG1hdGNoLnJvdXRlSWQpKSByb3V0ZXIucm91dGVzQnlJZFttYXRjaC5yb3V0ZUlkXS5vcHRpb25zLm9uTGVhdmU/LihtYXRjaCk7XG5cdH1cblx0Zm9yIChjb25zdCBtYXRjaCBvZiBtYXRjaGVzKSB7XG5cdFx0aWYgKG93bmVyICYmIHJvdXRlci5fdHggIT09IG93bmVyKSByZXR1cm47XG5cdFx0cm91dGVyLnJvdXRlc0J5SWRbbWF0Y2gucm91dGVJZF0ub3B0aW9uc1twcmV2aW91cy5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5yb3V0ZUlkID09PSBtYXRjaC5yb3V0ZUlkKSA/IFwib25TdGF5XCIgOiBcIm9uRW50ZXJcIl0/LihtYXRjaCk7XG5cdH1cbn1cbi8qKlxuKiBDb3JlLCBmcmFtZXdvcmstYWdub3N0aWMgcm91dGVyIGVuZ2luZSB0aGF0IHBvd2VycyBUYW5TdGFjayBSb3V0ZXIuXG4qXG4qIFByb3ZpZGVzIG5hdmlnYXRpb24sIG1hdGNoaW5nLCBsb2FkaW5nLCBwcmVsb2FkaW5nLCBjYWNoaW5nIGFuZCBldmVudCBBUElzXG4qIHVzZWQgYnkgZnJhbWV3b3JrIGFkYXB0ZXJzIChSZWFjdC9Tb2xpZCkuIFByZWZlciBmcmFtZXdvcmsgaGVscGVycyBsaWtlXG4qIGBjcmVhdGVSb3V0ZXJgIGluIGFwcCBjb2RlLlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvUm91dGVyVHlwZVxuKi9cbnZhciBSb3V0ZXJDb3JlID0gY2xhc3Mge1xuXHQvKipcblx0KiBAZGVwcmVjYXRlZCBVc2UgdGhlIGBjcmVhdGVSb3V0ZXJgIGZ1bmN0aW9uIGluc3RlYWRcblx0Ki9cblx0Y29uc3RydWN0b3Iob3B0aW9ucywgZ2V0U3RvcmVDb25maWcpIHtcblx0XHR0aGlzLnRlbXBMb2NhdGlvbktleSA9IGAke01hdGgucm91bmQoTWF0aC5yYW5kb20oKSAqIDFlNyl9YDtcblx0XHR0aGlzLl9zY3JvbGwgPSB7IG46IHRydWUgfTtcblx0XHR0aGlzLnN1YnNjcmliZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHR0aGlzLl9jYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0dGhpcy5fY29tbWl0dGVkID0gW107XG5cdFx0dGhpcy5zdGFydFRyYW5zaXRpb24gPSBhc3luYyAoZm4pID0+IHtcblx0XHRcdGZuKCk7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fTtcblx0XHR0aGlzLnVwZGF0ZSA9IChuZXdPcHRpb25zKSA9PiB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRcdGlmIChuZXdPcHRpb25zLm5vdEZvdW5kUm91dGUpIGNvbnNvbGUud2FybihcIlRoZSBub3RGb3VuZFJvdXRlIEFQSSBpcyBkZXByZWNhdGVkIGFuZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi4gU2VlIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci92MS9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9ub3QtZm91bmQtZXJyb3JzI21pZ3JhdGluZy1mcm9tLW5vdGZvdW5kcm91dGUgZm9yIG1vcmUgaW5mby5cIik7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBwcmV2T3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHRcdHRoaXMub3B0aW9ucyA9IHtcblx0XHRcdFx0Li4ucHJldk9wdGlvbnMsXG5cdFx0XHRcdC4uLm5ld09wdGlvbnNcblx0XHRcdH07XG5cdFx0XHR0aGlzLmlzU2VydmVyID0gdGhpcy5vcHRpb25zLmlzU2VydmVyID8/IGlzU2VydmVyID8/IHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIjtcblx0XHRcdGlmICghKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpKSB0aGlzLnN0YXRpY0xvY2F0aW9ucyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuXHRcdFx0dGhpcy5wcm90b2NvbEFsbG93bGlzdCA9IG5ldyBTZXQodGhpcy5vcHRpb25zLnByb3RvY29sQWxsb3dsaXN0KTtcblx0XHRcdGlmICghdGhpcy5oaXN0b3J5IHx8IHRoaXMub3B0aW9ucy5oaXN0b3J5ICYmIHRoaXMub3B0aW9ucy5oaXN0b3J5ICE9PSB0aGlzLmhpc3RvcnkpIGlmICghdGhpcy5vcHRpb25zLmhpc3RvcnkpIHtcblx0XHRcdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHRoaXMuaGlzdG9yeSA9IGNyZWF0ZUJyb3dzZXJIaXN0b3J5KCk7XG5cdFx0XHR9IGVsc2UgdGhpcy5oaXN0b3J5ID0gdGhpcy5vcHRpb25zLmhpc3Rvcnk7XG5cdFx0XHR0aGlzLm9yaWdpbiA9IHRoaXMub3B0aW9ucy5vcmlnaW47XG5cdFx0XHRpZiAoIXRoaXMub3JpZ2luKSBpZiAoIShpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSAmJiB3aW5kb3c/Lm9yaWdpbiAmJiB3aW5kb3cub3JpZ2luICE9PSBcIm51bGxcIikgdGhpcy5vcmlnaW4gPSB3aW5kb3cub3JpZ2luO1xuXHRcdFx0ZWxzZSB0aGlzLm9yaWdpbiA9IFwiaHR0cDovL2xvY2FsaG9zdFwiO1xuXHRcdFx0Y29uc3QgbmV4dEJhc2VwYXRoID0gdGhpcy5vcHRpb25zLmJhc2VwYXRoID8/IFwiL1wiO1xuXHRcdFx0Y29uc3QgbmV4dFJld3JpdGVPcHRpb24gPSB0aGlzLm9wdGlvbnMucmV3cml0ZTtcblx0XHRcdGNvbnN0IHJld3JpdGVDaGFuZ2VkID0gdGhpcy5iYXNlcGF0aCAhPT0gbmV4dEJhc2VwYXRoIHx8IHByZXZPcHRpb25zPy5yZXdyaXRlICE9PSBuZXh0UmV3cml0ZU9wdGlvbiB8fCBwcmV2T3B0aW9ucz8uY2FzZVNlbnNpdGl2ZSAhPT0gdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmU7XG5cdFx0XHRpZiAocmV3cml0ZUNoYW5nZWQpIHtcblx0XHRcdFx0dGhpcy5iYXNlcGF0aCA9IG5leHRCYXNlcGF0aDtcblx0XHRcdFx0dGhpcy5yZXdyaXRlID0gbmV4dEJhc2VwYXRoICE9PSBcIi9cIiAmJiB0cmltUGF0aChuZXh0QmFzZXBhdGgpID8gcmV3cml0ZUJhc2VwYXRoKG5leHRCYXNlcGF0aCwgdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmUsIG5leHRSZXdyaXRlT3B0aW9uKSA6IG5leHRSZXdyaXRlT3B0aW9uO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHRoaXMuaGlzdG9yeSkgdGhpcy51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5yb3V0ZVRyZWUgIT09IHRoaXMucm91dGVUcmVlIHx8IChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSAmJiBwcmV2T3B0aW9ucz8uY2FzZVNlbnNpdGl2ZSAhPT0gdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmUpIHtcblx0XHRcdFx0dGhpcy5yb3V0ZVRyZWUgPSB0aGlzLm9wdGlvbnMucm91dGVUcmVlO1xuXHRcdFx0XHRsZXQgcHJvY2Vzc1JvdXRlVHJlZVJlc3VsdDtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcImRldmVsb3BtZW50XCIgJiYgKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpICYmIGdsb2JhbFRoaXMuX19UU1JfQ0FDSEVfXyAmJiBnbG9iYWxUaGlzLl9fVFNSX0NBQ0hFX18ucm91dGVUcmVlID09PSB0aGlzLnJvdXRlVHJlZSAmJiBnbG9iYWxUaGlzLl9fVFNSX0NBQ0hFX18uY2FzZVNlbnNpdGl2ZSA9PT0gdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmUpIHByb2Nlc3NSb3V0ZVRyZWVSZXN1bHQgPSBnbG9iYWxUaGlzLl9fVFNSX0NBQ0hFX18ucHJvY2Vzc1JvdXRlVHJlZVJlc3VsdDtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0cHJvY2Vzc1JvdXRlVHJlZVJlc3VsdCA9IHRoaXMuYnVpbGRSb3V0ZVRyZWUoKTtcblx0XHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwiZGV2ZWxvcG1lbnRcIiAmJiAoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikgJiYgZ2xvYmFsVGhpcy5fX1RTUl9DQUNIRV9fID09PSB2b2lkIDApIGdsb2JhbFRoaXMuX19UU1JfQ0FDSEVfXyA9IHtcblx0XHRcdFx0XHRcdHJvdXRlVHJlZTogdGhpcy5yb3V0ZVRyZWUsXG5cdFx0XHRcdFx0XHRjYXNlU2Vuc2l0aXZlOiB0aGlzLm9wdGlvbnMuY2FzZVNlbnNpdGl2ZSxcblx0XHRcdFx0XHRcdHByb2Nlc3NSb3V0ZVRyZWVSZXN1bHRcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9XG5cdFx0XHRcdHRoaXMuc2V0Um91dGVzKHByb2Nlc3NSb3V0ZVRyZWVSZXN1bHQpO1xuXHRcdFx0fVxuXHRcdFx0aWYgKCF0aGlzLnN0b3Jlcykge1xuXHRcdFx0XHRpZiAodGhpcy5sYXRlc3RMb2NhdGlvbikge1xuXHRcdFx0XHRcdGNvbnN0IGNvbmZpZyA9IHRoaXMuZ2V0U3RvcmVDb25maWcodGhpcyk7XG5cdFx0XHRcdFx0dGhpcy5iYXRjaCA9IGNvbmZpZy5iYXRjaDtcblx0XHRcdFx0XHR0aGlzLnN0b3JlcyA9IGNyZWF0ZVJvdXRlclN0b3Jlcyh0aGlzLmxhdGVzdExvY2F0aW9uLCBjb25maWcpO1xuXHRcdFx0XHRcdGlmICghKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpKSBzZXR1cFNjcm9sbFJlc3RvcmF0aW9uKHRoaXMpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgaWYgKHJld3JpdGVDaGFuZ2VkKSB0aGlzLnN0b3Jlcy5sb2NhdGlvbi5zZXQodGhpcy5sYXRlc3RMb2NhdGlvbik7XG5cdFx0fTtcblx0XHR0aGlzLnVwZGF0ZUxhdGVzdExvY2F0aW9uID0gKCkgPT4ge1xuXHRcdFx0dGhpcy5sYXRlc3RMb2NhdGlvbiA9IHRoaXMucGFyc2VMb2NhdGlvbih0aGlzLmhpc3RvcnkubG9jYXRpb24sIHRoaXMubGF0ZXN0TG9jYXRpb24pO1xuXHRcdH07XG5cdFx0dGhpcy5idWlsZFJvdXRlVHJlZSA9ICgpID0+IHtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IHByb2Nlc3NSb3V0ZVRyZWUodGhpcy5yb3V0ZVRyZWUsIHRoaXMub3B0aW9ucy5jYXNlU2Vuc2l0aXZlKTtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMucm91dGVNYXNrcykgcHJvY2Vzc1JvdXRlTWFza3ModGhpcy5vcHRpb25zLnJvdXRlTWFza3MsIHJlc3VsdC5wcm9jZXNzZWRUcmVlKTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdC4uLnJlc3VsdCxcblx0XHRcdFx0cmVzb2x2ZVBhdGhDYWNoZTogY3JlYXRlU2lldmVDYWNoZSgxZTMpXG5cdFx0XHR9O1xuXHRcdH07XG5cdFx0dGhpcy5zdWJzY3JpYmUgPSAoZXZlbnRUeXBlLCBmbikgPT4ge1xuXHRcdFx0Y29uc3QgbGlzdGVuZXIgPSB7XG5cdFx0XHRcdGV2ZW50VHlwZSxcblx0XHRcdFx0Zm5cblx0XHRcdH07XG5cdFx0XHR0aGlzLnN1YnNjcmliZXJzLmFkZChsaXN0ZW5lcik7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHR0aGlzLnN1YnNjcmliZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG5cdFx0XHR9O1xuXHRcdH07XG5cdFx0dGhpcy5lbWl0ID0gKHJvdXRlckV2ZW50KSA9PiB7XG5cdFx0XHRmb3IgKGNvbnN0IGxpc3RlbmVyIG9mIHRoaXMuc3Vic2NyaWJlcnMpIGlmIChsaXN0ZW5lci5ldmVudFR5cGUgPT09IHJvdXRlckV2ZW50LnR5cGUpIHRyeSB7XG5cdFx0XHRcdGxpc3RlbmVyLmZuKHJvdXRlckV2ZW50KTtcblx0XHRcdH0gY2F0Y2ggKGUpIHtcblx0XHRcdFx0Y29uc29sZS5lcnJvcihlKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdHRoaXMucGFyc2VMb2NhdGlvbiA9IChsb2NhdGlvblRvUGFyc2UsIHByZXZpb3VzTG9jYXRpb24pID0+IHtcblx0XHRcdGNvbnN0IHBhcnNlID0gKHsgcGF0aG5hbWUsIHNlYXJjaCwgaGFzaCwgaHJlZiB9LCBzdGF0ZSkgPT4ge1xuXHRcdFx0XHRpZiAoIXRoaXMucmV3cml0ZSAmJiAhL1sgXFx4MDAtXFx4MWZcXHg3ZlxcdTAwODAtXFx1ZmZmZl0vLnRlc3QocGF0aG5hbWUpKSB7XG5cdFx0XHRcdFx0Y29uc3QgcGFyc2VkU2VhcmNoID0gdGhpcy5vcHRpb25zLnBhcnNlU2VhcmNoKHNlYXJjaCk7XG5cdFx0XHRcdFx0Y29uc3Qgc2VhcmNoU3RyID0gdGhpcy5vcHRpb25zLnN0cmluZ2lmeVNlYXJjaChwYXJzZWRTZWFyY2gpO1xuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHRocmVmOiBwYXRobmFtZSArIHNlYXJjaFN0ciArIGhhc2gsXG5cdFx0XHRcdFx0XHRwdWJsaWNIcmVmOiBwYXRobmFtZSArIHNlYXJjaFN0ciArIGhhc2gsXG5cdFx0XHRcdFx0XHRwYXRobmFtZTogZGVjb2RlUGF0aChwYXRobmFtZSksXG5cdFx0XHRcdFx0XHRleHRlcm5hbDogZmFsc2UsXG5cdFx0XHRcdFx0XHRzZWFyY2hTdHIsXG5cdFx0XHRcdFx0XHRzZWFyY2g6IG51bGxSZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzTG9jYXRpb24/LnNlYXJjaCwgcGFyc2VkU2VhcmNoKSxcblx0XHRcdFx0XHRcdGhhc2g6IGRlY29kZVBhdGgoaGFzaC5zbGljZSgxKSksXG5cdFx0XHRcdFx0XHRzdGF0ZTogcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c0xvY2F0aW9uPy5zdGF0ZSwgc3RhdGUpXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCB1cmwgPSBleGVjdXRlUmV3cml0ZUlucHV0KHRoaXMucmV3cml0ZSwgbmV3IFVSTChocmVmLCB0aGlzLm9yaWdpbikpO1xuXHRcdFx0XHRjb25zdCBwYXJzZWRTZWFyY2ggPSB0aGlzLm9wdGlvbnMucGFyc2VTZWFyY2godXJsLnNlYXJjaCk7XG5cdFx0XHRcdGNvbnN0IHNlYXJjaFN0ciA9IHRoaXMub3B0aW9ucy5zdHJpbmdpZnlTZWFyY2gocGFyc2VkU2VhcmNoKTtcblx0XHRcdFx0dXJsLnNlYXJjaCA9IHNlYXJjaFN0cjtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRocmVmOiB1cmwuaHJlZi5yZXBsYWNlKHVybC5vcmlnaW4sIFwiXCIpLFxuXHRcdFx0XHRcdHB1YmxpY0hyZWY6IGhyZWYsXG5cdFx0XHRcdFx0cGF0aG5hbWU6IGRlY29kZVBhdGgobm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZSh1cmwucGF0aG5hbWUpKSxcblx0XHRcdFx0XHRleHRlcm5hbDogISF0aGlzLnJld3JpdGUgJiYgaXNFeHRlcm5hbFVybCh1cmwsIHRoaXMub3JpZ2luKSxcblx0XHRcdFx0XHRzZWFyY2hTdHIsXG5cdFx0XHRcdFx0c2VhcmNoOiBudWxsUmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c0xvY2F0aW9uPy5zZWFyY2gsIHBhcnNlZFNlYXJjaCksXG5cdFx0XHRcdFx0aGFzaDogZGVjb2RlUGF0aCh1cmwuaGFzaC5zbGljZSgxKSksXG5cdFx0XHRcdFx0c3RhdGU6IHJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNMb2NhdGlvbj8uc3RhdGUsIHN0YXRlKVxuXHRcdFx0XHR9O1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IGxvY2F0aW9uID0gcGFyc2UobG9jYXRpb25Ub1BhcnNlLCBsb2NhdGlvblRvUGFyc2Uuc3RhdGUpO1xuXHRcdFx0Y29uc3QgeyBfX3RlbXBMb2NhdGlvbiwgX190ZW1wS2V5IH0gPSBsb2NhdGlvbi5zdGF0ZTtcblx0XHRcdGlmIChfX3RlbXBMb2NhdGlvbiAmJiAoIV9fdGVtcEtleSB8fCBfX3RlbXBLZXkgPT09IHRoaXMudGVtcExvY2F0aW9uS2V5KSkge1xuXHRcdFx0XHRjb25zdCBwYXJzZWRUZW1wTG9jYXRpb24gPSBwYXJzZShfX3RlbXBMb2NhdGlvbiwge1xuXHRcdFx0XHRcdC4uLl9fdGVtcExvY2F0aW9uLnN0YXRlLFxuXHRcdFx0XHRcdF9fdGVtcExvY2F0aW9uOiB2b2lkIDAsXG5cdFx0XHRcdFx0a2V5OiBsb2NhdGlvbi5zdGF0ZS5rZXksXG5cdFx0XHRcdFx0X19UU1Jfa2V5OiBsb2NhdGlvbi5zdGF0ZS5fX1RTUl9rZXlcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHBhcnNlZFRlbXBMb2NhdGlvbi5tYXNrZWRMb2NhdGlvbiA9IGxvY2F0aW9uO1xuXHRcdFx0XHRyZXR1cm4gcGFyc2VkVGVtcExvY2F0aW9uO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGxvY2F0aW9uO1xuXHRcdH07XG5cdFx0dGhpcy5tYXRjaFJvdXRlcyA9IChwYXRobmFtZU9yTmV4dCwgbG9jYXRpb25TZWFyY2hPck9wdHMsIG9wdHMpID0+IHtcblx0XHRcdGlmICh0eXBlb2YgcGF0aG5hbWVPck5leHQgPT09IFwic3RyaW5nXCIpIHJldHVybiB0aGlzLm1hdGNoUm91dGVzSW50ZXJuYWwoe1xuXHRcdFx0XHRwYXRobmFtZTogcGF0aG5hbWVPck5leHQsXG5cdFx0XHRcdHNlYXJjaDogbG9jYXRpb25TZWFyY2hPck9wdHNcblx0XHRcdH0sIG9wdHMpO1xuXHRcdFx0cmV0dXJuIHRoaXMubWF0Y2hSb3V0ZXNJbnRlcm5hbChwYXRobmFtZU9yTmV4dCwgbG9jYXRpb25TZWFyY2hPck9wdHMpO1xuXHRcdH07XG5cdFx0dGhpcy5nZXRNYXRjaGVkUm91dGVzID0gKHBhdGhuYW1lKSA9PiB7XG5cdFx0XHRjb25zdCByYXdQYXJhbXMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBmaW5kUm91dGVNYXRjaCh0cmltUGF0aFJpZ2h0KHBhdGhuYW1lKSwgdGhpcy5wcm9jZXNzZWRUcmVlLCB0cnVlKTtcblx0XHRcdGlmIChtYXRjaCkgT2JqZWN0LmFzc2lnbihyYXdQYXJhbXMsIG1hdGNoLnJhd1BhcmFtcyk7XG5cdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRtYXRjaD8uYnJhbmNoIHx8IFt0aGlzLnJvdXRlc0J5SWRbXCJfX3Jvb3RfX1wiXV0sXG5cdFx0XHRcdHJhd1BhcmFtcyxcblx0XHRcdFx0bWF0Y2g/LnJvdXRlXG5cdFx0XHRdO1xuXHRcdH07XG5cdFx0dGhpcy5idWlsZExvY2F0aW9uID0gKG9wdHMpID0+IHtcblx0XHRcdGlmICghKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpKSB7XG5cdFx0XHRcdGNvbnN0IGNhY2hlZCA9IHRoaXMuc3RhdGljTG9jYXRpb25zLmdldChvcHRzKTtcblx0XHRcdFx0aWYgKGNhY2hlZCkgcmV0dXJuIGNhY2hlZDtcblx0XHRcdH1cblx0XHRcdGxldCB1c2VkQ3VycmVudCA9IGZhbHNlO1xuXHRcdFx0Y29uc3QgYnVpbGQgPSAoZGVzdCA9IHt9KSA9PiB7XG5cdFx0XHRcdGlmIChkZXN0LmhyZWYpIHtcblx0XHRcdFx0XHRjb25zdCBwYXJzZWQgPSBwYXJzZUhyZWYoZGVzdC5ocmVmLCB7fSk7XG5cdFx0XHRcdFx0ZGVzdCA9IHtcblx0XHRcdFx0XHRcdC4uLmRlc3QsXG5cdFx0XHRcdFx0XHR0bzogZXhlY3V0ZVJld3JpdGVJbnB1dCh0aGlzLnJld3JpdGUsIG5ldyBVUkwocGFyc2VkLnBhdGhuYW1lLCB0aGlzLm9yaWdpbikpLnBhdGhuYW1lLFxuXHRcdFx0XHRcdFx0c2VhcmNoOiB0aGlzLm9wdGlvbnMucGFyc2VTZWFyY2gocGFyc2VkLnNlYXJjaCksXG5cdFx0XHRcdFx0XHRoYXNoOiBwYXJzZWQuaGFzaC5zbGljZSgxKVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgY3VycmVudExvY2F0aW9uID0gZGVzdC5fZnJvbUxvY2F0aW9uIHx8IHRoaXMuX3BlbmRpbmdMb2NhdGlvbiB8fCB0aGlzLmxhdGVzdExvY2F0aW9uO1xuXHRcdFx0XHRsZXQgbGlnaHR3ZWlnaHQ7XG5cdFx0XHRcdGNvbnN0IGN1cnJlbnQgPSAoKSA9PiB7XG5cdFx0XHRcdFx0dXNlZEN1cnJlbnQgPSB0cnVlO1xuXHRcdFx0XHRcdHJldHVybiBjdXJyZW50TG9jYXRpb247XG5cdFx0XHRcdH07XG5cdFx0XHRcdGNvbnN0IGN1cnJlbnRNYXRjaCA9ICgpID0+IHtcblx0XHRcdFx0XHR1c2VkQ3VycmVudCA9IHRydWU7XG5cdFx0XHRcdFx0cmV0dXJuIGxpZ2h0d2VpZ2h0ID8/PSB0aGlzLm1hdGNoUm91dGVzTGlnaHR3ZWlnaHQoY3VycmVudExvY2F0aW9uKTtcblx0XHRcdFx0fTtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBkZXN0LmZyb20gJiYgZGVzdC5faXNOYXZpZ2F0ZSkge1xuXHRcdFx0XHRcdGNvbnN0IFthbGxGcm9tTWF0Y2hlc10gPSB0aGlzLmdldE1hdGNoZWRSb3V0ZXMoZGVzdC5mcm9tKTtcblx0XHRcdFx0XHRjb25zdCBbbWF0Y2hlZFJvdXRlcywgZnVsbFBhdGhdID0gY3VycmVudE1hdGNoKCk7XG5cdFx0XHRcdFx0Y29uc3QgbWF0Y2hlZEZyb20gPSBmaW5kTGFzdChtYXRjaGVkUm91dGVzLCAoZCkgPT4ge1xuXHRcdFx0XHRcdFx0cmV0dXJuIGNvbXBhcmVQYXRocyhkLmZ1bGxQYXRoLCBkZXN0LmZyb20pO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGNvbnN0IG1hdGNoZWRDdXJyZW50ID0gZmluZExhc3QoYWxsRnJvbU1hdGNoZXMsIChkKSA9PiB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gY29tcGFyZVBhdGhzKGQuZnVsbFBhdGgsIGZ1bGxQYXRoKTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRpZiAoIW1hdGNoZWRGcm9tICYmICFtYXRjaGVkQ3VycmVudCkgY29uc29sZS53YXJuKGBDb3VsZCBub3QgZmluZCBtYXRjaCBmb3IgZnJvbTogJHtkZXN0LmZyb219YCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgdG8gPSBkZXN0LnRvID8gYCR7ZGVzdC50b31gIDogXCIuXCI7XG5cdFx0XHRcdGNvbnN0IG5leHRUbyA9IHJlc29sdmVQYXRoKHRvWzBdID09PSBcIi9cIiA/IFwiXCIgOiBkZXN0LnVuc2FmZVJlbGF0aXZlID09PSBcInBhdGhcIiA/IGN1cnJlbnQoKS5wYXRobmFtZSA6IGRlc3QuZnJvbSA/PyBjdXJyZW50TWF0Y2goKVsxXSwgdG8sIHRoaXMub3B0aW9ucy50cmFpbGluZ1NsYXNoLCB0aGlzLnJlc29sdmVQYXRoQ2FjaGUpO1xuXHRcdFx0XHRjb25zdCBkZXN0Um91dGUgPSB0aGlzLnJvdXRlc0J5UGF0aFt0cmltUGF0aFJpZ2h0KG5leHRUbyldO1xuXHRcdFx0XHRjb25zdCBpc1RlbXBsYXRlID0gbmV4dFRvLmluY2x1ZGVzKFwiJFwiKTtcblx0XHRcdFx0bGV0IGRlc3RSb3V0ZXM7XG5cdFx0XHRcdGlmIChkZXN0Um91dGUpIGRlc3RSb3V0ZXMgPSBkZXN0Um91dGUuX2JyYW5jaCA/Pz0gYnVpbGRSb3V0ZUJyYW5jaChkZXN0Um91dGUpO1xuXHRcdFx0XHRlbHNlIGlmIChpc1RlbXBsYXRlKSBkZXN0Um91dGVzID0gW107XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGNvbnN0IFttYXRjaGVkUm91dGVzLCByYXdQYXJhbXMsIGZvdW5kUm91dGVdID0gdGhpcy5nZXRNYXRjaGVkUm91dGVzKG5leHRUbyk7XG5cdFx0XHRcdFx0ZGVzdFJvdXRlcyA9IG1hdGNoZWRSb3V0ZXM7XG5cdFx0XHRcdFx0aWYgKHRoaXMub3B0aW9ucy5ub3RGb3VuZFJvdXRlICYmICghZm91bmRSb3V0ZSB8fCBmb3VuZFJvdXRlLnBhdGggIT09IFwiL1wiICYmIHJhd1BhcmFtc1tcIioqXCJdKSkgZGVzdFJvdXRlcyA9IFsuLi5kZXN0Um91dGVzLCB0aGlzLm9wdGlvbnMubm90Rm91bmRSb3V0ZV07XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgaW50ZXJwb2xhdGlvbiA9IGlzVGVtcGxhdGUgPyBkZXN0Um91dGU/Ll9pbnRlcnBvbGF0aW9uID8/IHBhcnNlU2VnbWVudHMoZmFsc2UsIHsgZnVsbFBhdGg6IG5leHRUbyB9LCAwKSA6IHZvaWQgMDtcblx0XHRcdFx0bGV0IG5leHRQYXJhbXM7XG5cdFx0XHRcdGZvciAoY29uc3Qgcm91dGUgb2YgZGVzdFJvdXRlcykge1xuXHRcdFx0XHRcdGNvbnN0IGZuID0gcm91dGUub3B0aW9ucy5wYXJhbXM/LnN0cmluZ2lmeSA/PyByb3V0ZS5vcHRpb25zLnN0cmluZ2lmeVBhcmFtcztcblx0XHRcdFx0XHRpZiAoZm4pIHtcblx0XHRcdFx0XHRcdGNvbnN0IGZyb21QYXJhbXMgPSBjdXJyZW50TWF0Y2goKVszXTtcblx0XHRcdFx0XHRcdG5leHRQYXJhbXMgPz89IHJlc29sdmVOZXh0UGFyYW1zKGRlc3QucGFyYW1zLCBmcm9tUGFyYW1zKTtcblx0XHRcdFx0XHRcdGlmICghaGFzS2V5cyhuZXh0UGFyYW1zKSkgYnJlYWs7XG5cdFx0XHRcdFx0XHRpZiAobmV4dFBhcmFtcyA9PT0gZnJvbVBhcmFtcykgbmV4dFBhcmFtcyA9IE9iamVjdC5hc3NpZ24oY3JlYXRlTnVsbCgpLCBuZXh0UGFyYW1zKTtcblx0XHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRcdE9iamVjdC5hc3NpZ24obmV4dFBhcmFtcywgZm4obmV4dFBhcmFtcykpO1xuXHRcdFx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRuZXh0UGFyYW1zID8/PSByZXNvbHZlTmV4dFBhcmFtcyhkZXN0LnBhcmFtcywgbmVlZHNJbmhlcml0ZWRQYXJhbXMoZGVzdC5wYXJhbXMsIGludGVycG9sYXRpb24pID8gY3VycmVudE1hdGNoKClbM10gOiBFTVBUWV9SRUNPUkQpO1xuXHRcdFx0XHRjb25zdCBuZXh0UGF0aG5hbWUgPSBvcHRzLmxlYXZlUGFyYW1zID8gbmV4dFRvIDogbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZShkZWNvZGVQYXRoKGludGVycG9sYXRpb24gPyBpbnRlcnBvbGF0ZVBhdGgobmV4dFRvLCBpbnRlcnBvbGF0aW9uLCBuZXh0UGFyYW1zLCB0aGlzLnBhdGhQYXJhbXNEZWNvZGVyKSA6IG5leHRUbykpO1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGRlc3RSb3V0ZSAmJiAhb3B0cy5sZWF2ZVBhcmFtcykgdHJ5IHtcblx0XHRcdFx0XHRjb25zdCBmb3VuZFJvdXRlID0gdGhpcy5nZXRNYXRjaGVkUm91dGVzKG5leHRQYXRobmFtZSlbMl07XG5cdFx0XHRcdFx0aWYgKGZvdW5kUm91dGU/LmlkICE9PSBkZXN0Um91dGUuaWQpIGNvbnNvbGUud2FybihgR2VuZXJhdGVkIHBhdGggXCIke25leHRQYXRobmFtZX1cIiBmb3Igcm91dGUgXCIke2Rlc3RSb3V0ZS5pZH1cIiBtYXRjaGVkIHJvdXRlIFwiJHtmb3VuZFJvdXRlPy5pZH1cIiBpbnN0ZWFkLiBUaGlzIGNhbiBoYXBwZW4gd2hlbiBtdWx0aXBsZSByb3V0ZSB0ZW1wbGF0ZXMgcmVzb2x2ZSB0byB0aGUgc2FtZSBVUkwuIFVzZSB0aGUgcm91dGUgdGVtcGxhdGUgdGhhdCBtYXRjaGVzIHRoZSBpbnRlbmRlZCByb3V0ZSwgb3IgYWRqdXN0IHBhcmFtcy5zdHJpbmdpZnkgaWYgaXQgY2hhbmdlZCB0aGUgdGFyZ2V0IHBhdGguYCk7XG5cdFx0XHRcdH0gY2F0Y2gge31cblx0XHRcdFx0Y29uc3QgbWlkZGxld2FyZXMgPSBnZXRTZWFyY2hNaWRkbGV3YXJlcyhkZXN0Um91dGVzLCBvcHRzLl9pbmNsdWRlVmFsaWRhdGVTZWFyY2gpO1xuXHRcdFx0XHRjb25zdCBmcm9tU2VhcmNoID0gKCkgPT4ge1xuXHRcdFx0XHRcdGxldCBzZWFyY2ggPSBjdXJyZW50TWF0Y2goKVsyXTtcblx0XHRcdFx0XHRpZiAob3B0cy5faW5jbHVkZVZhbGlkYXRlU2VhcmNoICYmIHRoaXMub3B0aW9ucy5zZWFyY2g/LnN0cmljdCkge1xuXHRcdFx0XHRcdFx0Y29uc3QgdmFsaWRhdGVkU2VhcmNoID0ge307XG5cdFx0XHRcdFx0XHRkZXN0Um91dGVzLmZvckVhY2goKHJvdXRlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdGlmIChyb3V0ZS5vcHRpb25zLnZhbGlkYXRlU2VhcmNoKSB0cnkge1xuXHRcdFx0XHRcdFx0XHRcdE9iamVjdC5hc3NpZ24odmFsaWRhdGVkU2VhcmNoLCB2YWxpZGF0ZVNlYXJjaChyb3V0ZS5vcHRpb25zLnZhbGlkYXRlU2VhcmNoLCB7XG5cdFx0XHRcdFx0XHRcdFx0XHQuLi52YWxpZGF0ZWRTZWFyY2gsXG5cdFx0XHRcdFx0XHRcdFx0XHQuLi5zZWFyY2hcblx0XHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHRcdH0gY2F0Y2gge31cblx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0c2VhcmNoID0gdmFsaWRhdGVkU2VhcmNoO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gc2VhcmNoO1xuXHRcdFx0XHR9O1xuXHRcdFx0XHRjb25zdCBuZXh0U2VhcmNoID0gbWlkZGxld2FyZXMubGVuZ3RoID8gYXBwbHlTZWFyY2hNaWRkbGV3YXJlKG1pZGRsZXdhcmVzLCBmcm9tU2VhcmNoKCksIGRlc3QpIDogZGVzdC5zZWFyY2ggPT09IHRydWUgPyBmcm9tU2VhcmNoKCkgOiB0eXBlb2YgZGVzdC5zZWFyY2ggPT09IFwiZnVuY3Rpb25cIiA/IGRlc3Quc2VhcmNoKGZyb21TZWFyY2goKSkgOiBkZXN0LnNlYXJjaCB8fCBFTVBUWV9SRUNPUkQ7XG5cdFx0XHRcdGNvbnN0IHNlYXJjaFN0ciA9IHRoaXMub3B0aW9ucy5zdHJpbmdpZnlTZWFyY2gobmV4dFNlYXJjaCk7XG5cdFx0XHRcdGNvbnN0IGhhc2ggPSBkZXN0Lmhhc2ggPT09IHRydWUgPyBjdXJyZW50KCkuaGFzaCA6IHR5cGVvZiBkZXN0Lmhhc2ggPT09IFwiZnVuY3Rpb25cIiA/IGRlc3QuaGFzaChjdXJyZW50KCkuaGFzaCkgOiBkZXN0Lmhhc2ggfHwgdm9pZCAwO1xuXHRcdFx0XHRjb25zdCBoYXNoU3RyID0gaGFzaCA/IGAjJHtoYXNofWAgOiBcIlwiO1xuXHRcdFx0XHRjb25zdCBuZXh0U3RhdGUgPSAhZGVzdC5zdGF0ZSA/IEVNUFRZX1JFQ09SRCA6IGRlc3Quc3RhdGUgPT09IHRydWUgPyBjdXJyZW50KCkuc3RhdGUgOiB0eXBlb2YgZGVzdC5zdGF0ZSA9PT0gXCJmdW5jdGlvblwiID8gZGVzdC5zdGF0ZShjdXJyZW50KCkuc3RhdGUpIDogZGVzdC5zdGF0ZTtcblx0XHRcdFx0Y29uc3QgZnVsbFBhdGggPSBgJHtuZXh0UGF0aG5hbWV9JHtzZWFyY2hTdHJ9JHtoYXNoU3RyfWA7XG5cdFx0XHRcdGxldCBocmVmO1xuXHRcdFx0XHRsZXQgcHVibGljSHJlZjtcblx0XHRcdFx0bGV0IGV4dGVybmFsID0gZmFsc2U7XG5cdFx0XHRcdGlmICh0aGlzLnJld3JpdGUpIHtcblx0XHRcdFx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKGZ1bGxQYXRoLCB0aGlzLm9yaWdpbik7XG5cdFx0XHRcdFx0Y29uc3Qgb3JpZ2luID0gdXJsLm9yaWdpbjtcblx0XHRcdFx0XHRjb25zdCByZXdyaXR0ZW5VcmwgPSBleGVjdXRlUmV3cml0ZU91dHB1dCh0aGlzLnJld3JpdGUsIHVybCk7XG5cdFx0XHRcdFx0aHJlZiA9IGdldFVybFBhdGgodXJsKTtcblx0XHRcdFx0XHRpZiAoaXNFeHRlcm5hbFVybChyZXdyaXR0ZW5VcmwsIG9yaWdpbikpIHtcblx0XHRcdFx0XHRcdHB1YmxpY0hyZWYgPSByZXdyaXR0ZW5VcmwuaHJlZjtcblx0XHRcdFx0XHRcdGV4dGVybmFsID0gdHJ1ZTtcblx0XHRcdFx0XHR9IGVsc2UgcHVibGljSHJlZiA9IG5vcm1hbGl6ZVByb3RvY29sUmVsYXRpdmUoZ2V0VXJsUGF0aChyZXdyaXR0ZW5VcmwpKTtcblx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRocmVmID0gZW5jb2RlUGF0aExpa2VVcmwoZnVsbFBhdGgpO1xuXHRcdFx0XHRcdHB1YmxpY0hyZWYgPSBocmVmO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0cHVibGljSHJlZixcblx0XHRcdFx0XHRocmVmLFxuXHRcdFx0XHRcdHBhdGhuYW1lOiBuZXh0UGF0aG5hbWUsXG5cdFx0XHRcdFx0c2VhcmNoOiBuZXh0U2VhcmNoLFxuXHRcdFx0XHRcdHNlYXJjaFN0cixcblx0XHRcdFx0XHRzdGF0ZTogbmV4dFN0YXRlLFxuXHRcdFx0XHRcdGhhc2g6IGhhc2ggPz8gXCJcIixcblx0XHRcdFx0XHRleHRlcm5hbCxcblx0XHRcdFx0XHR1bm1hc2tPblJlbG9hZDogZGVzdC51bm1hc2tPblJlbG9hZFxuXHRcdFx0XHR9O1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IG5leHQgPSBidWlsZChvcHRzKTtcblx0XHRcdGlmIChvcHRzLm1hc2spIG5leHQubWFza2VkTG9jYXRpb24gPSBidWlsZCh7XG5cdFx0XHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRcdFx0Li4ub3B0cy5tYXNrXG5cdFx0XHR9KTtcblx0XHRcdGVsc2UgaWYgKHRoaXMub3B0aW9ucy5yb3V0ZU1hc2tzKSB7XG5cdFx0XHRcdGNvbnN0IG1hdGNoID0gZmluZEZsYXRNYXRjaChuZXh0LnBhdGhuYW1lLCB0aGlzLnByb2Nlc3NlZFRyZWUpO1xuXHRcdFx0XHRpZiAobWF0Y2gpIHtcblx0XHRcdFx0XHRjb25zdCBwYXJhbXMgPSBPYmplY3QuYXNzaWduKGNyZWF0ZU51bGwoKSwgbWF0Y2gucmF3UGFyYW1zKTtcblx0XHRcdFx0XHRjb25zdCB7IGZyb206IF9mcm9tLCBwYXJhbXM6IG1hc2tQYXJhbXMsIC4uLm1hc2tQcm9wcyB9ID0gbWF0Y2gucm91dGU7XG5cdFx0XHRcdFx0Y29uc3QgbmV4dFBhcmFtcyA9IHJlc29sdmVOZXh0UGFyYW1zKG1hc2tQYXJhbXMsIHBhcmFtcyk7XG5cdFx0XHRcdFx0bmV4dC5tYXNrZWRMb2NhdGlvbiA9IGJ1aWxkKHtcblx0XHRcdFx0XHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRcdFx0XHRcdC4uLm1hc2tQcm9wcyxcblx0XHRcdFx0XHRcdHBhcmFtczogbmV4dFBhcmFtc1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoIShpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSAmJiAhdXNlZEN1cnJlbnQgJiYgb3B0cy5fZnJvbUxvY2F0aW9uICYmICFuZXh0Lm1hc2tlZExvY2F0aW9uKSB0aGlzLnN0YXRpY0xvY2F0aW9ucy5zZXQob3B0cywgbmV4dCk7XG5cdFx0XHRyZXR1cm4gbmV4dDtcblx0XHR9O1xuXHRcdHRoaXMuY29tbWl0TG9jYXRpb24gPSBhc3luYyAoeyB2aWV3VHJhbnNpdGlvbiwgaWdub3JlQmxvY2tlciwgLi4ubmV4dCB9KSA9PiB7XG5cdFx0XHRpZiAoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikgcmV0dXJuO1xuXHRcdFx0Y29uc3QgbmV4dExvY2F0aW9uID0gbmV4dC5tYXNrZWRMb2NhdGlvbiA/PyBuZXh0O1xuXHRcdFx0aWYgKG5leHRMb2NhdGlvbi5leHRlcm5hbCAmJiAhKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpKSByZXR1cm4gZG9jdW1lbnROYXZpZ2F0aW9uKHRoaXMsIG5leHRMb2NhdGlvbi5wdWJsaWNIcmVmLCB7XG5cdFx0XHRcdHJlcGxhY2U6IG5leHQucmVwbGFjZSxcblx0XHRcdFx0aWdub3JlQmxvY2tlclxuXHRcdFx0fSk7XG5cdFx0XHRsZXQgaGlzdG9yeUFjdGlvbjtcblx0XHRcdGNvbnN0IGlzU2FtZUxvY2F0aW9uID0gdHJpbVBhdGhSaWdodCh0aGlzLmxhdGVzdExvY2F0aW9uLmhyZWYpID09PSB0cmltUGF0aFJpZ2h0KG5leHQuaHJlZikgJiYgZGVlcEVxdWFsKF9nZXRVc2VySGlzdG9yeVN0YXRlKG5leHQuc3RhdGUpLCBfZ2V0VXNlckhpc3RvcnlTdGF0ZSh0aGlzLmxhdGVzdExvY2F0aW9uLnN0YXRlKSk7XG5cdFx0XHRjb25zdCBwcmV2aW91c0NvbW1pdFByb21pc2UgPSB0aGlzLl9jb21taXRQcm9taXNlO1xuXHRcdFx0bGV0IHJlc29sdmU7XG5cdFx0XHRjb25zdCBjb21taXRQcm9taXNlID0gbmV3IFByb21pc2UoKGRvbmUpID0+IHtcblx0XHRcdFx0cmVzb2x2ZSA9IGRvbmU7XG5cdFx0XHR9KTtcblx0XHRcdGNvbW1pdFByb21pc2UucmVzb2x2ZSA9ICgpID0+IHtcblx0XHRcdFx0cmVzb2x2ZSgpO1xuXHRcdFx0XHRwcmV2aW91c0NvbW1pdFByb21pc2U/LnJlc29sdmUoKTtcblx0XHRcdH07XG5cdFx0XHR0aGlzLl9jb21taXRQcm9taXNlID0gY29tbWl0UHJvbWlzZTtcblx0XHRcdGlmIChpc1NhbWVMb2NhdGlvbikgdGhpcy5sb2FkKCk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0bGV0IHsgbWFza2VkTG9jYXRpb24sIGhhc2hTY3JvbGxJbnRvVmlldywgLi4ubmV4dEhpc3RvcnkgfSA9IG5leHQ7XG5cdFx0XHRcdGlmIChtYXNrZWRMb2NhdGlvbikge1xuXHRcdFx0XHRcdG5leHRIaXN0b3J5ID0ge1xuXHRcdFx0XHRcdFx0Li4ubWFza2VkTG9jYXRpb24sXG5cdFx0XHRcdFx0XHRzdGF0ZToge1xuXHRcdFx0XHRcdFx0XHQuLi5tYXNrZWRMb2NhdGlvbi5zdGF0ZSxcblx0XHRcdFx0XHRcdFx0X190ZW1wS2V5OiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdF9fdGVtcExvY2F0aW9uOiB7XG5cdFx0XHRcdFx0XHRcdFx0Li4ubmV4dEhpc3RvcnksXG5cdFx0XHRcdFx0XHRcdFx0c2VhcmNoOiBuZXh0SGlzdG9yeS5zZWFyY2hTdHIsXG5cdFx0XHRcdFx0XHRcdFx0c3RhdGU6IHtcblx0XHRcdFx0XHRcdFx0XHRcdC4uLm5leHRIaXN0b3J5LnN0YXRlLFxuXHRcdFx0XHRcdFx0XHRcdFx0X190ZW1wS2V5OiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdFx0XHRfX3RlbXBMb2NhdGlvbjogdm9pZCAwLFxuXHRcdFx0XHRcdFx0XHRcdFx0X19UU1Jfa2V5OiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdFx0XHRrZXk6IHZvaWQgMFxuXHRcdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0aWYgKG5leHRIaXN0b3J5LnVubWFza09uUmVsb2FkID8/IHRoaXMub3B0aW9ucy51bm1hc2tPblJlbG9hZCA/PyBmYWxzZSkgbmV4dEhpc3Rvcnkuc3RhdGUuX190ZW1wS2V5ID0gdGhpcy50ZW1wTG9jYXRpb25LZXk7XG5cdFx0XHRcdH1cblx0XHRcdFx0bmV4dEhpc3Rvcnkuc3RhdGUgPSB7XG5cdFx0XHRcdFx0Li4ubmV4dEhpc3Rvcnkuc3RhdGUsXG5cdFx0XHRcdFx0X19oYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zOiBoYXNoU2Nyb2xsSW50b1ZpZXcgPz8gdGhpcy5vcHRpb25zLmRlZmF1bHRIYXNoU2Nyb2xsSW50b1ZpZXcgPz8gdHJ1ZVxuXHRcdFx0XHR9O1xuXHRcdFx0XHR0aGlzLnNob3VsZFZpZXdUcmFuc2l0aW9uID0gdmlld1RyYW5zaXRpb247XG5cdFx0XHRcdGhpc3RvcnlBY3Rpb24gPSBuZXh0LnJlcGxhY2UgPyBcIlJFUExBQ0VcIiA6IFwiUFVTSFwiO1xuXHRcdFx0XHR0aGlzLmhpc3RvcnlbaGlzdG9yeUFjdGlvbiA9PT0gXCJSRVBMQUNFXCIgPyBcInJlcGxhY2VcIiA6IFwicHVzaFwiXShuZXh0SGlzdG9yeS5wdWJsaWNIcmVmLCBuZXh0SGlzdG9yeS5zdGF0ZSwgeyBpZ25vcmVCbG9ja2VyIH0pO1xuXHRcdFx0XHRpZiAoIXRoaXMuaGlzdG9yeS5zdWJzY3JpYmVycy5zaXplKSB0aGlzLmxvYWQoeyBhY3Rpb246IHsgdHlwZTogaGlzdG9yeUFjdGlvbiB9IH0pO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5fc2Nyb2xsLm4gPSBuZXh0LnJlc2V0U2Nyb2xsID8/IHRydWU7XG5cdFx0XHRyZXR1cm4gdGhpcy5fY29tbWl0UHJvbWlzZTtcblx0XHR9O1xuXHRcdHRoaXMuYnVpbGRBbmRDb21taXRMb2NhdGlvbiA9ICh7IHJlcGxhY2UsIHJlc2V0U2Nyb2xsLCBoYXNoU2Nyb2xsSW50b1ZpZXcsIHZpZXdUcmFuc2l0aW9uLCBpZ25vcmVCbG9ja2VyLCAuLi5yZXN0IH0gPSB7fSkgPT4ge1xuXHRcdFx0aWYgKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRcdGNvbnN0IGxvY2F0aW9uID0gdGhpcy5idWlsZExvY2F0aW9uKHtcblx0XHRcdFx0Li4ucmVzdCxcblx0XHRcdFx0X2luY2x1ZGVWYWxpZGF0ZVNlYXJjaDogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLl9wZW5kaW5nTG9jYXRpb24gPSBsb2NhdGlvbjtcblx0XHRcdGNvbnN0IGNvbW1pdFByb21pc2UgPSB0aGlzLmNvbW1pdExvY2F0aW9uKHtcblx0XHRcdFx0Li4ubG9jYXRpb24sXG5cdFx0XHRcdHZpZXdUcmFuc2l0aW9uLFxuXHRcdFx0XHRyZXBsYWNlLFxuXHRcdFx0XHRyZXNldFNjcm9sbCxcblx0XHRcdFx0aGFzaFNjcm9sbEludG9WaWV3LFxuXHRcdFx0XHRpZ25vcmVCbG9ja2VyXG5cdFx0XHR9KTtcblx0XHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRcdFx0aWYgKHRoaXMuX3BlbmRpbmdMb2NhdGlvbiA9PT0gbG9jYXRpb24pIHRoaXMuX3BlbmRpbmdMb2NhdGlvbiA9IHZvaWQgMDtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIGNvbW1pdFByb21pc2U7XG5cdFx0fTtcblx0XHR0aGlzLm5hdmlnYXRlID0gYXN5bmMgKHsgdG8sIHJlbG9hZERvY3VtZW50LCBocmVmLCBwdWJsaWNIcmVmLCAuLi5yZXN0IH0pID0+IHtcblx0XHRcdGlmIChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSByZXR1cm47XG5cdFx0XHRjb25zdCBocmVmU2NoZW1lID0gaHJlZiA/IGdldFVybFNjaGVtZShocmVmKSA6IHZvaWQgMDtcblx0XHRcdGlmIChocmVmU2NoZW1lIHx8IHJlbG9hZERvY3VtZW50KSB7XG5cdFx0XHRcdGlmICh0byAhPT0gdm9pZCAwIHx8ICFocmVmKSB7XG5cdFx0XHRcdFx0Y29uc3QgbG9jYXRpb24gPSB0aGlzLmJ1aWxkTG9jYXRpb24oe1xuXHRcdFx0XHRcdFx0dG8sXG5cdFx0XHRcdFx0XHQuLi5yZXN0XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0Y29uc3QgcHVibGljTG9jYXRpb24gPSBsb2NhdGlvbi5tYXNrZWRMb2NhdGlvbiA/PyBsb2NhdGlvbjtcblx0XHRcdFx0XHRocmVmID8/PSBwdWJsaWNMb2NhdGlvbi5wdWJsaWNIcmVmO1xuXHRcdFx0XHRcdHB1YmxpY0hyZWYgPz89IHB1YmxpY0xvY2F0aW9uLnB1YmxpY0hyZWY7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y29uc3QgcmVsb2FkSHJlZiA9ICFocmVmU2NoZW1lICYmIHB1YmxpY0hyZWYgPyBwdWJsaWNIcmVmIDogaHJlZjtcblx0XHRcdFx0cmV0dXJuIGRvY3VtZW50TmF2aWdhdGlvbih0aGlzLCByZWxvYWRIcmVmLCByZXN0KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB0aGlzLmJ1aWxkQW5kQ29tbWl0TG9jYXRpb24oe1xuXHRcdFx0XHQuLi5yZXN0LFxuXHRcdFx0XHRocmVmLFxuXHRcdFx0XHR0byxcblx0XHRcdFx0X2lzTmF2aWdhdGU6IHRydWVcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy5sb2FkID0gYXN5bmMgKG9wdHMpID0+IHtcblx0XHRcdGlmIChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSByZXR1cm4gbG9hZFNlcnZlclJvdXRlKHRoaXMsIG9wdHMpO1xuXHRcdFx0dGhpcy51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdFx0aWYgKG9wdHM/LmFjdGlvbikgdGhpcy5fc2Nyb2xsLmggPSBvcHRzLmFjdGlvbi50eXBlID09PSBcIlBVU0hcIiB8fCBvcHRzLmFjdGlvbi50eXBlID09PSBcIlJFUExBQ0VcIjtcblx0XHRcdGF3YWl0IGxvYWRDbGllbnRSb3V0ZSh0aGlzLCBvcHRzKTtcblx0XHR9O1xuXHRcdHRoaXMuc3RhcnRWaWV3VHJhbnNpdGlvbiA9IChmbikgPT4ge1xuXHRcdFx0Y29uc3Qgc2hvdWxkVmlld1RyYW5zaXRpb24gPSB0aGlzLnNob3VsZFZpZXdUcmFuc2l0aW9uID8/IHRoaXMub3B0aW9ucy5kZWZhdWx0Vmlld1RyYW5zaXRpb247XG5cdFx0XHR0aGlzLnNob3VsZFZpZXdUcmFuc2l0aW9uID0gdm9pZCAwO1xuXHRcdFx0aWYgKHNob3VsZFZpZXdUcmFuc2l0aW9uICYmICEoaXNTZXJ2ZXIgPz8gdHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSAmJiB0eXBlb2YgZG9jdW1lbnQuc3RhcnRWaWV3VHJhbnNpdGlvbiA9PT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0XHRcdGxldCBzdGFydFZpZXdUcmFuc2l0aW9uUGFyYW1zO1xuXHRcdFx0XHRpZiAodHlwZW9mIHNob3VsZFZpZXdUcmFuc2l0aW9uID09PSBcIm9iamVjdFwiICYmIHdpbmRvdy5DU1M/LnN1cHBvcnRzPy4oXCJzZWxlY3Rvcig6YWN0aXZlLXZpZXctdHJhbnNpdGlvbi10eXBlKGEpKVwiKSkge1xuXHRcdFx0XHRcdGNvbnN0IG5leHQgPSB0aGlzLmxhdGVzdExvY2F0aW9uO1xuXHRcdFx0XHRcdGNvbnN0IHByZXZMb2NhdGlvbiA9IHRoaXMuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCk7XG5cdFx0XHRcdFx0Y29uc3QgcmVzb2x2ZWRWaWV3VHJhbnNpdGlvblR5cGVzID0gdHlwZW9mIHNob3VsZFZpZXdUcmFuc2l0aW9uLnR5cGVzID09PSBcImZ1bmN0aW9uXCIgPyBzaG91bGRWaWV3VHJhbnNpdGlvbi50eXBlcyhnZXRMb2NhdGlvbkNoYW5nZUluZm8obmV4dCwgcHJldkxvY2F0aW9uKSkgOiBzaG91bGRWaWV3VHJhbnNpdGlvbi50eXBlcztcblx0XHRcdFx0XHRpZiAocmVzb2x2ZWRWaWV3VHJhbnNpdGlvblR5cGVzID09PSBmYWxzZSkgcmV0dXJuIGZuKCk7XG5cdFx0XHRcdFx0c3RhcnRWaWV3VHJhbnNpdGlvblBhcmFtcyA9IHtcblx0XHRcdFx0XHRcdHVwZGF0ZTogZm4sXG5cdFx0XHRcdFx0XHR0eXBlczogcmVzb2x2ZWRWaWV3VHJhbnNpdGlvblR5cGVzXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fSBlbHNlIHN0YXJ0Vmlld1RyYW5zaXRpb25QYXJhbXMgPSBmbjtcblx0XHRcdFx0cmV0dXJuIGRvY3VtZW50LnN0YXJ0Vmlld1RyYW5zaXRpb24oc3RhcnRWaWV3VHJhbnNpdGlvblBhcmFtcykudXBkYXRlQ2FsbGJhY2tEb25lO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIGZuKCk7XG5cdFx0fTtcblx0XHR0aGlzLmludmFsaWRhdGUgPSAob3B0cykgPT4ge1xuXHRcdFx0Y29uc3QgY29tbWl0dGVkTWF0Y2hlcyA9IHRoaXMuX2NvbW1pdHRlZDtcblx0XHRcdGNvbnN0IGZpbHRlciA9IG9wdHM/LmZpbHRlcjtcblx0XHRcdGNvbnN0IHByZWxvYWRzID0gdGhpcy5fcHJlbG9hZHM7XG5cdFx0XHRjb25zdCBpbnZhbGlkSWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRcdGNvbnN0IGNvbnNpZGVyID0gKG1hdGNoKSA9PiB7XG5cdFx0XHRcdGlmICghZmlsdGVyIHx8IGZpbHRlcihtYXRjaCkpIGludmFsaWRJZHMuYWRkKG1hdGNoLmlkKTtcblx0XHRcdH07XG5cdFx0XHRjb21taXR0ZWRNYXRjaGVzLmZvckVhY2goY29uc2lkZXIpO1xuXHRcdFx0dGhpcy5fY2FjaGUuZm9yRWFjaChjb25zaWRlcik7XG5cdFx0XHRwcmVsb2Fkcz8uZm9yRWFjaCgobWF0Y2hlcykgPT4gbWF0Y2hlcy5mb3JFYWNoKGNvbnNpZGVyKSk7XG5cdFx0XHR0aGlzLl90eD8uWzNdLmZvckVhY2goY29uc2lkZXIpO1xuXHRcdFx0Y29uc3QgYWJvcnQgPSBbXTtcblx0XHRcdGZvciAoY29uc3QgW2NvbnRyb2xsZXIsIG1hdGNoZXNdIG9mIHByZWxvYWRzID8/IFtdKSBpZiAobWF0Y2hlcy5zb21lKChtYXRjaCkgPT4gaW52YWxpZElkcy5oYXMobWF0Y2guaWQpKSkge1xuXHRcdFx0XHRwcmVsb2Fkcy5kZWxldGUoY29udHJvbGxlcik7XG5cdFx0XHRcdGFib3J0LnB1c2goY29udHJvbGxlcik7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBpbnZhbGlkYXRlID0gKGQpID0+IHtcblx0XHRcdFx0aWYgKGludmFsaWRJZHMuaGFzKGQuaWQpKSB7XG5cdFx0XHRcdFx0Y29uc3Qgcm91dGUgPSB0aGlzLnJvdXRlc0J5SWRbZC5yb3V0ZUlkXTtcblx0XHRcdFx0XHRjb25zdCBuZXh0ID0ge1xuXHRcdFx0XHRcdFx0Li4uZCxcblx0XHRcdFx0XHRcdGludmFsaWQ6IHRydWUsXG5cdFx0XHRcdFx0XHQuLi4ob3B0cz8uZm9yY2VQZW5kaW5nIHx8IGQuc3RhdHVzID09PSBcImVycm9yXCIgfHwgZC5zdGF0dXMgPT09IFwibm90Rm91bmRcIikgJiYgcm91dGVOZWVkc0xvYWQocm91dGUpID8ge1xuXHRcdFx0XHRcdFx0XHRzdGF0dXM6IFwicGVuZGluZ1wiLFxuXHRcdFx0XHRcdFx0XHRlcnJvcjogdm9pZCAwXG5cdFx0XHRcdFx0XHR9IDogdm9pZCAwXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRkLl9mbGlnaHQgPSB2b2lkIDA7XG5cdFx0XHRcdFx0cmV0dXJuIG5leHQ7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIGQ7XG5cdFx0XHR9O1xuXHRcdFx0dGhpcy5fY29tbWl0dGVkID0gY29tbWl0dGVkTWF0Y2hlcy5tYXAoaW52YWxpZGF0ZSk7XG5cdFx0XHRmb3IgKGNvbnN0IFtpZCwgbWF0Y2hdIG9mIHRoaXMuX2NhY2hlKSBpZiAoaW52YWxpZElkcy5oYXMoaWQpKSB7XG5cdFx0XHRcdG1hdGNoLmludmFsaWQgPSB0cnVlO1xuXHRcdFx0XHRpZiAob3B0cz8uZm9yY2VQZW5kaW5nKSBtYXRjaC5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0XHRcdH1cblx0XHRcdGZvciAoY29uc3QgaWQgb2YgaW52YWxpZElkcykge1xuXHRcdFx0XHRjb25zdCBmbGlnaHQgPSB0aGlzLl9mbGlnaHRzPy5nZXQoaWQpO1xuXHRcdFx0XHR0aGlzLl9mbGlnaHRzPy5kZWxldGUoaWQpO1xuXHRcdFx0XHRpZiAoZmxpZ2h0ICYmICFmbGlnaHRbMl0pIGFib3J0LnB1c2goZmxpZ2h0WzFdKTtcblx0XHRcdH1cblx0XHRcdGZvciAoY29uc3QgY29udHJvbGxlciBvZiBhYm9ydCkgY29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0dGhpcy5zaG91bGRWaWV3VHJhbnNpdGlvbiA9IGZhbHNlO1xuXHRcdFx0cmV0dXJuIHRoaXMubG9hZCh7IHN5bmM6IG9wdHM/LnN5bmMgfSk7XG5cdFx0fTtcblx0XHR0aGlzLnJlc29sdmVSZWRpcmVjdCA9IChyZWRpcmVjdCkgPT4ge1xuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IHJlZGlyZWN0Lm9wdGlvbnM7XG5cdFx0XHRsZXQgaHJlZiA9IHJlZGlyZWN0LmhlYWRlcnMuZ2V0KFwiTG9jYXRpb25cIikgfHwgb3B0aW9ucy5ocmVmO1xuXHRcdFx0aWYgKCFocmVmKSB7XG5cdFx0XHRcdGNvbnN0IGxvY2F0aW9uID0gdGhpcy5idWlsZExvY2F0aW9uKG9wdGlvbnMpO1xuXHRcdFx0XHRocmVmID0gKGxvY2F0aW9uLm1hc2tlZExvY2F0aW9uID8/IGxvY2F0aW9uKS5wdWJsaWNIcmVmIHx8IFwiL1wiO1xuXHRcdFx0fVxuXHRcdFx0bGV0IHNjaGVtZTtcblx0XHRcdGlmIChwcm90b2NvbFJlbGF0aXZlUHJlZml4UmVnZXgudGVzdChocmVmKSB8fCAoc2NoZW1lID0gZ2V0VXJsU2NoZW1lKGhyZWYpKSAmJiAhdGhpcy5wcm90b2NvbEFsbG93bGlzdC5oYXMoc2NoZW1lKSkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IGBSZWRpcmVjdCBibG9ja2VkOiB1bnNhZmUgcHJvdG9jb2wgaW4gaHJlZiBcIiR7aHJlZn1cIi4gQWxsb3dlZCBwcm90b2NvbHM6ICR7QXJyYXkuZnJvbSh0aGlzLnByb3RvY29sQWxsb3dsaXN0KS5qb2luKFwiLCBcIil9LmAgOiBcIlJlZGlyZWN0IGJsb2NrZWQ6IHVuc2FmZSBwcm90b2NvbFwiKTtcblx0XHRcdGlmIChzY2hlbWUgPT09IFwiaHR0cDpcIiB8fCBzY2hlbWUgPT09IFwiaHR0cHM6XCIpIHtcblx0XHRcdFx0Y29uc3QgdXJsID0gbmV3IFVSTChocmVmKTtcblx0XHRcdFx0aWYgKHVybC5wYXRobmFtZS5zdGFydHNXaXRoKFwiLy9cIikpIGhyZWYgPSB1cmwuaHJlZjtcblx0XHRcdFx0ZWxzZSBpZiAoIWlzRXh0ZXJuYWxVcmwodXJsLCB0aGlzLm9yaWdpbikpIHtcblx0XHRcdFx0XHRocmVmID0gZ2V0VXJsUGF0aCh1cmwpO1xuXHRcdFx0XHRcdHNjaGVtZSA9IHZvaWQgMDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKHNjaGVtZSkgb3B0aW9ucy5yZWxvYWREb2N1bWVudCA9IHRydWU7XG5cdFx0XHRvcHRpb25zLmhyZWYgPSBocmVmO1xuXHRcdFx0cmVkaXJlY3QuaGVhZGVycy5zZXQoXCJMb2NhdGlvblwiLCBocmVmKTtcblx0XHRcdHJldHVybiByZWRpcmVjdDtcblx0XHR9O1xuXHRcdHRoaXMuY2xlYXJDYWNoZSA9IChvcHRzKSA9PiB7XG5cdFx0XHRjb25zdCBjYWNoZWQgPSB0aGlzLl9jYWNoZTtcblx0XHRcdGNvbnN0IHByZWxvYWRzID0gdGhpcy5fcHJlbG9hZHM7XG5cdFx0XHRjb25zdCBmaWx0ZXIgPSBvcHRzPy5maWx0ZXI7XG5cdFx0XHRjb25zdCBkaXNjYXJkZWQgPSBbXTtcblx0XHRcdGNvbnN0IGRpc2NhcmRlZElkcyA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBbaWQsIG1hdGNoXSBvZiBjYWNoZWQpIGlmICghZmlsdGVyIHx8IGZpbHRlcihtYXRjaCkpIHtcblx0XHRcdFx0ZGlzY2FyZGVkSWRzLnB1c2goaWQpO1xuXHRcdFx0XHRkaXNjYXJkZWQucHVzaChtYXRjaCk7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBhYm9ydCA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBbY29udHJvbGxlciwgbWF0Y2hlc10gb2YgcHJlbG9hZHMgPz8gW10pIGlmICghZmlsdGVyIHx8IG1hdGNoZXMuc29tZShmaWx0ZXIpKSB7XG5cdFx0XHRcdGFib3J0LnB1c2goY29udHJvbGxlcik7XG5cdFx0XHRcdGRpc2NhcmRlZC5wdXNoKC4uLm1hdGNoZXMpO1xuXHRcdFx0fVxuXHRcdFx0Zm9yIChjb25zdCBpZCBvZiBkaXNjYXJkZWRJZHMpIGNhY2hlZC5kZWxldGUoaWQpO1xuXHRcdFx0Zm9yIChjb25zdCBjb250cm9sbGVyIG9mIGFib3J0KSBwcmVsb2Fkcy5kZWxldGUoY29udHJvbGxlcik7XG5cdFx0XHRmb3IgKGNvbnN0IG1hdGNoIG9mIGRpc2NhcmRlZCkge1xuXHRcdFx0XHRjb25zdCBmbGlnaHQgPSBtYXRjaC5fZmxpZ2h0O1xuXHRcdFx0XHRtYXRjaC5fZmxpZ2h0ID0gdm9pZCAwO1xuXHRcdFx0XHRpZiAoZmxpZ2h0ICYmICEtLWZsaWdodFsyXSkge1xuXHRcdFx0XHRcdGlmICh0aGlzLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpID09PSBmbGlnaHQpIHRoaXMuX2ZsaWdodHMuZGVsZXRlKG1hdGNoLmlkKTtcblx0XHRcdFx0XHRhYm9ydC5wdXNoKGZsaWdodFsxXSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGZvciAoY29uc3QgY29udHJvbGxlciBvZiBhYm9ydCkgY29udHJvbGxlci5hYm9ydCgpO1xuXHRcdH07XG5cdFx0dGhpcy5sb2FkUm91dGVDaHVuayA9IGxvYWRSb3V0ZUNodW5rO1xuXHRcdHRoaXMucHJlbG9hZFJvdXRlID0gKG9wdHMpID0+IHByZWxvYWRDbGllbnRSb3V0ZSh0aGlzLCBvcHRzKTtcblx0XHR0aGlzLm1hdGNoUm91dGUgPSAobG9jYXRpb24sIG9wdHMpID0+IHtcblx0XHRcdGNvbnN0IG1hdGNoTG9jYXRpb24gPSB7XG5cdFx0XHRcdC4uLmxvY2F0aW9uLFxuXHRcdFx0XHR0bzogbG9jYXRpb24udG8gPyByZXNvbHZlUGF0aChsb2NhdGlvbi5mcm9tIHx8IFwiXCIsIGxvY2F0aW9uLnRvLCB0aGlzLm9wdGlvbnMudHJhaWxpbmdTbGFzaCwgdGhpcy5yZXNvbHZlUGF0aENhY2hlKSA6IHZvaWQgMCxcblx0XHRcdFx0cGFyYW1zOiBsb2NhdGlvbi5wYXJhbXMgfHwge30sXG5cdFx0XHRcdGxlYXZlUGFyYW1zOiB0cnVlXG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgbmV4dCA9IHRoaXMuYnVpbGRMb2NhdGlvbihtYXRjaExvY2F0aW9uKTtcblx0XHRcdGNvbnN0IGlzUGVuZGluZyA9IHRoaXMuc3RvcmVzLnN0YXR1cy5nZXQoKSA9PT0gXCJwZW5kaW5nXCI7XG5cdFx0XHRpZiAob3B0cz8ucGVuZGluZyAmJiAhaXNQZW5kaW5nKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRjb25zdCBiYXNlTG9jYXRpb24gPSBvcHRzPy5wZW5kaW5nID8/ICFpc1BlbmRpbmcgPyB0aGlzLmxhdGVzdExvY2F0aW9uIDogdGhpcy5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5nZXQoKSB8fCB0aGlzLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKTtcblx0XHRcdGNvbnN0IG1hdGNoID0gZmluZFNpbmdsZU1hdGNoKG5leHQucGF0aG5hbWUsIG9wdHM/LmNhc2VTZW5zaXRpdmUgPz8gZmFsc2UsIG9wdHM/LmZ1enp5ID8/IGZhbHNlLCBiYXNlTG9jYXRpb24ucGF0aG5hbWUsIHRoaXMucHJvY2Vzc2VkVHJlZSk7XG5cdFx0XHRpZiAoIW1hdGNoKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRpZiAobG9jYXRpb24ucGFyYW1zKSB7XG5cdFx0XHRcdGlmICghZGVlcEVxdWFsKG1hdGNoLnJhd1BhcmFtcywgbG9jYXRpb24ucGFyYW1zLCB0cnVlKSkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0aWYgKG9wdHM/LmluY2x1ZGVTZWFyY2ggPz8gdHJ1ZSkgcmV0dXJuIGRlZXBFcXVhbChiYXNlTG9jYXRpb24uc2VhcmNoLCBuZXh0LnNlYXJjaCwgdHJ1ZSkgPyBtYXRjaC5yYXdQYXJhbXMgOiBmYWxzZTtcblx0XHRcdHJldHVybiBtYXRjaC5yYXdQYXJhbXM7XG5cdFx0fTtcblx0XHR0aGlzLmdldFN0b3JlQ29uZmlnID0gZ2V0U3RvcmVDb25maWc7XG5cdFx0aWYgKG9wdGlvbnMucGF0aFBhcmFtc0FsbG93ZWRDaGFyYWN0ZXJzPy5sZW5ndGgpIHRoaXMucGF0aFBhcmFtc0RlY29kZXIgPSBjb21waWxlRGVjb2RlQ2hhck1hcChvcHRpb25zLnBhdGhQYXJhbXNBbGxvd2VkQ2hhcmFjdGVycyk7XG5cdFx0dGhpcy51cGRhdGUoe1xuXHRcdFx0ZGVmYXVsdFByZWxvYWREZWxheTogNTAsXG5cdFx0XHRkZWZhdWx0UGVuZGluZ01zOiAxZTMsXG5cdFx0XHRkZWZhdWx0UGVuZGluZ01pbk1zOiA1MDAsXG5cdFx0XHRjb250ZXh0OiB2b2lkIDAsXG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0Y2FzZVNlbnNpdGl2ZTogb3B0aW9ucy5jYXNlU2Vuc2l0aXZlID8/IGZhbHNlLFxuXHRcdFx0bm90Rm91bmRNb2RlOiBvcHRpb25zLm5vdEZvdW5kTW9kZSA/PyBcImZ1enp5XCIsXG5cdFx0XHRzdHJpbmdpZnlTZWFyY2g6IG9wdGlvbnMuc3RyaW5naWZ5U2VhcmNoID8/IGRlZmF1bHRTdHJpbmdpZnlTZWFyY2gsXG5cdFx0XHRwYXJzZVNlYXJjaDogb3B0aW9ucy5wYXJzZVNlYXJjaCA/PyBkZWZhdWx0UGFyc2VTZWFyY2gsXG5cdFx0XHRwcm90b2NvbEFsbG93bGlzdDogb3B0aW9ucy5wcm90b2NvbEFsbG93bGlzdCA/PyBERUZBVUxUX1BST1RPQ09MX0FMTE9XTElTVFxuXHRcdH0pO1xuXHRcdGlmICghKGlzU2VydmVyID8/IHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIikpIHNlbGYuX19UU1JfUk9VVEVSX18gPSB0aGlzO1xuXHR9XG5cdGlzU2hlbGwoKSB7XG5cdFx0cmV0dXJuICEhdGhpcy5vcHRpb25zLmlzU2hlbGw7XG5cdH1cblx0Z2V0IHN0YXRlKCkge1xuXHRcdHJldHVybiB0aGlzLnN0b3Jlcy5fX3N0b3JlLmdldCgpO1xuXHR9XG5cdHNldFJvdXRlcyhjYWNoZXMpIHtcblx0XHRPYmplY3QuYXNzaWduKHRoaXMsIGNhY2hlcyk7XG5cdFx0dGhpcy5saWdodHdlaWdodENhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHRoaXMuc3RhdGljTG9jYXRpb25zID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdFx0Y29uc3Qgbm90Rm91bmRSb3V0ZSA9IHRoaXMub3B0aW9ucy5ub3RGb3VuZFJvdXRlO1xuXHRcdGlmIChub3RGb3VuZFJvdXRlKSB7XG5cdFx0XHRub3RGb3VuZFJvdXRlLmluaXQoOTk5OTk5OTk5OTkpO1xuXHRcdFx0aWYgKHRoaXMucm91dGVzQnlJZFtub3RGb3VuZFJvdXRlLmlkXSAhPT0gbm90Rm91bmRSb3V0ZSkgbm90Rm91bmRSb3V0ZS5faW50ZXJwb2xhdGlvbiA9IHBhcnNlU2VnbWVudHMoZmFsc2UsIG5vdEZvdW5kUm91dGUsIDApO1xuXHRcdFx0dGhpcy5yb3V0ZXNCeUlkW25vdEZvdW5kUm91dGUuaWRdID0gbm90Rm91bmRSb3V0ZTtcblx0XHR9XG5cdH1cblx0bWF0Y2hSb3V0ZXNJbnRlcm5hbChuZXh0LCBvcHRzKSB7XG5cdFx0Y29uc3QgW2luaXRpYWxNYXRjaGVkUm91dGVzLCByYXdQYXJhbXMsIGZvdW5kUm91dGVdID0gdGhpcy5nZXRNYXRjaGVkUm91dGVzKG5leHQucGF0aG5hbWUpO1xuXHRcdGxldCBtYXRjaGVkUm91dGVzID0gaW5pdGlhbE1hdGNoZWRSb3V0ZXM7XG5cdFx0bGV0IGlzR2xvYmFsTm90Rm91bmQgPSBmYWxzZTtcblx0XHRpZiAoZm91bmRSb3V0ZSA/IGZvdW5kUm91dGUucGF0aCAhPT0gXCIvXCIgJiYgcmF3UGFyYW1zW1wiKipcIl0gOiB0cmltUGF0aFJpZ2h0KG5leHQucGF0aG5hbWUpKSBpZiAodGhpcy5vcHRpb25zLm5vdEZvdW5kUm91dGUpIG1hdGNoZWRSb3V0ZXMgPSBbLi4ubWF0Y2hlZFJvdXRlcywgdGhpcy5vcHRpb25zLm5vdEZvdW5kUm91dGVdO1xuXHRcdGVsc2UgaXNHbG9iYWxOb3RGb3VuZCA9IHRydWU7XG5cdFx0Y29uc3QgX25vdEZvdW5kUm91dGVJZCA9IGlzR2xvYmFsTm90Rm91bmQgPyBmaW5kR2xvYmFsTm90Rm91bmRSb3V0ZUlkKHRoaXMub3B0aW9ucy5ub3RGb3VuZE1vZGUsIG1hdGNoZWRSb3V0ZXMpIDogdm9pZCAwO1xuXHRcdGNvbnN0IG1hdGNoZXMgPSBuZXcgQXJyYXkobWF0Y2hlZFJvdXRlcy5sZW5ndGgpO1xuXHRcdGNvbnN0IGNvbW1pdHRlZCA9IHRoaXMuX2NvbW1pdHRlZDtcblx0XHRjb25zdCBwcmV2aW91c0F0ID0gKHJvdXRlLCBpbmRleCkgPT4ge1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBjb21taXR0ZWRbaW5kZXhdO1xuXHRcdFx0cmV0dXJuIG1hdGNoPy5yb3V0ZUlkID09PSByb3V0ZS5pZCA/IG1hdGNoIDogcm91dGUgPT09IHRoaXMub3B0aW9ucy5ub3RGb3VuZFJvdXRlID8gY29tbWl0dGVkLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLnJvdXRlSWQgPT09IHJvdXRlLmlkKSA6IHZvaWQgMDtcblx0XHR9O1xuXHRcdGxldCBzdHJpY3RQYXJhbXM7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZWRSb3V0ZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCByb3V0ZSA9IG1hdGNoZWRSb3V0ZXNbaW5kZXhdO1xuXHRcdFx0Y29uc3QgcGFyZW50TWF0Y2ggPSBtYXRjaGVzW2luZGV4IC0gMV07XG5cdFx0XHRsZXQgcHJlTWF0Y2hTZWFyY2g7XG5cdFx0XHRsZXQgc3RyaWN0TWF0Y2hTZWFyY2g7XG5cdFx0XHRsZXQgc2VhcmNoRXJyb3I7XG5cdFx0XHR7XG5cdFx0XHRcdGNvbnN0IHBhcmVudFNlYXJjaCA9IHBhcmVudE1hdGNoPy5zZWFyY2ggPz8gbmV4dC5zZWFyY2g7XG5cdFx0XHRcdGNvbnN0IHBhcmVudFN0cmljdFNlYXJjaCA9IHBhcmVudE1hdGNoPy5fc3RyaWN0U2VhcmNoID8/IHZvaWQgMDtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCBzdHJpY3RTZWFyY2ggPSB2YWxpZGF0ZVNlYXJjaChyb3V0ZS5vcHRpb25zLnZhbGlkYXRlU2VhcmNoLCB7IC4uLnBhcmVudFNlYXJjaCB9KSA/PyB2b2lkIDA7XG5cdFx0XHRcdFx0cHJlTWF0Y2hTZWFyY2ggPSB7XG5cdFx0XHRcdFx0XHQuLi5wYXJlbnRTZWFyY2gsXG5cdFx0XHRcdFx0XHQuLi5zdHJpY3RTZWFyY2hcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdHN0cmljdE1hdGNoU2VhcmNoID0ge1xuXHRcdFx0XHRcdFx0Li4ucGFyZW50U3RyaWN0U2VhcmNoLFxuXHRcdFx0XHRcdFx0Li4uc3RyaWN0U2VhcmNoXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdFx0bGV0IHNlYXJjaFBhcmFtRXJyb3IgPSBlcnI7XG5cdFx0XHRcdFx0aWYgKCEoZXJyIGluc3RhbmNlb2YgU2VhcmNoUGFyYW1FcnJvcikpIHNlYXJjaFBhcmFtRXJyb3IgPSBuZXcgU2VhcmNoUGFyYW1FcnJvcihlcnIubWVzc2FnZSwgeyBjYXVzZTogZXJyIH0pO1xuXHRcdFx0XHRcdGlmIChvcHRzPy50aHJvd09uRXJyb3IpIHRocm93IHNlYXJjaFBhcmFtRXJyb3I7XG5cdFx0XHRcdFx0cHJlTWF0Y2hTZWFyY2ggPSBwYXJlbnRTZWFyY2g7XG5cdFx0XHRcdFx0c3RyaWN0TWF0Y2hTZWFyY2ggPSB7fTtcblx0XHRcdFx0XHRzZWFyY2hFcnJvciA9IHNlYXJjaFBhcmFtRXJyb3I7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGxldCBsb2FkZXJEZXBzID0gXCJcIjtcblx0XHRcdGxldCBsb2FkZXJEZXBzSGFzaCA9IFwiXCI7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRsb2FkZXJEZXBzID0gcm91dGUub3B0aW9ucy5sb2FkZXJEZXBzPy4oeyBzZWFyY2g6IHByZU1hdGNoU2VhcmNoIH0pID8/IFwiXCI7XG5cdFx0XHRcdGxvYWRlckRlcHNIYXNoID0gbG9hZGVyRGVwcyA/IEpTT04uc3RyaW5naWZ5KGxvYWRlckRlcHMpIHx8IFwiXCIgOiBcIlwiO1xuXHRcdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdFx0aWYgKG9wdHM/LnRocm93T25FcnJvcikgdGhyb3cgY2F1c2U7XG5cdFx0XHRcdHNlYXJjaEVycm9yID8/PSBjYXVzZTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHVzZWRQYXJhbXMgPSBjcmVhdGVOdWxsKCk7XG5cdFx0XHRjb25zdCBpbnRlcnBvbGF0ZWRQYXRoID0gcm91dGUuX2ludGVycG9sYXRpb24gPyBpbnRlcnBvbGF0ZVBhdGgocm91dGUuZnVsbFBhdGgsIHJvdXRlLl9pbnRlcnBvbGF0aW9uLCByYXdQYXJhbXMsIHRoaXMucGF0aFBhcmFtc0RlY29kZXIsIHVzZWRQYXJhbXMpIDogcm91dGUuZnVsbFBhdGg7XG5cdFx0XHRjb25zdCBtYXRjaElkID0gcm91dGUuaWQgKyBpbnRlcnBvbGF0ZWRQYXRoICsgbG9hZGVyRGVwc0hhc2g7XG5cdFx0XHRjb25zdCBwcmV2aW91c01hdGNoID0gcHJldmlvdXNBdChyb3V0ZSwgaW5kZXgpO1xuXHRcdFx0Y29uc3QgZXhpc3RpbmdNYXRjaCA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBvcHRzPy5fcmVtYXRlcmlhbGl6ZSA/IHZvaWQgMCA6IHRoaXMuX2NhY2hlLmdldChtYXRjaElkKSA/PyAocHJldmlvdXNNYXRjaD8uaWQgPT09IG1hdGNoSWQgPyBwcmV2aW91c01hdGNoIDogdm9pZCAwKTtcblx0XHRcdHN0cmljdFBhcmFtcyA9IGV4aXN0aW5nTWF0Y2g/Ll9zdHJpY3RQYXJhbXMgPz8gT2JqZWN0LmFzc2lnbih1c2VkUGFyYW1zLCBzdHJpY3RQYXJhbXMpO1xuXHRcdFx0bGV0IHBhcmFtc0Vycm9yO1xuXHRcdFx0aWYgKCFleGlzdGluZ01hdGNoKSB0cnkge1xuXHRcdFx0XHRleHRyYWN0U3RyaWN0UGFyYW1zKHJvdXRlLCBzdHJpY3RQYXJhbXMpO1xuXHRcdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRcdGlmIChpc05vdEZvdW5kKGVycikgfHwgaXNSZWRpcmVjdChlcnIpKSBwYXJhbXNFcnJvciA9IGVycjtcblx0XHRcdFx0ZWxzZSBwYXJhbXNFcnJvciA9IG5ldyBQYXRoUGFyYW1FcnJvcihlcnIubWVzc2FnZSwgeyBjYXVzZTogZXJyIH0pO1xuXHRcdFx0XHRpZiAob3B0cz8udGhyb3dPbkVycm9yKSB0aHJvdyBwYXJhbXNFcnJvcjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGNhdXNlID0gcHJldmlvdXNNYXRjaCA/IFwic3RheVwiIDogXCJlbnRlclwiO1xuXHRcdFx0bGV0IG1hdGNoO1xuXHRcdFx0aWYgKGV4aXN0aW5nTWF0Y2gpIG1hdGNoID0ge1xuXHRcdFx0XHQuLi5leGlzdGluZ01hdGNoLFxuXHRcdFx0XHRjYXVzZSxcblx0XHRcdFx0c2VhcmNoOiBwcmV2aW91c01hdGNoID8gbnVsbFJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNNYXRjaC5zZWFyY2gsIHByZU1hdGNoU2VhcmNoKSA6IG51bGxSZXBsYWNlRXF1YWxEZWVwKGV4aXN0aW5nTWF0Y2guc2VhcmNoLCBwcmVNYXRjaFNlYXJjaCksXG5cdFx0XHRcdF9zdHJpY3RTZWFyY2g6IHN0cmljdE1hdGNoU2VhcmNoLFxuXHRcdFx0XHRzZWFyY2hFcnJvclxuXHRcdFx0fTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBzdGF0dXMgPSByb3V0ZU5lZWRzTG9hZChyb3V0ZSkgPyBcInBlbmRpbmdcIiA6IFwic3VjY2Vzc1wiO1xuXHRcdFx0XHRtYXRjaCA9IHtcblx0XHRcdFx0XHRpZDogbWF0Y2hJZCxcblx0XHRcdFx0XHRzc3I6IGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIgPyB2b2lkIDAgOiByb3V0ZS5vcHRpb25zLnNzcixcblx0XHRcdFx0XHRpbmRleCxcblx0XHRcdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZCxcblx0XHRcdFx0XHRwYXJhbXM6IHByZXZpb3VzTWF0Y2g/LnBhcmFtcyA/PyBzdHJpY3RQYXJhbXMsXG5cdFx0XHRcdFx0X3N0cmljdFBhcmFtczogc3RyaWN0UGFyYW1zLFxuXHRcdFx0XHRcdHBhdGhuYW1lOiBpbnRlcnBvbGF0ZWRQYXRoLFxuXHRcdFx0XHRcdHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRcdFx0XHRzZWFyY2g6IHByZXZpb3VzTWF0Y2ggPyBudWxsUmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c01hdGNoLnNlYXJjaCwgcHJlTWF0Y2hTZWFyY2gpIDogcHJlTWF0Y2hTZWFyY2gsXG5cdFx0XHRcdFx0X3N0cmljdFNlYXJjaDogc3RyaWN0TWF0Y2hTZWFyY2gsXG5cdFx0XHRcdFx0c2VhcmNoRXJyb3IsXG5cdFx0XHRcdFx0c3RhdHVzLFxuXHRcdFx0XHRcdGlzRmV0Y2hpbmc6IGZhbHNlLFxuXHRcdFx0XHRcdGVycm9yOiB2b2lkIDAsXG5cdFx0XHRcdFx0cGFyYW1zRXJyb3IsXG5cdFx0XHRcdFx0Y29udGV4dDoge30sXG5cdFx0XHRcdFx0YWJvcnRDb250cm9sbGVyOiBvcHRzPy5fY29udHJvbGxlciA/PyBuZXcgQWJvcnRDb250cm9sbGVyKCksXG5cdFx0XHRcdFx0Y2F1c2UsXG5cdFx0XHRcdFx0bG9hZGVyRGVwczogcHJldmlvdXNNYXRjaCA/IHJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNNYXRjaC5sb2FkZXJEZXBzLCBsb2FkZXJEZXBzKSA6IGxvYWRlckRlcHMsXG5cdFx0XHRcdFx0aW52YWxpZDogZmFsc2UsXG5cdFx0XHRcdFx0cHJlbG9hZDogZmFsc2UsXG5cdFx0XHRcdFx0c3RhdGljRGF0YTogcm91dGUub3B0aW9ucy5zdGF0aWNEYXRhIHx8IHt9LFxuXHRcdFx0XHRcdGZ1bGxQYXRoOiByb3V0ZS5mdWxsUGF0aFxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgX25vdEZvdW5kID0gX25vdEZvdW5kUm91dGVJZCA9PT0gcm91dGUuaWQ7XG5cdFx0XHRpZiAobWF0Y2guX25vdEZvdW5kICYmICFfbm90Rm91bmQpIG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRcdFx0bWF0Y2guX25vdEZvdW5kID0gX25vdEZvdW5kO1xuXHRcdFx0bWF0Y2hlc1tpbmRleF0gPSBtYXRjaDtcblx0XHR9XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdFx0bWF0Y2gucGFyYW1zID0gbWF0Y2guY2F1c2UgPT09IFwic3RheVwiID8gbnVsbFJlcGxhY2VFcXVhbERlZXAobWF0Y2gucGFyYW1zLCBzdHJpY3RQYXJhbXMpIDogc3RyaWN0UGFyYW1zO1xuXHRcdFx0aWYgKG9wdHM/Ll9jb250cm9sbGVyKSBtYXRjaC5jb250ZXh0ID0ge307XG5cdFx0fVxuXHRcdHJldHVybiBtYXRjaGVzO1xuXHR9XG5cdC8qKlxuXHQqIExpZ2h0d2VpZ2h0IHJvdXRlIG1hdGNoaW5nIGZvciBidWlsZExvY2F0aW9uLlxuXHQqIE9ubHkgY29tcHV0ZXMgZnVsbFBhdGgsIGFjY3VtdWxhdGVkIHNlYXJjaCwgYW5kIHBhcmFtcyAtIHNraXBwaW5nIGV4cGVuc2l2ZVxuXHQqIG9wZXJhdGlvbnMgbGlrZSBBYm9ydENvbnRyb2xsZXIsIGxvYWRlckRlcHMsIGFuZCBmdWxsIG1hdGNoIG9iamVjdHMuXG5cdCovXG5cdG1hdGNoUm91dGVzTGlnaHR3ZWlnaHQobG9jYXRpb24pIHtcblx0XHRjb25zdCBsYXN0Um91dGVJZCA9IGxhc3QodGhpcy5zdG9yZXMuaWRzLmdldCgpKTtcblx0XHRjb25zdCBsYXN0U3RhdGVNYXRjaCA9IGxhc3RSb3V0ZUlkID8gdGhpcy5zdG9yZXMuYnlSb3V0ZS5nZXQobGFzdFJvdXRlSWQpLmdldCgpIDogdm9pZCAwO1xuXHRcdGNvbnN0IGxhc3RTdGF0ZU1hdGNoSWQgPSBsYXN0U3RhdGVNYXRjaD8uaWQ7XG5cdFx0Y29uc3QgY2FjaGVkID0gdGhpcy5saWdodHdlaWdodENhY2hlLmdldChsb2NhdGlvbik7XG5cdFx0aWYgKGNhY2hlZCAmJiBjYWNoZWRbMF0gPT09IGxhc3RTdGF0ZU1hdGNoSWQpIHJldHVybiBjYWNoZWRbMV07XG5cdFx0Y29uc3QgW21hdGNoZWRSb3V0ZXMsIHJhd1BhcmFtc10gPSB0aGlzLmdldE1hdGNoZWRSb3V0ZXMobG9jYXRpb24ucGF0aG5hbWUpO1xuXHRcdGNvbnN0IGxhc3RSb3V0ZSA9IGxhc3QobWF0Y2hlZFJvdXRlcyk7XG5cdFx0Y29uc3QgYWNjdW11bGF0ZWRTZWFyY2ggPSB7IC4uLmxvY2F0aW9uLnNlYXJjaCB9O1xuXHRcdGZvciAoY29uc3Qgcm91dGUgb2YgbWF0Y2hlZFJvdXRlcykgdHJ5IHtcblx0XHRcdE9iamVjdC5hc3NpZ24oYWNjdW11bGF0ZWRTZWFyY2gsIHZhbGlkYXRlU2VhcmNoKHJvdXRlLm9wdGlvbnMudmFsaWRhdGVTZWFyY2gsIGFjY3VtdWxhdGVkU2VhcmNoKSk7XG5cdFx0fSBjYXRjaCB7fVxuXHRcdGNvbnN0IGNhblJldXNlUGFyYW1zID0gbGFzdFN0YXRlTWF0Y2ggJiYgbGFzdFN0YXRlTWF0Y2gucm91dGVJZCA9PT0gbGFzdFJvdXRlLmlkICYmIGxhc3RTdGF0ZU1hdGNoLnBhdGhuYW1lID09PSBsb2NhdGlvbi5wYXRobmFtZTtcblx0XHRsZXQgcGFyYW1zO1xuXHRcdGlmIChjYW5SZXVzZVBhcmFtcykgcGFyYW1zID0gbGFzdFN0YXRlTWF0Y2gucGFyYW1zO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3Qgc3RyaWN0UGFyYW1zID0gcmF3UGFyYW1zO1xuXHRcdFx0Zm9yIChjb25zdCByb3V0ZSBvZiBtYXRjaGVkUm91dGVzKSB0cnkge1xuXHRcdFx0XHRleHRyYWN0U3RyaWN0UGFyYW1zKHJvdXRlLCBzdHJpY3RQYXJhbXMpO1xuXHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0cGFyYW1zID0gc3RyaWN0UGFyYW1zO1xuXHRcdH1cblx0XHRjb25zdCByZXN1bHQgPSBbXG5cdFx0XHRtYXRjaGVkUm91dGVzLFxuXHRcdFx0bGFzdFJvdXRlLmZ1bGxQYXRoLFxuXHRcdFx0YWNjdW11bGF0ZWRTZWFyY2gsXG5cdFx0XHRwYXJhbXNcblx0XHRdO1xuXHRcdHRoaXMubGlnaHR3ZWlnaHRDYWNoZS5zZXQobG9jYXRpb24sIFtsYXN0U3RhdGVNYXRjaElkLCByZXN1bHRdKTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9XG59O1xuYXN5bmMgZnVuY3Rpb24gZG9jdW1lbnROYXZpZ2F0aW9uKHJvdXRlciwgaHJlZiwgeyByZXBsYWNlLCBpZ25vcmVCbG9ja2VyIH0pIHtcblx0aWYgKGlzRGFuZ2Vyb3VzUHJvdG9jb2woaHJlZiwgcm91dGVyLnByb3RvY29sQWxsb3dsaXN0KSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihgQmxvY2tlZCBuYXZpZ2F0aW9uIHRvIGRhbmdlcm91cyBwcm90b2NvbDogJHtocmVmfWApO1xuXHRcdHJldHVybjtcblx0fVxuXHRpZiAoIWlnbm9yZUJsb2NrZXIpIHtcblx0XHRjb25zdCBibG9ja2VycyA9IHJvdXRlci5oaXN0b3J5Ll9nZXRCbG9ja2VycygpO1xuXHRcdGZvciAoY29uc3QgYmxvY2tlciBvZiBibG9ja2VycykgaWYgKGJsb2NrZXI/LmJsb2NrZXJGbikge1xuXHRcdFx0aWYgKGF3YWl0IGJsb2NrZXIuYmxvY2tlckZuKHtcblx0XHRcdFx0Y3VycmVudExvY2F0aW9uOiByb3V0ZXIuaGlzdG9yeS5sb2NhdGlvbixcblx0XHRcdFx0bmV4dExvY2F0aW9uOiByb3V0ZXIuaGlzdG9yeS5sb2NhdGlvbixcblx0XHRcdFx0YWN0aW9uOiByZXBsYWNlID8gXCJSRVBMQUNFXCIgOiBcIlBVU0hcIlxuXHRcdFx0fSkpIHJldHVybjtcblx0XHR9XG5cdH1cblx0cm91dGVyLmhpc3RvcnkuX2lnbm9yZU5leHRCZWZvcmVVbmxvYWQ/LihocmVmKTtcblx0aWYgKHJlcGxhY2UpIHdpbmRvdy5sb2NhdGlvbi5yZXBsYWNlKGhyZWYpO1xuXHRlbHNlIHdpbmRvdy5sb2NhdGlvbi5ocmVmID0gaHJlZjtcbn1cbi8qKlxuKiBJbiBub24tcHJvZHVjdGlvbiBlbnZpcm9ubWVudHMsXG4qIGF1Z21lbnQgdGhlIFJvdXRlckNvcmUgY2xhc3Mgd2l0aCBhIGBfcmVmcmVzaFJvdXRlYCBtZXRob2RcbiogZGVkaWNhdGVkIHRvIEhNUi5cbiovXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFJvdXRlckNvcmUucHJvdG90eXBlLl9yZXBsYWNlUm91dGVDaHVuayA9IHJlcGxhY2VSb3V0ZUNodW5rO1xuXHRSb3V0ZXJDb3JlLnByb3RvdHlwZS5fcmVmcmVzaFJvdXRlID0gYXN5bmMgZnVuY3Rpb24oKSB7XG5cdFx0dGhpcy5fc2VydmVyUmVzdWx0ID0gdm9pZCAwO1xuXHRcdHRoaXMudXBkYXRlTGF0ZXN0TG9jYXRpb24oKTtcblx0XHRhd2FpdCByZWZyZXNoQ2xpZW50Um91dGUodGhpcyk7XG5cdH07XG59XG4vKiogRXJyb3IgdGhyb3duIHdoZW4gc2VhcmNoIHBhcmFtZXRlciB2YWxpZGF0aW9uIGZhaWxzLiAqL1xudmFyIFNlYXJjaFBhcmFtRXJyb3IgPSBjbGFzcyBleHRlbmRzIEVycm9yIHt9O1xuLyoqIEVycm9yIHRocm93biB3aGVuIHBhdGggcGFyYW1ldGVyIHBhcnNpbmcvdmFsaWRhdGlvbiBmYWlscy4gKi9cbnZhciBQYXRoUGFyYW1FcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige307XG5jb25zdCBub3JtYWxpemUgPSAoc3RyKSA9PiBzdHIuZW5kc1dpdGgoXCIvXCIpICYmIHN0ci5sZW5ndGggPiAxID8gc3RyLnNsaWNlKDAsIC0xKSA6IHN0cjtcbmZ1bmN0aW9uIGNvbXBhcmVQYXRocyhhLCBiKSB7XG5cdHJldHVybiBub3JtYWxpemUoYSkgPT09IG5vcm1hbGl6ZShiKTtcbn1cbi8qKlxuKiBMYXppbHkgaW1wb3J0IGEgbW9kdWxlIGZ1bmN0aW9uIGFuZCBmb3J3YXJkIGFyZ3VtZW50cyB0byBpdCwgcmV0YWluaW5nXG4qIHBhcmFtZXRlciBhbmQgcmV0dXJuIHR5cGVzIGZvciB0aGUgc2VsZWN0ZWQgZXhwb3J0IGtleS5cbiovXG5mdW5jdGlvbiBsYXp5Rm4oZm4sIGtleSkge1xuXHRyZXR1cm4gYXN5bmMgKC4uLmFyZ3MpID0+IHtcblx0XHRyZXR1cm4gKGF3YWl0IGZuKCkpW2tleSB8fCBcImRlZmF1bHRcIl0oLi4uYXJncyk7XG5cdH07XG59XG4vKiogQ3JlYXRlIGFuIGluaXRpYWwgUm91dGVyU3RhdGUgZnJvbSBhIHBhcnNlZCBsb2NhdGlvbi4gKi9cbmZ1bmN0aW9uIGdldEluaXRpYWxSb3V0ZXJTdGF0ZShsb2NhdGlvbikge1xuXHRyZXR1cm4ge1xuXHRcdGlzTG9hZGluZzogZmFsc2UsXG5cdFx0c3RhdHVzOiBcImlkbGVcIixcblx0XHRyZXNvbHZlZExvY2F0aW9uOiB2b2lkIDAsXG5cdFx0bG9jYXRpb24sXG5cdFx0bWF0Y2hlczogW11cblx0fTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlU2VhcmNoKHZhbGlkYXRlU2VhcmNoLCBpbnB1dCkge1xuXHRpZiAodmFsaWRhdGVTZWFyY2ggPT0gbnVsbCkgcmV0dXJuIHt9O1xuXHRpZiAoXCJ+c3RhbmRhcmRcIiBpbiB2YWxpZGF0ZVNlYXJjaCkge1xuXHRcdGNvbnN0IHJlc3VsdCA9IHZhbGlkYXRlU2VhcmNoW1wifnN0YW5kYXJkXCJdLnZhbGlkYXRlKGlucHV0KTtcblx0XHRpZiAocmVzdWx0IGluc3RhbmNlb2YgUHJvbWlzZSkgdGhyb3cgbmV3IFNlYXJjaFBhcmFtRXJyb3IoXCJBc3luYyB2YWxpZGF0aW9uIG5vdCBzdXBwb3J0ZWRcIik7XG5cdFx0aWYgKHJlc3VsdC5pc3N1ZXMpIHRocm93IG5ldyBTZWFyY2hQYXJhbUVycm9yKEpTT04uc3RyaW5naWZ5KHJlc3VsdC5pc3N1ZXMsIHZvaWQgMCwgMiksIHsgY2F1c2U6IHJlc3VsdCB9KTtcblx0XHRyZXR1cm4gcmVzdWx0LnZhbHVlO1xuXHR9XG5cdGlmIChcInBhcnNlXCIgaW4gdmFsaWRhdGVTZWFyY2gpIHJldHVybiB2YWxpZGF0ZVNlYXJjaC5wYXJzZShpbnB1dCk7XG5cdGlmICh0eXBlb2YgdmFsaWRhdGVTZWFyY2ggPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIHZhbGlkYXRlU2VhcmNoKGlucHV0KTtcblx0cmV0dXJuIHt9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZU5leHRQYXJhbXMoc3BlYywgYmFzZSkge1xuXHRpZiAoc3BlYyA9PT0gdm9pZCAwIHx8IHNwZWMgPT09IHRydWUpIHJldHVybiBiYXNlO1xuXHRjb25zdCBuZXh0ID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0aWYgKHNwZWMgPT09IGZhbHNlIHx8IHNwZWMgPT09IG51bGwpIHJldHVybiBuZXh0O1xuXHRpZiAodHlwZW9mIHNwZWMgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdE9iamVjdC5hc3NpZ24obmV4dCwgYmFzZSk7XG5cdFx0cmV0dXJuIE9iamVjdC5hc3NpZ24obmV4dCwgc3BlYyhuZXh0KSk7XG5cdH1cblx0cmV0dXJuIE9iamVjdC5hc3NpZ24obmV4dCwgYmFzZSwgc3BlYyk7XG59XG5mdW5jdGlvbiBuZWVkc0luaGVyaXRlZFBhcmFtcyhzcGVjLCBpbnRlcnBvbGF0aW9uKSB7XG5cdGlmICh0eXBlb2Ygc3BlYyA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKCFpbnRlcnBvbGF0aW9uIHx8IHNwZWMgPT09IGZhbHNlIHx8IHNwZWMgPT09IG51bGwpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIHNwZWMgPT09IHZvaWQgMCB8fCBzcGVjID09PSB0cnVlIHx8IGludGVycG9sYXRpb24uc29tZSgocGFydCkgPT4gdHlwZW9mIHBhcnQgIT09IFwic3RyaW5nXCIgJiYgIWhhc093bi5jYWxsKHNwZWMsIHBhcnRbMV0pKTtcbn1cbmNvbnN0IEVNUFRZX1JFQ09SRCA9IE9iamVjdC5mcmVlemUoe30pO1xuZnVuY3Rpb24gZ2V0U2VhcmNoTWlkZGxld2FyZXMoZGVzdFJvdXRlcywgaW5jbHVkZVZhbGlkYXRlU2VhcmNoKSB7XG5cdGNvbnN0IG1pZGRsZXdhcmVzID0gW107XG5cdGZvciAobGV0IGkgPSAwOyBpIDwgZGVzdFJvdXRlcy5sZW5ndGg7IGkrKykge1xuXHRcdGNvbnN0IHJvdXRlT3B0aW9ucyA9IGRlc3RSb3V0ZXNbaV0ub3B0aW9ucztcblx0XHRpZiAoXCJzZWFyY2hcIiBpbiByb3V0ZU9wdGlvbnMpIHtcblx0XHRcdGlmIChyb3V0ZU9wdGlvbnMuc2VhcmNoPy5taWRkbGV3YXJlcykgbWlkZGxld2FyZXMucHVzaCguLi5yb3V0ZU9wdGlvbnMuc2VhcmNoLm1pZGRsZXdhcmVzKTtcblx0XHR9IGVsc2UgaWYgKHJvdXRlT3B0aW9ucy5wcmVTZWFyY2hGaWx0ZXJzIHx8IHJvdXRlT3B0aW9ucy5wb3N0U2VhcmNoRmlsdGVycykge1xuXHRcdFx0Y29uc3QgbGVnYWN5TWlkZGxld2FyZSA9ICh7IHNlYXJjaCwgbmV4dCB9KSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlc3VsdCA9IG5leHQocm91dGVPcHRpb25zLnByZVNlYXJjaEZpbHRlcnMgPyByb3V0ZU9wdGlvbnMucHJlU2VhcmNoRmlsdGVycy5yZWR1Y2UoKHByZXYsIG5leHQpID0+IG5leHQocHJldiksIHNlYXJjaCkgOiBzZWFyY2gpO1xuXHRcdFx0XHRyZXR1cm4gcm91dGVPcHRpb25zLnBvc3RTZWFyY2hGaWx0ZXJzID8gcm91dGVPcHRpb25zLnBvc3RTZWFyY2hGaWx0ZXJzLnJlZHVjZSgocHJldiwgbmV4dCkgPT4gbmV4dChwcmV2KSwgcmVzdWx0KSA6IHJlc3VsdDtcblx0XHRcdH07XG5cdFx0XHRtaWRkbGV3YXJlcy5wdXNoKGxlZ2FjeU1pZGRsZXdhcmUpO1xuXHRcdH1cblx0XHRjb25zdCByb3V0ZVZhbGlkYXRlU2VhcmNoID0gcm91dGVPcHRpb25zLnZhbGlkYXRlU2VhcmNoO1xuXHRcdGlmIChpbmNsdWRlVmFsaWRhdGVTZWFyY2ggJiYgcm91dGVWYWxpZGF0ZVNlYXJjaCkge1xuXHRcdFx0Y29uc3QgdmFsaWRhdGUgPSAoeyBzZWFyY2gsIG5leHQsIG1ldGEgfSkgPT4ge1xuXHRcdFx0XHRjb25zdCByZXN1bHQgPSBuZXh0KHNlYXJjaCk7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0Y29uc3QgdmFsaWRhdGVkID0gdmFsaWRhdGVTZWFyY2gocm91dGVWYWxpZGF0ZVNlYXJjaCwgcmVzdWx0KTtcblx0XHRcdFx0XHRpZiAobWV0YSAmJiB2YWxpZGF0ZWQpIHtcblx0XHRcdFx0XHRcdGZvciAoY29uc3Qga2V5IGluIHZhbGlkYXRlZCkgaWYgKCEoa2V5IGluIHJlc3VsdCkpIChtZXRhLmRlZmF1bHRlZCB8fD0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkuc2V0KGtleSwgdmFsaWRhdGVkW2tleV0pO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdFx0Li4ucmVzdWx0LFxuXHRcdFx0XHRcdFx0Li4udmFsaWRhdGVkXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdFx0fTtcblx0XHRcdG1pZGRsZXdhcmVzLnB1c2godmFsaWRhdGUpO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gbWlkZGxld2FyZXM7XG59XG5mdW5jdGlvbiBhcHBseVNlYXJjaE1pZGRsZXdhcmUobWlkZGxld2FyZXMsIHNlYXJjaCwgZGVzdCkge1xuXHRjb25zdCBhcHBseU5leHQgPSAoaW5kZXgsIGN1cnJlbnRTZWFyY2gsIG1ldGEpID0+IHtcblx0XHRpZiAoaW5kZXggPj0gbWlkZGxld2FyZXMubGVuZ3RoKSB7XG5cdFx0XHRpZiAoIWRlc3Quc2VhcmNoKSByZXR1cm4ge307XG5cdFx0XHRpZiAoZGVzdC5zZWFyY2ggPT09IHRydWUpIHJldHVybiBjdXJyZW50U2VhcmNoO1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gZnVuY3Rpb25hbFVwZGF0ZShkZXN0LnNlYXJjaCwgY3VycmVudFNlYXJjaCk7XG5cdFx0XHRpZiAobWV0YSkgbWV0YS5leHBsaWNpdCA9IHJlc3VsdDtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fVxuXHRcdGNvbnN0IG5leHQgPSAobmV3U2VhcmNoLCBjb2xsZWN0TWV0YSkgPT4ge1xuXHRcdFx0aWYgKGNvbGxlY3RNZXRhKSB7XG5cdFx0XHRcdGNvbnN0IG5leHRNZXRhID0gbWV0YSB8fCB7fTtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRzZWFyY2g6IGFwcGx5TmV4dChpbmRleCArIDEsIG5ld1NlYXJjaCwgbmV4dE1ldGEpLFxuXHRcdFx0XHRcdG1ldGE6IG5leHRNZXRhXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gYXBwbHlOZXh0KGluZGV4ICsgMSwgbmV3U2VhcmNoLCBtZXRhKTtcblx0XHR9O1xuXHRcdHJldHVybiBtaWRkbGV3YXJlc1tpbmRleF0oe1xuXHRcdFx0c2VhcmNoOiBjdXJyZW50U2VhcmNoLFxuXHRcdFx0bmV4dCxcblx0XHRcdG1ldGFcblx0XHR9KTtcblx0fTtcblx0cmV0dXJuIGFwcGx5TmV4dCgwLCBzZWFyY2gpO1xufVxuZnVuY3Rpb24gZmluZEdsb2JhbE5vdEZvdW5kUm91dGVJZChub3RGb3VuZE1vZGUsIHJvdXRlcykge1xuXHRpZiAobm90Rm91bmRNb2RlICE9PSBcInJvb3RcIikge1xuXHRcdGxldCBmYWxsYmFjaztcblx0XHRmb3IgKGxldCBpID0gcm91dGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRjb25zdCByb3V0ZSA9IHJvdXRlc1tpXTtcblx0XHRcdGlmIChyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50KSByZXR1cm4gcm91dGUuaWQ7XG5cdFx0XHRmYWxsYmFjayB8fD0gcm91dGUuY2hpbGRyZW4gJiYgcm91dGUuaWQ7XG5cdFx0fVxuXHRcdGlmIChmYWxsYmFjaykgcmV0dXJuIGZhbGxiYWNrO1xuXHR9XG5cdHJldHVybiByb290Um91dGVJZDtcbn1cbmZ1bmN0aW9uIGV4dHJhY3RTdHJpY3RQYXJhbXMocm91dGUsIGFjY3VtdWxhdGVkUGFyYW1zKSB7XG5cdGNvbnN0IHBhcnNlUGFyYW1zID0gcm91dGUub3B0aW9ucy5wYXJhbXM/LnBhcnNlID8/IHJvdXRlLm9wdGlvbnMucGFyc2VQYXJhbXM7XG5cdGlmIChwYXJzZVBhcmFtcykgT2JqZWN0LmFzc2lnbihhY2N1bXVsYXRlZFBhcmFtcywgcGFyc2VQYXJhbXMoYWNjdW11bGF0ZWRQYXJhbXMpKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUGF0aFBhcmFtRXJyb3IsIFJvdXRlckNvcmUsIFNlYXJjaFBhcmFtRXJyb3IsIGRlZmF1bHRTZXJpYWxpemVFcnJvciwgZ2V0SW5pdGlhbFJvdXRlclN0YXRlLCBnZXRMb2NhdGlvbkNoYW5nZUluZm8sIGxhenlGbiwgbGlmZWN5Y2xlRW5kLCBydW5Sb3V0ZUxpZmVjeWNsZSwgdHJhaWxpbmdTbGFzaE9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyLmpzLm1hcCIsImltcG9ydCB7IGlzTm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCB7IGlzUmVkaXJlY3QgfSBmcm9tIFwiLi9yZWRpcmVjdC5qc1wiO1xuaW1wb3J0IHsgaHlkcmF0ZVNzck1hdGNoSWQgfSBmcm9tIFwiLi9zc3Ivc3NyLW1hdGNoLWlkLmpzXCI7XG5pbXBvcnQgeyBnZXRMb2NhdGlvbkNoYW5nZUluZm8sIGxpZmVjeWNsZUVuZCwgcnVuUm91dGVMaWZlY3ljbGUgfSBmcm9tIFwiLi9yb3V0ZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvbG9hZC1jbGllbnQudHNcbmZ1bmN0aW9uIHJlcGxhY2VSb3V0ZUNodW5rKHJvdXRlLCBsYXp5Rm4pIHtcblx0cm91dGUubGF6eUZuID0gbGF6eUZuID8/IHJvdXRlLmxhenlGbjtcblx0cm91dGUuX2xhenkgPSB2b2lkIDA7XG59XG5mdW5jdGlvbiBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCB0eXBlKSB7XG5cdHJldHVybiByb3V0ZS5vcHRpb25zW3R5cGVdPy5wcmVsb2FkPy4oKTtcbn1cbmZ1bmN0aW9uIGxvYWRDb21wb25lbnRzKHJvdXRlLCBvblBlbmRpbmdSZWFkeSkge1xuXHRjb25zdCBjb21wb25lbnQgPSBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCBcImNvbXBvbmVudFwiKTtcblx0bGV0IHBlbmRpbmcgPSBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCBcInBlbmRpbmdDb21wb25lbnRcIik7XG5cdGlmIChvblBlbmRpbmdSZWFkeSkgaWYgKHBlbmRpbmcpIHBlbmRpbmcgPSBwZW5kaW5nLnRoZW4ob25QZW5kaW5nUmVhZHkpO1xuXHRlbHNlIG9uUGVuZGluZ1JlYWR5KCk7XG5cdGlmIChjb21wb25lbnQgJiYgcGVuZGluZykgcmV0dXJuIFByb21pc2UuYWxsKFtjb21wb25lbnQsIHBlbmRpbmddKS50aGVuKCgpID0+IHt9KTtcblx0cmV0dXJuIGNvbXBvbmVudCA/PyBwZW5kaW5nO1xufVxuZnVuY3Rpb24gbG9hZFJvdXRlQ2h1bmsocm91dGUsIGNvbXBvbmVudFR5cGUsIG9uUGVuZGluZ1JlYWR5KSB7XG5cdGNvbnN0IGFmdGVyTGF6eSA9ICgpID0+IGNvbXBvbmVudFR5cGUgPT09IGZhbHNlID8gdm9pZCAwIDogY29tcG9uZW50VHlwZSA/IHByZWxvYWRDb21wb25lbnQocm91dGUsIGNvbXBvbmVudFR5cGUpIDogbG9hZENvbXBvbmVudHMocm91dGUsIG9uUGVuZGluZ1JlYWR5KTtcblx0Y29uc3QgY3VycmVudCA9IHJvdXRlLl9sYXp5O1xuXHRpZiAoY3VycmVudCkgcmV0dXJuIGN1cnJlbnQgPT09IHRydWUgPyBhZnRlckxhenkoKSA6IGN1cnJlbnQudGhlbihhZnRlckxhenkpO1xuXHRpZiAoIXJvdXRlLmxhenlGbikgcmV0dXJuIGFmdGVyTGF6eSgpO1xuXHRjb25zdCBwcm9taXNlID0gcm91dGUubGF6eUZuKCkudGhlbigobGF6eVJvdXRlKSA9PiB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiB8fCByb3V0ZS5fbGF6eSA9PT0gcHJvbWlzZSkge1xuXHRcdFx0Y29uc3QgeyBpZDogX2lkLCAuLi5vcHRpb25zIH0gPSBsYXp5Um91dGUub3B0aW9ucztcblx0XHRcdE9iamVjdC5hc3NpZ24ocm91dGUub3B0aW9ucywgb3B0aW9ucyk7XG5cdFx0XHRyb3V0ZS5fbGF6eSA9IHRydWU7XG5cdFx0fVxuXHR9LCAoZXJyb3IpID0+IHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiIHx8IHJvdXRlLl9sYXp5ID09PSBwcm9taXNlKSByb3V0ZS5fbGF6eSA9IHZvaWQgMDtcblx0XHR0aHJvdyBlcnJvcjtcblx0fSk7XG5cdHJvdXRlLl9sYXp5ID0gcHJvbWlzZTtcblx0cmV0dXJuIHByb21pc2UudGhlbihhZnRlckxhenkpO1xufVxuLyoqIFJldHVybiB0aGUgc3RydWN0dXJhbCBsYW5lIHRocm91Z2ggdGhlIGZpcnN0IHRlcm1pbmFsIHJlbmRlciBib3VuZGFyeS4gKi9cbmZ1bmN0aW9uIF9nZXRSZW5kZXJlZE1hdGNoZXMobWF0Y2hlcykge1xuXHRjb25zdCBlbmQgPSBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgbWF0Y2guX25vdEZvdW5kKSArIDE7XG5cdHJldHVybiBlbmQgJiYgZW5kIDwgbWF0Y2hlcy5sZW5ndGggPyBtYXRjaGVzLnNsaWNlKDAsIGVuZCkgOiBtYXRjaGVzO1xufVxuLyoqIFJldHVybiB0aGUgbGFuZSB3aG9zZSBkb2N1bWVudCBhc3NldHMgYmVsb25nIHRvIHRoZSBjdXJyZW50IHByZXNlbnRhdGlvbi4gKi9cbmZ1bmN0aW9uIF9nZXRBc3NldE1hdGNoZXMobWF0Y2hlcykge1xuXHRsZXQgZW5kID0gbWF0Y2hlcy5sZW5ndGg7XG5cdGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdGlmIChtYXRjaC5fYXNzZXRFbmQgIT09IHZvaWQgMCkge1xuXHRcdFx0ZW5kID0gTWF0aC5taW4oZW5kLCBNYXRoLm1heChpbmRleCArIDEsIG1hdGNoLl9hc3NldEVuZCkpO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGlmIChtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiIHx8IG1hdGNoLl9ub3RGb3VuZCkge1xuXHRcdFx0ZW5kID0gaW5kZXggKyAxO1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBlbmQgPCBtYXRjaGVzLmxlbmd0aCA/IG1hdGNoZXMuc2xpY2UoMCwgZW5kKSA6IG1hdGNoZXM7XG59XG5jb25zdCBTVUNDRVNTID0gMDtcbmNvbnN0IEVSUk9SID0gMTtcbmNvbnN0IE5PVF9GT1VORCA9IDI7XG5jb25zdCBSRURJUkVDVEVEID0gMztcbmNvbnN0IENBTkNFTEVEX09VVENPTUUgPSBbNF07XG5mdW5jdGlvbiBpc0NvbnRyb2wocmVzdWx0KSB7XG5cdHJldHVybiB0eXBlb2YgcmVzdWx0WzBdID09PSBcIm51bWJlclwiO1xufVxuZnVuY3Rpb24gd2FpdEZvcih2YWx1ZSwgc2lnbmFsKSB7XG5cdGlmIChzaWduYWwuYWJvcnRlZCkgcmV0dXJuIFByb21pc2UucmFjZShbUHJvbWlzZS5yZWplY3Qoc2lnbmFsKSwgdmFsdWVdKTtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCBhYm9ydCA9ICgpID0+IHJlamVjdChzaWduYWwpO1xuXHRcdHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRQcm9taXNlLnJlc29sdmUodmFsdWUpLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KS50aGVuKCgpID0+IHNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnQpKTtcblx0fSk7XG59XG5mdW5jdGlvbiBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKSB7XG5cdHJldHVybiByb3V0ZXIucm91dGVzQnlJZFttYXRjaC5yb3V0ZUlkXTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZSh2YWx1ZSwgcmVqZWN0ZWQsIHJvdXRlSWQpIHtcblx0aWYgKGlzUmVkaXJlY3QodmFsdWUpKSByZXR1cm4gW1JFRElSRUNURUQsIHZhbHVlXTtcblx0aWYgKGlzTm90Rm91bmQodmFsdWUpKSB7XG5cdFx0dmFsdWUucm91dGVJZCB8fD0gcm91dGVJZDtcblx0XHRyZXR1cm4gW05PVF9GT1VORCwgdmFsdWVdO1xuXHR9XG5cdGlmICghcmVqZWN0ZWQpIHJldHVybiBbU1VDQ0VTUywgdmFsdWVdO1xuXHRpZiAodHlwZW9mIHZhbHVlPy50aGVuID09PSBcImZ1bmN0aW9uXCIpIHZhbHVlID0gbmV3IEVycm9yKFwiQSBQcm9taXNlIHdhcyB0aHJvd25cIiwgeyBjYXVzZTogdmFsdWUgfSk7XG5cdHJldHVybiBbRVJST1IsIHZhbHVlXTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUVycm9yKHJvdXRlLCBjYXVzZSkge1xuXHRsZXQgb3V0Y29tZSA9IG5vcm1hbGl6ZShjYXVzZSwgdHJ1ZSwgcm91dGUuaWQpO1xuXHRpZiAob3V0Y29tZVswXSAhPT0gRVJST1IpIHJldHVybiBvdXRjb21lO1xuXHR0cnkge1xuXHRcdHJvdXRlLm9wdGlvbnMub25FcnJvcj8uKG91dGNvbWVbMV0pO1xuXHR9IGNhdGNoIChvbkVycm9yQ2F1c2UpIHtcblx0XHRvdXRjb21lID0gbm9ybWFsaXplKG9uRXJyb3JDYXVzZSwgdHJ1ZSwgcm91dGUuaWQpO1xuXHR9XG5cdHJldHVybiBvdXRjb21lO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplTGFuZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBvcHRpb25zKSB7XG5cdGlmIChvcHRpb25zWzBdLnNpZ25hbC5hYm9ydGVkKSByZXR1cm4gQ0FOQ0VMRURfT1VUQ09NRTtcblx0cmV0dXJuIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgbm9ybWFsaXplRXJyb3Iocm91dGUsIGNhdXNlKSwgb3B0aW9ucyk7XG59XG5hc3luYyBmdW5jdGlvbiBjb250ZXh0dWFsaXplKHJvdXRlciwgbGFuZSwgb3B0aW9ucywgZW5kLCBwbGFuU3VjY2Vzc2Z1bExhbmUsIHJldGFpbmVkRW5kKSB7XG5cdGNvbnN0IFtsb2NhdGlvbiwgbWF0Y2hlc10gPSBsYW5lO1xuXHRjb25zdCBzaWduYWwgPSBvcHRpb25zWzBdLnNpZ25hbDtcblx0Y29uc3QgcHJlbG9hZCA9ICEhb3B0aW9uc1szXTtcblx0Zm9yIChsZXQgaW5kZXggPSBvcHRpb25zWzZdID8/IDA7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2luZGV4XTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRcdG1hdGNoLmFib3J0Q29udHJvbGxlciA9IG9wdGlvbnNbMF07XG5cdFx0Y29uc3QgcGFyZW50Q29udGV4dCA9IG1hdGNoZXNbaW5kZXggLSAxXT8uY29udGV4dCA/PyByb3V0ZXIub3B0aW9ucy5jb250ZXh0ID8/IHt9O1xuXHRcdGNvbnN0IGNvbW1vbiA9IHtcblx0XHRcdHBhcmFtczogbWF0Y2gucGFyYW1zLFxuXHRcdFx0bG9jYXRpb24sXG5cdFx0XHRuYXZpZ2F0ZTogKG9wdHMpID0+IHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdF9mcm9tTG9jYXRpb246IGxvY2F0aW9uXG5cdFx0XHR9KSxcblx0XHRcdGJ1aWxkTG9jYXRpb246IHJvdXRlci5idWlsZExvY2F0aW9uLFxuXHRcdFx0Y2F1c2U6IHByZWxvYWQgPyBcInByZWxvYWRcIiA6IG1hdGNoLmNhdXNlLFxuXHRcdFx0YWJvcnRDb250cm9sbGVyOiBvcHRpb25zWzBdLFxuXHRcdFx0cHJlbG9hZCxcblx0XHRcdG1hdGNoZXMsXG5cdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZFxuXHRcdH07XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IHJvdXRlQ29udGV4dCA9IG1hdGNoLl9jdHggfHw9IHJvdXRlLm9wdGlvbnMuY29udGV4dCA/IHJvdXRlLm9wdGlvbnMuY29udGV4dCh7XG5cdFx0XHRcdC4uLmNvbW1vbixcblx0XHRcdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRcdFx0Y29udGV4dDogcGFyZW50Q29udGV4dFxuXHRcdFx0fSkgfHwge30gOiB2b2lkIDA7XG5cdFx0XHRtYXRjaC5jb250ZXh0ID0ge1xuXHRcdFx0XHQuLi5wYXJlbnRDb250ZXh0LFxuXHRcdFx0XHQuLi5yb3V0ZUNvbnRleHRcblx0XHRcdH07XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRyZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIG9wdGlvbnMpXTtcblx0XHR9XG5cdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm4gW2luZGV4LCBDQU5DRUxFRF9PVVRDT01FXTtcblx0XHRjb25zdCB2YWxpZGF0aW9uRXJyb3IgPSBtYXRjaC5wYXJhbXNFcnJvciA/PyBtYXRjaC5zZWFyY2hFcnJvcjtcblx0XHRpZiAodmFsaWRhdGlvbkVycm9yICE9PSB2b2lkIDApIHtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRyZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgdmFsaWRhdGlvbkVycm9yLCBvcHRpb25zKV07XG5cdFx0fVxuXHRcdGNvbnN0IGJlZm9yZUxvYWQgPSByb3V0ZS5vcHRpb25zLmJlZm9yZUxvYWQ7XG5cdFx0aWYgKCFiZWZvcmVMb2FkKSBjb250aW51ZTtcblx0XHRjb25zdCBwcmV2aW91c1N0YXR1cyA9IG1hdGNoLnN0YXR1cztcblx0XHRpZiAoaW5kZXggPj0gcmV0YWluZWRFbmQpIHtcblx0XHRcdG1hdGNoLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRcdFx0b3B0aW9uc1s3XT8uKCk7XG5cdFx0fVxuXHRcdHRyeSB7XG5cdFx0XHRzZXRGZXRjaGluZyhyb3V0ZXIsIG1hdGNoLCBcImJlZm9yZUxvYWRcIiwgb3B0aW9uc1swXSk7XG5cdFx0XHRjb25zdCB2YWx1ZSA9IGJlZm9yZUxvYWQoe1xuXHRcdFx0XHQuLi5jb21tb24sXG5cdFx0XHRcdHNlYXJjaDogbWF0Y2guc2VhcmNoLFxuXHRcdFx0XHRjb250ZXh0OiBtYXRjaC5jb250ZXh0LFxuXHRcdFx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCAodHlwZW9mIHZhbHVlPy50aGVuID09PSBcImZ1bmN0aW9uXCIgPyB3YWl0Rm9yKHZhbHVlLCBzaWduYWwpIDogdmFsdWUpO1xuXHRcdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm4gW2luZGV4LCBDQU5DRUxFRF9PVVRDT01FXTtcblx0XHRcdGNvbnN0IG91dGNvbWUgPSBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIG5vcm1hbGl6ZShyZXN1bHQsIGZhbHNlLCByb3V0ZS5pZCksIG9wdGlvbnMpO1xuXHRcdFx0aWYgKG91dGNvbWVbMF0gIT09IFNVQ0NFU1MpIHtcblx0XHRcdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdFx0cmV0dXJuIFtpbmRleCwgb3V0Y29tZV07XG5cdFx0XHR9XG5cdFx0XHRtYXRjaC5jb250ZXh0ID0ge1xuXHRcdFx0XHQuLi5tYXRjaC5jb250ZXh0LFxuXHRcdFx0XHQuLi5yZXN1bHRcblx0XHRcdH07XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRyZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIG9wdGlvbnMpXTtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0bWF0Y2guc3RhdHVzID0gcHJldmlvdXNTdGF0dXM7XG5cdFx0XHRzZXRGZXRjaGluZyhyb3V0ZXIsIG1hdGNoLCBmYWxzZSwgb3B0aW9uc1swXSk7XG5cdFx0fVxuXHR9XG5cdHBsYW5TdWNjZXNzZnVsTGFuZSgpO1xufVxuZnVuY3Rpb24gcmVsZWFzZU93bmVkRmxpZ2h0KHJvdXRlciwgbWF0Y2gsIGZsaWdodCkge1xuXHRpZiAoIWZsaWdodCB8fCAtLWZsaWdodFsyXSkgcmV0dXJuO1xuXHRpZiAocm91dGVyLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpID09PSBmbGlnaHQpIHtcblx0XHRjb25zdCBjdXJyZW50ID0gcm91dGVyLl90eDtcblx0XHRpZiAoY3VycmVudCAmJiAhY3VycmVudFswXS5zaWduYWwuYWJvcnRlZCAmJiAhY3VycmVudFszXS5pbmNsdWRlcyhtYXRjaCkgJiYgY3VycmVudFszXS5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gbWF0Y2guaWQpICYmIGN1cnJlbnRbM10uc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaXNGZXRjaGluZyA9PT0gXCJiZWZvcmVMb2FkXCIpKSByZXR1cm47XG5cdFx0cm91dGVyLl9mbGlnaHRzLmRlbGV0ZShtYXRjaC5pZCk7XG5cdH1cblx0cmV0dXJuIGZsaWdodFsxXTtcbn1cbmZ1bmN0aW9uIHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCkge1xuXHRjb25zdCBmbGlnaHQgPSBtYXRjaC5fZmxpZ2h0O1xuXHRtYXRjaC5fZmxpZ2h0ID0gdm9pZCAwO1xuXHRyZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgZmxpZ2h0KT8uYWJvcnQoKTtcbn1cbi8qKlxuKiBOb3QgcGFzc2luZyBpbiBhIGBuZXh0YCBvd25lcnNoaXAgcmVjaXBpZW50XG4qIGlzIGVxdWl2YWxlbnQgdG8gZGlzY2FyZGluZyB0aGUgbWF0Y2ggcmVzb3VyY2VzXG4qL1xuZnVuY3Rpb24gdHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIHByZXZpb3VzLCBuZXh0LCBkZWZlclNhbWVJZEZsaWdodCkge1xuXHRjb25zdCBhYm9ydCA9IFtdO1xuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIHByZXZpb3VzKSBpZiAoIW5leHQ/LmluY2x1ZGVzKG1hdGNoKSkge1xuXHRcdGNvbnN0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdFx0bWF0Y2guX2ZsaWdodCA9IHZvaWQgMDtcblx0XHRpZiAoZGVmZXJTYW1lSWRGbGlnaHQgJiYgZmxpZ2h0Py5bMl0gPT09IDEgJiYgcm91dGVyLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpID09PSBmbGlnaHQgJiYgbmV4dD8uc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IG1hdGNoLmlkKSkgZmxpZ2h0WzJdID0gMDtcblx0XHRlbHNlIHtcblx0XHRcdGNvbnN0IGNvbnRyb2xsZXIgPSByZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgZmxpZ2h0KTtcblx0XHRcdGlmIChjb250cm9sbGVyKSBhYm9ydC5wdXNoKGNvbnRyb2xsZXIpO1xuXHRcdH1cblx0fVxuXHRmb3IgKGNvbnN0IGNvbnRyb2xsZXIgb2YgYWJvcnQpIGNvbnRyb2xsZXIuYWJvcnQoKTtcbn1cbmZ1bmN0aW9uIGFjcXVpcmVNYXRjaFJlc291cmNlcyhtYXRjaGVzKSB7XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgbWF0Y2hlcykge1xuXHRcdGNvbnN0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdFx0aWYgKGZsaWdodCkgZmxpZ2h0WzJdKys7XG5cdH1cbn1cbmZ1bmN0aW9uIHNldEZldGNoaW5nKHJvdXRlciwgbWF0Y2gsIHZhbHVlLCBvd25lcikge1xuXHRtYXRjaC5pc0ZldGNoaW5nID0gdmFsdWU7XG5cdGlmIChvd25lciAmJiByb3V0ZXIuX3R4Py5bMF0gIT09IG93bmVyKSByZXR1cm47XG5cdGNvbnN0IHN0b3JlID0gcm91dGVyLnN0b3Jlcy5ieVJvdXRlLmdldChtYXRjaC5yb3V0ZUlkKTtcblx0Y29uc3QgcHJlc2VudGVkID0gc3RvcmU/LmdldCgpO1xuXHRpZiAocHJlc2VudGVkPy5pZCA9PT0gbWF0Y2guaWQpIHN0b3JlLnNldCh7XG5cdFx0Li4ucHJlc2VudGVkLFxuXHRcdGlzRmV0Y2hpbmc6IHZhbHVlXG5cdH0pO1xufVxuZnVuY3Rpb24gZ2V0TG9hZGVyQ29udGV4dChyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgY29udHJvbGxlciwgcGFyZW50TWF0Y2hQcm9taXNlLCBwcmVsb2FkKSB7XG5cdGNvbnN0IGxvY2F0aW9uID0gbGFuZVswXTtcblx0cmV0dXJuIHtcblx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRsb2NhdGlvbixcblx0XHRuYXZpZ2F0ZTogKG9wdHMpID0+IHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0XHQuLi5vcHRzLFxuXHRcdFx0X2Zyb21Mb2NhdGlvbjogbG9jYXRpb25cblx0XHR9KSxcblx0XHRjYXVzZTogcHJlbG9hZCA/IFwicHJlbG9hZFwiIDogbWF0Y2guY2F1c2UsXG5cdFx0YWJvcnRDb250cm9sbGVyOiBjb250cm9sbGVyLFxuXHRcdHByZWxvYWQsXG5cdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRwYXJlbnRNYXRjaFByb21pc2UsXG5cdFx0Y29udGV4dDogbWF0Y2guY29udGV4dCxcblx0XHRyb3V0ZSxcblx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHR9O1xufVxuYXN5bmMgZnVuY3Rpb24gbG9hZFJlc291cmNlKHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBsb2FkZXIsIHBhcmVudE1hdGNoUHJvbWlzZSwgb3B0aW9ucykge1xuXHRjb25zdCBvd25lciA9IG9wdGlvbnNbMF07XG5cdGNvbnN0IHNpZ25hbCA9IG93bmVyLnNpZ25hbDtcblx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm4gQ0FOQ0VMRURfT1VUQ09NRTtcblx0aWYgKCFsb2FkZXIpIHJldHVybiBbU1VDQ0VTUywgdm9pZCAwXTtcblx0bGV0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdHNldEZldGNoaW5nKHJvdXRlciwgbWF0Y2gsIFwibG9hZGVyXCIsIG93bmVyKTtcblx0dHJ5IHtcblx0XHRpZiAoIWZsaWdodCkge1xuXHRcdFx0Y29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRcdGZsaWdodCA9IFtcblx0XHRcdFx0UHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiBsb2FkZXIoZ2V0TG9hZGVyQ29udGV4dChyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgY29udHJvbGxlciwgcGFyZW50TWF0Y2hQcm9taXNlLCAhIW9wdGlvbnNbM10pKSkudGhlbigodmFsdWUpID0+IG5vcm1hbGl6ZSh2YWx1ZSwgZmFsc2UsIHJvdXRlLmlkKSwgKGNhdXNlKSA9PiBub3JtYWxpemUoY2F1c2UsIHRydWUsIHJvdXRlLmlkKSkudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0XHRcdFx0aWYgKHJlc3VsdFswXSAhPT0gU1VDQ0VTUyAmJiByb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodCkge1xuXHRcdFx0XHRcdFx0cm91dGVyLl9mbGlnaHRzLmRlbGV0ZShtYXRjaC5pZCk7XG5cdFx0XHRcdFx0XHRpZiAoIWZsaWdodFsyXSkgY29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRyZXR1cm4gcmVzdWx0WzBdID09PSBFUlJPUiAmJiBmbGlnaHRbMl0gPyBub3JtYWxpemVFcnJvcihyb3V0ZSwgcmVzdWx0WzFdKSA6IHJlc3VsdDtcblx0XHRcdFx0fSksXG5cdFx0XHRcdGNvbnRyb2xsZXIsXG5cdFx0XHRcdDFcblx0XHRcdF07XG5cdFx0XHQocm91dGVyLl9mbGlnaHRzID8/PSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKS5zZXQobWF0Y2guaWQsIGZsaWdodCk7XG5cdFx0fVxuXHRcdG1hdGNoLl9mbGlnaHQgPSBmbGlnaHQ7XG5cdFx0bWF0Y2guYWJvcnRDb250cm9sbGVyID0gZmxpZ2h0WzFdO1xuXHRcdHJldHVybiBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIGF3YWl0IHdhaXRGb3IoZmxpZ2h0WzBdLCBzaWduYWwpLCBvcHRpb25zKTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRpZiAoY2F1c2UgIT09IHNpZ25hbCB8fCAhc2lnbmFsLmFib3J0ZWQpIHRocm93IGNhdXNlO1xuXHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0cmV0dXJuIENBTkNFTEVEX09VVENPTUU7XG5cdH0gZmluYWxseSB7XG5cdFx0c2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgZmFsc2UsIG93bmVyKTtcblx0fVxufVxuZnVuY3Rpb24gc2V0dGxlSW50byhtYXRjaCwgcmVzdWx0LCBwcmVsb2FkKSB7XG5cdGlmIChyZXN1bHRbMF0gPT09IFJFRElSRUNURUQpIHJldHVybjtcblx0bWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRpZiAocmVzdWx0WzBdID09PSBTVUNDRVNTKSB7XG5cdFx0bWF0Y2gubG9hZGVyRGF0YSA9IHJlc3VsdFsxXTtcblx0XHRtYXRjaC5pbnZhbGlkID0gZmFsc2U7XG5cdFx0bWF0Y2gudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcblx0XHRtYXRjaC5wcmVsb2FkID0gcHJlbG9hZDtcblx0fSBlbHNlIG1hdGNoLmludmFsaWQgPSB0cnVlO1xufVxuZnVuY3Rpb24gY2FjaGVMb2FkZXJNYXRjaChyb3V0ZXIsIG1hdGNoLCBwbGFubmVkKSB7XG5cdGNvbnN0IGN1cnJlbnQgPSByb3V0ZXIuX2NhY2hlLmdldChtYXRjaC5pZCk7XG5cdGlmIChjdXJyZW50ICE9PSBwbGFubmVkIHx8IHJvdXRlci5fY29tbWl0dGVkLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBtYXRjaC5pZCAmJiBjYW5kaWRhdGUuX2ZsaWdodCA9PT0gbWF0Y2guX2ZsaWdodCkpIHJldHVybjtcblx0Y29uc3QgY2FjaGVkID0ge1xuXHRcdC4uLm1hdGNoLFxuXHRcdF9ub3RGb3VuZDogdm9pZCAwLFxuXHRcdGNvbnRleHQ6IHt9XG5cdH07XG5cdGlmIChjYWNoZWQuX2ZsaWdodCkgY2FjaGVkLl9mbGlnaHRbMl0rKztcblx0cm91dGVyLl9jYWNoZS5zZXQobWF0Y2guaWQsIGNhY2hlZCk7XG5cdGlmIChjdXJyZW50KSByZWxlYXNlRmxpZ2h0KHJvdXRlciwgY3VycmVudCk7XG59XG5mdW5jdGlvbiBnZXRQYXJlbnRTbmFwc2hvdChtYXRjaCwgb3V0Y29tZSkge1xuXHRpZiAob3V0Y29tZVswXSA9PT0gRVJST1IgfHwgb3V0Y29tZVswXSA9PT0gTk9UX0ZPVU5EKSByZXR1cm4ge1xuXHRcdC4uLm1hdGNoLFxuXHRcdHN0YXR1czogb3V0Y29tZVswXSA9PT0gRVJST1IgPyBcImVycm9yXCIgOiBcIm5vdEZvdW5kXCIsXG5cdFx0ZXJyb3I6IG91dGNvbWVbMV0sXG5cdFx0X2ZsaWdodDogdm9pZCAwXG5cdH07XG5cdHJldHVybiBtYXRjaDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUxvYWRlclRhc2socm91dGVyLCBsYW5lLCBpbmRleCwgdGFza3MsIHNlbWFudGljUGFyZW50LCBvcHRpb25zLCByZXRhaW5lZEVuZCkge1xuXHRjb25zdCBtYXRjaCA9IGxhbmVbMV1baW5kZXhdO1xuXHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRjb25zdCBwcmVsb2FkID0gISFvcHRpb25zWzNdO1xuXHRjb25zdCBwbGFubmVkQ2FjaGVNYXRjaCA9IHJvdXRlci5fY2FjaGUuZ2V0KG1hdGNoLmlkKTtcblx0bGV0IGNvbmZpZ3VyZWQ7XG5cdGxldCByZWxvYWQgPSBmYWxzZTtcblx0bGV0IHJlbG9hZEZhaWx1cmU7XG5cdHRyeSB7XG5cdFx0aWYgKG1hdGNoLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIpIHtcblx0XHRcdGNvbmZpZ3VyZWQgPSByb3V0ZS5vcHRpb25zLnNob3VsZFJlbG9hZDtcblx0XHRcdGlmICh0eXBlb2YgY29uZmlndXJlZCA9PT0gXCJmdW5jdGlvblwiKSBjb25maWd1cmVkID0gY29uZmlndXJlZChnZXRMb2FkZXJDb250ZXh0KHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBvcHRpb25zWzBdLCBzZW1hbnRpY1BhcmVudCwgcHJlbG9hZCkpO1xuXHRcdFx0aWYgKG9wdGlvbnNbMF0uc2lnbmFsLmFib3J0ZWQpIHJlbG9hZEZhaWx1cmUgPSBDQU5DRUxFRF9PVVRDT01FO1xuXHRcdH1cblx0XHRpZiAoIXJlbG9hZEZhaWx1cmUpIGlmIChtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiKSByZWxvYWQgPSB0cnVlO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3Qgc3RhbGVBZ2UgPSBwcmVsb2FkIHx8IG1hdGNoLnByZWxvYWQgPyByb3V0ZS5vcHRpb25zLnByZWxvYWRTdGFsZVRpbWUgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFByZWxvYWRTdGFsZVRpbWUgPz8gM2U0IDogcm91dGUub3B0aW9ucy5zdGFsZVRpbWUgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFN0YWxlVGltZSA/PyAwO1xuXHRcdFx0cmVsb2FkID0gISEobWF0Y2guaW52YWxpZCB8fCBjb25maWd1cmVkIHx8IGNvbmZpZ3VyZWQgPT09IHZvaWQgMCAmJiBEYXRlLm5vdygpIC0gbWF0Y2gudXBkYXRlZEF0ID49IHN0YWxlQWdlICYmIChvcHRpb25zWzVdIHx8IG1hdGNoLmNhdXNlID09PSBcImVudGVyXCIgfHwgb3B0aW9uc1syXS5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5yb3V0ZUlkID09PSBtYXRjaC5yb3V0ZUlkICYmIGNhbmRpZGF0ZS5pZCAhPT0gbWF0Y2guaWQpKSk7XG5cdFx0fVxuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdG1hdGNoLmludmFsaWQgPSB0cnVlO1xuXHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBtYXRjaCk7XG5cdFx0cmVsb2FkRmFpbHVyZSA9IG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgb3B0aW9ucyk7XG5cdH1cblx0Y29uc3Qgcm91dGVMb2FkZXIgPSByb3V0ZS5vcHRpb25zLmxvYWRlcjtcblx0Y29uc3QgaXNMb2FkZXJGbiA9IHR5cGVvZiByb3V0ZUxvYWRlciA9PT0gXCJmdW5jdGlvblwiO1xuXHRjb25zdCBsb2FkZXIgPSBpc0xvYWRlckZuID8gcm91dGVMb2FkZXIgOiByb3V0ZUxvYWRlcj8uaGFuZGxlcjtcblx0Y29uc3QgcHJlbG9hZGFibGUgPSAhcHJlbG9hZCB8fCByb3V0ZS5vcHRpb25zLnByZWxvYWQgIT09IGZhbHNlO1xuXHRsZXQgZG9ub3IgPSBwcmVsb2FkYWJsZSAmJiByb3V0ZUxvYWRlciAmJiAhKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiByb3V0ZXIuX3R4Py5bNl0pID8gcm91dGVyLl9mbGlnaHRzPy5nZXQobWF0Y2guaWQpIDogdm9pZCAwO1xuXHRpZiAoZG9ub3IgPT09IG1hdGNoLl9mbGlnaHQgfHwgcmVsb2FkRmFpbHVyZSkgZG9ub3IgPSB2b2lkIDA7XG5cdGVsc2UgaWYgKGRvbm9yICYmICFyZWxvYWQgJiYgIXByZWxvYWQgJiYgY29uZmlndXJlZCA9PT0gdm9pZCAwKSByZWxvYWQgPSB0cnVlO1xuXHRlbHNlIGlmICghcmVsb2FkKSBkb25vciA9IHZvaWQgMDtcblx0Y29uc3QgYmFja2dyb3VuZCA9ICEhKHJvdXRlTG9hZGVyICYmIHJlbG9hZCAmJiBtYXRjaC5zdGF0dXMgPT09IFwic3VjY2Vzc1wiICYmICFwcmVsb2FkICYmICFvcHRpb25zWzRdICYmICgoaXNMb2FkZXJGbiA/IHZvaWQgMCA6IHJvdXRlTG9hZGVyLnN0YWxlUmVsb2FkTW9kZSkgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFN0YWxlUmVsb2FkTW9kZSkgIT09IFwiYmxvY2tpbmdcIik7XG5cdGNvbnN0IGxvYWRlZCA9IHJlbG9hZCAmJiBwcmVsb2FkYWJsZTtcblx0Y29uc3QgYmxvY2tpbmcgPSBsb2FkZWQgJiYgIWJhY2tncm91bmQgJiYgKG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgISFyb3V0ZUxvYWRlcik7XG5cdGNvbnN0IG9uUmVhZHkgPSBpbmRleCA+PSByZXRhaW5lZEVuZCA/IG9wdGlvbnNbN10gOiB2b2lkIDA7XG5cdGNvbnN0IG9uTGF6eVJlYWR5ID0gcm91dGUubGF6eUZuICYmIHJvdXRlLl9sYXp5ICE9PSB0cnVlID8gb25SZWFkeSA6IHZvaWQgMDtcblx0aWYgKGxvYWRlZCAmJiAhcm91dGVMb2FkZXIpIHtcblx0XHRtYXRjaC5pbnZhbGlkID0gZmFsc2U7XG5cdFx0bWF0Y2gudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcblx0fVxuXHRpZiAoZG9ub3IpIGRvbm9yWzJdKys7XG5cdGlmIChibG9ja2luZykge1xuXHRcdGNvbnN0IGFjY2VwdGVkRmxpZ2h0ID0gbWF0Y2guX2ZsaWdodDtcblx0XHRtYXRjaC5fZmxpZ2h0ID0gZG9ub3I7XG5cdFx0cmVsZWFzZU93bmVkRmxpZ2h0KHJvdXRlciwgbWF0Y2gsIGFjY2VwdGVkRmxpZ2h0KT8uYWJvcnQoKTtcblx0XHRpZiAoaW5kZXggPj0gcmV0YWluZWRFbmQpIG1hdGNoLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRcdG9uUmVhZHk/LigpO1xuXHR9XG5cdGlmICghbG9hZGVkKSBtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdGNvbnN0IG91dGNvbWUgPSAhcmVsb2FkRmFpbHVyZSAmJiBibG9ja2luZyA/IGxvYWRSZXNvdXJjZShyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgbG9hZGVyLCBzZW1hbnRpY1BhcmVudCwgb3B0aW9ucykudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0c2V0dGxlSW50byhtYXRjaCwgcmVzdWx0LCBwcmVsb2FkKTtcblx0XHRpZiAocmVzdWx0WzBdID09PSBTVUNDRVNTKSB7XG5cdFx0XHRpZiAocm91dGVMb2FkZXIgJiYgIW9wdGlvbnNbMF0uc2lnbmFsLmFib3J0ZWQpIGNhY2hlTG9hZGVyTWF0Y2gocm91dGVyLCBtYXRjaCwgcGxhbm5lZENhY2hlTWF0Y2gpO1xuXHRcdFx0aWYgKGluZGV4ID49IHJldGFpbmVkRW5kKSBtYXRjaC5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0XHR9XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSkgOiBQcm9taXNlLnJlc29sdmUocmVsb2FkRmFpbHVyZSA/PyBbU1VDQ0VTUywgbWF0Y2gubG9hZGVyRGF0YV0pO1xuXHRjb25zdCBjaHVua0ZhaWx1cmUgPSAoYXN5bmMgKCkgPT4ge1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBjaHVuayA9IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCB2b2lkIDAsIG9uTGF6eVJlYWR5KTtcblx0XHRcdGlmIChjaHVuaykgYXdhaXQgd2FpdEZvcihjaHVuaywgb3B0aW9uc1swXS5zaWduYWwpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoIWxhbmVbMV0uc29tZSgoY2FuZGlkYXRlLCBjYW5kaWRhdGVJbmRleCkgPT4gY2FuZGlkYXRlSW5kZXggPD0gaW5kZXggJiYgKGNhbmRpZGF0ZS5zdGF0dXMgPT09IFwiZXJyb3JcIiB8fCBjYW5kaWRhdGUuc3RhdHVzID09PSBcIm5vdEZvdW5kXCIgfHwgY2FuZGlkYXRlLl9ub3RGb3VuZCkpKSByZXR1cm4gW2luZGV4LCBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIG9wdGlvbnMpXTtcblx0XHR9XG5cdFx0Y29uc3QgcmVzdWx0ID0gYXdhaXQgb3V0Y29tZTtcblx0XHRpZiAoYmxvY2tpbmcgJiYgcmVzdWx0WzBdID09PSBTVUNDRVNTICYmIG1hdGNoLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIgJiYgIW9wdGlvbnNbMF0uc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRcdG1hdGNoLnN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdFx0b25SZWFkeT8uKCk7XG5cdFx0fVxuXHR9KSgpO1xuXHR0YXNrcy5wdXNoKFtcblx0XHRpbmRleCxcblx0XHRvdXRjb21lLFxuXHRcdGNodW5rRmFpbHVyZVxuXHRdKTtcblx0aWYgKCFiYWNrZ3JvdW5kKSByZXR1cm4gb3V0Y29tZS50aGVuKChyZXN1bHQpID0+IGdldFBhcmVudFNuYXBzaG90KG1hdGNoLCByZXN1bHQpKTtcblx0Y29uc3QgY2FuZGlkYXRlID0ge1xuXHRcdC4uLm1hdGNoLFxuXHRcdHN0YXR1czogXCJwZW5kaW5nXCIsXG5cdFx0cHJlbG9hZDogZmFsc2UsXG5cdFx0X2ZsaWdodDogZG9ub3Jcblx0fTtcblx0bWF0Y2guaW52YWxpZCA9IGZhbHNlO1xuXHRtYXRjaC5pc0ZldGNoaW5nID0gXCJsb2FkZXJcIjtcblx0Y29uc3QgYmFja2dyb3VuZE91dGNvbWUgPSBsb2FkUmVzb3VyY2Uocm91dGVyLCBsYW5lLCBjYW5kaWRhdGUsIHJvdXRlLCBsb2FkZXIsIHNlbWFudGljUGFyZW50LCBvcHRpb25zKS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0c2V0dGxlSW50byhjYW5kaWRhdGUsIHJlc3VsdCwgZmFsc2UpO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH0pO1xuXHQobGFuZVsyXSA/Pz0gW10pLnB1c2goW1xuXHRcdGluZGV4LFxuXHRcdGJhY2tncm91bmRPdXRjb21lLFxuXHRcdGNodW5rRmFpbHVyZSxcblx0XHRjYW5kaWRhdGVcblx0XSk7XG5cdHJldHVybiBiYWNrZ3JvdW5kT3V0Y29tZS50aGVuKChyZXN1bHQpID0+IGdldFBhcmVudFNuYXBzaG90KGNhbmRpZGF0ZSwgcmVzdWx0KSk7XG59XG5hc3luYyBmdW5jdGlvbiBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgaW5kZXhlZCwgc2lnbmFsLCBmYWxsYmFjayA9IDApIHtcblx0Y29uc3QgY2F1c2UgPSBpbmRleGVkPy5bMV1bMV07XG5cdGxldCBpbmRleCA9IGNhdXNlPy5yb3V0ZUlkID8gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkID09PSBjYXVzZS5yb3V0ZUlkKSA6IGluZGV4ZWQ/LlswXSA/PyBtYXRjaGVzLmxlbmd0aCAtIDE7XG5cdGlmIChpbmRleCA8IDApIGluZGV4ID0gMDtcblx0Zm9yIChsZXQgaSA9IGluZGV4OyBpID49IDA7IGktLSkge1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaGVzW2ldKTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgbG9hZGluZyA9IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBmYWxzZSk7XG5cdFx0XHRpZiAobG9hZGluZykgYXdhaXQgd2FpdEZvcihsb2FkaW5nLCBzaWduYWwpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoY2F1c2UgPT09IHNpZ25hbCAmJiBzaWduYWwuYWJvcnRlZCkgdGhyb3cgY2F1c2U7XG5cdFx0fVxuXHRcdGlmIChyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50KSByZXR1cm4gaTtcblx0fVxuXHRyZXR1cm4gY2F1c2U/LnJvdXRlSWQgPyBpbmRleCA6IGZhbGxiYWNrO1xufVxuZnVuY3Rpb24gZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBsYW5lKSB7XG5cdGlmIChsYW5lWzJdKSB7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIGxhbmVbMl0ubWFwKCh0YXNrKSA9PiB0YXNrWzNdKSk7XG5cdFx0bGFuZVsyXSA9IHZvaWQgMDtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gc2V0dGxlVGFza3ModGFza3MsIHNlcmlhbEZhaWx1cmUsIHJlZGlyZWN0VGFza3MsIGdhdGUpIHtcblx0bGV0IGxvYWRlckZhaWx1cmU7XG5cdHRyeSB7XG5cdFx0YXdhaXQgUHJvbWlzZS5hbGwodGFza3MubWFwKCh0YXNrKSA9PiB0YXNrWzFdLnRoZW4oYXN5bmMgKG91dGNvbWUpID0+IHtcblx0XHRcdGNvbnN0IHRhc2tJbmRleCA9IHRhc2tbMF07XG5cdFx0XHRpZiAoZ2F0ZSAmJiB0YXNrSW5kZXggPj0gYXdhaXQgZ2F0ZSkgcmV0dXJuO1xuXHRcdFx0aWYgKG91dGNvbWVbMF0gPj0gUkVESVJFQ1RFRCkgdGhyb3cgW3Rhc2tJbmRleCwgb3V0Y29tZV07XG5cdFx0XHRpZiAoIWxvYWRlckZhaWx1cmUgJiYgb3V0Y29tZVswXSAhPT0gU1VDQ0VTUykge1xuXHRcdFx0XHRsb2FkZXJGYWlsdXJlID0gW3Rhc2tJbmRleCwgb3V0Y29tZV07XG5cdFx0XHRcdGF3YWl0IFByb21pc2UuYWxsKChyZWRpcmVjdFRhc2tzID8/IFtdKS5tYXAoKG5leHRUYXNrKSA9PiB7XG5cdFx0XHRcdFx0aWYgKG5leHRUYXNrWzBdIDw9IHRhc2tJbmRleCkgcmV0dXJuO1xuXHRcdFx0XHRcdHJldHVybiBuZXh0VGFza1sxXS50aGVuKChuZXh0T3V0Y29tZSkgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKG5leHRPdXRjb21lWzBdID09PSBSRURJUkVDVEVEKSB0aHJvdyBbbmV4dFRhc2tbMF0sIG5leHRPdXRjb21lXTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fSkpO1xuXHRcdFx0fVxuXHRcdH0pKSk7XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0cmV0dXJuIGNhdXNlO1xuXHR9XG5cdHJldHVybiBzZXJpYWxGYWlsdXJlID8/IGxvYWRlckZhaWx1cmU7XG59XG5mdW5jdGlvbiBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIG91dGNvbWUsIG9wdGlvbnMsIGZhaWxlZCkge1xuXHR3aGlsZSAob3V0Y29tZVswXSA9PT0gUkVESVJFQ1RFRCkge1xuXHRcdGNvbnN0IHJlZGlyZWN0ID0gb3V0Y29tZVsxXTtcblx0XHRjb25zdCByZWRpcmVjdE9wdGlvbnMgPSByZWRpcmVjdC5vcHRpb25zO1xuXHRcdHRyeSB7XG5cdFx0XHRpZiAocmVkaXJlY3RPcHRpb25zLmhyZWYgfHwgcmVkaXJlY3QuaGVhZGVycy5oYXMoXCJMb2NhdGlvblwiKSkge1xuXHRcdFx0XHRyb3V0ZXIucmVzb2x2ZVJlZGlyZWN0KHJlZGlyZWN0KTtcblx0XHRcdFx0aWYgKHJlZGlyZWN0T3B0aW9ucy5yZWxvYWREb2N1bWVudCkgcmV0dXJuIG91dGNvbWU7XG5cdFx0XHR9XG5cdFx0XHRpZiAocmVkaXJlY3RPcHRpb25zLnJlbG9hZERvY3VtZW50ID8gb3B0aW9uc1szXSA6IG9wdGlvbnNbMV0gPj0gMjApIHJldHVybiBvdXRjb21lO1xuXHRcdFx0Y29uc3QgbG9jYXRpb24gPSByb3V0ZXIuYnVpbGRMb2NhdGlvbih7XG5cdFx0XHRcdC4uLnJlZGlyZWN0T3B0aW9ucyxcblx0XHRcdFx0X2Zyb21Mb2NhdGlvbjogbGFuZVswXSxcblx0XHRcdFx0X2luY2x1ZGVWYWxpZGF0ZVNlYXJjaDogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCBwdWJsaWNMb2NhdGlvbiA9IGxvY2F0aW9uLm1hc2tlZExvY2F0aW9uID8/IGxvY2F0aW9uO1xuXHRcdFx0aWYgKHB1YmxpY0xvY2F0aW9uLmV4dGVybmFsKSB7XG5cdFx0XHRcdGNvbnN0IHJlc29sdmVkID0gcmVkaXJlY3QuY2xvbmUoKTtcblx0XHRcdFx0cmVzb2x2ZWQub3B0aW9ucyA9IHsgLi4ucmVkaXJlY3RPcHRpb25zIH07XG5cdFx0XHRcdHJlc29sdmVkLmhlYWRlcnMuc2V0KFwiTG9jYXRpb25cIiwgcHVibGljTG9jYXRpb24ucHVibGljSHJlZik7XG5cdFx0XHRcdHJvdXRlci5yZXNvbHZlUmVkaXJlY3QocmVzb2x2ZWQpO1xuXHRcdFx0XHRyZXR1cm4gb3B0aW9uc1szXSA/IFtSRURJUkVDVEVELCByZXNvbHZlZF0gOiBbXG5cdFx0XHRcdFx0UkVESVJFQ1RFRCxcblx0XHRcdFx0XHRyZXNvbHZlZCxcblx0XHRcdFx0XHRwdWJsaWNMb2NhdGlvblxuXHRcdFx0XHRdO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIFtcblx0XHRcdFx0UkVESVJFQ1RFRCxcblx0XHRcdFx0cmVkaXJlY3QsXG5cdFx0XHRcdGxvY2F0aW9uXG5cdFx0XHRdO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRvdXRjb21lID0gZmFpbGVkID8gW0VSUk9SLCBjYXVzZV0gOiBub3JtYWxpemVFcnJvcihyb3V0ZSwgY2F1c2UpO1xuXHRcdFx0ZmFpbGVkID0gdHJ1ZTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIG91dGNvbWU7XG59XG5hc3luYyBmdW5jdGlvbiByZWR1Y2VMYW5lKHJvdXRlciwgbGFuZSwgdGFza3MsIGNvbnRyb2xsZXIsIHNldHRsZW1lbnQsIG9uUmVhZHkpIHtcblx0Y29uc3QgbWF0Y2hlcyA9IGxhbmVbMV07XG5cdGxldCBmYWlsdXJlID0gYXdhaXQgc2V0dGxlbWVudDtcblx0bGV0IHJlZGlyZWN0TGltaXRFeGNlZWRlZCA9IGZhbHNlO1xuXHRjb25zdCBwbGFubmVkQm91bmRhcnkgPSBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdGNvbnN0IGJvdW5kYXJ5T2YgPSAoZm91bmQpID0+IGZvdW5kWzFdWzBdID09PSBOT1RfRk9VTkQgPyBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgZm91bmQsIGNvbnRyb2xsZXIuc2lnbmFsKSA6IGZvdW5kWzBdO1xuXHRsZXQgcmVhZGluZXNzRW5kID0gcGxhbm5lZEJvdW5kYXJ5IDwgMCA/IG1hdGNoZXMubGVuZ3RoIDogcGxhbm5lZEJvdW5kYXJ5O1xuXHRpZiAoKGZhaWx1cmU/LlsxXVswXSA/PyAwKSA+PSBSRURJUkVDVEVEKSByZWFkaW5lc3NFbmQgPSAwO1xuXHRlbHNlIGlmIChmYWlsdXJlKSB7XG5cdFx0cmVhZGluZXNzRW5kID0gZmFpbHVyZVsyXSA/Pz0gYXdhaXQgYm91bmRhcnlPZihmYWlsdXJlKTtcblx0XHRmb3IgKGNvbnN0IHRhc2sgb2YgdGFza3MpIHtcblx0XHRcdGlmICh0YXNrWzBdID49IHJlYWRpbmVzc0VuZCkgYnJlYWs7XG5cdFx0XHRjb25zdCBvdXRjb21lID0gYXdhaXQgdGFza1sxXTtcblx0XHRcdGlmIChvdXRjb21lWzBdICE9PSBTVUNDRVNTICYmIG91dGNvbWVbMF0gPCBSRURJUkVDVEVEICYmICEoXCJsb2FkZXJEYXRhXCIgaW4gbWF0Y2hlc1t0YXNrWzBdXSkpIHtcblx0XHRcdFx0ZmFpbHVyZSA9IFt0YXNrWzBdLCBvdXRjb21lXTtcblx0XHRcdFx0cmVhZGluZXNzRW5kID0gZmFpbHVyZVsyXSA9IGF3YWl0IGJvdW5kYXJ5T2YoZmFpbHVyZSk7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRmb3IgKGNvbnN0IHRhc2sgb2YgdGFza3MpIHtcblx0XHRpZiAodGFza1swXSA+PSByZWFkaW5lc3NFbmQpIGJyZWFrO1xuXHRcdGNvbnN0IGNodW5rRmFpbHVyZSA9IGF3YWl0IHRhc2tbMl07XG5cdFx0aWYgKCFjaHVua0ZhaWx1cmUpIGNvbnRpbnVlO1xuXHRcdGZhaWx1cmUgPSBjaHVua0ZhaWx1cmU7XG5cdFx0YnJlYWs7XG5cdH1cblx0aWYgKChmYWlsdXJlPy5bMV1bMF0gPz8gMCkgPj0gUkVESVJFQ1RFRCkge1xuXHRcdGNvbnN0IG91dGNvbWUgPSBmYWlsdXJlWzFdO1xuXHRcdGlmIChvdXRjb21lWzBdICE9PSBSRURJUkVDVEVEIHx8IG91dGNvbWVbMV0ub3B0aW9ucy5yZWxvYWREb2N1bWVudCB8fCBvdXRjb21lWzJdKSB7XG5cdFx0XHRkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIGxhbmUpO1xuXHRcdFx0cmV0dXJuIG91dGNvbWU7XG5cdFx0fVxuXHRcdHJlZGlyZWN0TGltaXRFeGNlZWRlZCA9IHRydWU7XG5cdFx0ZmFpbHVyZSA9IFswLCBbRVJST1IsIC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJUb28gbWFueSByZWRpcmVjdHNcIildXTtcblx0fVxuXHRjb25zdCBib3VuZGFyeSA9IGZhaWx1cmUgPyBmYWlsdXJlWzJdID8/IGF3YWl0IGJvdW5kYXJ5T2YoZmFpbHVyZSkgOiBwbGFubmVkQm91bmRhcnk7XG5cdGlmIChib3VuZGFyeSA+PSAwKSB7XG5cdFx0Y29uc3Qgb3V0Y29tZSA9IGZhaWx1cmU/LlsxXTtcblx0XHRjb25zdCBraW5kID0gb3V0Y29tZT8uWzBdO1xuXHRcdGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tib3VuZGFyeV07XG5cdFx0Y29uc3QgY2F1c2UgPSBvdXRjb21lPy5bMV07XG5cdFx0Y29uc3QgaW5zdGFsbCA9ICgpID0+IHtcblx0XHRcdGlmIChvdXRjb21lKSB7XG5cdFx0XHRcdG1hdGNoLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRcdFx0aWYgKGtpbmQgPT09IEVSUk9SKSBtYXRjaC5zdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0XHRcdGVsc2Uge1xuXHRcdFx0XHRcdGNhdXNlLnJvdXRlSWQgPSBtYXRjaC5yb3V0ZUlkO1xuXHRcdFx0XHRcdGlmIChtYXRjaC5yb3V0ZUlkID09PSByb3V0ZXIucm91dGVUcmVlLmlkKSB7XG5cdFx0XHRcdFx0XHRtYXRjaC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRcdFx0XHRcdG1hdGNoLl9ub3RGb3VuZCA9IHRydWU7XG5cdFx0XHRcdFx0fSBlbHNlIG1hdGNoLnN0YXR1cyA9IFwibm90Rm91bmRcIjtcblx0XHRcdFx0fVxuXHRcdFx0XHRtYXRjaC5lcnJvciA9IGNhdXNlO1xuXHRcdFx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRpbnN0YWxsKCk7XG5cdFx0aWYgKCFvdXRjb21lKSBvblJlYWR5Py4oKTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRcdHRyeSB7XG5cdFx0XHRhd2FpdCB3YWl0Rm9yKG91dGNvbWUgPyBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBraW5kID09PSBFUlJPUiA/IFwiZXJyb3JDb21wb25lbnRcIiA6IFwibm90Rm91bmRDb21wb25lbnRcIikpIDogUHJvbWlzZS5hbGwoW2xvYWRSb3V0ZUNodW5rKHJvdXRlKSwgbG9hZFJvdXRlQ2h1bmsocm91dGUsIFwibm90Rm91bmRDb21wb25lbnRcIildKSwgY29udHJvbGxlci5zaWduYWwpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoY2F1c2UgPT09IGNvbnRyb2xsZXIuc2lnbmFsICYmIGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRcdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBsYW5lKTtcblx0XHRcdFx0cmV0dXJuIENBTkNFTEVEX09VVENPTUU7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmICghb3V0Y29tZSkgbWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0ZWxzZSBpZiAocmVkaXJlY3RMaW1pdEV4Y2VlZGVkKSB7XG5cdFx0XHRjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHRhd2FpdCBQcm9taXNlLmFsbChbXG5cdFx0XHRcdC4uLnRhc2tzLm1hcCgodGFzaykgPT4gdGFza1sxXSksXG5cdFx0XHRcdC4uLnRhc2tzLm1hcCgodGFzaykgPT4gdGFza1syXSksXG5cdFx0XHRcdC4uLihsYW5lWzJdID8/IFtdKS5tYXAoKHRhc2spID0+IHRhc2tbMV0pXG5cdFx0XHRdKTtcblx0XHRcdGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlciwgbGFuZSk7XG5cdFx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcyk7XG5cdFx0XHRpbnN0YWxsKCk7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBsYW5lO1xufVxuYXN5bmMgZnVuY3Rpb24gcHJvamVjdExhbmUocm91dGVyLCBsYW5lLCBzaWduYWwsIHN0YXJ0ID0gMCwgZW5kID0gbGFuZVsxXS5sZW5ndGgpIHtcblx0Y29uc3QgbWF0Y2hlcyA9IGxhbmVbMV07XG5cdGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2luZGV4XTtcblx0XHRjb25zdCByb3V0ZU9wdGlvbnMgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKS5vcHRpb25zO1xuXHRcdGlmIChyb3V0ZU9wdGlvbnMuaGVhZCB8fCByb3V0ZU9wdGlvbnMuc2NyaXB0cykgdHJ5IHtcblx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdHNzcjogcm91dGVyLm9wdGlvbnMuc3NyLFxuXHRcdFx0XHRtYXRjaGVzLFxuXHRcdFx0XHRtYXRjaCxcblx0XHRcdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0XHRcdGxvYWRlckRhdGE6IG1hdGNoLmxvYWRlckRhdGFcblx0XHRcdH07XG5cdFx0XHRjb25zdCBbaGVhZCwgc2NyaXB0c10gPSBhd2FpdCB3YWl0Rm9yKFByb21pc2UuYWxsKFtyb3V0ZU9wdGlvbnMuaGVhZD8uKGNvbnRleHQpLCByb3V0ZU9wdGlvbnMuc2NyaXB0cz8uKGNvbnRleHQpXSksIHNpZ25hbCk7XG5cdFx0XHRtYXRjaC5tZXRhID0gaGVhZD8ubWV0YTtcblx0XHRcdG1hdGNoLmxpbmtzID0gaGVhZD8ubGlua3M7XG5cdFx0XHRtYXRjaC5oZWFkU2NyaXB0cyA9IGhlYWQ/LnNjcmlwdHM7XG5cdFx0XHRtYXRjaC5zdHlsZXMgPSBoZWFkPy5zdHlsZXM7XG5cdFx0XHRtYXRjaC5zY3JpcHRzID0gc2NyaXB0cztcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0aWYgKGNhdXNlID09PSBzaWduYWwgJiYgc2lnbmFsLmFib3J0ZWQpIGJyZWFrO1xuXHRcdFx0Y29uc29sZS5lcnJvcihjYXVzZSk7XG5cdFx0fVxuXHRcdGlmIChtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiIHx8IG1hdGNoLl9ub3RGb3VuZCkgYnJlYWs7XG5cdH1cblx0cmV0dXJuIGxhbmU7XG59XG5hc3luYyBmdW5jdGlvbiBleGVjdXRlQ2xpZW50TGFuZShyb3V0ZXIsIGxvY2F0aW9uLCBtYXRjaGVzLCBvcHRpb25zKSB7XG5cdGNvbnN0IG1hdGNoZWQgPSBbbG9jYXRpb24sIG1hdGNoZXNdO1xuXHRjb25zdCBzaWduYWwgPSBvcHRpb25zWzBdLnNpZ25hbDtcblx0bGV0IHJlZHVjZWQ7XG5cdHRyeSB7XG5cdFx0Y29uc3QgcHJlc2VudGVkID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpO1xuXHRcdGxldCBwbGFubmVkQm91bmRhcnkgPSBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdFx0aWYgKHJvdXRlci5vcHRpb25zLm5vdEZvdW5kTW9kZSAhPT0gXCJyb290XCIgJiYgcGxhbm5lZEJvdW5kYXJ5ID49IDApIHtcblx0XHRcdGNvbnN0IGJvdW5kYXJ5ID0gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIG1hdGNoZXMsIHZvaWQgMCwgc2lnbmFsLCBwbGFubmVkQm91bmRhcnkpO1xuXHRcdFx0bWF0Y2hlc1twbGFubmVkQm91bmRhcnldLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRcdG1hdGNoZXNbYm91bmRhcnldLl9ub3RGb3VuZCA9IHRydWU7XG5cdFx0XHRwbGFubmVkQm91bmRhcnkgPSBib3VuZGFyeTtcblx0XHR9XG5cdFx0bGV0IGVuZCA9IHBsYW5uZWRCb3VuZGFyeSA8IDAgPyBtYXRjaGVzLmxlbmd0aCA6IHBsYW5uZWRCb3VuZGFyeSArIDE7XG5cdFx0bGV0IHJldGFpbmVkRW5kID0gMDtcblx0XHR3aGlsZSAocmV0YWluZWRFbmQgPCBlbmQgJiYgcmV0YWluZWRFbmQgIT09IHBsYW5uZWRCb3VuZGFyeSkge1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW3JldGFpbmVkRW5kXTtcblx0XHRcdGNvbnN0IGNvbW1pdHRlZCA9IG9wdGlvbnNbMl1bcmV0YWluZWRFbmRdO1xuXHRcdFx0Y29uc3QgdmlzaWJsZSA9IHByZXNlbnRlZFtyZXRhaW5lZEVuZF07XG5cdFx0XHRpZiAoY29tbWl0dGVkPy5pZCAhPT0gbWF0Y2guaWQgfHwgY29tbWl0dGVkLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgbWF0Y2gucHJlbG9hZCB8fCB2aXNpYmxlPy5pZCAhPT0gbWF0Y2guaWQgfHwgdmlzaWJsZS5zdGF0dXMgIT09IFwic3VjY2Vzc1wiKSBicmVhaztcblx0XHRcdHJldGFpbmVkRW5kKys7XG5cdFx0XHRpZiAoY29tbWl0dGVkLl9ub3RGb3VuZCB8fCB2aXNpYmxlLl9ub3RGb3VuZCkgYnJlYWs7XG5cdFx0fVxuXHRcdGNvbnN0IHRhc2tzID0gW107XG5cdFx0Y29uc3Qgc3RhcnQgPSBvcHRpb25zWzZdID8/IDA7XG5cdFx0bGV0IHNlbWFudGljUGFyZW50ID0gc3RhcnQgPyBQcm9taXNlLnJlc29sdmUobWF0Y2hlc1tzdGFydCAtIDFdKSA6IHZvaWQgMDtcblx0XHRjb25zdCBwbGFuU3VjY2Vzc2Z1bExhbmUgPSAoKSA9PiB7XG5cdFx0XHRmb3IgKGxldCBpbmRleCA9IHN0YXJ0OyBpbmRleCA8IGVuZDsgaW5kZXgrKykge1xuXHRcdFx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIGJyZWFrO1xuXHRcdFx0XHRzZW1hbnRpY1BhcmVudCA9IGNyZWF0ZUxvYWRlclRhc2socm91dGVyLCBtYXRjaGVkLCBpbmRleCwgdGFza3MsIHNlbWFudGljUGFyZW50LCBvcHRpb25zLCByZXRhaW5lZEVuZCk7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRjb25zdCBmYWlsdXJlID0gYXdhaXQgY29udGV4dHVhbGl6ZShyb3V0ZXIsIG1hdGNoZWQsIG9wdGlvbnMsIGVuZCwgcGxhblN1Y2Nlc3NmdWxMYW5lLCByZXRhaW5lZEVuZCk7XG5cdFx0aWYgKGZhaWx1cmUpIHtcblx0XHRcdG9wdGlvbnNbNF0gPSB0cnVlO1xuXHRcdFx0ZW5kID0gZmFpbHVyZVswXTtcblx0XHRcdGlmIChmYWlsdXJlWzFdWzBdID09PSBOT1RfRk9VTkQpIHtcblx0XHRcdFx0Y29uc3QgYm91bmRhcnkgPSBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgZmFpbHVyZSwgc2lnbmFsKTtcblx0XHRcdFx0ZmFpbHVyZVsyXSA9IGJvdW5kYXJ5O1xuXHRcdFx0XHRlbmQgPSBNYXRoLm1pbihlbmQsIGJvdW5kYXJ5ICsgMSk7XG5cdFx0XHR9IGVsc2UgaWYgKGZhaWx1cmVbMV1bMF0gPj0gUkVESVJFQ1RFRCkgZW5kID0gMDtcblx0XHRcdHBsYW5TdWNjZXNzZnVsTGFuZSgpO1xuXHRcdH1cblx0XHRpZiAoIXNpZ25hbC5hYm9ydGVkICYmICFvcHRpb25zWzNdKSB7XG5cdFx0XHRjb25zdCBhYm9ydCA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBbaWQsIGZsaWdodF0gb2Ygcm91dGVyLl9mbGlnaHRzID8/IFtdKSBpZiAoIWZsaWdodFsyXSkge1xuXHRcdFx0XHRyb3V0ZXIuX2ZsaWdodHMuZGVsZXRlKGlkKTtcblx0XHRcdFx0YWJvcnQucHVzaChmbGlnaHRbMV0pO1xuXHRcdFx0fVxuXHRcdFx0Zm9yIChjb25zdCBjb250cm9sbGVyIG9mIGFib3J0KSBjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0fVxuXHRcdGNvbnN0IHJlZHVjdGlvbiA9IHJlZHVjZUxhbmUocm91dGVyLCBtYXRjaGVkLCB0YXNrcywgb3B0aW9uc1swXSwgc2V0dGxlVGFza3ModGFza3MsIGZhaWx1cmUsIG1hdGNoZWRbMl0pLCBvcHRpb25zWzddKTtcblx0XHRpZiAobWF0Y2hlZFsyXT8ubGVuZ3RoKSBtYXRjaGVkWzNdID0gc2V0dGxlVGFza3MobWF0Y2hlZFsyXSwgdm9pZCAwLCB2b2lkIDAsIHJlZHVjdGlvbi50aGVuKChmb3JlZ3JvdW5kKSA9PiBpc0NvbnRyb2woZm9yZWdyb3VuZCkgPyAwIDogX2dldFJlbmRlcmVkTWF0Y2hlcyhtYXRjaGVzKS5sZW5ndGgsICgpID0+IDApKTtcblx0XHRyZWR1Y2VkID0gYXdhaXQgcmVkdWN0aW9uO1xuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlciwgbWF0Y2hlZCk7XG5cdFx0aWYgKGNhdXNlID09PSBzaWduYWwgJiYgc2lnbmFsLmFib3J0ZWQpIHJldHVybiBDQU5DRUxFRF9PVVRDT01FO1xuXHRcdHRocm93IGNhdXNlO1xuXHR9XG5cdGlmIChpc0NvbnRyb2wocmVkdWNlZCkpIHJldHVybiByZWR1Y2VkO1xuXHRyZXR1cm4gcHJvamVjdExhbmUocm91dGVyLCByZWR1Y2VkLCBzaWduYWwsIG9wdGlvbnNbNl0gPT09IG1hdGNoZXMubGVuZ3RoID8gb3B0aW9uc1s2XSA6IDApO1xufVxuLyoqXG4qIFdhaXRzIGZvciBgcGVuZGluZ01zYCwgdGhlbiBwcmVzZW50cyB0aGUgY29tcGxldGUgbGFuZS4gUmVuZGVyaW5nIGFwcGxpZXMgdGhlXG4qIHNlbGVjdGVkIGJvdW5kYXJ5IGN1dG9mZiB3aGlsZSByZXRhaW5pbmcgZXZlcnkgbWF0Y2gncyBzdHJ1Y3R1cmFsIHN0YXRlLlxuKiBBIHJlcGxhY2VtZW50IGxvYWQgZm9yIHRoZSBzYW1lIG1hdGNoIGtlZXBzIHRoZSB0aW1lcjsgY2hvb3NpbmcgYSBkaWZmZXJlbnRcbiogbWF0Y2ggcmVzZXRzIGl0LiBgcGVuZGluZ01pbk1zYCBzdGFydHMgYWZ0ZXIgdGhlIGZhbGxiYWNrIHJlbmRlcnMuXG4qL1xuZnVuY3Rpb24gb2ZmZXJQZW5kaW5nKHJvdXRlciwgdHgpIHtcblx0aWYgKHJvdXRlci5fdHggIT09IHR4KSByZXR1cm47XG5cdGNvbnN0IG1hdGNoZXMgPSB0eFszXTtcblx0Y29uc3QgcHJlc2VudGVkID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpO1xuXHRsZXQgc2Vzc2lvbiA9IHJvdXRlci5fcGVuZGluZztcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2luZGV4XTtcblx0XHRjb25zdCBzdWNjZXNzID0gbWF0Y2guc3RhdHVzID09PSBcInN1Y2Nlc3NcIiAmJiAhbWF0Y2guX25vdEZvdW5kO1xuXHRcdGNvbnN0IHByZXNlbnRlZFBlbmRpbmcgPSBwcmVzZW50ZWRbaW5kZXhdPy5pZCA9PT0gbWF0Y2guaWQgJiYgcHJlc2VudGVkW2luZGV4XT8uc3RhdHVzID09PSBcInBlbmRpbmdcIjtcblx0XHRpZiAoc3VjY2VzcyAmJiAhcHJlc2VudGVkUGVuZGluZykgY29udGludWU7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHRjb25zdCBkZWxheSA9IHN1Y2Nlc3MgfHwgbWF0Y2guaW52YWxpZCA/IDAgOiByb3V0ZS5vcHRpb25zLnBlbmRpbmdNcyA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UGVuZGluZ01zO1xuXHRcdGNvbnN0IGNvbXBvbmVudCA9IHJvdXRlLm9wdGlvbnMucGVuZGluZ0NvbXBvbmVudCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UGVuZGluZ0NvbXBvbmVudDtcblx0XHRpZiAoIWNvbXBvbmVudCB8fCB0eXBlb2YgZGVsYXkgIT09IFwibnVtYmVyXCIgfHwgZGVsYXkgPT09IEluZmluaXR5KSB7XG5cdFx0XHRpZiAoc2Vzc2lvbikge1xuXHRcdFx0XHRzZXNzaW9uWzBdID0gdHg7XG5cdFx0XHRcdHNlc3Npb25bMl0gPSAwO1xuXHRcdFx0XHRzZXNzaW9uWzRdID0gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgbWluID0gcm91dGUub3B0aW9ucy5wZW5kaW5nTWluTXMgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFBlbmRpbmdNaW5NcyA/PyAwO1xuXHRcdGxldCB0b29rT3ZlciA9IGZhbHNlO1xuXHRcdGlmIChzZXNzaW9uPy5bMV0gPT09IG1hdGNoLmlkKSB7XG5cdFx0XHR0b29rT3ZlciA9IHNlc3Npb25bMF0gIT09IHR4O1xuXHRcdFx0c2Vzc2lvblswXSA9IHR4O1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRjbGVhclRpbWVvdXQoc2Vzc2lvbj8uWzNdKTtcblx0XHRcdHJvdXRlci5fcGVuZGluZyA9IHNlc3Npb24gPSB2b2lkIDA7XG5cdFx0fVxuXHRcdGlmICghc2Vzc2lvbikgcm91dGVyLl9wZW5kaW5nID0gc2Vzc2lvbiA9IFtcblx0XHRcdHR4LFxuXHRcdFx0bWF0Y2guaWQsXG5cdFx0XHRwcmVzZW50ZWRQZW5kaW5nID8gRGF0ZS5ub3coKSArIG1pbiA6IHR4WzRdICsgZGVsYXksXG5cdFx0XHR2b2lkIDAsXG5cdFx0XHRwcmVzZW50ZWRQZW5kaW5nIHx8IHZvaWQgMCxcblx0XHRcdGNvbXBvbmVudFxuXHRcdF07XG5cdFx0aWYgKHNlc3Npb25bNF0gJiYgIXRvb2tPdmVyICYmIHNlc3Npb25bNV0gPT09IGNvbXBvbmVudCkgcmV0dXJuO1xuXHRcdHNlc3Npb25bNV0gPSBjb21wb25lbnQ7XG5cdFx0aWYgKCFzZXNzaW9uWzRdKSB7XG5cdFx0XHRjbGVhclRpbWVvdXQoc2Vzc2lvblszXSk7XG5cdFx0XHRjb25zdCByZW1haW5pbmcgPSBzZXNzaW9uWzJdIC0gRGF0ZS5ub3coKTtcblx0XHRcdGlmIChyZW1haW5pbmcgPiAwKSB7XG5cdFx0XHRcdHNlc3Npb25bM10gPSBzZXRUaW1lb3V0KCgpID0+IG9mZmVyUGVuZGluZyhyb3V0ZXIsIHR4KSwgcmVtYWluaW5nKTtcblx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0c2Vzc2lvblsyXSA9IDA7XG5cdFx0fVxuXHRcdGNvbnN0IG9mZmVyZWQgPSBtYXRjaGVzLm1hcCgobWF0Y2gpID0+ICh7XG5cdFx0XHQuLi5tYXRjaCxcblx0XHRcdF9mbGlnaHQ6IHZvaWQgMFxuXHRcdH0pKTtcblx0XHRvZmZlcmVkW2luZGV4XS5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0XHRjb25zdCBhY2sgPSBzZXNzaW9uWzRdID0gcm91dGVyLnN0YXJ0VHJhbnNpdGlvbigoKSA9PiByb3V0ZXIuc3RvcmVzLnNldE1hdGNoZXMob2ZmZXJlZCksIG9mZmVyZWQpLnRoZW4oKHJlbmRlcmVkKSA9PiB7XG5cdFx0XHRpZiAocmVuZGVyZWQgJiYgcm91dGVyLl9wZW5kaW5nID09PSBzZXNzaW9uICYmIHNlc3Npb25bNF0gPT09IGFjayAmJiAhc2Vzc2lvblsyXSkgc2Vzc2lvblsyXSA9IERhdGUubm93KCkgKyBtaW47XG5cdFx0XHRyZXR1cm4gcmVuZGVyZWQ7XG5cdFx0fSk7XG5cdFx0cmV0dXJuO1xuXHR9XG59XG4vKipcbiogQ2FuY2VscyBwZW5kaW5nIFVJIHRpbWluZyB1bmxlc3MgdGhlIGN1cnJlbnQgc3VjY2Vzc29yIGNhbiB0YWtlIG92ZXIgdGhlXG4qIHNhbWUgYm91bmRhcnkgdGhhdCByZW1haW5zIHBhaW50ZWQuXG4qL1xuZnVuY3Rpb24gZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KSB7XG5cdGNvbnN0IHNlc3Npb24gPSByb3V0ZXIuX3BlbmRpbmc7XG5cdGlmIChyb3V0ZXIuX3R4ID09PSB0eCB8fCAhcm91dGVyLl90eD8uWzNdLnNvbWUoKG1hdGNoKSA9PiBtYXRjaC5pZCA9PT0gc2Vzc2lvbj8uWzFdKSkge1xuXHRcdGNsZWFyVGltZW91dChzZXNzaW9uPy5bM10pO1xuXHRcdHJvdXRlci5fcGVuZGluZyA9IHZvaWQgMDtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gYXdhaXRQZW5kaW5nTWluaW11bShyb3V0ZXIsIHR4KSB7XG5cdGNvbnN0IHNlc3Npb24gPSByb3V0ZXIuX3BlbmRpbmc7XG5cdGlmICghc2Vzc2lvbikgcmV0dXJuO1xuXHRjbGVhclRpbWVvdXQoc2Vzc2lvblszXSk7XG5cdGNvbnN0IHJlbWFpbmluZyA9IHNlc3Npb25bMl0gLSBEYXRlLm5vdygpO1xuXHRpZiAoIXNlc3Npb25bNF0gfHwgcmVtYWluaW5nIDw9IDAgfHwgIV9nZXRSZW5kZXJlZE1hdGNoZXModHhbM10pLnNvbWUoKG1hdGNoKSA9PiBtYXRjaC5pZCA9PT0gc2Vzc2lvblsxXSkpIHJldHVybjtcblx0bGV0IHRpbWVyO1xuXHR0cnkge1xuXHRcdGF3YWl0IHdhaXRGb3IobmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdHRpbWVyID0gc2V0VGltZW91dChyZXNvbHZlLCByZW1haW5pbmcpO1xuXHRcdH0pLCB0eFswXS5zaWduYWwpO1xuXHR9IGNhdGNoIHt9XG5cdGNsZWFyVGltZW91dCh0aW1lcik7XG59XG5mdW5jdGlvbiBwdWJsaXNoTWF0Y2hlcyhyb3V0ZXIsIG1hdGNoZXMpIHtcblx0cm91dGVyLl9jb21taXR0ZWQgPSBtYXRjaGVzO1xuXHRyb3V0ZXIuc3RvcmVzLnNldE1hdGNoZXMobWF0Y2hlcyk7XG59XG5mdW5jdGlvbiBjb21taXRNYXRjaGVzKHJvdXRlciwgdHgsIG1hdGNoZXMsIHJlc29sdmVkUHJlZml4KSB7XG5cdGNvbnN0IHByZXZpb3VzID0gcm91dGVyLl9jb21taXR0ZWQ7XG5cdGNvbnN0IHByZXZpb3VzRW5kID0gcm91dGVyLl9saWZlY3ljbGVFbmQ7XG5cdGNvbnN0IHByZXZpb3VzQ2FjaGVkID0gcm91dGVyLl9jYWNoZTtcblx0Zm9yIChjb25zdCBtYXRjaCBvZiBtYXRjaGVzKSB7XG5cdFx0bWF0Y2gucHJlbG9hZCA9IGZhbHNlO1xuXHRcdGlmIChyZXNvbHZlZFByZWZpeCkgbWF0Y2guX2Fzc2V0RW5kID0gdm9pZCAwO1xuXHR9XG5cdGNvbnN0IGN1dCA9IF9nZXRSZW5kZXJlZE1hdGNoZXMobWF0Y2hlcykubGVuZ3RoO1xuXHRjb25zdCBjYWNoZWQgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiIHx8ICF0eFs2XSkge1xuXHRcdGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG5cdFx0Y29uc3Qgc3VwZXJzZWRlZCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IG1hdGNoZXMubGVuZ3RoOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdFx0aWYgKGluZGV4IDwgY3V0IHx8IG1hdGNoLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIpIHN1cGVyc2VkZWQuYWRkKG1hdGNoLmlkKTtcblx0XHR9XG5cdFx0Zm9yIChjb25zdCBtYXRjaCBvZiBbLi4ucHJldmlvdXMsIC4uLnByZXZpb3VzQ2FjaGVkLnZhbHVlcygpXSkge1xuXHRcdFx0aWYgKG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgc3VwZXJzZWRlZC5oYXMobWF0Y2guaWQpKSBjb250aW51ZTtcblx0XHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRpZiAoIXJvdXRlLm9wdGlvbnMubG9hZGVyIHx8IG5vdyAtIG1hdGNoLnVwZGF0ZWRBdCA+PSAobWF0Y2gucHJlbG9hZCA/IHJvdXRlLm9wdGlvbnMucHJlbG9hZEdjVGltZSA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UHJlbG9hZEdjVGltZSA/PyAzZTUgOiByb3V0ZS5vcHRpb25zLmdjVGltZSA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0R2NUaW1lID8/IDNlNSkpIGNvbnRpbnVlO1xuXHRcdFx0Y2FjaGVkLnNldChtYXRjaC5pZCwgcHJldmlvdXNDYWNoZWQuZ2V0KG1hdGNoLmlkKSA9PT0gbWF0Y2ggPyBtYXRjaCA6IHtcblx0XHRcdFx0Li4ubWF0Y2gsXG5cdFx0XHRcdF9mbGlnaHQ6IHZvaWQgMCxcblx0XHRcdFx0aXNGZXRjaGluZzogZmFsc2UsXG5cdFx0XHRcdGNvbnRleHQ6IHt9XG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0dHhbM10gPSBbXTtcblx0cm91dGVyLl9jYWNoZSA9IGNhY2hlZDtcblx0Y29uc3QgbmV4dEVuZCA9IHJvdXRlci5fbGlmZWN5Y2xlRW5kID0gbGlmZWN5Y2xlRW5kKG1hdGNoZXMpO1xuXHRwdWJsaXNoTWF0Y2hlcyhyb3V0ZXIsIG1hdGNoZXMpO1xuXHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgWy4uLnByZXZpb3VzQ2FjaGVkLnZhbHVlcygpLCAuLi5wcmV2aW91c10uZmlsdGVyKChtYXRjaCkgPT4gbWF0Y2guX2ZsaWdodCAmJiBjYWNoZWQuZ2V0KG1hdGNoLmlkKSAhPT0gbWF0Y2gpLCBtYXRjaGVzKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdGNvbnN0IGhhbmRvZmYgPSB0eFs2XT8uWzBdO1xuXHRcdGlmIChoYW5kb2ZmICYmIHJvdXRlci5faGFuZG9mZiA9PT0gaGFuZG9mZikgaGFuZG9mZlsxXSgpO1xuXHR9XG5cdHJ1blJvdXRlTGlmZWN5Y2xlKHJvdXRlciwgcHJldmlvdXMsIG1hdGNoZXMsIHByZXZpb3VzRW5kLCBuZXh0RW5kLCB0eCk7XG59XG4vKipcbiogUmVzb2x2ZSBvbmNlIHRoZSByb3V0ZXIgaGFzIHNldHRsZWQgb24gYSB0cmFuc2FjdGlvbiBvdGhlciB0aGFuIGBvd25lcmAuXG4qIEVhY2ggdHJhbnNhY3Rpb24ncyBjb21wbGV0aW9uIGZvbGxvd3MgaXRzIGN1cnJlbnQgc3VjY2Vzc29yLCBzbyBhbGwgd2FpdGVyc1xuKiBzaGFyZSB0aGUgc2FtZSBjaGFpbiBpbnN0ZWFkIG9mIHBvbGxpbmcgZXZlcnkgc3VjY2Vzc29yIGluZGVwZW5kZW50bHkuXG4qL1xuYXN5bmMgZnVuY3Rpb24gYXdhaXRDdXJyZW50KHJvdXRlciwgb3duZXIpIHtcblx0bGV0IGN1cnJlbnQgPSByb3V0ZXIuX3R4O1xuXHR3aGlsZSAoY3VycmVudCAmJiBjdXJyZW50ICE9PSBvd25lcikge1xuXHRcdG93bmVyID0gY3VycmVudDtcblx0XHRhd2FpdCBjdXJyZW50WzVdO1xuXHRcdGN1cnJlbnQgPSByb3V0ZXIuX3R4O1xuXHR9XG59XG5mdW5jdGlvbiBmb2xsb3dSZWRpcmVjdChyb3V0ZXIsIHR4LCBvdXRjb21lKSB7XG5cdGNvbnN0IG9wdGlvbnMgPSBvdXRjb21lWzFdLm9wdGlvbnM7XG5cdGNvbnN0IGxvY2F0aW9uID0gb3V0Y29tZVsyXTtcblx0aWYgKCFsb2NhdGlvbikgcmV0dXJuIHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRyZXBsYWNlOiB0cnVlLFxuXHRcdGlnbm9yZUJsb2NrZXI6IHRydWVcblx0fSk7XG5cdGlmIChvcHRpb25zLnJlbG9hZERvY3VtZW50KSByZXR1cm4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRocmVmOiAobG9jYXRpb24ubWFza2VkTG9jYXRpb24gPz8gbG9jYXRpb24pLnB1YmxpY0hyZWYsXG5cdFx0cmVsb2FkRG9jdW1lbnQ6IHRydWUsXG5cdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRpZ25vcmVCbG9ja2VyOiB0cnVlXG5cdH0pO1xuXHRsb2NhdGlvbi5fcmVkaXJlY3RzID0gdHhbMV0gKyAxO1xuXHRyb3V0ZXIuX3BlbmRpbmdMb2NhdGlvbiA9IGxvY2F0aW9uO1xuXHRjb25zdCBjb21taXR0ZWQgPSByb3V0ZXIuY29tbWl0TG9jYXRpb24oe1xuXHRcdC4uLmxvY2F0aW9uLFxuXHRcdHZpZXdUcmFuc2l0aW9uOiBvcHRpb25zLnZpZXdUcmFuc2l0aW9uLFxuXHRcdHJlcGxhY2U6IHRydWUsXG5cdFx0cmVzZXRTY3JvbGw6IG9wdGlvbnMucmVzZXRTY3JvbGwsXG5cdFx0aGFzaFNjcm9sbEludG9WaWV3OiBvcHRpb25zLmhhc2hTY3JvbGxJbnRvVmlldyxcblx0XHRpZ25vcmVCbG9ja2VyOiB0cnVlXG5cdH0pO1xuXHRxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG5cdFx0aWYgKHJvdXRlci5fcGVuZGluZ0xvY2F0aW9uID09PSBsb2NhdGlvbikgcm91dGVyLl9wZW5kaW5nTG9jYXRpb24gPSB2b2lkIDA7XG5cdH0pO1xuXHRyZXR1cm4gY29tbWl0dGVkO1xufVxuYXN5bmMgZnVuY3Rpb24gcnVuQmFja2dyb3VuZChyb3V0ZXIsIHR4LCBiYXNlLCB0YXNrcywgc2V0dGxlbWVudCkge1xuXHRjb25zdCBuZXh0ID0gYmFzZS5tYXAoKG1hdGNoKSA9PiAoeyAuLi5tYXRjaCB9KSk7XG5cdGFjcXVpcmVNYXRjaFJlc291cmNlcyhuZXh0KTtcblx0Zm9yIChjb25zdCB0YXNrIG9mIHRhc2tzKSB7XG5cdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG5leHRbdGFza1swXV0pO1xuXHRcdG5leHRbdGFza1swXV0gPSB0YXNrWzNdO1xuXHR9XG5cdGNvbnN0IGxhbmUgPSBbdHhbMl0sIG5leHRdO1xuXHRsZXQgcmVkdWNlZDtcblx0dHJ5IHtcblx0XHRyZWR1Y2VkID0gYXdhaXQgcmVkdWNlTGFuZShyb3V0ZXIsIGxhbmUsIHRhc2tzLCB0eFswXSwgc2V0dGxlbWVudCk7XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG5leHQpO1xuXHRcdHRocm93IGNhdXNlO1xuXHR9XG5cdGlmIChpc0NvbnRyb2wocmVkdWNlZCkpIHtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbmV4dCk7XG5cdFx0aWYgKHJlZHVjZWRbMF0gPT09IFJFRElSRUNURUQgJiYgcm91dGVyLl90eCA9PT0gdHggJiYgcm91dGVyLl9jb21taXR0ZWQgPT09IGJhc2UpIGF3YWl0IGZvbGxvd1JlZGlyZWN0KHJvdXRlciwgdHgsIHJlZHVjZWQpO1xuXHRcdHJldHVybjtcblx0fVxuXHRhd2FpdCBwcm9qZWN0TGFuZShyb3V0ZXIsIHJlZHVjZWQsIHR4WzBdLnNpZ25hbCk7XG5cdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCB8fCByb3V0ZXIuX2NvbW1pdHRlZCAhPT0gYmFzZSkge1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBuZXh0KTtcblx0XHRyZXR1cm47XG5cdH1cblx0Zm9yIChjb25zdCBtYXRjaCBvZiBuZXh0KSB7XG5cdFx0Y29uc3QgY2FjaGVkID0gcm91dGVyLl9jYWNoZS5nZXQobWF0Y2guaWQpO1xuXHRcdGlmIChjYWNoZWQ/Ll9mbGlnaHQgJiYgY2FjaGVkLl9mbGlnaHQgPT09IG1hdGNoLl9mbGlnaHQpIHtcblx0XHRcdHJvdXRlci5fY2FjaGUuZGVsZXRlKG1hdGNoLmlkKTtcblx0XHRcdHJlbGVhc2VGbGlnaHQocm91dGVyLCBjYWNoZWQpO1xuXHRcdH1cblx0fVxuXHRwdWJsaXNoTWF0Y2hlcyhyb3V0ZXIsIG5leHQpO1xuXHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgYmFzZSwgbmV4dCk7XG59XG5hc3luYyBmdW5jdGlvbiBydW5DbGllbnRUcmFuc2FjdGlvbihyb3V0ZXIsIHR4LCBmb3JjZVN0YWxlUmVsb2FkLCBvblJlYWR5LCBzeW5jLCByZXNvbHZlZFByZWZpeCkge1xuXHRjb25zdCByZXN1bHQgPSBhd2FpdCBleGVjdXRlQ2xpZW50TGFuZShyb3V0ZXIsIHR4WzJdLCB0eFszXSwgW1xuXHRcdHR4WzBdLFxuXHRcdHR4WzFdLFxuXHRcdHJvdXRlci5fY29tbWl0dGVkLFxuXHRcdHZvaWQgMCxcblx0XHRzeW5jLFxuXHRcdGZvcmNlU3RhbGVSZWxvYWQsXG5cdFx0cmVzb2x2ZWRQcmVmaXgsXG5cdFx0b25SZWFkeVxuXHRdKTtcblx0aWYgKGlzQ29udHJvbChyZXN1bHQpKSB7XG5cdFx0Y29uc3QgZm9sbG93ID0gcmVzdWx0WzBdID09PSBSRURJUkVDVEVEICYmIHJvdXRlci5fdHggPT09IHR4O1xuXHRcdGlmICghZm9sbG93IHx8IHJlc3VsdFsxXS5vcHRpb25zLnJlbG9hZERvY3VtZW50KSBmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpO1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCB0eFszXSk7XG5cdFx0dHhbM10gPSBbXTtcblx0XHRpZiAoIWZvbGxvdykgcmV0dXJuO1xuXHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuXHRcdFx0ZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiB0eFs2XSkgcm91dGVyLl9yZWZyZXNoTmV4dExvYWQgPSB0cnVlO1xuXHRcdGF3YWl0IGZvbGxvd1JlZGlyZWN0KHJvdXRlciwgdHgsIHJlc3VsdCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IG1hdGNoZXMgPSByZXN1bHRbMV07XG5cdGlmIChyb3V0ZXIuX3R4ID09PSB0eCkgYXdhaXQgYXdhaXRQZW5kaW5nTWluaW11bShyb3V0ZXIsIHR4KTtcblx0aWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG5cdFx0ZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KTtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcyk7XG5cdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCByZXN1bHQpO1xuXHRcdHJldHVybjtcblx0fVxuXHRjb25zdCB0b0xvY2F0aW9uID0gdHhbMl07XG5cdGNvbnN0IGNoYW5nZUluZm8gPSBnZXRMb2NhdGlvbkNoYW5nZUluZm8odG9Mb2NhdGlvbiwgcm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLmdldCgpKTtcblx0Y29uc3QgYmFja2dyb3VuZCA9IHJlc3VsdFsyXTtcblx0YXdhaXQgcm91dGVyLnN0YXJ0Vmlld1RyYW5zaXRpb24oYXN5bmMgKCkgPT4ge1xuXHRcdGlmIChyb3V0ZXIuX3R4ID09PSB0eCkgYXdhaXQgYXdhaXRQZW5kaW5nTWluaW11bShyb3V0ZXIsIHR4KTtcblx0XHRpZiAocm91dGVyLl90eCAhPT0gdHgpIHtcblx0XHRcdGZpbmlzaFBlbmRpbmcocm91dGVyLCB0eCk7XG5cdFx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcyk7XG5cdFx0XHRkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIHJlc3VsdCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGNvbnN0IGNvbW1pdCA9ICgpID0+IHtcblx0XHRcdGZpbmlzaFBlbmRpbmcocm91dGVyLCB0eCk7XG5cdFx0XHRjb21taXRNYXRjaGVzKHJvdXRlciwgdHgsIG1hdGNoZXMsIHJlc29sdmVkUHJlZml4KTtcblx0XHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkgcmV0dXJuO1xuXHRcdFx0cm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uTG9hZFwiLFxuXHRcdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0XHR9KTtcblx0XHRcdGlmIChyb3V0ZXIuX3R4ID09PSB0eCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uQmVmb3JlUm91dGVNb3VudFwiLFxuXHRcdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdGNvbnN0IHJlbmRlcmVkID0gYXdhaXQgcm91dGVyLnN0YXJ0VHJhbnNpdGlvbihjb21taXQsIG1hdGNoZXMpO1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgdHhbNl0pIHR4WzZdID0gdm9pZCAwO1xuXHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuXHRcdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCByZXN1bHQpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoYmFja2dyb3VuZD8ubGVuZ3RoKSBydW5CYWNrZ3JvdW5kKHJvdXRlciwgdHgsIG1hdGNoZXMsIGJhY2tncm91bmQsIHJlc3VsdFszXSkuY2F0Y2goY29uc29sZS5lcnJvcik7XG5cdFx0cm91dGVyLmJhdGNoKCgpID0+IHtcblx0XHRcdHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5zZXQodG9Mb2NhdGlvbik7XG5cdFx0XHRyb3V0ZXIuc3RvcmVzLnN0YXR1cy5zZXQoXCJpZGxlXCIpO1xuXHRcdFx0aWYgKHJvdXRlci5fdHggPT09IHR4KSByb3V0ZXIuZW1pdCh7XG5cdFx0XHRcdHR5cGU6IFwib25SZXNvbHZlZFwiLFxuXHRcdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0XHR9KTtcblx0XHRcdGlmIChyZW5kZXJlZCAmJiByb3V0ZXIuX3R4ID09PSB0eCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uUmVuZGVyZWRcIixcblx0XHRcdFx0Li4uY2hhbmdlSW5mb1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0aWYgKHJvdXRlci5fdHggIT09IHR4KSByZXR1cm47XG5cdFx0cm91dGVyLl9jb21taXRQcm9taXNlPy5yZXNvbHZlKCk7XG5cdFx0cm91dGVyLl9jb21taXRQcm9taXNlID0gdm9pZCAwO1xuXHR9KTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGxvYWRDbGllbnRSb3V0ZShyb3V0ZXIsIG9wdHMpIHtcblx0bGV0IHJlbWF0ZXJpYWxpemUgPSBmYWxzZTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgcmVtYXRlcmlhbGl6ZSA9ICEhcm91dGVyLl9yZWZyZXNoTmV4dExvYWQgfHwgISFyb3V0ZXIuX3R4Py5bNl07XG5cdGNvbnN0IHByZXZpb3VzT3duZXIgPSByb3V0ZXIuX3R4O1xuXHRjb25zdCByZXNvbHZlZExvY2F0aW9uID0gcm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLmdldCgpO1xuXHRjb25zdCBwcmV2aW91c0xvY2F0aW9uID0gcmVzb2x2ZWRMb2NhdGlvbiA/PyByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpO1xuXHRjb25zdCBsb2NhdGlvbiA9IHJvdXRlci5sYXRlc3RMb2NhdGlvbjtcblx0Y29uc3QgcGVuZGluZ0xvY2F0aW9uID0gcm91dGVyLl9wZW5kaW5nTG9jYXRpb247XG5cdGNvbnN0IHJlZGlyZWN0cyA9IHBlbmRpbmdMb2NhdGlvbj8uaHJlZiA9PT0gbG9jYXRpb24uaHJlZiA/IHBlbmRpbmdMb2NhdGlvbi5fcmVkaXJlY3RzID8/IDAgOiAwO1xuXHRjb25zdCBoYW5kb2ZmID0gcm91dGVyLl9oYW5kb2ZmO1xuXHRjb25zdCBoeWRyYXRpb25Db250cm9sbGVyID0gcmVtYXRlcmlhbGl6ZSA/IHZvaWQgMCA6IGhhbmRvZmY/LlswXSgpO1xuXHRjb25zdCBwcmVmbGlnaHQgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdGNvbnN0IHByZXZpb3VzUHJlZmxpZ2h0ID0gcm91dGVyLl9wcmVmbGlnaHQ7XG5cdHJvdXRlci5fcHJlZmxpZ2h0ID0gcHJlZmxpZ2h0O1xuXHRpZiAoIXJlbWF0ZXJpYWxpemUgJiYgIWh5ZHJhdGlvbkNvbnRyb2xsZXIpIGhhbmRvZmY/LlsxXSgpO1xuXHRwcmV2aW91c1ByZWZsaWdodD8uYWJvcnQoKTtcblx0aWYgKCFwcmVmbGlnaHQuc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRjb25zdCBjaGFuZ2VJbmZvID0gZ2V0TG9jYXRpb25DaGFuZ2VJbmZvKGxvY2F0aW9uLCByZXNvbHZlZExvY2F0aW9uKTtcblx0XHRyb3V0ZXIuZW1pdCh7XG5cdFx0XHR0eXBlOiBcIm9uQmVmb3JlTmF2aWdhdGVcIixcblx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHR9KTtcblx0XHRpZiAoIXByZWZsaWdodC5zaWduYWwuYWJvcnRlZCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0dHlwZTogXCJvbkJlZm9yZUxvYWRcIixcblx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHR9KTtcblx0fVxuXHRpZiAocHJlZmxpZ2h0LnNpZ25hbC5hYm9ydGVkKSB7XG5cdFx0YXdhaXQgYXdhaXRDdXJyZW50KHJvdXRlciwgcHJldmlvdXNPd25lcik7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IHNhbWVIcmVmID0gcHJldmlvdXNMb2NhdGlvbi5ocmVmID09PSBsb2NhdGlvbi5ocmVmO1xuXHRsZXQgY29udHJvbGxlciA9IHByZWZsaWdodDtcblx0Y29uc3QgbWF0Y2hlcyA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiByZW1hdGVyaWFsaXplID8gcm91dGVyLm1hdGNoUm91dGVzKGxvY2F0aW9uLCB7XG5cdFx0X2NvbnRyb2xsZXI6IHByZWZsaWdodCxcblx0XHRfcmVtYXRlcmlhbGl6ZTogdHJ1ZVxuXHR9KSA6IHJvdXRlci5tYXRjaFJvdXRlcyhsb2NhdGlvbiwgeyBfY29udHJvbGxlcjogcHJlZmxpZ2h0IH0pO1xuXHRhY3F1aXJlTWF0Y2hSZXNvdXJjZXMobWF0Y2hlcyk7XG5cdGNvbnN0IHJlc29sdmVkUHJlZml4ID0gaHlkcmF0aW9uQ29udHJvbGxlciA/IGhhbmRvZmZbMV0obWF0Y2hlcykgOiB2b2lkIDA7XG5cdGlmIChyZXNvbHZlZFByZWZpeCkgY29udHJvbGxlciA9IGh5ZHJhdGlvbkNvbnRyb2xsZXI7XG5cdGVsc2UgaHlkcmF0aW9uQ29udHJvbGxlcj8uYWJvcnQoKTtcblx0aWYgKHByZWZsaWdodC5zaWduYWwuYWJvcnRlZCkge1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKTtcblx0XHRhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCBwcmV2aW91c093bmVyKTtcblx0XHRyZXR1cm47XG5cdH1cblx0cm91dGVyLl9wcmVmbGlnaHQgPSB2b2lkIDA7XG5cdGxldCBzZXR0bGU7XG5cdGNvbnN0IHJ1biA9ICgpID0+IHJ1bkNsaWVudFRyYW5zYWN0aW9uKHJvdXRlciwgdHgsIHNhbWVIcmVmLCAoKSA9PiBvZmZlclBlbmRpbmcocm91dGVyLCB0eCksIG9wdHM/LnN5bmMsIHJlc29sdmVkUHJlZml4KTtcblx0Y29uc3QgZG9uZSA9IG9wdHM/LnN5bmMgPyBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0dGxlID0gcmVzb2x2ZSkgOiBQcm9taXNlLnJlc29sdmUoKS50aGVuKHJ1bik7XG5cdGNvbnN0IHR4ID0gW1xuXHRcdGNvbnRyb2xsZXIsXG5cdFx0cmVkaXJlY3RzLFxuXHRcdGxvY2F0aW9uLFxuXHRcdG1hdGNoZXMsXG5cdFx0RGF0ZS5ub3coKSxcblx0XHRkb25lLnRoZW4oKCkgPT4gYXdhaXRDdXJyZW50KHJvdXRlciwgdHgpKVxuXHRdO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHJlbWF0ZXJpYWxpemUpIHtcblx0XHR0eFs2XSA9IFtoYW5kb2ZmXTtcblx0XHRyb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCA9IHZvaWQgMDtcblx0fVxuXHRyb3V0ZXIuX3R4ID0gdHg7XG5cdGlmIChwcmV2aW91c093bmVyKSB7XG5cdFx0Zm9yIChjb25zdCBtYXRjaCBvZiByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCkpIHtcblx0XHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkgYnJlYWs7XG5cdFx0XHRpZiAobWF0Y2guaXNGZXRjaGluZykgc2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgZmFsc2UpO1xuXHRcdH1cblx0XHRwcmV2aW91c093bmVyWzBdLmFib3J0KCk7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIHByZXZpb3VzT3duZXJbM10sIHR4WzNdLCB0cnVlKTtcblx0fVxuXHRpZiAocm91dGVyLl90eCAhPT0gdHgpIHtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgdHhbM10pO1xuXHRcdHR4WzNdID0gW107XG5cdFx0c2V0dGxlPy4oKTtcblx0XHRhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCB0eCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJvdXRlci5iYXRjaCgoKSA9PiB7XG5cdFx0cm91dGVyLnN0b3Jlcy5zdGF0dXMuc2V0KFwicGVuZGluZ1wiKTtcblx0XHRyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLnNldChsb2NhdGlvbik7XG5cdH0pO1xuXHRpZiAocmVzb2x2ZWRQcmVmaXggfHwgIXJvdXRlci5fY29tbWl0dGVkLmxlbmd0aCAmJiBtYXRjaGVzWzBdPy5zdGF0dXMgIT09IFwic3VjY2Vzc1wiICYmICFtYXRjaGVzLnNvbWUoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpKSBvZmZlclBlbmRpbmcocm91dGVyLCB0eCk7XG5cdHNldHRsZT8uKHJ1bigpKTtcblx0YXdhaXQgdHhbNV07XG59XG5hc3luYyBmdW5jdGlvbiByZWZyZXNoQ2xpZW50Um91dGUocm91dGVyKSB7XG5cdGNvbnN0IHBlbmRpbmcgPSByb3V0ZXIuX3R4O1xuXHRpZiAocGVuZGluZyAmJiAhcGVuZGluZ1s2XSAmJiByb3V0ZXIuc3RvcmVzLnN0YXR1cy5nZXQoKSA9PT0gXCJwZW5kaW5nXCIpIHtcblx0XHRhd2FpdCBwZW5kaW5nWzVdO1xuXHRcdGlmIChyb3V0ZXIuX3R4ICE9PSBwZW5kaW5nKSBhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCBwZW5kaW5nKTtcblx0fVxuXHRyb3V0ZXIuX2ZsaWdodHM/LmNsZWFyKCk7XG5cdHJvdXRlci5jbGVhckNhY2hlKCk7XG5cdHJvdXRlci5fcmVmcmVzaE5leHRMb2FkID0gdHJ1ZTtcblx0YXdhaXQgbG9hZENsaWVudFJvdXRlKHJvdXRlciwgeyBzeW5jOiB0cnVlIH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gcHJlbG9hZENsaWVudFJvdXRlKHJvdXRlciwgb3B0cykge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIChyb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCB8fCByb3V0ZXIuX3R4Py5bNl0pKSByZXR1cm47XG5cdGxldCBsb2NhdGlvbiA9IHJvdXRlci5idWlsZExvY2F0aW9uKG9wdHMpO1xuXHRmb3IgKGxldCByZWRpcmVjdHMgPSAwOzsgcmVkaXJlY3RzKyspIHtcblx0XHRjb25zdCBiYXNlID0gcm91dGVyLl9jb21taXR0ZWQ7XG5cdFx0Y29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRsZXQgbWF0Y2hlcztcblx0XHRsZXQgYWN0aXZlO1xuXHRcdGxldCByZXN1bHQ7XG5cdFx0dHJ5IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdG1hdGNoZXMgPSByb3V0ZXIubWF0Y2hSb3V0ZXMobG9jYXRpb24sIHsgX2NvbnRyb2xsZXI6IGNvbnRyb2xsZXIgfSk7XG5cdFx0XHRcdGFjcXVpcmVNYXRjaFJlc291cmNlcyhtYXRjaGVzKTtcblx0XHRcdFx0YWN0aXZlID0gKHJvdXRlci5fcHJlbG9hZHMgPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpLnNldChjb250cm9sbGVyLCBtYXRjaGVzKTtcblx0XHRcdFx0cmVzdWx0ID0gYXdhaXQgZXhlY3V0ZUNsaWVudExhbmUocm91dGVyLCBsb2NhdGlvbiwgbWF0Y2hlcywgW1xuXHRcdFx0XHRcdGNvbnRyb2xsZXIsXG5cdFx0XHRcdFx0cmVkaXJlY3RzLFxuXHRcdFx0XHRcdGJhc2UsXG5cdFx0XHRcdFx0dHJ1ZVxuXHRcdFx0XHRdKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdGlmIChhY3RpdmUpIHtcblx0XHRcdFx0XHRhY3RpdmUgPSBhY3RpdmUuZGVsZXRlKGNvbnRyb2xsZXIpO1xuXHRcdFx0XHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIWlzQ29udHJvbChyZXN1bHQpKSByZXR1cm4gcmVzdWx0WzFdO1xuXHRcdFx0aWYgKCFhY3RpdmUgfHwgcmVzdWx0Lmxlbmd0aCA8IDMgfHwgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIChyb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCB8fCByb3V0ZXIuX3R4Py5bNl0pKSByZXR1cm47XG5cdFx0XHRsb2NhdGlvbiA9IHJlc3VsdFsyXTtcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0aWYgKCFpc05vdEZvdW5kKGNhdXNlKSkgY29uc29sZS5lcnJvcihjYXVzZSk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHR9XG59XG5hc3luYyBmdW5jdGlvbiBoeWRyYXRlKHJvdXRlcikge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICF3aW5kb3cuJF9UU1IpIHRocm93IG5ldyBFcnJvcihcIkludmFyaWFudCBmYWlsZWQ6IEV4cGVjdGVkIHRvIGZpbmQgYm9vdHN0cmFwIGRhdGEgb24gd2luZG93LiRfVFNSLCBidXQgd2UgZGlkIG5vdC4gUGxlYXNlIGZpbGUgYW4gaXNzdWUhXCIpO1xuXHRjb25zdCB0c3IgPSB3aW5kb3cuJF9UU1I7XG5cdGNvbnN0IGFkYXB0ZXJzID0gcm91dGVyLm9wdGlvbnMuc2VyaWFsaXphdGlvbkFkYXB0ZXJzO1xuXHRpZiAoYWRhcHRlcnM/Lmxlbmd0aCkge1xuXHRcdHRzci50ID0gbmV3IE1hcChhZGFwdGVycy5tYXAoKGFkYXB0ZXIpID0+IFthZGFwdGVyLmtleSwgYWRhcHRlci5mcm9tU2VyaWFsaXphYmxlXSkpO1xuXHRcdHRzci5idWZmZXIuZm9yRWFjaCgoc2NyaXB0KSA9PiBzY3JpcHQoKSk7XG5cdH1cblx0dHNyLmluaXRpYWxpemVkID0gdHJ1ZTtcblx0Y29uc3QgZGVoeWRyYXRlZFJvdXRlciA9IHRzci5yb3V0ZXI7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIWRlaHlkcmF0ZWRSb3V0ZXIpIHRocm93IG5ldyBFcnJvcihcIkludmFyaWFudCBmYWlsZWQ6IEV4cGVjdGVkIHRvIGZpbmQgYSBkZWh5ZHJhdGVkIGRhdGEgb24gd2luZG93LiRfVFNSLnJvdXRlciwgYnV0IHdlIGRpZCBub3QuIFBsZWFzZSBmaWxlIGFuIGlzc3VlIVwiKTtcblx0cm91dGVyLnNzciA9IHsgbWFuaWZlc3Q6IGRlaHlkcmF0ZWRSb3V0ZXIubWFuaWZlc3QgfTtcblx0cm91dGVyLm9wdGlvbnMuc3NyID0geyBub25jZTogZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcIm1ldGFbcHJvcGVydHk9XFxcImNzcC1ub25jZVxcXCJdXCIpPy5jb250ZW50IH07XG5cdGNvbnN0IGRlaHlkcmF0ZWRNYXRjaGVzID0gZGVoeWRyYXRlZFJvdXRlci5tYXRjaGVzO1xuXHRjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRjb25zdCBwcmV2aW91c1ByZWZsaWdodCA9IHJvdXRlci5fcHJlZmxpZ2h0O1xuXHRyb3V0ZXIuX3ByZWZsaWdodCA9IGNvbnRyb2xsZXI7XG5cdHByZXZpb3VzUHJlZmxpZ2h0Py5hYm9ydCgpO1xuXHRjb25zdCBpc0N1cnJlbnQgPSAoKSA9PiByb3V0ZXIuX3ByZWZsaWdodCA9PT0gY29udHJvbGxlcjtcblx0bGV0IGxvY2F0aW9uO1xuXHRsZXQgY2FuZGlkYXRlcztcblx0bGV0IGhhbmRvZmZIaXN0b3J5SHJlZjtcblx0bGV0IGhhbmRvZmZIaXN0b3J5U3RhdGU7XG5cdHRyeSB7XG5cdFx0YXdhaXQgd2FpdEZvcihyb3V0ZXIub3B0aW9ucy5oeWRyYXRlPy4oZGVoeWRyYXRlZFJvdXRlci5kZWh5ZHJhdGVkRGF0YSksIGNvbnRyb2xsZXIuc2lnbmFsKTtcblx0XHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdFx0Y29uc3QgaGlzdG9yeUxvY2F0aW9uID0gcm91dGVyLmhpc3RvcnkubG9jYXRpb247XG5cdFx0aGFuZG9mZkhpc3RvcnlIcmVmID0gaGlzdG9yeUxvY2F0aW9uLmhyZWY7XG5cdFx0aGFuZG9mZkhpc3RvcnlTdGF0ZSA9IGhpc3RvcnlMb2NhdGlvbi5zdGF0ZTtcblx0XHRyb3V0ZXIudXBkYXRlTGF0ZXN0TG9jYXRpb24oKTtcblx0XHRsb2NhdGlvbiA9IHJvdXRlci5sYXRlc3RMb2NhdGlvbjtcblx0XHRyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLnNldChsb2NhdGlvbik7XG5cdFx0Y2FuZGlkYXRlcyA9IHJvdXRlci5tYXRjaFJvdXRlcyhsb2NhdGlvbiwgeyBfY29udHJvbGxlcjogY29udHJvbGxlciB9KTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRpZiAoaXNDdXJyZW50KCkpIHJvdXRlci5fcHJlZmxpZ2h0ID0gdm9pZCAwO1xuXHRcdGNvbnRyb2xsZXIuYWJvcnQoY2F1c2UpO1xuXHRcdGlmIChjYXVzZSAhPT0gY29udHJvbGxlci5zaWduYWwpIHRocm93IGNhdXNlO1xuXHR9XG5cdGlmICghaXNDdXJyZW50KCkpIHJldHVybjtcblx0Y29uc3QgY29tbWl0dGVkID0gW107XG5cdGxldCBwZW5kaW5nQm91bmRhcnk7XG5cdGxldCB2ZXJpZmllZEFzc2V0RW5kID0gMDtcblx0Y29uc3QgcmV0cnlGcm9tID0gKGluZGV4KSA9PiB7XG5cdFx0dmVyaWZpZWRBc3NldEVuZCA9IE1hdGgubWluKHZlcmlmaWVkQXNzZXRFbmQsIGluZGV4ICsgMSk7XG5cdFx0Y29uc3QgcmVtb3ZlZCA9IGNvbW1pdHRlZC5zcGxpY2UoaW5kZXgpO1xuXHRcdGZvciAoY29uc3QgbWF0Y2ggb2YgcmVtb3ZlZCkgaWYgKGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpLm9wdGlvbnMubG9hZGVyICYmIChtYXRjaC5zdGF0dXMgPT09IFwic3VjY2Vzc1wiIHx8ICFtYXRjaC5pbnZhbGlkICYmIFwibG9hZGVyRGF0YVwiIGluIG1hdGNoKSkgY2FjaGVMb2FkZXJNYXRjaChyb3V0ZXIsIHtcblx0XHRcdC4uLm1hdGNoLFxuXHRcdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHRcdGVycm9yOiB2b2lkIDAsXG5cdFx0XHRwcmVsb2FkOiB0cnVlXG5cdFx0fSwgcm91dGVyLl9jYWNoZS5nZXQobWF0Y2guaWQpKTtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgcmVtb3ZlZCk7XG5cdH07XG5cdGNvbnN0IHNoYXJlZCA9IGRlaHlkcmF0ZWRNYXRjaGVzLmxlbmd0aCA+IGNhbmRpZGF0ZXMubGVuZ3RoID8gY2FuZGlkYXRlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpICsgMSA6IGRlaHlkcmF0ZWRNYXRjaGVzLmxlbmd0aDtcblx0bGV0IGlzVGVybWluYWwgPSBmYWxzZTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IHNoYXJlZDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IGNhbmRpZGF0ZSA9IGNhbmRpZGF0ZXNbaW5kZXhdO1xuXHRcdGNvbnN0IGRlaHlkcmF0ZWQgPSBkZWh5ZHJhdGVkTWF0Y2hlc1tpbmRleF07XG5cdFx0aWYgKHR5cGVvZiBkZWh5ZHJhdGVkLmkgIT09IFwic3RyaW5nXCIgfHwgaHlkcmF0ZVNzck1hdGNoSWQoZGVoeWRyYXRlZC5pKSAhPT0gY2FuZGlkYXRlLmlkKSB7XG5cdFx0XHRwZW5kaW5nQm91bmRhcnkgPz89IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHRcdHZlcmlmaWVkQXNzZXRFbmQgPSBpbmRleCArIDE7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIGNhbmRpZGF0ZSk7XG5cdFx0aWYgKFwibFwiIGluIGRlaHlkcmF0ZWQgfHwgZGVoeWRyYXRlZC5zID09PSBcInN1Y2Nlc3NcIiAmJiBkZWh5ZHJhdGVkLmUgPT09IHZvaWQgMCAmJiByb3V0ZS5vcHRpb25zLmxvYWRlcikgY2FuZGlkYXRlLmxvYWRlckRhdGEgPSBkZWh5ZHJhdGVkLmw7XG5cdFx0Y2FuZGlkYXRlLnN0YXR1cyA9IGRlaHlkcmF0ZWQucztcblx0XHRjYW5kaWRhdGUuc3NyID0gZGVoeWRyYXRlZC5zc3I7XG5cdFx0cm91dGUub3B0aW9ucy5zc3IgPSBjYW5kaWRhdGUuc3NyO1xuXHRcdGNhbmRpZGF0ZS51cGRhdGVkQXQgPSBkZWh5ZHJhdGVkLnU7XG5cdFx0Y2FuZGlkYXRlLmVycm9yID0gZGVoeWRyYXRlZC5lO1xuXHRcdGNhbmRpZGF0ZS5fbm90Rm91bmQgfHw9IGRlaHlkcmF0ZWQuZztcblx0XHRpZiAoY2FuZGlkYXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiIHx8IGNhbmRpZGF0ZS5zdGF0dXMgPT09IFwibm90Rm91bmRcIiB8fCBjYW5kaWRhdGUuX25vdEZvdW5kKSB7XG5cdFx0XHRpc1Rlcm1pbmFsID0gdHJ1ZTtcblx0XHRcdGNvbW1pdHRlZC5wdXNoKGNhbmRpZGF0ZSk7XG5cdFx0XHRpZiAoY2FuZGlkYXRlLnNzciA9PT0gZmFsc2UgfHwgY2FuZGlkYXRlLnNzciA9PT0gXCJkYXRhLW9ubHlcIikgcGVuZGluZ0JvdW5kYXJ5ID8/PSBpbmRleDtcblx0XHRcdGJyZWFrO1xuXHRcdH1cblx0XHRpZiAoY2FuZGlkYXRlLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHtcblx0XHRcdHBlbmRpbmdCb3VuZGFyeSA/Pz0gaW5kZXg7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdFx0Y29tbWl0dGVkLnB1c2goY2FuZGlkYXRlKTtcblx0XHRpZiAoY2FuZGlkYXRlLnNzciA9PT0gXCJkYXRhLW9ubHlcIikgcGVuZGluZ0JvdW5kYXJ5ID8/PSBpbmRleDtcblx0fVxuXHRpZiAoIWlzVGVybWluYWwgJiYgY29tbWl0dGVkLmxlbmd0aCA9PT0gc2hhcmVkICYmIHNoYXJlZCA8IGNhbmRpZGF0ZXMubGVuZ3RoKSBwZW5kaW5nQm91bmRhcnkgPSBzaGFyZWQ7XG5cdGNvbnN0IGNodW5rcyA9IGNvbW1pdHRlZC5tYXAoYXN5bmMgKG1hdGNoKSA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRhd2FpdCAobWF0Y2guX25vdEZvdW5kID8gUHJvbWlzZS5hbGwoW2xvYWRSb3V0ZUNodW5rKHJvdXRlKSwgbG9hZFJvdXRlQ2h1bmsocm91dGUsIFwibm90Rm91bmRDb21wb25lbnRcIildKSA6IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBtYXRjaC5zdGF0dXMgPT09IFwiZXJyb3JcIiA/IFwiZXJyb3JDb21wb25lbnRcIiA6IG1hdGNoLnN0YXR1cyA9PT0gXCJub3RGb3VuZFwiID8gXCJub3RGb3VuZENvbXBvbmVudFwiIDogdm9pZCAwKSk7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9IGNhdGNoIHtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdH0pO1xuXHRsZXQgY2h1bmtGYWlsdXJlID0gMDtcblx0dHJ5IHtcblx0XHR3aGlsZSAoY2h1bmtGYWlsdXJlIDwgY2h1bmtzLmxlbmd0aCAmJiBhd2FpdCB3YWl0Rm9yKGNodW5rc1tjaHVua0ZhaWx1cmVdLCBjb250cm9sbGVyLnNpZ25hbCkpIGNodW5rRmFpbHVyZSsrO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm47XG5cdH1cblx0aWYgKCFpc0N1cnJlbnQoKSkgcmV0dXJuO1xuXHRpZiAoY2h1bmtGYWlsdXJlIDwgY29tbWl0dGVkLmxlbmd0aCkgcmV0cnlGcm9tKGNodW5rRmFpbHVyZSk7XG5cdGNvbnN0IGNvbnRleHRFbmQgPSBNYXRoLm1heChwZW5kaW5nQm91bmRhcnkgPT09IGNvbW1pdHRlZC5sZW5ndGggPyBjb21taXR0ZWQubGVuZ3RoICsgMSA6IGNvbW1pdHRlZC5sZW5ndGgsIGNodW5rRmFpbHVyZSA8IGNodW5rcy5sZW5ndGggPyBjaHVua0ZhaWx1cmUgOiB2ZXJpZmllZEFzc2V0RW5kKTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGNvbnRleHRFbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IGNhbmRpZGF0ZXNbaW5kZXhdO1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0Y29uc3QgcGFyZW50Q29udGV4dCA9IGNhbmRpZGF0ZXNbaW5kZXggLSAxXT8uY29udGV4dCA/PyByb3V0ZXIub3B0aW9ucy5jb250ZXh0ID8/IHt9O1xuXHRcdGxldCByb3V0ZUNvbnRleHQ7XG5cdFx0aWYgKHJvdXRlLm9wdGlvbnMuY29udGV4dCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0cm91dGVDb250ZXh0ID0gbWF0Y2guX2N0eCA9IHJvdXRlLm9wdGlvbnMuY29udGV4dCh7XG5cdFx0XHRcdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRcdFx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRcdFx0XHRjb250ZXh0OiBwYXJlbnRDb250ZXh0LFxuXHRcdFx0XHRcdGxvY2F0aW9uLFxuXHRcdFx0XHRcdG5hdmlnYXRlOiAob3B0cykgPT4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRcdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdFx0XHRfZnJvbUxvY2F0aW9uOiBsb2NhdGlvblxuXHRcdFx0XHRcdH0pLFxuXHRcdFx0XHRcdGJ1aWxkTG9jYXRpb246IHJvdXRlci5idWlsZExvY2F0aW9uLFxuXHRcdFx0XHRcdGNhdXNlOiBtYXRjaC5jYXVzZSxcblx0XHRcdFx0XHRhYm9ydENvbnRyb2xsZXI6IGNvbnRyb2xsZXIsXG5cdFx0XHRcdFx0cHJlbG9hZDogZmFsc2UsXG5cdFx0XHRcdFx0bWF0Y2hlczogY2FuZGlkYXRlcyxcblx0XHRcdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZFxuXHRcdFx0XHR9KSB8fCB7fTtcblx0XHRcdH0gY2F0Y2gge1xuXHRcdFx0XHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdFx0XHRcdGlmIChtYXRjaC5zdGF0dXMgIT09IFwiZXJyb3JcIiAmJiBtYXRjaC5zdGF0dXMgIT09IFwibm90Rm91bmRcIiAmJiAhbWF0Y2guX25vdEZvdW5kKSB7XG5cdFx0XHRcdFx0cGVuZGluZ0JvdW5kYXJ5ID0gTWF0aC5taW4ocGVuZGluZ0JvdW5kYXJ5ID8/IGluZGV4LCBpbmRleCk7XG5cdFx0XHRcdFx0cmV0cnlGcm9tKGluZGV4KTtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0aWYgKCFpc0N1cnJlbnQoKSkgcmV0dXJuO1xuXHRcdH1cblx0XHRtYXRjaC5jb250ZXh0ID0ge1xuXHRcdFx0Li4ucGFyZW50Q29udGV4dCxcblx0XHRcdC4uLnJvdXRlQ29udGV4dCxcblx0XHRcdC4uLmNvbW1pdHRlZFtpbmRleF0gJiYgZGVoeWRyYXRlZE1hdGNoZXNbaW5kZXhdLmJcblx0XHR9O1xuXHR9XG5cdGF3YWl0IHByb2plY3RMYW5lKHJvdXRlciwgW2xvY2F0aW9uLCBjYW5kaWRhdGVzXSwgY29udHJvbGxlci5zaWduYWwsIDAsIHZlcmlmaWVkQXNzZXRFbmQpO1xuXHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdGNvbnN0IG5lZWRzQ2xpZW50TG9hZCA9IHBlbmRpbmdCb3VuZGFyeSAhPT0gdm9pZCAwIHx8IGNvbW1pdHRlZC5sZW5ndGggPCBzaGFyZWQ7XG5cdGNvbnN0IGNvbW1pdHRlZE1hdGNoZXMgPSBpc1Rlcm1pbmFsICYmIGNvbW1pdHRlZC5sZW5ndGggPT09IHNoYXJlZCA/IGNhbmRpZGF0ZXMgOiBjb21taXR0ZWQ7XG5cdGxldCBwcmVzZW50ZWQgPSBuZWVkc0NsaWVudExvYWQgPyBjYW5kaWRhdGVzIDogY29tbWl0dGVkTWF0Y2hlcztcblx0bGV0IGRhdGFPbmx5QXNzZXRFbmQ7XG5cdGlmIChuZWVkc0NsaWVudExvYWQgJiYgcGVuZGluZ0JvdW5kYXJ5ICE9PSB2b2lkIDApIHtcblx0XHRjb25zdCBib3VuZGFyeSA9IHByZXNlbnRlZFtwZW5kaW5nQm91bmRhcnldO1xuXHRcdGRhdGFPbmx5QXNzZXRFbmQgPSBib3VuZGFyeS5zc3IgPT09IFwiZGF0YS1vbmx5XCIgJiYgdmVyaWZpZWRBc3NldEVuZCA+IHBlbmRpbmdCb3VuZGFyeSArIDEgPyB2ZXJpZmllZEFzc2V0RW5kIDogdm9pZCAwO1xuXHRcdHByZXNlbnRlZCA9IHByZXNlbnRlZC5zbGljZSgpO1xuXHRcdHByZXNlbnRlZFtwZW5kaW5nQm91bmRhcnldID0ge1xuXHRcdFx0Li4uYm91bmRhcnksXG5cdFx0XHRzdGF0dXM6IFwicGVuZGluZ1wiLFxuXHRcdFx0c3NyOiBib3VuZGFyeS5zc3IgPT09IFwiZGF0YS1vbmx5XCIgPyBcImRhdGEtb25seVwiIDogZmFsc2UsXG5cdFx0XHRfYXNzZXRFbmQ6IGRhdGFPbmx5QXNzZXRFbmRcblx0XHR9O1xuXHR9XG5cdGNvbnN0IGNsYWltID0gKCkgPT4ge1xuXHRcdGNvbnN0IGhpc3RvcnlMb2NhdGlvbiA9IHJvdXRlci5oaXN0b3J5LmxvY2F0aW9uO1xuXHRcdHJldHVybiBuZWVkc0NsaWVudExvYWQgJiYgIXJvdXRlci5fdHggJiYgaGlzdG9yeUxvY2F0aW9uLmhyZWYgPT09IGhhbmRvZmZIaXN0b3J5SHJlZiAmJiBoaXN0b3J5TG9jYXRpb24uc3RhdGUgPT09IGhhbmRvZmZIaXN0b3J5U3RhdGUgJiYgcm91dGVyLl9jb21taXR0ZWQgPT09IGNvbW1pdHRlZE1hdGNoZXMgJiYgY29tbWl0dGVkTWF0Y2hlcy5sZW5ndGggJiYgIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQgPyBjb250cm9sbGVyIDogdm9pZCAwO1xuXHR9O1xuXHRjb25zdCBoYW5kb2ZmID0gW2NsYWltLCAobWF0Y2hlcykgPT4ge1xuXHRcdGlmIChyb3V0ZXIuX2hhbmRvZmYgIT09IGhhbmRvZmYpIHJldHVybjtcblx0XHRyb3V0ZXIuX2hhbmRvZmYgPSB2b2lkIDA7XG5cdFx0Y29uc3QgcHJlZml4ID0gY29tbWl0dGVkTWF0Y2hlcy5sZW5ndGg7XG5cdFx0aWYgKCFtYXRjaGVzIHx8ICFjbGFpbSgpIHx8IGNvbW1pdHRlZE1hdGNoZXMuc29tZSgobWF0Y2gsIGluZGV4KSA9PiBtYXRjaC5pZCAhPT0gbWF0Y2hlc1tpbmRleF0/LmlkKSkge1xuXHRcdFx0Y29udHJvbGxlci5hYm9ydCgpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRsZXQgaGFuZG9mZkFzc2V0RW5kID0gZGF0YU9ubHlBc3NldEVuZDtcblx0XHRpZiAoaGFuZG9mZkFzc2V0RW5kICE9PSB2b2lkIDApIHtcblx0XHRcdGZvciAobGV0IGluZGV4ID0gcHJlZml4OyBpbmRleCA8IGhhbmRvZmZBc3NldEVuZDsgaW5kZXgrKykgaWYgKGNhbmRpZGF0ZXNbaW5kZXhdPy5pZCAhPT0gbWF0Y2hlc1tpbmRleF0/LmlkKSB7XG5cdFx0XHRcdGhhbmRvZmZBc3NldEVuZCA9IGluZGV4ID4gcGVuZGluZ0JvdW5kYXJ5ICsgMSA/IGluZGV4IDogdm9pZCAwO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHR9XG5cdFx0Y29uc3QgY2xvbmVzID0gY29tbWl0dGVkTWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiAoeyAuLi5tYXRjaCB9KSk7XG5cdFx0aWYgKGhhbmRvZmZBc3NldEVuZCAhPT0gdm9pZCAwKSBjbG9uZXNbcGVuZGluZ0JvdW5kYXJ5XS5fYXNzZXRFbmQgPSBoYW5kb2ZmQXNzZXRFbmQ7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG1hdGNoZXMuc3BsaWNlKDAsIHByZWZpeCwgLi4uY2xvbmVzKSk7XG5cdFx0Zm9yIChsZXQgaW5kZXggPSBwcmVmaXg7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF07XG5cdFx0XHRjb25zdCBoeWRyYXRlZCA9IGNhbmRpZGF0ZXNbaW5kZXhdO1xuXHRcdFx0aWYgKGh5ZHJhdGVkPy5pZCA9PT0gbWF0Y2guaWQgJiYgaHlkcmF0ZWQuX2N0eCkgbWF0Y2guX2N0eCA9IGh5ZHJhdGVkLl9jdHg7XG5cdFx0XHRtYXRjaC5hYm9ydENvbnRyb2xsZXIgPSBjb250cm9sbGVyO1xuXHRcdH1cblx0XHRyZXR1cm4gcHJlZml4O1xuXHR9XTtcblx0cm91dGVyLl9jb21taXR0ZWQgPSBjb21taXR0ZWRNYXRjaGVzO1xuXHRyb3V0ZXIuX2xpZmVjeWNsZUVuZCA9IGxpZmVjeWNsZUVuZChjb21taXR0ZWRNYXRjaGVzKTtcblx0cm91dGVyLl9oYW5kb2ZmID0gaGFuZG9mZjtcblx0cm91dGVyLl9wcmVmbGlnaHQgPSB2b2lkIDA7XG5cdHJvdXRlci5iYXRjaCgoKSA9PiB7XG5cdFx0cm91dGVyLnN0b3Jlcy5zZXRNYXRjaGVzKHByZXNlbnRlZCk7XG5cdFx0cm91dGVyLnN0b3Jlcy5zdGF0dXMuc2V0KFwiaWRsZVwiKTtcblx0XHRpZiAoIW5lZWRzQ2xpZW50TG9hZCkgcm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLnNldChyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpKTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IF9nZXRBc3NldE1hdGNoZXMsIF9nZXRSZW5kZXJlZE1hdGNoZXMsIGh5ZHJhdGUsIGxvYWRDbGllbnRSb3V0ZSwgbG9hZFJvdXRlQ2h1bmssIHByZWxvYWRDbGllbnRSb3V0ZSwgcmVmcmVzaENsaWVudFJvdXRlLCByZXBsYWNlUm91dGVDaHVuayB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1sb2FkLWNsaWVudC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL2F3YWl0LXNpZ25hbC50c1xuZnVuY3Rpb24gb2JzZXJ2ZUxhdGUoY2FsbGJhY2ssIHZhbHVlKSB7XG5cdGlmICghY2FsbGJhY2spIHJldHVybjtcblx0dHJ5IHtcblx0XHRjb25zdCByZXN1bHQgPSBjYWxsYmFjayh2YWx1ZSk7XG5cdFx0aWYgKHJlc3VsdCAhPT0gdm9pZCAwKSBQcm9taXNlLnJlc29sdmUocmVzdWx0KS5jYXRjaCgoKSA9PiB7fSk7XG5cdH0gY2F0Y2gge31cbn1cbi8qKlxuKiBBd2FpdCBgdmFsdWVgIHVubGVzcyBgc2lnbmFsYCBhYm9ydHMgZmlyc3QuIEEgcmVzdWx0IHRoYXQgc2V0dGxlcyBhZnRlciB0aGVcbiogYWJvcnQgaXMgcGFzc2VkIHRvIGBvbkxhdGVgIC8gYG9uTGF0ZUVycm9yYCBpbnN0ZWFkLlxuKlxuKiBPbmUgYWJvcnQgbGlzdGVuZXIgcGVyIHdhaXQ6IFNTUiByZXF1ZXN0cyBuZXN0IGF0IG1vc3QgYSBmZXcgd2FpdHMgb24gb25lXG4qIHNpZ25hbCwgc28gcG9vbGluZyB0aGVtIHdhcyBtZWFzdXJhYmx5IHNsb3dlciB0aGFuIHRoaXMuXG4qL1xuZnVuY3Rpb24gd2FpdEZvclJlYXNvbih2YWx1ZSwgc2lnbmFsLCBvbkxhdGUsIG9uTGF0ZUVycm9yKSB7XG5cdGNvbnN0IHByb21pc2UgPSBQcm9taXNlLnJlc29sdmUodmFsdWUpO1xuXHRpZiAoc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRwcm9taXNlLnRoZW4oKHJlc3VsdCkgPT4gb2JzZXJ2ZUxhdGUob25MYXRlLCByZXN1bHQpLCAoZXJyb3IpID0+IG9ic2VydmVMYXRlKG9uTGF0ZUVycm9yLCBlcnJvcikpO1xuXHRcdHJldHVybiBQcm9taXNlLnJlamVjdChzaWduYWwucmVhc29uKTtcblx0fVxuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IGFib3J0ID0gKCkgPT4gcmVqZWN0KHNpZ25hbC5yZWFzb24pO1xuXHRcdHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnQsIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRwcm9taXNlLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdFx0c2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydCk7XG5cdFx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIG9ic2VydmVMYXRlKG9uTGF0ZSwgcmVzdWx0KTtcblx0XHRcdGVsc2UgcmVzb2x2ZShyZXN1bHQpO1xuXHRcdH0sIChlcnJvcikgPT4ge1xuXHRcdFx0c2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydCk7XG5cdFx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIG9ic2VydmVMYXRlKG9uTGF0ZUVycm9yLCBlcnJvcik7XG5cdFx0XHRlbHNlIHJlamVjdChlcnJvcik7XG5cdFx0fSk7XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB3YWl0Rm9yUmVhc29uIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWF3YWl0LXNpZ25hbC5qcy5tYXAiLCJpbXBvcnQgeyBpc05vdEZvdW5kIH0gZnJvbSBcIi4vbm90LWZvdW5kLmpzXCI7XG5pbXBvcnQgeyByb290Um91dGVJZCB9IGZyb20gXCIuL3Jvb3QuanNcIjtcbmltcG9ydCB7IGlzUmVkaXJlY3QsIHJlZGlyZWN0IH0gZnJvbSBcIi4vcmVkaXJlY3QuanNcIjtcbmltcG9ydCB7IGxvYWRSb3V0ZUNodW5rIH0gZnJvbSBcIi4vbG9hZC1jbGllbnQuanNcIjtcbmltcG9ydCB7IGdldExvY2F0aW9uQ2hhbmdlSW5mbywgbGlmZWN5Y2xlRW5kLCBydW5Sb3V0ZUxpZmVjeWNsZSB9IGZyb20gXCIuL3JvdXRlci5qc1wiO1xuaW1wb3J0IHsgd2FpdEZvclJlYXNvbiB9IGZyb20gXCIuL2F3YWl0LXNpZ25hbC5qc1wiO1xuLy8jcmVnaW9uIHNyYy9sb2FkLXNlcnZlci50c1xuY29uc3QgU1VDQ0VTUyA9IDA7XG5jb25zdCBFUlJPUiA9IDE7XG5jb25zdCBOT1RfRk9VTkQgPSAyO1xuY29uc3QgUkVESVJFQ1RFRCA9IDM7XG5jb25zdCBTS0lQUEVEID0gNDtcbmNvbnN0IE1BVENIX1NFVFRMRURfQUJPUlRfUkVBU09OID0gT2JqZWN0LmZyZWV6ZSh7XG5cdG5hbWU6IFwiQWJvcnRFcnJvclwiLFxuXHRtZXNzYWdlOiBcIlRhblN0YWNrIFJvdXRlciBhYm9ydGVkIHRoaXMgc2VydmVyIG1hdGNoIGJlY2F1c2UgaXQgc2V0dGxlZC5cIlxufSk7XG5jb25zdCBSRURJUkVDVF9BQk9SVF9SRUFTT04gPSBPYmplY3QuZnJlZXplKHtcblx0bmFtZTogXCJBYm9ydEVycm9yXCIsXG5cdG1lc3NhZ2U6IFwiVGFuU3RhY2sgUm91dGVyIGFib3J0ZWQgdGhpcyBzZXJ2ZXIgbWF0Y2ggYmVjYXVzZSBvZiBhIHJlZGlyZWN0LlwiXG59KTtcbmZ1bmN0aW9uIGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpIHtcblx0cmV0dXJuIHJvdXRlci5yb3V0ZXNCeUlkW21hdGNoLnJvdXRlSWRdO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplKHZhbHVlLCByZWplY3RlZCkge1xuXHRpZiAoaXNSZWRpcmVjdCh2YWx1ZSkpIHJldHVybiBbUkVESVJFQ1RFRCwgdmFsdWVdO1xuXHRpZiAoaXNOb3RGb3VuZCh2YWx1ZSkpIHJldHVybiBbTk9UX0ZPVU5ELCB2YWx1ZV07XG5cdGlmIChyZWplY3RlZCAmJiB0eXBlb2YgdmFsdWU/LnRoZW4gPT09IFwiZnVuY3Rpb25cIikgdmFsdWUgPSBuZXcgRXJyb3IoXCJBIFByb21pc2Ugd2FzIHRocm93blwiLCB7IGNhdXNlOiB2YWx1ZSB9KTtcblx0cmV0dXJuIHJlamVjdGVkID8gW0VSUk9SLCB2YWx1ZV0gOiBbU1VDQ0VTUywgdmFsdWVdO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCwgbm90aWZ5ID0gdHJ1ZSkge1xuXHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdGxldCBvdXRjb21lID0gbm9ybWFsaXplKGNhdXNlLCB0cnVlKTtcblx0aWYgKG91dGNvbWVbMF0gIT09IEVSUk9SKSByZXR1cm4gbWF0ZXJpYWxpemVSZWRpcmVjdChyb3V0ZXIsIGxhbmUsIHJvdXRlLCBvdXRjb21lLCBzaWduYWwsIG5vdGlmeSk7XG5cdHRyeSB7XG5cdFx0cm91dGUub3B0aW9ucy5vbkVycm9yPy4ob3V0Y29tZVsxXSk7XG5cdH0gY2F0Y2ggKG9uRXJyb3JDYXVzZSkge1xuXHRcdG91dGNvbWUgPSBub3JtYWxpemUob25FcnJvckNhdXNlLCB0cnVlKTtcblx0fVxuXHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdHJldHVybiBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIG91dGNvbWUsIHNpZ25hbCwgbm90aWZ5KTtcbn1cbmZ1bmN0aW9uIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgb3V0Y29tZSwgc2lnbmFsLCBub3RpZnkgPSB0cnVlKSB7XG5cdGlmIChvdXRjb21lWzBdICE9PSBSRURJUkVDVEVEKSByZXR1cm4gb3V0Y29tZTtcblx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHR0cnkge1xuXHRcdG91dGNvbWVbMV0ub3B0aW9ucy5fZnJvbUxvY2F0aW9uID0gbGFuZS5sb2NhdGlvbjtcblx0XHRyb3V0ZXIucmVzb2x2ZVJlZGlyZWN0KG91dGNvbWVbMV0pO1xuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRyZXR1cm4gb3V0Y29tZTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0cmV0dXJuIG5vdGlmeSA/IG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBzaWduYWwsIGZhbHNlKSA6IFtFUlJPUiwgY2F1c2VdO1xuXHR9XG59XG5mdW5jdGlvbiBtYXliZSh2YWx1ZSwgY2F1c2UpIHtcblx0aWYgKGNhdXNlICE9PSB2b2lkIDApIHJldHVybiB7XG5cdFx0c3RhdHVzOiBcImVycm9yXCIsXG5cdFx0ZXJyb3I6IGNhdXNlXG5cdH07XG5cdHJldHVybiB7XG5cdFx0c3RhdHVzOiBcInN1Y2Nlc3NcIixcblx0XHR2YWx1ZVxuXHR9O1xufVxuZnVuY3Rpb24gbmF2aWdhdGVGcm9tKHJvdXRlciwgbG9jYXRpb24pIHtcblx0cmV0dXJuIChvcHRpb25zKSA9PiByb3V0ZXIubmF2aWdhdGUoe1xuXHRcdC4uLm9wdGlvbnMsXG5cdFx0X2Zyb21Mb2NhdGlvbjogbG9jYXRpb25cblx0fSk7XG59XG5mdW5jdGlvbiB3YWl0Rm9yKHZhbHVlLCBzaWduYWwpIHtcblx0cmV0dXJuIHNpZ25hbCA/IHdhaXRGb3JSZWFzb24odmFsdWUsIHNpZ25hbCkgOiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVTc3Iocm91dGVyLCBsYW5lLCBpbmRleCkge1xuXHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tpbmRleF07XG5cdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdGNvbnN0IHBhcmVudFNzciA9IGxhbmUubWF0Y2hlc1tpbmRleCAtIDFdPy5zc3I7XG5cdGlmIChyb3V0ZXIuaXNTaGVsbCgpKSByZXR1cm4gcm91dGUuaWQgPT09IHJvb3RSb3V0ZUlkO1xuXHRpZiAocGFyZW50U3NyID09PSBmYWxzZSkgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBpbmhlcml0ID0gKHZhbHVlKSA9PiB7XG5cdFx0cmV0dXJuIHZhbHVlID09PSB0cnVlICYmIHBhcmVudFNzciA9PT0gXCJkYXRhLW9ubHlcIiA/IFwiZGF0YS1vbmx5XCIgOiB2YWx1ZTtcblx0fTtcblx0Y29uc3QgZGVmYXVsdFNzciA9IHJvdXRlci5vcHRpb25zLmRlZmF1bHRTc3IgPz8gdHJ1ZTtcblx0Y29uc3QgaW5oZXJpdGVkRGVmYXVsdCA9IGluaGVyaXQoZGVmYXVsdFNzcik7XG5cdG1hdGNoLnNzciA9IGluaGVyaXRlZERlZmF1bHQ7XG5cdGNvbnN0IG9wdGlvbiA9IHJvdXRlLm9wdGlvbnMuc3NyO1xuXHRpZiAob3B0aW9uID09PSB2b2lkIDApIHJldHVybiBpbmhlcml0ZWREZWZhdWx0O1xuXHRpZiAodHlwZW9mIG9wdGlvbiAhPT0gXCJmdW5jdGlvblwiKSByZXR1cm4gaW5oZXJpdChvcHRpb24pO1xuXHRjb25zdCBjb250ZXh0ID0ge1xuXHRcdHNlYXJjaDogbWF5YmUobWF0Y2guc2VhcmNoLCBtYXRjaC5zZWFyY2hFcnJvciksXG5cdFx0cGFyYW1zOiBtYXliZShtYXRjaC5wYXJhbXMsIG1hdGNoLnBhcmFtc0Vycm9yKSxcblx0XHRsb2NhdGlvbjogbGFuZS5sb2NhdGlvbixcblx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXMubWFwKChjYW5kaWRhdGUpID0+ICh7XG5cdFx0XHRpbmRleDogY2FuZGlkYXRlLmluZGV4LFxuXHRcdFx0cGF0aG5hbWU6IGNhbmRpZGF0ZS5wYXRobmFtZSxcblx0XHRcdGZ1bGxQYXRoOiBjYW5kaWRhdGUuZnVsbFBhdGgsXG5cdFx0XHRzdGF0aWNEYXRhOiBjYW5kaWRhdGUuc3RhdGljRGF0YSxcblx0XHRcdGlkOiBjYW5kaWRhdGUuaWQsXG5cdFx0XHRyb3V0ZUlkOiBjYW5kaWRhdGUucm91dGVJZCxcblx0XHRcdHNlYXJjaDogbWF5YmUoY2FuZGlkYXRlLnNlYXJjaCwgY2FuZGlkYXRlLnNlYXJjaEVycm9yKSxcblx0XHRcdHBhcmFtczogbWF5YmUoY2FuZGlkYXRlLnBhcmFtcywgY2FuZGlkYXRlLnBhcmFtc0Vycm9yKSxcblx0XHRcdHNzcjogY2FuZGlkYXRlLnNzclxuXHRcdH0pKVxuXHR9O1xuXHR0cnkge1xuXHRcdHJldHVybiBQcm9taXNlLnJlc29sdmUob3B0aW9uKGNvbnRleHQpKS50aGVuKCh2YWx1ZSkgPT4gaW5oZXJpdCh2YWx1ZSA/PyBkZWZhdWx0U3NyKSk7XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KGNhdXNlKTtcblx0fVxufVxuZnVuY3Rpb24gc3RhbXBOb3RGb3VuZChtYXRjaCwgb3V0Y29tZSkge1xuXHRpZiAob3V0Y29tZVswXSA9PT0gTk9UX0ZPVU5EICYmICFvdXRjb21lWzFdLnJvdXRlSWQpIG91dGNvbWVbMV0ucm91dGVJZCA9IG1hdGNoLnJvdXRlSWQ7XG5cdHJldHVybiBvdXRjb21lO1xufVxuYXN5bmMgZnVuY3Rpb24gY29udGV4dHVhbGl6ZShyb3V0ZXIsIGxhbmUsIHNpZ25hbCkge1xuXHRjb25zdCBnbG9iYWxCb3VuZGFyeSA9IGxhbmUubWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpO1xuXHRsZXQgZW5kID0gZ2xvYmFsQm91bmRhcnkgPCAwID8gbGFuZS5tYXRjaGVzLmxlbmd0aCA6IGdsb2JhbEJvdW5kYXJ5ICsgMTtcblx0bGV0IGZhaWx1cmU7XG5cdGxldCBwYXJlbnRDb250ZXh0ID0geyAuLi5yb3V0ZXIub3B0aW9ucy5jb250ZXh0ID8/IHt9IH07XG5cdGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tpbmRleF07XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3Qgc3NyID0gcmVzb2x2ZVNzcihyb3V0ZXIsIGxhbmUsIGluZGV4KTtcblx0XHRcdG1hdGNoLnNzciA9IHNzciBpbnN0YW5jZW9mIFByb21pc2UgPyBhd2FpdCBzc3IgOiBzc3I7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGZhaWx1cmUgPSBbaW5kZXgsIHN0YW1wTm90Rm91bmQobWF0Y2gsIG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBzaWduYWwpKV07XG5cdFx0XHRlbmQgPSBpbmRleDtcblx0XHR9XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChmYWlsdXJlPy5bMV1bMF0gPT09IFJFRElSRUNURUQpIGJyZWFrO1xuXHRcdG1hdGNoLl9fYmVmb3JlTG9hZENvbnRleHQgPSB2b2lkIDA7XG5cdFx0bGV0IGNvbnRleHQgPSBwYXJlbnRDb250ZXh0O1xuXHRcdHRyeSB7XG5cdFx0XHRsZXQgcm91dGVDb250ZXh0O1xuXHRcdFx0aWYgKHJvdXRlLm9wdGlvbnMuY29udGV4dCkge1xuXHRcdFx0XHRjb25zdCByb3V0ZUNvbnRleHRPcHRpb25zID0ge1xuXHRcdFx0XHRcdGRlcHM6IG1hdGNoLmxvYWRlckRlcHMsXG5cdFx0XHRcdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0XHRcdFx0Y29udGV4dDogcGFyZW50Q29udGV4dCxcblx0XHRcdFx0XHRsb2NhdGlvbjogbGFuZS5sb2NhdGlvbixcblx0XHRcdFx0XHRuYXZpZ2F0ZTogbmF2aWdhdGVGcm9tKHJvdXRlciwgbGFuZS5sb2NhdGlvbiksXG5cdFx0XHRcdFx0YnVpbGRMb2NhdGlvbjogcm91dGVyLmJ1aWxkTG9jYXRpb24sXG5cdFx0XHRcdFx0Y2F1c2U6IG1hdGNoLmNhdXNlLFxuXHRcdFx0XHRcdGFib3J0Q29udHJvbGxlcjogbWF0Y2guYWJvcnRDb250cm9sbGVyLFxuXHRcdFx0XHRcdHByZWxvYWQ6IGZhbHNlLFxuXHRcdFx0XHRcdG1hdGNoZXM6IGxhbmUubWF0Y2hlcyxcblx0XHRcdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZFxuXHRcdFx0XHR9O1xuXHRcdFx0XHRyb3V0ZUNvbnRleHQgPSByb3V0ZS5vcHRpb25zLmNvbnRleHQocm91dGVDb250ZXh0T3B0aW9ucykgPz8gdm9pZCAwO1xuXHRcdFx0fVxuXHRcdFx0Y29udGV4dCA9IHtcblx0XHRcdFx0Li4ucGFyZW50Q29udGV4dCxcblx0XHRcdFx0Li4ucm91dGVDb250ZXh0XG5cdFx0XHR9O1xuXHRcdFx0bWF0Y2guY29udGV4dCA9IGNvbnRleHQ7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGlmICghZmFpbHVyZSkgZmFpbHVyZSA9IFtpbmRleCwgc3RhbXBOb3RGb3VuZChtYXRjaCwgbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCkpXTtcblx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRpZiAoZmFpbHVyZSkgYnJlYWs7XG5cdFx0Y29uc3QgdmFsaWRhdGlvbkVycm9yID0gbWF0Y2gucGFyYW1zRXJyb3IgPz8gbWF0Y2guc2VhcmNoRXJyb3I7XG5cdFx0aWYgKHZhbGlkYXRpb25FcnJvciAhPT0gdm9pZCAwKSB7XG5cdFx0XHRmYWlsdXJlID0gW2luZGV4LCBzdGFtcE5vdEZvdW5kKG1hdGNoLCBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCB2YWxpZGF0aW9uRXJyb3IsIHNpZ25hbCkpXTtcblx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRpZiAobWF0Y2guc3NyID09PSBmYWxzZSB8fCAhcm91dGUub3B0aW9ucy5iZWZvcmVMb2FkKSB7XG5cdFx0XHRwYXJlbnRDb250ZXh0ID0gY29udGV4dDtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBtYXRjaC5hYm9ydENvbnRyb2xsZXI7XG5cdFx0Y29uc3Qgb3B0aW9ucyA9IHtcblx0XHRcdHNlYXJjaDogbWF0Y2guc2VhcmNoLFxuXHRcdFx0YWJvcnRDb250cm9sbGVyLFxuXHRcdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0XHRwcmVsb2FkOiBmYWxzZSxcblx0XHRcdGNvbnRleHQsXG5cdFx0XHRsb2NhdGlvbjogbGFuZS5sb2NhdGlvbixcblx0XHRcdG5hdmlnYXRlOiBuYXZpZ2F0ZUZyb20ocm91dGVyLCBsYW5lLmxvY2F0aW9uKSxcblx0XHRcdGJ1aWxkTG9jYXRpb246IHJvdXRlci5idWlsZExvY2F0aW9uLFxuXHRcdFx0Y2F1c2U6IG1hdGNoLmNhdXNlLFxuXHRcdFx0bWF0Y2hlczogbGFuZS5tYXRjaGVzLFxuXHRcdFx0cm91dGVJZDogcm91dGUuaWQsXG5cdFx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHRcdH07XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGJlZm9yZUxvYWRDb250ZXh0ID0gYXdhaXQgcm91dGUub3B0aW9ucy5iZWZvcmVMb2FkKG9wdGlvbnMpO1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0Y29uc3Qgb3V0Y29tZSA9IHN0YW1wTm90Rm91bmQobWF0Y2gsIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgbm9ybWFsaXplKGJlZm9yZUxvYWRDb250ZXh0LCBmYWxzZSksIHNpZ25hbCkpO1xuXHRcdFx0aWYgKG91dGNvbWVbMF0gIT09IFNVQ0NFU1MpIHtcblx0XHRcdFx0ZmFpbHVyZSA9IFtpbmRleCwgb3V0Y29tZV07XG5cdFx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHRcdG1hdGNoLl9fYmVmb3JlTG9hZENvbnRleHQgPSBiZWZvcmVMb2FkQ29udGV4dDtcblx0XHRcdG1hdGNoLmNvbnRleHQgPSB7XG5cdFx0XHRcdC4uLmNvbnRleHQsXG5cdFx0XHRcdC4uLmJlZm9yZUxvYWRDb250ZXh0XG5cdFx0XHR9O1xuXHRcdFx0cGFyZW50Q29udGV4dCA9IG1hdGNoLmNvbnRleHQ7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGZhaWx1cmUgPSBbaW5kZXgsIHN0YW1wTm90Rm91bmQobWF0Y2gsIG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBzaWduYWwpKV07XG5cdFx0XHRlbmQgPSBpbmRleDtcblx0XHRcdGJyZWFrO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4ge1xuXHRcdGxvY2F0aW9uOiBsYW5lLmxvY2F0aW9uLFxuXHRcdG1hdGNoZXM6IGxhbmUubWF0Y2hlcyxcblx0XHRlbmQsXG5cdFx0ZmFpbHVyZVxuXHR9O1xufVxuZnVuY3Rpb24gZ2V0TG9hZGVyQ29udGV4dChyb3V0ZXIsIGxhbmUsIG1hdGNoLCByb3V0ZSwgaW5kZXgsIHRhc2tzKSB7XG5cdHJldHVybiB7XG5cdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRwcmVsb2FkOiBmYWxzZSxcblx0XHRwYXJlbnRNYXRjaFByb21pc2U6IHRhc2tzW2luZGV4IC0gMV0/Lm1hdGNoLFxuXHRcdGFib3J0Q29udHJvbGxlcjogbWF0Y2guYWJvcnRDb250cm9sbGVyLFxuXHRcdGNvbnRleHQ6IG1hdGNoLmNvbnRleHQsXG5cdFx0bG9jYXRpb246IGxhbmUubG9jYXRpb24sXG5cdFx0bmF2aWdhdGU6IG5hdmlnYXRlRnJvbShyb3V0ZXIsIGxhbmUubG9jYXRpb24pLFxuXHRcdGNhdXNlOiBtYXRjaC5jYXVzZSxcblx0XHRyb3V0ZSxcblx0XHQuLi5yb3V0ZXIub3B0aW9ucy5hZGRpdGlvbmFsQ29udGV4dFxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlTG9hZGVyVGFzayhyb3V0ZXIsIGxhbmUsIGluZGV4LCB0YXNrcywgc2lnbmFsKSB7XG5cdGNvbnN0IG1hdGNoID0gbGFuZS5tYXRjaGVzW2luZGV4XTtcblx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0bGV0IG91dGNvbWU7XG5cdGlmIChtYXRjaC5zc3IgPT09IGZhbHNlKSBvdXRjb21lID0gUHJvbWlzZS5yZXNvbHZlKFtTS0lQUEVEXSk7XG5cdGVsc2Uge1xuXHRcdGNvbnN0IHJvdXRlTG9hZGVyID0gcm91dGUub3B0aW9ucy5sb2FkZXI7XG5cdFx0Y29uc3QgbG9hZGVyID0gdHlwZW9mIHJvdXRlTG9hZGVyID09PSBcImZ1bmN0aW9uXCIgPyByb3V0ZUxvYWRlciA6IHJvdXRlTG9hZGVyPy5oYW5kbGVyO1xuXHRcdGlmICghbG9hZGVyKSBvdXRjb21lID0gUHJvbWlzZS5yZXNvbHZlKFtTVUNDRVNTLCB2b2lkIDBdKTtcblx0XHRlbHNlIG91dGNvbWUgPSBQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IGxvYWRlcihnZXRMb2FkZXJDb250ZXh0KHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBpbmRleCwgdGFza3MpKSkudGhlbigocmVzdWx0KSA9PiBub3JtYWxpemUocmVzdWx0LCBmYWxzZSksIChjYXVzZSkgPT4gbm9ybWFsaXplKGNhdXNlLCB0cnVlKSkudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0XHRpZiAoc2lnbmFsPy5hYm9ydGVkIHx8IG1hdGNoLmFib3J0Q29udHJvbGxlci5zaWduYWwucmVhc29uID09PSBSRURJUkVDVF9BQk9SVF9SRUFTT04pIHJldHVybiBbU0tJUFBFRF07XG5cdFx0XHRpZiAocmVzdWx0WzBdID09PSBFUlJPUikgcmVzdWx0ID0gbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgcmVzdWx0WzFdLCBzaWduYWwpO1xuXHRcdFx0ZWxzZSByZXN1bHQgPSBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIHJlc3VsdCwgc2lnbmFsKTtcblx0XHRcdHJldHVybiBzdGFtcE5vdEZvdW5kKG1hdGNoLCByZXN1bHQpO1xuXHRcdH0pO1xuXHR9XG5cdGNvbnN0IHBhcmVudE1hdGNoID0gb3V0Y29tZS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRjb25zdCBzbmFwc2hvdCA9IHsgLi4ubWF0Y2ggfTtcblx0XHRpZiAocmVzdWx0WzBdID09PSBTVUNDRVNTKSB7XG5cdFx0XHRzbmFwc2hvdC5sb2FkZXJEYXRhID0gcmVzdWx0WzFdO1xuXHRcdFx0c25hcHNob3Quc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0XHRzbmFwc2hvdC5lcnJvciA9IHZvaWQgMDtcblx0XHRcdHNuYXBzaG90LmludmFsaWQgPSBmYWxzZTtcblx0XHRcdHNuYXBzaG90LmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHR9IGVsc2UgaWYgKHJlc3VsdFswXSA9PT0gRVJST1IpIHtcblx0XHRcdHNuYXBzaG90LnN0YXR1cyA9IFwiZXJyb3JcIjtcblx0XHRcdHNuYXBzaG90LmVycm9yID0gcmVzdWx0WzFdO1xuXHRcdH0gZWxzZSBpZiAocmVzdWx0WzBdID09PSBOT1RfRk9VTkQpIHtcblx0XHRcdHNuYXBzaG90LnN0YXR1cyA9IFwibm90Rm91bmRcIjtcblx0XHRcdHNuYXBzaG90LmVycm9yID0gcmVzdWx0WzFdO1xuXHRcdH1cblx0XHRyZXR1cm4gc25hcHNob3Q7XG5cdH0pO1xuXHRyZXR1cm4ge1xuXHRcdGluZGV4LFxuXHRcdG91dGNvbWUsXG5cdFx0bWF0Y2g6IHBhcmVudE1hdGNoXG5cdH07XG59XG5hc3luYyBmdW5jdGlvbiBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgaW5kZXhlZCwgc2lnbmFsLCBmYWxsYmFjayA9IDApIHtcblx0Y29uc3QgY2F1c2UgPSBpbmRleGVkPy5bMV1bMV07XG5cdGxldCBpbmRleCA9IGNhdXNlPy5yb3V0ZUlkID8gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkID09PSBjYXVzZS5yb3V0ZUlkKSA6IGluZGV4ZWQ/LlswXSA/PyBtYXRjaGVzLmxlbmd0aCAtIDE7XG5cdGlmIChpbmRleCA8IDApIGluZGV4ID0gMDtcblx0Zm9yIChsZXQgY2FuZGlkYXRlID0gaW5kZXg7IGNhbmRpZGF0ZSA+PSAwOyBjYW5kaWRhdGUtLSkge1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaGVzW2NhbmRpZGF0ZV0pO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2FkaW5nID0gbG9hZFJvdXRlQ2h1bmsocm91dGUsIGZhbHNlKTtcblx0XHRcdGlmIChsb2FkaW5nKSBhd2FpdCBsb2FkaW5nO1xuXHRcdH0gY2F0Y2gge1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdH1cblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0aWYgKHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQpIHJldHVybiBjYW5kaWRhdGU7XG5cdH1cblx0cmV0dXJuIGNhdXNlPy5yb3V0ZUlkID8gaW5kZXggOiBmYWxsYmFjaztcbn1cbmZ1bmN0aW9uIGFib3J0TWF0Y2hlcyhtYXRjaGVzLCBzdGFydCA9IDAsIHJlYXNvbiA9IE1BVENIX1NFVFRMRURfQUJPUlRfUkVBU09OKSB7XG5cdGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIG1hdGNoZXNbaW5kZXhdLmFib3J0Q29udHJvbGxlci5hYm9ydChyZWFzb24pO1xufVxuYXN5bmMgZnVuY3Rpb24gYXBwbHlGYWlsdXJlKHJvdXRlciwgbGFuZSwgaW5kZXhlZCwgc2lnbmFsKSB7XG5cdGlmICghaW5kZXhlZCkge1xuXHRcdGNvbnN0IGJvdW5kYXJ5ID0gbGFuZS5tYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdFx0aWYgKGJvdW5kYXJ5ID49IDApIHtcblx0XHRcdGFib3J0TWF0Y2hlcyhsYW5lLm1hdGNoZXMsIGJvdW5kYXJ5ICsgMSk7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRzdGF0dXM6IDQwNCxcblx0XHRcdFx0Ym91bmRhcnksXG5cdFx0XHRcdGtpbmQ6IE5PVF9GT1VORFxuXHRcdFx0fTtcblx0XHR9XG5cdFx0cmV0dXJuIHsgc3RhdHVzOiAyMDAgfTtcblx0fVxuXHRjb25zdCBbaW5kZXgsIG91dGNvbWVdID0gaW5kZXhlZDtcblx0aWYgKG91dGNvbWVbMF0gPT09IEVSUk9SKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBsYW5lLm1hdGNoZXNbaW5kZXhdO1xuXHRcdG1hdGNoLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRtYXRjaC5zdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0bWF0Y2guZXJyb3IgPSBvdXRjb21lWzFdO1xuXHRcdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHRhYm9ydE1hdGNoZXMobGFuZS5tYXRjaGVzLCBpbmRleCArIDEpO1xuXHRcdHJldHVybiB7XG5cdFx0XHRzdGF0dXM6IDUwMCxcblx0XHRcdGJvdW5kYXJ5OiBpbmRleCxcblx0XHRcdGtpbmQ6IEVSUk9SXG5cdFx0fTtcblx0fVxuXHRjb25zdCBib3VuZGFyeSA9IGluZGV4ZWRbMl0gPz8gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIGxhbmUubWF0Y2hlcywgaW5kZXhlZCwgc2lnbmFsKTtcblx0Y29uc3QgbWF0Y2ggPSBsYW5lLm1hdGNoZXNbYm91bmRhcnldO1xuXHRjb25zdCBjYXVzZSA9IG91dGNvbWVbMV07XG5cdGNhdXNlLnJvdXRlSWQgPSBtYXRjaC5yb3V0ZUlkO1xuXHRtYXRjaC5fbm90Rm91bmQgPSB2b2lkIDA7XG5cdGlmIChtYXRjaC5yb3V0ZUlkID09PSByb3V0ZXIucm91dGVUcmVlLmlkKSB7XG5cdFx0bWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0bWF0Y2guX25vdEZvdW5kID0gdHJ1ZTtcblx0XHRtYXRjaC5lcnJvciA9IGNhdXNlO1xuXHR9IGVsc2Uge1xuXHRcdG1hdGNoLnN0YXR1cyA9IFwibm90Rm91bmRcIjtcblx0XHRtYXRjaC5lcnJvciA9IGNhdXNlO1xuXHR9XG5cdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0YWJvcnRNYXRjaGVzKGxhbmUubWF0Y2hlcywgYm91bmRhcnkgKyAxKTtcblx0cmV0dXJuIHtcblx0XHRzdGF0dXM6IDQwNCxcblx0XHRib3VuZGFyeSxcblx0XHRraW5kOiBOT1RfRk9VTkRcblx0fTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGxvYWROb3JtYWxDaHVua3Mocm91dGVyLCBsYW5lLCBlbmQsIHNpZ25hbCkge1xuXHRjb25zdCBjaHVua3MgPSBbXTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGxhbmUubWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tpbmRleF07XG5cdFx0aWYgKGluZGV4ID49IGVuZCB8fCBtYXRjaC5zc3IgIT09IHRydWUgfHwgbWF0Y2guc3RhdHVzICE9PSBcInN1Y2Nlc3NcIikgY29udGludWU7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgbG9hZGluZyA9IGxvYWRSb3V0ZUNodW5rKHJvdXRlKTtcblx0XHRcdGlmIChsb2FkaW5nKSB7XG5cdFx0XHRcdGNvbnN0IGNodW5rID0gbG9hZGluZy50aGVuKCgpID0+IHtcblx0XHRcdFx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0XHRcdH0sIChjYXVzZSkgPT4ge1xuXHRcdFx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdFx0XHRyZXR1cm4gW2luZGV4LCBzdGFtcE5vdEZvdW5kKG1hdGNoLCBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgc2lnbmFsKSldO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0Y2h1bmsuY2F0Y2goKCkgPT4ge30pO1xuXHRcdFx0XHRjaHVua3MucHVzaChjaHVuayk7XG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdGNodW5rcy5wdXNoKFtpbmRleCwgc3RhbXBOb3RGb3VuZChtYXRjaCwgbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCkpXSk7XG5cdFx0fVxuXHR9XG5cdGZvciAoY29uc3QgY2h1bmsgb2YgY2h1bmtzKSB7XG5cdFx0Y29uc3QgaW5kZXhlZCA9IEFycmF5LmlzQXJyYXkoY2h1bmspID8gY2h1bmsgOiBhd2FpdCBjaHVuaztcblx0XHRpZiAoaW5kZXhlZCkgcmV0dXJuIGluZGV4ZWQ7XG5cdH1cbn1cbmFzeW5jIGZ1bmN0aW9uIHByb2plY3RMYW5lKHJvdXRlciwgbGFuZSwgc2lnbmFsKSB7XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgbGFuZS5tYXRjaGVzKSB7XG5cdFx0Y29uc3Qgcm91dGVPcHRpb25zID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCkub3B0aW9ucztcblx0XHRpZiAocm91dGVPcHRpb25zLmhlYWQgfHwgcm91dGVPcHRpb25zLnNjcmlwdHMgfHwgcm91dGVPcHRpb25zLmhlYWRlcnMpIHtcblx0XHRcdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0XHRcdHNzcjogcm91dGVyLm9wdGlvbnMuc3NyLFxuXHRcdFx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXMsXG5cdFx0XHRcdG1hdGNoLFxuXHRcdFx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRcdFx0bG9hZGVyRGF0YTogbWF0Y2gubG9hZGVyRGF0YVxuXHRcdFx0fTtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IFtoZWFkLCBzY3JpcHRzLCBoZWFkZXJzXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcblx0XHRcdFx0XHRyb3V0ZU9wdGlvbnMuaGVhZD8uKGNvbnRleHQpLFxuXHRcdFx0XHRcdHJvdXRlT3B0aW9ucy5zY3JpcHRzPy4oY29udGV4dCksXG5cdFx0XHRcdFx0cm91dGVPcHRpb25zLmhlYWRlcnM/Lihjb250ZXh0KVxuXHRcdFx0XHRdKTtcblx0XHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0XHRtYXRjaC5tZXRhID0gaGVhZD8ubWV0YTtcblx0XHRcdFx0bWF0Y2gubGlua3MgPSBoZWFkPy5saW5rcztcblx0XHRcdFx0bWF0Y2guaGVhZFNjcmlwdHMgPSBoZWFkPy5zY3JpcHRzO1xuXHRcdFx0XHRtYXRjaC5zdHlsZXMgPSBoZWFkPy5zdHlsZXM7XG5cdFx0XHRcdG1hdGNoLnNjcmlwdHMgPSBzY3JpcHRzO1xuXHRcdFx0XHRtYXRjaC5oZWFkZXJzID0gaGVhZGVycztcblx0XHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdFx0Y29uc29sZS5lcnJvcihjYXVzZSk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChtYXRjaC5zc3IgPT09IGZhbHNlIHx8IG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgbWF0Y2guX25vdEZvdW5kKSBicmVhaztcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gZXhlY3V0ZVNlcnZlckxhbmUocm91dGVyLCBsb2NhdGlvbiwgbWF0Y2hlZE1hdGNoZXMsIHNpZ25hbCkge1xuXHRjb25zdCBtYXRjaGVkID0ge1xuXHRcdGxvY2F0aW9uLFxuXHRcdG1hdGNoZXM6IG1hdGNoZWRNYXRjaGVzLm1hcCgobWF0Y2gpID0+ICh7XG5cdFx0XHQuLi5tYXRjaCxcblx0XHRcdF9fYmVmb3JlTG9hZENvbnRleHQ6IHZvaWQgMCxcblx0XHRcdGNvbnRleHQ6IHt9LFxuXHRcdFx0aXNGZXRjaGluZzogZmFsc2UsXG5cdFx0XHRhYm9ydENvbnRyb2xsZXI6IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxuXHRcdH0pKVxuXHR9O1xuXHRjb25zdCBhYm9ydExhbmUgPSAoKSA9PiBhYm9ydE1hdGNoZXMobWF0Y2hlZC5tYXRjaGVzLCAwLCBzaWduYWw/LnJlYXNvbiA/PyBNQVRDSF9TRVRUTEVEX0FCT1JUX1JFQVNPTik7XG5cdGlmIChzaWduYWw/LmFib3J0ZWQpIHtcblx0XHRhYm9ydExhbmUoKTtcblx0XHRzaWduYWwudGhyb3dJZkFib3J0ZWQoKTtcblx0fVxuXHRzaWduYWw/LmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydExhbmUsIHsgb25jZTogdHJ1ZSB9KTtcblx0dHJ5IHtcblx0XHRjb25zdCBwbGFubmVkR2xvYmFsQm91bmRhcnkgPSBtYXRjaGVkLm1hdGNoZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guX25vdEZvdW5kKTtcblx0XHRpZiAocm91dGVyLm9wdGlvbnMubm90Rm91bmRNb2RlICE9PSBcInJvb3RcIiAmJiBwbGFubmVkR2xvYmFsQm91bmRhcnkgPj0gMCkge1xuXHRcdFx0Y29uc3QgYm91bmRhcnkgPSBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlZC5tYXRjaGVzLCB2b2lkIDAsIHNpZ25hbCwgcGxhbm5lZEdsb2JhbEJvdW5kYXJ5KTtcblx0XHRcdGlmIChib3VuZGFyeSAhPT0gcGxhbm5lZEdsb2JhbEJvdW5kYXJ5KSB7XG5cdFx0XHRcdG1hdGNoZWQubWF0Y2hlc1twbGFubmVkR2xvYmFsQm91bmRhcnldLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0XHRcdFx0bWF0Y2hlZC5tYXRjaGVzW2JvdW5kYXJ5XS5fbm90Rm91bmQgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRjb25zdCBsYW5lID0gYXdhaXQgY29udGV4dHVhbGl6ZShyb3V0ZXIsIG1hdGNoZWQsIHNpZ25hbCk7XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGxldCBsb2FkZXJFbmQgPSBsYW5lLmVuZDtcblx0XHRpZiAobGFuZS5mYWlsdXJlPy5bMV1bMF0gPT09IFJFRElSRUNURUQpIGxvYWRlckVuZCA9IDA7XG5cdFx0ZWxzZSBpZiAobGFuZS5mYWlsdXJlPy5bMV1bMF0gPT09IE5PVF9GT1VORCkge1xuXHRcdFx0bGFuZS5mYWlsdXJlWzJdID0gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIGxhbmUubWF0Y2hlcywgbGFuZS5mYWlsdXJlLCBzaWduYWwpO1xuXHRcdFx0bG9hZGVyRW5kID0gTWF0aC5taW4obG9hZGVyRW5kLCBsYW5lLmZhaWx1cmVbMl0gKyAxKTtcblx0XHR9XG5cdFx0Y29uc3QgdGFza3MgPSBbXTtcblx0XHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbG9hZGVyRW5kOyBpbmRleCsrKSB7XG5cdFx0XHRjb25zdCB0YXNrID0gY3JlYXRlTG9hZGVyVGFzayhyb3V0ZXIsIGxhbmUsIGluZGV4LCB0YXNrcywgc2lnbmFsKTtcblx0XHRcdHRhc2tzLnB1c2godGFzayk7XG5cdFx0fVxuXHRcdGxldCBsb2FkZXJGYWlsdXJlO1xuXHRcdGxldCBjb250cm9sID0gbGFuZS5mYWlsdXJlPy5bMV1bMF0gPT09IFJFRElSRUNURUQgPyBsYW5lLmZhaWx1cmUgOiB2b2lkIDA7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IFByb21pc2UuYWxsKHRhc2tzLm1hcCgodGFzaykgPT4gdGFzay5vdXRjb21lLnRoZW4oKGxvYWRlZE91dGNvbWUpID0+IHtcblx0XHRcdFx0Y29uc3QgbWF0Y2ggPSBsYW5lLm1hdGNoZXNbdGFzay5pbmRleF07XG5cdFx0XHRcdGNvbnN0IG91dGNvbWUgPSBsb2FkZWRPdXRjb21lO1xuXHRcdFx0XHRpZiAob3V0Y29tZVswXSA9PT0gU1VDQ0VTUykge1xuXHRcdFx0XHRcdG1hdGNoLmxvYWRlckRhdGEgPSBvdXRjb21lWzFdO1xuXHRcdFx0XHRcdG1hdGNoLnN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdFx0XHRcdG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRcdFx0XHRcdG1hdGNoLmludmFsaWQgPSBmYWxzZTtcblx0XHRcdFx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0XHRcdFx0bWF0Y2gudXBkYXRlZEF0ID0gRGF0ZS5ub3coKTtcblx0XHRcdFx0fSBlbHNlIGlmIChvdXRjb21lWzBdID09PSBSRURJUkVDVEVEKSB7XG5cdFx0XHRcdFx0Y29udHJvbCA9IFt0YXNrLmluZGV4LCBvdXRjb21lXTtcblx0XHRcdFx0XHR0aHJvdyBjb250cm9sO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGlmIChtYXRjaC5zc3IgIT09IGZhbHNlKSB7XG5cdFx0XHRcdFx0XHRtYXRjaC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRcdFx0XHRcdG1hdGNoLmVycm9yID0gdm9pZCAwO1xuXHRcdFx0XHRcdFx0bWF0Y2guaW52YWxpZCA9IHRydWU7XG5cdFx0XHRcdFx0XHRtYXRjaC5pc0ZldGNoaW5nID0gZmFsc2U7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICghbG9hZGVyRmFpbHVyZSAmJiBvdXRjb21lWzBdICE9PSBTS0lQUEVEKSBsb2FkZXJGYWlsdXJlID0gW3Rhc2suaW5kZXgsIG91dGNvbWVdO1xuXHRcdFx0XHR9XG5cdFx0XHR9KSkpO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoIUFycmF5LmlzQXJyYXkoY2F1c2UpKSB0aHJvdyBjYXVzZTtcblx0XHRcdGNvbnRyb2wgPSBjYXVzZTtcblx0XHR9XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChjb250cm9sPy5bMV1bMF0gPT09IFJFRElSRUNURUQpIHtcblx0XHRcdGFib3J0TWF0Y2hlcyhsYW5lLm1hdGNoZXMsIDAsIFJFRElSRUNUX0FCT1JUX1JFQVNPTik7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHR0eXBlOiBcInJlZGlyZWN0XCIsXG5cdFx0XHRcdHJlZGlyZWN0OiBjb250cm9sWzFdWzFdXG5cdFx0XHR9O1xuXHRcdH1cblx0XHRsZXQgZmFpbHVyZSA9IGxhbmUuZmFpbHVyZSA/PyBsb2FkZXJGYWlsdXJlO1xuXHRcdGNvbnN0IHBsYW5uZWRCb3VuZGFyeSA9IGxhbmUubWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpO1xuXHRcdGxldCByZWFkaW5lc3NFbmQ7XG5cdFx0aWYgKGZhaWx1cmUpIHtcblx0XHRcdGNvbnN0IG91dGNvbWVFbmQgPSBmYWlsdXJlWzJdID8/PSBmYWlsdXJlWzFdWzBdID09PSBOT1RfRk9VTkQgPyBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbGFuZS5tYXRjaGVzLCBmYWlsdXJlLCBzaWduYWwpIDogZmFpbHVyZVswXTtcblx0XHRcdGZvciAoY29uc3QgdGFzayBvZiB0YXNrcykge1xuXHRcdFx0XHRpZiAodGFzay5pbmRleCA+PSBvdXRjb21lRW5kKSBicmVhaztcblx0XHRcdFx0Y29uc3Qgb3V0Y29tZSA9IGF3YWl0IHRhc2sub3V0Y29tZTtcblx0XHRcdFx0aWYgKG91dGNvbWVbMF0gIT09IFNVQ0NFU1MgJiYgb3V0Y29tZVswXSA8IFJFRElSRUNURUQgJiYgIShcImxvYWRlckRhdGFcIiBpbiBsYW5lLm1hdGNoZXNbdGFzay5pbmRleF0pKSB7XG5cdFx0XHRcdFx0ZmFpbHVyZSA9IFt0YXNrLmluZGV4LCBvdXRjb21lXTtcblx0XHRcdFx0XHRmYWlsdXJlWzJdID0gb3V0Y29tZVswXSA9PT0gTk9UX0ZPVU5EID8gYXdhaXQgZ2V0Tm90Rm91bmRCb3VuZGFyeShyb3V0ZXIsIGxhbmUubWF0Y2hlcywgZmFpbHVyZSwgc2lnbmFsKSA6IHRhc2suaW5kZXg7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJlYWRpbmVzc0VuZCA9IGZhaWx1cmVbMl07XG5cdFx0fSBlbHNlIHJlYWRpbmVzc0VuZCA9IHBsYW5uZWRCb3VuZGFyeSA8IDAgPyBsYW5lLm1hdGNoZXMubGVuZ3RoIDogcGxhbm5lZEJvdW5kYXJ5O1xuXHRcdGNvbnN0IHJlcXVpcmVkRmFpbHVyZSA9IGF3YWl0IGxvYWROb3JtYWxDaHVua3Mocm91dGVyLCBsYW5lLCByZWFkaW5lc3NFbmQsIHNpZ25hbCk7XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChyZXF1aXJlZEZhaWx1cmUpIHtcblx0XHRcdGlmIChyZXF1aXJlZEZhaWx1cmVbMV1bMF0gPT09IFJFRElSRUNURUQpIHtcblx0XHRcdFx0YWJvcnRNYXRjaGVzKGxhbmUubWF0Y2hlcywgMCwgUkVESVJFQ1RfQUJPUlRfUkVBU09OKTtcblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHR0eXBlOiBcInJlZGlyZWN0XCIsXG5cdFx0XHRcdFx0cmVkaXJlY3Q6IHJlcXVpcmVkRmFpbHVyZVsxXVsxXVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdFx0ZmFpbHVyZSA9IHJlcXVpcmVkRmFpbHVyZTtcblx0XHR9XG5cdFx0Y29uc3QgdGVybWluYWwgPSBhd2FpdCBhcHBseUZhaWx1cmUocm91dGVyLCBsYW5lLCBmYWlsdXJlLCBzaWduYWwpO1xuXHRcdGlmICh0ZXJtaW5hbC5ib3VuZGFyeSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1t0ZXJtaW5hbC5ib3VuZGFyeV07XG5cdFx0XHRpZiAobWF0Y2guc3NyID09PSB0cnVlKSB7XG5cdFx0XHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0aWYgKHRlcm1pbmFsLmtpbmQgPT09IEVSUk9SKSBhd2FpdCBsb2FkUm91dGVDaHVuayhyb3V0ZSwgXCJlcnJvckNvbXBvbmVudFwiKTtcblx0XHRcdFx0XHRlbHNlIGlmIChtYXRjaC5fbm90Rm91bmQpIGF3YWl0IFByb21pc2UuYWxsKFtsb2FkUm91dGVDaHVuayhyb3V0ZSksIGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBcIm5vdEZvdW5kQ29tcG9uZW50XCIpXSk7XG5cdFx0XHRcdFx0ZWxzZSBhd2FpdCBsb2FkUm91dGVDaHVuayhyb3V0ZSwgXCJub3RGb3VuZENvbXBvbmVudFwiKTtcblx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRhd2FpdCBwcm9qZWN0TGFuZShyb3V0ZXIsIHtcblx0XHRcdGxvY2F0aW9uOiBsYW5lLmxvY2F0aW9uLFxuXHRcdFx0bWF0Y2hlczogbGFuZS5tYXRjaGVzXG5cdFx0fSwgc2lnbmFsKTtcblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0cm91dGVyLnNlcnZlclNzcj8ub25DbGVhbnVwKChzZXR0bGVkKSA9PiB7XG5cdFx0XHRpZiAoIXNldHRsZWQpIGFib3J0TGFuZSgpO1xuXHRcdH0pO1xuXHRcdHJldHVybiB7XG5cdFx0XHR0eXBlOiBcInJlbmRlclwiLFxuXHRcdFx0c3RhdHVzOiB0ZXJtaW5hbC5zdGF0dXMsXG5cdFx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXNcblx0XHR9O1xuXHR9IGZpbmFsbHkge1xuXHRcdHNpZ25hbD8ucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGFib3J0TGFuZSk7XG5cdH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGxvYWRTZXJ2ZXJSb3V0ZShyb3V0ZXIsIG9wdHMpIHtcblx0cm91dGVyLnVwZGF0ZUxhdGVzdExvY2F0aW9uKCk7XG5cdGNvbnN0IG5leHQgPSByb3V0ZXIubGF0ZXN0TG9jYXRpb247XG5cdGNvbnN0IHByZXZpb3VzID0gcm91dGVyLl9jb21taXR0ZWQ7XG5cdGNvbnN0IHByZXZpb3VzRW5kID0gcm91dGVyLl9saWZlY3ljbGVFbmQ7XG5cdGxldCByZXN1bHQ7XG5cdHRyeSB7XG5cdFx0Y29uc3QgY2Fub25pY2FsID0gcm91dGVyLmJ1aWxkTG9jYXRpb24oe1xuXHRcdFx0dG86IG5leHQucGF0aG5hbWUsXG5cdFx0XHRzZWFyY2g6IHRydWUsXG5cdFx0XHRwYXJhbXM6IHRydWUsXG5cdFx0XHRoYXNoOiB0cnVlLFxuXHRcdFx0c3RhdGU6IHRydWUsXG5cdFx0XHRfaW5jbHVkZVZhbGlkYXRlU2VhcmNoOiB0cnVlXG5cdFx0fSk7XG5cdFx0aWYgKG5leHQucHVibGljSHJlZiAhPT0gY2Fub25pY2FsLnB1YmxpY0hyZWYpIHRocm93IHJlZGlyZWN0KHsgaHJlZjogY2Fub25pY2FsLnB1YmxpY0hyZWYgfHwgXCIvXCIgfSk7XG5cdFx0Y29uc3QgY2hhbmdlSW5mbyA9IGdldExvY2F0aW9uQ2hhbmdlSW5mbyhuZXh0LCByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCkpO1xuXHRcdHJvdXRlci5lbWl0KHtcblx0XHRcdHR5cGU6IFwib25CZWZvcmVOYXZpZ2F0ZVwiLFxuXHRcdFx0Li4uY2hhbmdlSW5mb1xuXHRcdH0pO1xuXHRcdHJvdXRlci5lbWl0KHtcblx0XHRcdHR5cGU6IFwib25CZWZvcmVMb2FkXCIsXG5cdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0fSk7XG5cdFx0b3B0cz8uX3NpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRyZXN1bHQgPSBhd2FpdCB3YWl0Rm9yKGV4ZWN1dGVTZXJ2ZXJMYW5lKHJvdXRlciwgbmV4dCwgcm91dGVyLm1hdGNoUm91dGVzKG5leHQpLCBvcHRzPy5fc2lnbmFsKSwgb3B0cz8uX3NpZ25hbCk7XG5cdFx0b3B0cz8uX3NpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRvcHRzPy5fc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmICghaXNSZWRpcmVjdChjYXVzZSkpIHRocm93IGNhdXNlO1xuXHRcdGNhdXNlLm9wdGlvbnMuX2Zyb21Mb2NhdGlvbiA9IG5leHQ7XG5cdFx0cmVzdWx0ID0ge1xuXHRcdFx0dHlwZTogXCJyZWRpcmVjdFwiLFxuXHRcdFx0cmVkaXJlY3Q6IHJvdXRlci5yZXNvbHZlUmVkaXJlY3QoY2F1c2UpXG5cdFx0fTtcblx0fVxuXHRyb3V0ZXIuX3NlcnZlclJlc3VsdCA9IHJlc3VsdDtcblx0bGV0IG5leHRFbmQgPSAwO1xuXHRyb3V0ZXIuYmF0Y2goKCkgPT4ge1xuXHRcdHJvdXRlci5zdG9yZXMubG9jYXRpb24uc2V0KG5leHQpO1xuXHRcdHJvdXRlci5zdG9yZXMuc3RhdHVzLnNldChcImlkbGVcIik7XG5cdFx0aWYgKHJlc3VsdC50eXBlID09PSBcInJlbmRlclwiKSB7XG5cdFx0XHRyb3V0ZXIuX2NvbW1pdHRlZCA9IHJlc3VsdC5tYXRjaGVzO1xuXHRcdFx0bmV4dEVuZCA9IHJvdXRlci5fbGlmZWN5Y2xlRW5kID0gbGlmZWN5Y2xlRW5kKHJlc3VsdC5tYXRjaGVzKTtcblx0XHRcdHJvdXRlci5zdG9yZXMuc2V0TWF0Y2hlcyhyZXN1bHQubWF0Y2hlcyk7XG5cdFx0XHRyb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uc2V0KG5leHQpO1xuXHRcdH1cblx0fSk7XG5cdGlmIChyZXN1bHQudHlwZSA9PT0gXCJyZW5kZXJcIikgcnVuUm91dGVMaWZlY3ljbGUocm91dGVyLCBwcmV2aW91cywgcmVzdWx0Lm1hdGNoZXMsIHByZXZpb3VzRW5kLCBuZXh0RW5kKTtcblx0cm91dGVyLl9jb21taXRQcm9taXNlPy5yZXNvbHZlKCk7XG5cdHJvdXRlci5fY29tbWl0UHJvbWlzZSA9IHZvaWQgMDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbG9hZFNlcnZlclJvdXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxvYWQtc2VydmVyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuLyoqXG4qIFJlYWN0LnVzZSBpZiBhdmFpbGFibGUgKFJlYWN0IDE5KyksIHVuZGVmaW5lZCBvdGhlcndpc2UuXG4qIFVzZSBkeW5hbWljIGxvb2t1cCB0byBhdm9pZCBXZWJwYWNrIGNvbXBpbGF0aW9uIGVycm9ycyB3aXRoIFJlYWN0IDE4LlxuKi9cbnZhciByZWFjdFVzZSA9IFJlYWN0JDFbXCJ1c2VcIl07XG52YXIgdXNlTGF5b3V0RWZmZWN0ID0gaXNTZXJ2ZXIgPz8gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIiA/IFJlYWN0JDEudXNlRWZmZWN0IDogUmVhY3QkMS51c2VMYXlvdXRFZmZlY3Q7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHJlYWN0VXNlLCB1c2VMYXlvdXRFZmZlY3QgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXRpbHMuanMubWFwIiwiaW1wb3J0IHsgZGVmYXVsdFNlcmlhbGl6ZUVycm9yIH0gZnJvbSBcIi4vcm91dGVyLmpzXCI7XG4vLyNyZWdpb24gc3JjL2RlZmVyLnRzXG4vKipcbiogV2VsbC1rbm93biBzeW1ib2wgdXNlZCBieSB7QGxpbmsgZGVmZXJ9IHRvIHRhZyBhIHByb21pc2Ugd2l0aFxuKiBpdHMgZGVmZXJyZWQgc3RhdGUuIENvbnN1bWVycyBjYW4gcmVhZCBgcHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV1gXG4qIHRvIGFjY2VzcyBgc3RhdHVzYCwgYGRhdGFgLCBvciBgZXJyb3JgLlxuKi9cbmNvbnN0IFRTUl9ERUZFUlJFRF9QUk9NSVNFID0gU3ltYm9sLmZvcihcIlRTUl9ERUZFUlJFRF9QUk9NSVNFXCIpO1xuLyoqXG4qIFdyYXAgYSBwcm9taXNlIHdpdGggYSBkZWZlcnJlZCBzdGF0ZSBmb3IgdXNlIHdpdGggYDxBd2FpdD5gIGFuZCBgdXNlQXdhaXRlZGAuXG4qXG4qIFRoZSByZXR1cm5lZCBwcm9taXNlIGlzIGF1Z21lbnRlZCB3aXRoIGludGVybmFsIHN0YXRlIChzdGF0dXMvZGF0YS9lcnJvcilcbiogc28gVUkgY2FuIHJlYWQgcHJvZ3Jlc3Mgb3Igc3VzcGVuZCB1bnRpbCBpdCBzZXR0bGVzLlxuKlxuKiBAcGFyYW0gX3Byb21pc2UgVGhlIHByb21pc2UgdG8gd3JhcC5cbiogQHBhcmFtIG9wdGlvbnMgT3B0aW9uYWwgY29uZmlnLiBQcm92aWRlIGBzZXJpYWxpemVFcnJvcmAgdG8gY3VzdG9taXplIGhvd1xuKiBlcnJvcnMgYXJlIHNlcmlhbGl6ZWQgZm9yIHRyYW5zZmVyLlxuKiBAcmV0dXJucyBUaGUgc2FtZSBwcm9taXNlIHdpdGggYXR0YWNoZWQgZGVmZXJyZWQgbWV0YWRhdGEuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9kZWZlckZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gZGVmZXIoX3Byb21pc2UsIG9wdGlvbnMpIHtcblx0Y29uc3QgcHJvbWlzZSA9IF9wcm9taXNlO1xuXHRpZiAocHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0pIHJldHVybiBwcm9taXNlO1xuXHRwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXSA9IHsgc3RhdHVzOiBcInBlbmRpbmdcIiB9O1xuXHRwcm9taXNlLnRoZW4oKGRhdGEpID0+IHtcblx0XHRwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5kYXRhID0gZGF0YTtcblx0fSkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0cHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0uc3RhdHVzID0gXCJlcnJvclwiO1xuXHRcdHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLmVycm9yID0ge1xuXHRcdFx0ZGF0YTogKG9wdGlvbnM/LnNlcmlhbGl6ZUVycm9yID8/IGRlZmF1bHRTZXJpYWxpemVFcnJvcikoZXJyb3IpLFxuXHRcdFx0X19pc1NlcnZlckVycm9yOiB0cnVlXG5cdFx0fTtcblx0fSk7XG5cdHJldHVybiBwcm9taXNlO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBUU1JfREVGRVJSRURfUFJPTUlTRSwgZGVmZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZGVmZXIuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9saW5rLnRzXG5jb25zdCBwcmVsb2FkV2FybmluZyA9IFwiRXJyb3IgcHJlbG9hZGluZyByb3V0ZSEg4pid77iPXCI7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHByZWxvYWRXYXJuaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxpbmsuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9tYW5pZmVzdC50c1xuY29uc3QgREVWX1NUWUxFU19BVFRSID0gXCJkYXRhLXRhbnN0YWNrLXJvdXRlci1kZXYtc3R5bGVzXCI7XG5mdW5jdGlvbiBnZXRBc3NldENyb3NzT3JpZ2luKGFzc2V0Q3Jvc3NPcmlnaW4sIGtpbmQpIHtcblx0aWYgKCFhc3NldENyb3NzT3JpZ2luKSByZXR1cm47XG5cdGlmICh0eXBlb2YgYXNzZXRDcm9zc09yaWdpbiA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIGFzc2V0Q3Jvc3NPcmlnaW47XG5cdHJldHVybiBhc3NldENyb3NzT3JpZ2luW2tpbmRdO1xufVxuZnVuY3Rpb24gZ2V0TWFuaWZlc3RTY3JpcHRGb3JtYXQobWFuaWZlc3QpIHtcblx0cmV0dXJuIG1hbmlmZXN0Py5zY3JpcHRGb3JtYXQgPz8gXCJtb2R1bGVcIjtcbn1cbmZ1bmN0aW9uIGdldFNjcmlwdFByZWxvYWRBdHRycyhtYW5pZmVzdCwgbGluaywgYXNzZXRDcm9zc09yaWdpbikge1xuXHRjb25zdCBwcmVsb2FkTGluayA9IHJlc29sdmVNYW5pZmVzdEFzc2V0TGluayhsaW5rKTtcblx0Y29uc3QgY3Jvc3NPcmlnaW4gPSBnZXRBc3NldENyb3NzT3JpZ2luKGFzc2V0Q3Jvc3NPcmlnaW4sIFwic2NyaXB0XCIpID8/IHByZWxvYWRMaW5rLmNyb3NzT3JpZ2luO1xuXHRyZXR1cm4ge1xuXHRcdC4uLmdldE1hbmlmZXN0U2NyaXB0Rm9ybWF0KG1hbmlmZXN0KSA9PT0gXCJpaWZlXCIgPyB7XG5cdFx0XHRyZWw6IFwicHJlbG9hZFwiLFxuXHRcdFx0YXM6IFwic2NyaXB0XCJcblx0XHR9IDogeyByZWw6IFwibW9kdWxlcHJlbG9hZFwiIH0sXG5cdFx0aHJlZjogcHJlbG9hZExpbmsuaHJlZixcblx0XHQuLi5jcm9zc09yaWdpbiA/IHsgY3Jvc3NPcmlnaW4gfSA6IHt9XG5cdH07XG59XG5mdW5jdGlvbiByZXNvbHZlTWFuaWZlc3RBc3NldExpbmsobGluaykge1xuXHRpZiAodHlwZW9mIGxpbmsgPT09IFwic3RyaW5nXCIpIHJldHVybiB7XG5cdFx0aHJlZjogbGluayxcblx0XHRjcm9zc09yaWdpbjogdm9pZCAwXG5cdH07XG5cdHJldHVybiBsaW5rO1xufVxuZnVuY3Rpb24gYXBwZW5kVW5pcXVlVXNlclRhZ3ModGFyZ2V0LCB0YWdzKSB7XG5cdGlmICh0YWdzLmxlbmd0aCA9PT0gMCkgcmV0dXJuO1xuXHRpZiAodGFncy5sZW5ndGggPT09IDEpIHtcblx0XHR0YXJnZXQucHVzaCh0YWdzWzBdKTtcblx0XHRyZXR1cm47XG5cdH1cblx0Y29uc3Qgc2VlbiA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGZvciAoY29uc3QgdGFnIG9mIHRhZ3MpIHtcblx0XHRjb25zdCBrZXkgPSBKU09OLnN0cmluZ2lmeSh0YWcpO1xuXHRcdGlmIChzZWVuLmhhcyhrZXkpKSBjb250aW51ZTtcblx0XHRzZWVuLmFkZChrZXkpO1xuXHRcdHRhcmdldC5wdXNoKHRhZyk7XG5cdH1cbn1cbmZ1bmN0aW9uIGdldFN0eWxlc2hlZXRIcmVmKGFzc2V0KSB7XG5cdHJldHVybiByZXNvbHZlTWFuaWZlc3RDc3NMaW5rKGFzc2V0KS5ocmVmO1xufVxuZnVuY3Rpb24gcmVzb2x2ZU1hbmlmZXN0Q3NzTGluayhsaW5rKSB7XG5cdGlmICh0eXBlb2YgbGluayA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIHtcblx0XHRocmVmOiBsaW5rLFxuXHRcdGNyb3NzT3JpZ2luOiB2b2lkIDBcblx0fTtcblx0cmV0dXJuIGxpbms7XG59XG5mdW5jdGlvbiBjcmVhdGVJbmxpbmVDc3NTdHlsZUFzc2V0KGNzcykge1xuXHRyZXR1cm4ge1xuXHRcdGF0dHJzOiB7IHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZSB9LFxuXHRcdGNoaWxkcmVuOiBjc3Ncblx0fTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUlubGluZUNzc1BsYWNlaG9sZGVyQXNzZXQoKSB7XG5cdHJldHVybiB7IGF0dHJzOiB7IHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZSB9IH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IERFVl9TVFlMRVNfQVRUUiwgYXBwZW5kVW5pcXVlVXNlclRhZ3MsIGNyZWF0ZUlubGluZUNzc1BsYWNlaG9sZGVyQXNzZXQsIGNyZWF0ZUlubGluZUNzc1N0eWxlQXNzZXQsIGdldEFzc2V0Q3Jvc3NPcmlnaW4sIGdldE1hbmlmZXN0U2NyaXB0Rm9ybWF0LCBnZXRTY3JpcHRQcmVsb2FkQXR0cnMsIGdldFN0eWxlc2hlZXRIcmVmLCByZXNvbHZlTWFuaWZlc3RBc3NldExpbmssIHJlc29sdmVNYW5pZmVzdENzc0xpbmsgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bWFuaWZlc3QuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9NYXRjaGVzLnRzXG4vKipcbiogTmFycm93cyBtYXRjaGVzIGJhc2VkIG9uIGEgcGF0aFxuKiBAZXhwZXJpbWVudGFsXG4qL1xuY29uc3QgaXNNYXRjaCA9IChtYXRjaCwgcGF0aCkgPT4ge1xuXHRjb25zdCBwYXJ0cyA9IHBhdGguc3BsaXQoXCIuXCIpO1xuXHRsZXQgcGFydDtcblx0bGV0IGkgPSAwO1xuXHRsZXQgdmFsdWUgPSBtYXRjaDtcblx0d2hpbGUgKChwYXJ0ID0gcGFydHNbaSsrXSkgIT0gbnVsbCAmJiB2YWx1ZSAhPSBudWxsKSB2YWx1ZSA9IHZhbHVlW3BhcnRdO1xuXHRyZXR1cm4gdmFsdWUgIT0gbnVsbDtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzTWF0Y2ggfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9TWF0Y2hlcy5qcy5tYXAiLCJpbXBvcnQgeyBfZ2V0QXNzZXRNYXRjaGVzIH0gZnJvbSBcIi4uL2xvYWQtY2xpZW50LmpzXCI7XG4vLyNyZWdpb24gc3JjL3Nzci9ib2R5U2NyaXB0cy50c1xuZnVuY3Rpb24gZ2V0U3NyQm9keVNjcmlwdFBhcnRzKG1hdGNoZXMsIG1hbmlmZXN0LCBub25jZSwgcm91dGVTY3JpcHRBdHRycykge1xuXHRjb25zdCBhc3NldE1hdGNoZXMgPSBfZ2V0QXNzZXRNYXRjaGVzKG1hdGNoZXMpO1xuXHRjb25zdCByb3V0ZVNjcmlwdHMgPSBbXTtcblx0Y29uc3QgbWFuaWZlc3RTY3JpcHRzID0gW107XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgYXNzZXRNYXRjaGVzKSBmb3IgKGNvbnN0IHNjcmlwdCBvZiBBcnJheS5pc0FycmF5KG1hdGNoLnNjcmlwdHMpID8gbWF0Y2guc2NyaXB0cyA6IFtdKSB7XG5cdFx0aWYgKCFzY3JpcHQpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IHsgY2hpbGRyZW4sIC4uLmF0dHJzIH0gPSBzY3JpcHQ7XG5cdFx0cm91dGVTY3JpcHRzLnB1c2goe1xuXHRcdFx0dGFnOiBcInNjcmlwdFwiLFxuXHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRcdC4uLnJvdXRlU2NyaXB0QXR0cnMsXG5cdFx0XHRcdG5vbmNlXG5cdFx0XHR9LFxuXHRcdFx0Y2hpbGRyZW5cblx0XHR9KTtcblx0fVxuXHRpZiAobWFuaWZlc3QpIGZvciAoY29uc3QgbWF0Y2ggb2YgYXNzZXRNYXRjaGVzKSBmb3IgKGNvbnN0IGFzc2V0IG9mIG1hbmlmZXN0LnJvdXRlc1ttYXRjaC5yb3V0ZUlkXT8uc2NyaXB0cyA/PyBbXSkgbWFuaWZlc3RTY3JpcHRzLnB1c2goe1xuXHRcdHRhZzogXCJzY3JpcHRcIixcblx0XHRhdHRyczoge1xuXHRcdFx0Li4uYXNzZXQuYXR0cnMsXG5cdFx0XHRub25jZVxuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IGFzc2V0LmNoaWxkcmVuXG5cdH0pO1xuXHRyZXR1cm4gW3JvdXRlU2NyaXB0cywgbWFuaWZlc3RTY3JpcHRzXTtcbn1cbmZ1bmN0aW9uIGNvbXBvc2VTc3JCb2R5U2NyaXB0cyhbcm91dGVTY3JpcHRzLCBtYW5pZmVzdFNjcmlwdHNdLCBpbml0aWFsSHlkcmF0aW9uU2NyaXB0cykge1xuXHRpZiAoIWluaXRpYWxIeWRyYXRpb25TY3JpcHRzKSByZXR1cm4gWy4uLnJvdXRlU2NyaXB0cywgLi4ubWFuaWZlc3RTY3JpcHRzXTtcblx0cmV0dXJuIFtcblx0XHQuLi5pbml0aWFsSHlkcmF0aW9uU2NyaXB0cy5iZWZvcmUsXG5cdFx0Li4ucm91dGVTY3JpcHRzLFxuXHRcdC4uLm1hbmlmZXN0U2NyaXB0cyxcblx0XHRpbml0aWFsSHlkcmF0aW9uU2NyaXB0cy5ib3VuZGFyeVxuXHRdO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjb21wb3NlU3NyQm9keVNjcmlwdHMsIGdldFNzckJvZHlTY3JpcHRQYXJ0cyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1ib2R5U2NyaXB0cy5qcy5tYXAiLCJpbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwiLi9pbnZhcmlhbnQuanNcIjtcbmltcG9ydCB7IGNsZWFuUGF0aCwgdHJpbVBhdGhMZWZ0LCB0cmltUGF0aFJpZ2h0IH0gZnJvbSBcIi4vcGF0aC5qc1wiO1xuaW1wb3J0IHsgbm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCB7IHJvb3RSb3V0ZUlkIH0gZnJvbSBcIi4vcm9vdC5qc1wiO1xuaW1wb3J0IHsgcmVkaXJlY3QgfSBmcm9tIFwiLi9yZWRpcmVjdC5qc1wiO1xuLy8jcmVnaW9uIHNyYy9yb3V0ZS50c1xudmFyIEJhc2VSb3V0ZSA9IGNsYXNzIHtcblx0Z2V0IHRvKCkge1xuXHRcdHJldHVybiB0aGlzLl90bztcblx0fVxuXHRnZXQgaWQoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX2lkO1xuXHR9XG5cdGdldCBwYXRoKCkge1xuXHRcdHJldHVybiB0aGlzLl9wYXRoO1xuXHR9XG5cdGdldCBmdWxsUGF0aCgpIHtcblx0XHRyZXR1cm4gdGhpcy5fZnVsbFBhdGg7XG5cdH1cblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHRoaXMuaW5pdCA9IChvcmlnaW5hbEluZGV4KSA9PiB7XG5cdFx0XHR0aGlzLm9yaWdpbmFsSW5kZXggPSBvcmlnaW5hbEluZGV4O1xuXHRcdFx0dGhpcy5fYnJhbmNoID0gdm9pZCAwO1xuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IHRoaXMub3B0aW9ucztcblx0XHRcdGNvbnN0IGlzUm9vdCA9ICFvcHRpb25zPy5wYXRoICYmICFvcHRpb25zPy5pZDtcblx0XHRcdHRoaXMucGFyZW50Um91dGUgPSB0aGlzLm9wdGlvbnMuZ2V0UGFyZW50Um91dGU/LigpO1xuXHRcdFx0aWYgKGlzUm9vdCkgdGhpcy5fcGF0aCA9IHJvb3RSb3V0ZUlkO1xuXHRcdFx0ZWxzZSBpZiAoIXRoaXMucGFyZW50Um91dGUpIHtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhyb3cgbmV3IEVycm9yKGBJbnZhcmlhbnQgZmFpbGVkOiBDaGlsZCBSb3V0ZSBpbnN0YW5jZXMgbXVzdCBwYXNzIGEgJ2dldFBhcmVudFJvdXRlOiAoKSA9PiBQYXJlbnRSb3V0ZScgb3B0aW9uIHRoYXQgcmV0dXJucyBhIFJvdXRlIGluc3RhbmNlLmApO1xuXHRcdFx0XHRpbnZhcmlhbnQoKTtcblx0XHRcdH1cblx0XHRcdGxldCBwYXRoID0gaXNSb290ID8gcm9vdFJvdXRlSWQgOiBvcHRpb25zPy5wYXRoO1xuXHRcdFx0aWYgKHBhdGggJiYgcGF0aCAhPT0gXCIvXCIpIHBhdGggPSB0cmltUGF0aExlZnQocGF0aCk7XG5cdFx0XHRjb25zdCBjdXN0b21JZCA9IG9wdGlvbnM/LmlkIHx8IHBhdGg7XG5cdFx0XHRjb25zdCBpZCA9IGlzUm9vdCA/IHJvb3RSb3V0ZUlkIDogY2xlYW5QYXRoKCh0aGlzLnBhcmVudFJvdXRlLmlkID09PSBcIl9fcm9vdF9fXCIgPyBcIlwiIDogdGhpcy5wYXJlbnRSb3V0ZS5pZCkgKyBcIi9cIiArIChjdXN0b21JZCA/PyBcIlwiKSk7XG5cdFx0XHRpZiAocGF0aCA9PT0gXCJfX3Jvb3RfX1wiKSBwYXRoID0gXCIvXCI7XG5cdFx0XHRjb25zdCBmdWxsUGF0aCA9IGlkID09PSBcIl9fcm9vdF9fXCIgPyBcIi9cIiA6IHBhdGggPT09IHZvaWQgMCA/IHRoaXMucGFyZW50Um91dGUuZnVsbFBhdGggOiBjbGVhblBhdGgodGhpcy5wYXJlbnRSb3V0ZS5mdWxsUGF0aCArIFwiL1wiICsgcGF0aCk7XG5cdFx0XHR0aGlzLl9wYXRoID0gcGF0aDtcblx0XHRcdHRoaXMuX2lkID0gaWQ7XG5cdFx0XHR0aGlzLl9mdWxsUGF0aCA9IGZ1bGxQYXRoO1xuXHRcdFx0dGhpcy5fdG8gPSB0cmltUGF0aFJpZ2h0KGZ1bGxQYXRoKTtcblx0XHR9O1xuXHRcdHRoaXMuYWRkQ2hpbGRyZW4gPSAoY2hpbGRyZW4pID0+IHtcblx0XHRcdHJldHVybiB0aGlzLl9hZGRGaWxlQ2hpbGRyZW4oY2hpbGRyZW4pO1xuXHRcdH07XG5cdFx0dGhpcy5fYWRkRmlsZUNoaWxkcmVuID0gKGNoaWxkcmVuKSA9PiB7XG5cdFx0XHRpZiAoQXJyYXkuaXNBcnJheShjaGlsZHJlbikpIHRoaXMuY2hpbGRyZW4gPSBjaGlsZHJlbjtcblx0XHRcdGlmICh0eXBlb2YgY2hpbGRyZW4gPT09IFwib2JqZWN0XCIgJiYgY2hpbGRyZW4gIT09IG51bGwpIHRoaXMuY2hpbGRyZW4gPSBPYmplY3QudmFsdWVzKGNoaWxkcmVuKTtcblx0XHRcdHJldHVybiB0aGlzO1xuXHRcdH07XG5cdFx0dGhpcy5fYWRkRmlsZVR5cGVzID0gKCkgPT4ge1xuXHRcdFx0cmV0dXJuIHRoaXM7XG5cdFx0fTtcblx0XHR0aGlzLnVwZGF0ZUxvYWRlciA9IChvcHRpb25zKSA9PiB7XG5cdFx0XHRPYmplY3QuYXNzaWduKHRoaXMub3B0aW9ucywgb3B0aW9ucyk7XG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXHRcdHRoaXMudXBkYXRlID0gKG9wdGlvbnMpID0+IHtcblx0XHRcdE9iamVjdC5hc3NpZ24odGhpcy5vcHRpb25zLCBvcHRpb25zKTtcblx0XHRcdHJldHVybiB0aGlzO1xuXHRcdH07XG5cdFx0dGhpcy5sYXp5ID0gKGxhenlGbikgPT4ge1xuXHRcdFx0dGhpcy5sYXp5Rm4gPSBsYXp5Rm47XG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXHRcdHRoaXMucmVkaXJlY3QgPSAob3B0cykgPT4gcmVkaXJlY3Qoe1xuXHRcdFx0ZnJvbTogdGhpcy5mdWxsUGF0aCxcblx0XHRcdC4uLm9wdHNcblx0XHR9KTtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuXHRcdHRoaXMuaXNSb290ID0gIW9wdGlvbnM/LmdldFBhcmVudFJvdXRlO1xuXHRcdGlmIChvcHRpb25zPy5pZCAmJiBvcHRpb25zPy5wYXRoKSB0aHJvdyBuZXcgRXJyb3IoYFJvdXRlIGNhbm5vdCBoYXZlIGJvdGggYW4gJ2lkJyBhbmQgYSAncGF0aCcgb3B0aW9uLmApO1xuXHR9XG59O1xudmFyIEJhc2VSb3V0ZUFwaSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IoeyBpZCB9KSB7XG5cdFx0dGhpcy5ub3RGb3VuZCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gbm90Rm91bmQoe1xuXHRcdFx0XHRyb3V0ZUlkOiB0aGlzLmlkLFxuXHRcdFx0XHQuLi5vcHRzXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMucmVkaXJlY3QgPSAob3B0cykgPT4gcmVkaXJlY3Qoe1xuXHRcdFx0ZnJvbTogdGhpcy5pZCxcblx0XHRcdC4uLm9wdHNcblx0XHR9KTtcblx0XHR0aGlzLmlkID0gaWQ7XG5cdH1cbn07XG52YXIgQmFzZVJvb3RSb3V0ZSA9IGNsYXNzIGV4dGVuZHMgQmFzZVJvdXRlIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKG9wdGlvbnMpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBCYXNlUm9vdFJvdXRlLCBCYXNlUm91dGUsIEJhc2VSb3V0ZUFwaSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZS5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL2NvbmZpZy50c1xuY29uc3QgY3JlYXRlUm91dGVyQ29uZmlnID0gKG9wdGlvbnMpID0+IHtcblx0cmV0dXJuIHtcblx0XHRzZXJpYWxpemF0aW9uQWRhcHRlcnM6IG9wdGlvbnMuc2VyaWFsaXphdGlvbkFkYXB0ZXJzLFxuXHRcdGRlZmF1bHRTc3I6IG9wdGlvbnMuZGVmYXVsdFNzclxuXHR9O1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY3JlYXRlUm91dGVyQ29uZmlnIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbmZpZy5qcy5tYXAiLCJpbXBvcnQgeyBkZWVwRXF1YWwsIGhhc093biB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG4vLyNyZWdpb24gc3JjL3NlYXJjaE1pZGRsZXdhcmUudHNcbi8qKlxuKiBSZXRhaW4gc3BlY2lmaWVkIHNlYXJjaCBwYXJhbXMgYWNyb3NzIG5hdmlnYXRpb25zLlxuKlxuKiBJZiBga2V5c2AgaXMgYHRydWVgLCByZXRhaW4gYWxsIGN1cnJlbnQgcGFyYW1zLiBPdGhlcndpc2UsIGNvcHkgb25seSB0aGVcbiogbGlzdGVkIGtleXMgZnJvbSB0aGUgY3VycmVudCBzZWFyY2ggaW50byB0aGUgbmV4dCBzZWFyY2guXG4qXG4qIEBwYXJhbSBrZXlzIGB0cnVlYCB0byByZXRhaW4gYWxsLCBvciBhIGxpc3Qgb2Yga2V5cyB0byByZXRhaW4uXG4qIEByZXR1cm5zIEEgc2VhcmNoIG1pZGRsZXdhcmUgc3VpdGFibGUgZm9yIHJvdXRlIGBzZWFyY2gubWlkZGxld2FyZXNgLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvcmV0YWluU2VhcmNoUGFyYW1zRnVuY3Rpb25cbiovXG5mdW5jdGlvbiByZXRhaW5TZWFyY2hQYXJhbXMoa2V5cykge1xuXHRyZXR1cm4gKHsgc2VhcmNoLCBuZXh0IH0pID0+IHtcblx0XHRjb25zdCB7IHNlYXJjaDogcmVzdWx0U2VhcmNoLCBtZXRhIH0gPSBuZXh0KHNlYXJjaCwgdHJ1ZSk7XG5cdFx0aWYgKGtleXMgPT09IHRydWUpIHtcblx0XHRcdGNvbnN0IGNvcHkgPSB7XG5cdFx0XHRcdC4uLnNlYXJjaCxcblx0XHRcdFx0Li4ucmVzdWx0U2VhcmNoXG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgcmVtb3ZlZCA9IG1ldGEucmVtb3ZlZDtcblx0XHRcdGNvbnN0IGV4cGxpY2l0ID0gbWV0YS5leHBsaWNpdDtcblx0XHRcdGZvciAoY29uc3Qga2V5IG9mIHJlbW92ZWQ/LmtleXMoKSB8fCBbXSkgaWYgKGV4cGxpY2l0ICYmIGhhc093bi5jYWxsKGV4cGxpY2l0LCBrZXkpIHx8IGRlZXBFcXVhbChzZWFyY2hba2V5XSwgcmVtb3ZlZC5nZXQoa2V5KSkpIGRlbGV0ZSBjb3B5W2tleV07XG5cdFx0XHRmb3IgKGNvbnN0IGtleSBvZiBtZXRhLnJlbW92ZWRBbnkgfHwgW10pIGRlbGV0ZSBjb3B5W2tleV07XG5cdFx0XHRmb3IgKGNvbnN0IGtleSBvZiBtZXRhLmRlZmF1bHRlZD8ua2V5cygpIHx8IFtdKSBpZiAoa2V5IGluIHNlYXJjaCAmJiAhbWV0YS5yZW1vdmVkQW55Py5oYXMoa2V5KSAmJiAhKG1ldGEucmVtb3ZlZD8uaGFzKGtleSkgJiYgKGV4cGxpY2l0ICYmIGhhc093bi5jYWxsKGV4cGxpY2l0LCBrZXkpIHx8IGRlZXBFcXVhbChzZWFyY2hba2V5XSwgbWV0YS5yZW1vdmVkLmdldChrZXkpKSkpKSBjb3B5W2tleV0gPSBzZWFyY2hba2V5XTtcblx0XHRcdHJldHVybiBjb3B5O1xuXHRcdH1cblx0XHRjb25zdCBjb3B5ID0geyAuLi5yZXN1bHRTZWFyY2ggfTtcblx0XHRjb25zdCBleHBsaWNpdCA9IG1ldGEuZXhwbGljaXQ7XG5cdFx0Zm9yIChjb25zdCBrZXkgb2Yga2V5cykge1xuXHRcdFx0Y29uc3Qgc3RyaW5nS2V5ID0ga2V5O1xuXHRcdFx0aWYgKCEobWV0YS5yZW1vdmVkQW55Py5oYXMoc3RyaW5nS2V5KSB8fCBtZXRhLnJlbW92ZWQ/LmhhcyhzdHJpbmdLZXkpICYmIChleHBsaWNpdCAmJiBoYXNPd24uY2FsbChleHBsaWNpdCwgc3RyaW5nS2V5KSB8fCBkZWVwRXF1YWwoc2VhcmNoW2tleV0sIG1ldGEucmVtb3ZlZC5nZXQoc3RyaW5nS2V5KSkpKSAmJiAoIShrZXkgaW4gY29weSkgfHwga2V5IGluIHNlYXJjaCAmJiBtZXRhLmRlZmF1bHRlZD8uaGFzKHN0cmluZ0tleSkgJiYgZGVlcEVxdWFsKGNvcHlba2V5XSwgbWV0YS5kZWZhdWx0ZWQuZ2V0KHN0cmluZ0tleSkpKSkgY29weVtrZXldID0gc2VhcmNoW2tleV07XG5cdFx0fVxuXHRcdHJldHVybiBjb3B5O1xuXHR9O1xufVxuLyoqXG4qIFJlbW92ZSBvcHRpb25hbCBvciBkZWZhdWx0LXZhbHVlZCBzZWFyY2ggcGFyYW1zIGZyb20gbmF2aWdhdGlvbnMuXG4qXG4qIC0gUGFzcyBgdHJ1ZWAgKG9ubHkgaWYgdGhlcmUgYXJlIG5vIHJlcXVpcmVkIHNlYXJjaCBwYXJhbXMpIHRvIHN0cmlwIGFsbC5cbiogLSBQYXNzIGFuIGFycmF5IHRvIGFsd2F5cyByZW1vdmUgdGhvc2Ugb3B0aW9uYWwga2V5cy5cbiogLSBQYXNzIGFuIG9iamVjdCBvZiBkZWZhdWx0IHZhbHVlczsga2V5cyBlcXVhbCAoZGVlcGx5KSB0byB0aGUgZGVmYXVsdHMgYXJlIHJlbW92ZWQuXG4qXG4qIEByZXR1cm5zIEEgc2VhcmNoIG1pZGRsZXdhcmUgc3VpdGFibGUgZm9yIHJvdXRlIGBzZWFyY2gubWlkZGxld2FyZXNgLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvc3RyaXBTZWFyY2hQYXJhbXNGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIHN0cmlwU2VhcmNoUGFyYW1zKGlucHV0KSB7XG5cdHJldHVybiAoKHsgc2VhcmNoLCBuZXh0LCBtZXRhIH0pID0+IHtcblx0XHRpZiAoaW5wdXQgPT09IHRydWUpIHtcblx0XHRcdE9iamVjdC5rZXlzKHNlYXJjaCkuZm9yRWFjaCgoa2V5KSA9PiB7XG5cdFx0XHRcdGlmIChtZXRhKSAobWV0YS5yZW1vdmVkQW55IHx8PSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpKS5hZGQoa2V5KTtcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIHt9O1xuXHRcdH1cblx0XHRjb25zdCByZXN1bHQgPSB7IC4uLm5leHQoc2VhcmNoKSB9O1xuXHRcdGlmIChBcnJheS5pc0FycmF5KGlucHV0KSkgaW5wdXQuZm9yRWFjaCgoa2V5KSA9PiB7XG5cdFx0XHRkZWxldGUgcmVzdWx0W2tleV07XG5cdFx0XHRpZiAobWV0YSkgKG1ldGEucmVtb3ZlZEFueSB8fD0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSkuYWRkKGtleSk7XG5cdFx0fSk7XG5cdFx0ZWxzZSBPYmplY3QuZW50cmllcyhpbnB1dCkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG5cdFx0XHRpZiAoZGVlcEVxdWFsKHJlc3VsdFtrZXldLCB2YWx1ZSkpIHtcblx0XHRcdFx0ZGVsZXRlIHJlc3VsdFtrZXldO1xuXHRcdFx0XHRpZiAobWV0YSkgKG1ldGEucmVtb3ZlZCB8fD0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkuc2V0KGtleSwgdmFsdWUpO1xuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyByZXRhaW5TZWFyY2hQYXJhbXMsIHN0cmlwU2VhcmNoUGFyYW1zIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlYXJjaE1pZGRsZXdhcmUuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9zc3Ivc2VyaWFsaXplci90cmFuc2Zvcm1lci50c1xuLyoqXG4qIENyZWF0ZSBhIHN0cm9uZ2x5LXR5cGVkIHNlcmlhbGl6YXRpb24gYWRhcHRlciBmb3IgU1NSIGh5ZHJhdGlvbi5cbiogVXNlIHRvIHJlZ2lzdGVyIGN1c3RvbSB0eXBlcyB3aXRoIHRoZSByb3V0ZXIgc2VyaWFsaXplci5cbiovXG5mdW5jdGlvbiBjcmVhdGVTZXJpYWxpemF0aW9uQWRhcHRlcihvcHRzKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAoIW9wdHMua2V5IHx8IC9bXFwwXCJcXFxcPFxcYlxcdFxcZlxcclxcblxcdTIwMjhcXHUyMDI5XFx1RDgwMC1cXHVERkZGXS8udGVzdChvcHRzLmtleSkpIHRocm93IG5ldyBFcnJvcihgY3JlYXRlU2VyaWFsaXphdGlvbkFkYXB0ZXI6IGtleSAke0pTT04uc3RyaW5naWZ5KG9wdHMua2V5KX0gaXMgaW52YWxpZC4gU2VyaWFsaXphdGlvbiBhZGFwdGVyIGtleXMgbXVzdCBiZSBub24tZW1wdHkgYW5kIG5vdCBjb250YWluIE5VTCwgXCIsIFxcXFwsIDwsIGJhY2tzcGFjZSwgdGFiLCBmb3JtIGZlZWQsIGxpbmUgdGVybWluYXRvcnMsIG9yIFVURi0xNiBzdXJyb2dhdGUgY29kZSB1bml0cy5gKTtcblx0fVxuXHRyZXR1cm4gb3B0cztcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY3JlYXRlU2VyaWFsaXphdGlvbkFkYXB0ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dHJhbnNmb3JtZXIuanMubWFwIiwiaW1wb3J0IHsgcmVhY3RVc2UgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgVFNSX0RFRkVSUkVEX1BST01JU0UsIGRlZmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9hd2FpdGVkLnRzeFxuLyoqIFN1c3BlbmQgdW50aWwgYSBkZWZlcnJlZCBwcm9taXNlIHJlc29sdmVzIG9yIHJlamVjdHMgYW5kIHJldHVybiBpdHMgZGF0YS4gKi9cbmZ1bmN0aW9uIHVzZUF3YWl0ZWQoeyBwcm9taXNlOiBfcHJvbWlzZSB9KSB7XG5cdGlmIChyZWFjdFVzZSkgcmV0dXJuIHJlYWN0VXNlKF9wcm9taXNlKTtcblx0Y29uc3QgcHJvbWlzZSA9IGRlZmVyKF9wcm9taXNlKTtcblx0aWYgKHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLnN0YXR1cyA9PT0gXCJwZW5kaW5nXCIpIHRocm93IHByb21pc2U7XG5cdGlmIChwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5zdGF0dXMgPT09IFwiZXJyb3JcIikgdGhyb3cgcHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0uZXJyb3I7XG5cdHJldHVybiBwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5kYXRhO1xufVxuLyoqXG4qIENvbXBvbmVudCB0aGF0IHN1c3BlbmRzIG9uIGEgZGVmZXJyZWQgcHJvbWlzZSBhbmQgcmVuZGVycyBpdHMgY2hpbGQgd2l0aFxuKiB0aGUgcmVzb2x2ZWQgdmFsdWUuIE9wdGlvbmFsbHkgcHJvdmlkZXMgYSBTdXNwZW5zZSBmYWxsYmFjay5cbiovXG5mdW5jdGlvbiBBd2FpdChwcm9wcykge1xuXHRjb25zdCBpbm5lciA9IC8qIEBfX1BVUkVfXyAqLyBqc3goQXdhaXRJbm5lciwgeyAuLi5wcm9wcyB9KTtcblx0aWYgKHByb3BzLmZhbGxiYWNrKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChSZWFjdCQxLlN1c3BlbnNlLCB7XG5cdFx0ZmFsbGJhY2s6IHByb3BzLmZhbGxiYWNrLFxuXHRcdGNoaWxkcmVuOiBpbm5lclxuXHR9KTtcblx0cmV0dXJuIGlubmVyO1xufVxuZnVuY3Rpb24gQXdhaXRJbm5lcihwcm9wcykge1xuXHRjb25zdCBkYXRhID0gdXNlQXdhaXRlZChwcm9wcyk7XG5cdHJldHVybiBwcm9wcy5jaGlsZHJlbihkYXRhKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQXdhaXQsIHVzZUF3YWl0ZWQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXdhaXRlZC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvbm9uUm91dGVDb21wb25lbnRDb250ZXh0LnRzeFxudmFyIG5vblJvdXRlQ29tcG9uZW50Q29udGV4dCA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFJlYWN0JDEuY3JlYXRlQ29udGV4dCh2b2lkIDApIDogdm9pZCAwO1xuZnVuY3Rpb24gd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0KGVsZW1lbnQsIGNvbXBvbmVudCkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChub25Sb3V0ZUNvbXBvbmVudENvbnRleHQuUHJvdmlkZXIsIHtcblx0XHR2YWx1ZTogY29tcG9uZW50LFxuXHRcdGNoaWxkcmVuOiBlbGVtZW50XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBub25Sb3V0ZUNvbXBvbmVudENvbnRleHQsIHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub25Sb3V0ZUNvbXBvbmVudENvbnRleHQuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQgfSBmcm9tIFwiLi9ub25Sb3V0ZUNvbXBvbmVudENvbnRleHQuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3gsIGpzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvQ2F0Y2hCb3VuZGFyeS50c3hcbnZhciBDYXRjaEJvdW5kYXJ5ID0gY2xhc3MgZXh0ZW5kcyBSZWFjdCQxLkNvbXBvbmVudCB7XG5cdGNvbnN0cnVjdG9yKC4uLl9hcmdzKSB7XG5cdFx0c3VwZXIoLi4uX2FyZ3MpO1xuXHRcdHRoaXMuc3RhdGUgPSB7IGVycm9yOiAwIH07XG5cdFx0dGhpcy5yZXNldCA9ICgpID0+IHtcblx0XHRcdHRoaXMuc2V0U3RhdGUoeyBlcnJvcjogMCB9KTtcblx0XHR9O1xuXHR9XG5cdHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tUHJvcHMocHJvcHMsIHN0YXRlKSB7XG5cdFx0Y29uc3QgcmVzZXRLZXkgPSBwcm9wcy5nZXRSZXNldEtleSgpO1xuXHRcdGlmIChzdGF0ZS5lcnJvciAmJiBzdGF0ZS5yZXNldEtleSAhPT0gcmVzZXRLZXkpIHJldHVybiB7XG5cdFx0XHRyZXNldEtleSxcblx0XHRcdGVycm9yOiAwXG5cdFx0fTtcblx0XHRyZXR1cm4geyByZXNldEtleSB9O1xuXHR9XG5cdHN0YXRpYyBnZXREZXJpdmVkU3RhdGVGcm9tRXJyb3IoZXJyb3IpIHtcblx0XHRyZXR1cm4geyBlcnJvcjogW2Vycm9yXSB9O1xuXHR9XG5cdGNvbXBvbmVudERpZENhdGNoKGVycm9yLCBlcnJvckluZm8pIHtcblx0XHR0aGlzLnByb3BzLm9uQ2F0Y2g/LihlcnJvciwgZXJyb3JJbmZvKTtcblx0fVxuXHRyZW5kZXIoKSB7XG5cdFx0Y29uc3QgZXJyb3IgPSB0aGlzLnN0YXRlLmVycm9yO1xuXHRcdGlmIChlcnJvcikge1xuXHRcdFx0Y29uc3QgZWxlbWVudCA9IFJlYWN0JDEuY3JlYXRlRWxlbWVudCh0aGlzLnByb3BzLmVycm9yQ29tcG9uZW50ID8/IEVycm9yQ29tcG9uZW50LCB7XG5cdFx0XHRcdGVycm9yOiBlcnJvclswXSxcblx0XHRcdFx0cmVzZXQ6IHRoaXMucmVzZXRcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dChlbGVtZW50LCBcImVycm9yQ29tcG9uZW50XCIpIDogZWxlbWVudDtcblx0XHR9XG5cdFx0cmV0dXJuIHRoaXMucHJvcHMuY2hpbGRyZW47XG5cdH1cbn07XG5mdW5jdGlvbiBFcnJvckNvbXBvbmVudCh7IGVycm9yIH0pIHtcblx0Y29uc3QgW3Nob3csIHNldFNob3ddID0gUmVhY3QkMS51c2VTdGF0ZShwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeHMoXCJkaXZcIiwge1xuXHRcdHN0eWxlOiB7XG5cdFx0XHRwYWRkaW5nOiBcIi41cmVtXCIsXG5cdFx0XHRtYXhXaWR0aDogXCIxMDAlXCJcblx0XHR9LFxuXHRcdGNoaWxkcmVuOiBbXG5cdFx0XHQvKiBAX19QVVJFX18gKi8ganN4cyhcImRpdlwiLCB7XG5cdFx0XHRcdHN0eWxlOiB7XG5cdFx0XHRcdFx0ZGlzcGxheTogXCJmbGV4XCIsXG5cdFx0XHRcdFx0YWxpZ25JdGVtczogXCJjZW50ZXJcIixcblx0XHRcdFx0XHRnYXA6IFwiLjVyZW1cIlxuXHRcdFx0XHR9LFxuXHRcdFx0XHRjaGlsZHJlbjogWy8qIEBfX1BVUkVfXyAqLyBqc3goXCJzdHJvbmdcIiwge1xuXHRcdFx0XHRcdHN0eWxlOiB7IGZvbnRTaXplOiBcIjFyZW1cIiB9LFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBcIlNvbWV0aGluZyB3ZW50IHdyb25nIVwiXG5cdFx0XHRcdH0pLCAvKiBAX19QVVJFX18gKi8ganN4KFwiYnV0dG9uXCIsIHtcblx0XHRcdFx0XHRzdHlsZToge1xuXHRcdFx0XHRcdFx0YXBwZWFyYW5jZTogXCJub25lXCIsXG5cdFx0XHRcdFx0XHRmb250U2l6ZTogXCIuNmVtXCIsXG5cdFx0XHRcdFx0XHRib3JkZXI6IFwiMXB4IHNvbGlkIGN1cnJlbnRDb2xvclwiLFxuXHRcdFx0XHRcdFx0cGFkZGluZzogXCIuMXJlbSAuMnJlbVwiLFxuXHRcdFx0XHRcdFx0Zm9udFdlaWdodDogXCJib2xkXCIsXG5cdFx0XHRcdFx0XHRib3JkZXJSYWRpdXM6IFwiLjI1cmVtXCJcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdG9uQ2xpY2s6ICgpID0+IHNldFNob3coKGQpID0+ICFkKSxcblx0XHRcdFx0XHRjaGlsZHJlbjogc2hvdyA/IFwiSGlkZSBFcnJvclwiIDogXCJTaG93IEVycm9yXCJcblx0XHRcdFx0fSldXG5cdFx0XHR9KSxcblx0XHRcdC8qIEBfX1BVUkVfXyAqLyBqc3goXCJkaXZcIiwgeyBzdHlsZTogeyBoZWlnaHQ6IFwiLjI1cmVtXCIgfSB9KSxcblx0XHRcdHNob3cgPyAvKiBAX19QVVJFX18gKi8ganN4KFwiZGl2XCIsIHsgY2hpbGRyZW46IC8qIEBfX1BVUkVfXyAqLyBqc3goXCJwcmVcIiwge1xuXHRcdFx0XHRzdHlsZToge1xuXHRcdFx0XHRcdGZvbnRTaXplOiBcIi43ZW1cIixcblx0XHRcdFx0XHRib3JkZXI6IFwiMXB4IHNvbGlkIHJlZFwiLFxuXHRcdFx0XHRcdGJvcmRlclJhZGl1czogXCIuMjVyZW1cIixcblx0XHRcdFx0XHRwYWRkaW5nOiBcIi4zcmVtXCIsXG5cdFx0XHRcdFx0Y29sb3I6IFwicmVkXCIsXG5cdFx0XHRcdFx0b3ZlcmZsb3c6IFwiYXV0b1wiXG5cdFx0XHRcdH0sXG5cdFx0XHRcdGNoaWxkcmVuOiBlcnJvcj8ubWVzc2FnZSA/IC8qIEBfX1BVUkVfXyAqLyBqc3goXCJjb2RlXCIsIHsgY2hpbGRyZW46IGVycm9yLm1lc3NhZ2UgfSkgOiBudWxsXG5cdFx0XHR9KSB9KSA6IG51bGxcblx0XHRdXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBDYXRjaEJvdW5kYXJ5LCBFcnJvckNvbXBvbmVudCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1DYXRjaEJvdW5kYXJ5LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL0NsaWVudE9ubHkudHN4XG52YXIgZ2V0U25hcHNob3QgPSAoKSA9PiB0cnVlO1xudmFyIGdldFNlcnZlclNuYXBzaG90ID0gKCkgPT4gZmFsc2U7XG4vKipcbiogUmVuZGVyIHRoZSBjaGlsZHJlbiBvbmx5IGFmdGVyIHRoZSBKUyBoYXMgbG9hZGVkIGNsaWVudC1zaWRlLiBVc2UgYW4gb3B0aW9uYWxcbiogZmFsbGJhY2sgY29tcG9uZW50IGlmIHRoZSBKUyBpcyBub3QgeWV0IGxvYWRlZC5cbipcbiogQGV4YW1wbGVcbiogUmVuZGVyIGEgQ2hhcnQgY29tcG9uZW50IGlmIEpTIGxvYWRzLCByZW5kZXJzIGEgc2ltcGxlIEZha2VDaGFydFxuKiBjb21wb25lbnQgc2VydmVyLXNpZGUgb3IgaWYgdGhlcmUgaXMgbm8gSlMuIFRoZSBGYWtlQ2hhcnQgY2FuIGhhdmUgb25seSB0aGVcbiogVUkgd2l0aG91dCB0aGUgYmVoYXZpb3Igb3IgYmUgYSBsb2FkaW5nIHNwaW5uZXIgb3Igc2tlbGV0b24uXG4qXG4qIGBgYHRzeFxuKiByZXR1cm4gKFxuKiAgIDxDbGllbnRPbmx5IGZhbGxiYWNrPXs8RmFrZUNoYXJ0IC8+fT5cbiogICAgIDxDaGFydCAvPlxuKiAgIDwvQ2xpZW50T25seT5cbiogKVxuKiBgYGBcbiovXG5mdW5jdGlvbiBDbGllbnRPbmx5KHsgY2hpbGRyZW4sIGZhbGxiYWNrID0gbnVsbCB9KSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFJlYWN0LkZyYWdtZW50LCB7IGNoaWxkcmVuOiB1c2VIeWRyYXRlZCgpID8gY2hpbGRyZW4gOiBmYWxsYmFjayB9KTtcbn1cbi8qKiBAaW50ZXJuYWwgKi9cbmZ1bmN0aW9uIHVzZUh5ZHJhdGVkKGVuYWJsZWQgPSB0cnVlKSB7XG5cdHJldHVybiBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmUsIGdldFNuYXBzaG90LCBlbmFibGVkID8gZ2V0U2VydmVyU25hcHNob3QgOiBnZXRTbmFwc2hvdCk7XG59XG5mdW5jdGlvbiBzdWJzY3JpYmUoKSB7XG5cdHJldHVybiAoKSA9PiB7fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQ2xpZW50T25seSwgdXNlSHlkcmF0ZWQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2xpZW50T25seS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlckNvbnRleHQudHN4XG52YXIgcm91dGVyQ29udGV4dCA9IFJlYWN0JDEuY3JlYXRlQ29udGV4dChudWxsKTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcm91dGVyQ29udGV4dCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZXJDb250ZXh0LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgcm91dGVyQ29udGV4dCB9IGZyb20gXCIuL3JvdXRlckNvbnRleHQuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL3VzZVJvdXRlci50c3hcbi8qKlxuKiBBY2Nlc3MgdGhlIGN1cnJlbnQgVGFuU3RhY2sgUm91dGVyIGluc3RhbmNlIGZyb20gUmVhY3QgY29udGV4dC5cbiogTXVzdCBiZSB1c2VkIHdpdGhpbiBhIGBSb3V0ZXJQcm92aWRlcmAuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYHdhcm5gOiBMb2cgYSB3YXJuaW5nIGlmIG5vIHJvdXRlciBjb250ZXh0IGlzIGZvdW5kIChkZWZhdWx0OiB0cnVlKS5cbipcbiogQHJldHVybnMgVGhlIHJlZ2lzdGVyZWQgcm91dGVyIGluc3RhbmNlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlUm91dGVySG9va1xuKi9cbmZ1bmN0aW9uIHVzZVJvdXRlcihvcHRzKSB7XG5cdGNvbnN0IHZhbHVlID0gUmVhY3QkMS51c2VDb250ZXh0KHJvdXRlckNvbnRleHQpO1xuXHRpZiAoIXZhbHVlKSB3YXJuTWlzc2luZ1JvdXRlcihvcHRzKTtcblx0cmV0dXJuIHZhbHVlO1xufVxuZnVuY3Rpb24gd2Fybk1pc3NpbmdSb3V0ZXIob3B0cykge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIChvcHRzPy53YXJuID8/IHRydWUpKSBjb25zb2xlLndhcm4oXCJXYXJuaW5nOiB1c2VSb3V0ZXIgbXVzdCBiZSB1c2VkIGluc2lkZSBhIDxSb3V0ZXJQcm92aWRlcj4gY29tcG9uZW50IVwiKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlUm91dGVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVJvdXRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL21hdGNoQ29udGV4dC50c3hcbnZhciBtYXRjaENvbnRleHQgPSBSZWFjdCQxLmNyZWF0ZUNvbnRleHQodm9pZCAwKTtcbnZhciBkdW1teU1hdGNoQ29udGV4dCA9IFJlYWN0JDEuY3JlYXRlQ29udGV4dCh2b2lkIDApO1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkdW1teU1hdGNoQ29udGV4dCwgbWF0Y2hDb250ZXh0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1hdGNoQ29udGV4dC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL2FsaWVuLnRzXG5jb25zdCBOT05FID0gMDtcbmNvbnN0IE1VVEFCTEUgPSAxO1xuY29uc3QgV0FUQ0hJTkcgPSAyO1xuY29uc3QgUkVDVVJTRURfQ0hFQ0sgPSA0O1xuY29uc3QgUkVDVVJTRUQgPSA4O1xuY29uc3QgRElSVFkgPSAxNjtcbmNvbnN0IFBFTkRJTkcgPSAzMjtcbi8qIEBfX05PX1NJREVfRUZGRUNUU19fICovXG5mdW5jdGlvbiBjcmVhdGVSZWFjdGl2ZVN5c3RlbSh7IHVwZGF0ZSwgbm90aWZ5LCB1bndhdGNoZWQgfSkge1xuXHRyZXR1cm4ge1xuXHRcdGxpbmssXG5cdFx0dW5saW5rLFxuXHRcdHByb3BhZ2F0ZSxcblx0XHRjaGVja0RpcnR5LFxuXHRcdHNoYWxsb3dQcm9wYWdhdGVcblx0fTtcblx0ZnVuY3Rpb24gbGluayhkZXAsIHN1YiwgdmVyc2lvbikge1xuXHRcdGNvbnN0IHByZXZEZXAgPSBzdWIuZGVwc1RhaWw7XG5cdFx0aWYgKHByZXZEZXAgIT09IHZvaWQgMCAmJiBwcmV2RGVwLmRlcCA9PT0gZGVwKSByZXR1cm47XG5cdFx0Y29uc3QgbmV4dERlcCA9IHByZXZEZXAgIT09IHZvaWQgMCA/IHByZXZEZXAubmV4dERlcCA6IHN1Yi5kZXBzO1xuXHRcdGlmIChuZXh0RGVwICE9PSB2b2lkIDAgJiYgbmV4dERlcC5kZXAgPT09IGRlcCkge1xuXHRcdFx0bmV4dERlcC52ZXJzaW9uID0gdmVyc2lvbjtcblx0XHRcdHN1Yi5kZXBzVGFpbCA9IG5leHREZXA7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGNvbnN0IHByZXZTdWIgPSBkZXAuc3Vic1RhaWw7XG5cdFx0aWYgKHByZXZTdWIgIT09IHZvaWQgMCAmJiBwcmV2U3ViLnZlcnNpb24gPT09IHZlcnNpb24gJiYgcHJldlN1Yi5zdWIgPT09IHN1YikgcmV0dXJuO1xuXHRcdGNvbnN0IG5ld0xpbmsgPSBzdWIuZGVwc1RhaWwgPSBkZXAuc3Vic1RhaWwgPSB7XG5cdFx0XHR2ZXJzaW9uLFxuXHRcdFx0ZGVwLFxuXHRcdFx0c3ViLFxuXHRcdFx0cHJldkRlcCxcblx0XHRcdG5leHREZXAsXG5cdFx0XHRwcmV2U3ViLFxuXHRcdFx0bmV4dFN1Yjogdm9pZCAwXG5cdFx0fTtcblx0XHRpZiAobmV4dERlcCAhPT0gdm9pZCAwKSBuZXh0RGVwLnByZXZEZXAgPSBuZXdMaW5rO1xuXHRcdGlmIChwcmV2RGVwICE9PSB2b2lkIDApIHByZXZEZXAubmV4dERlcCA9IG5ld0xpbms7XG5cdFx0ZWxzZSBzdWIuZGVwcyA9IG5ld0xpbms7XG5cdFx0aWYgKHByZXZTdWIgIT09IHZvaWQgMCkgcHJldlN1Yi5uZXh0U3ViID0gbmV3TGluaztcblx0XHRlbHNlIGRlcC5zdWJzID0gbmV3TGluaztcblx0fVxuXHRmdW5jdGlvbiB1bmxpbmsobGluaywgc3ViID0gbGluay5zdWIpIHtcblx0XHRjb25zdCBkZXAgPSBsaW5rLmRlcDtcblx0XHRjb25zdCBwcmV2RGVwID0gbGluay5wcmV2RGVwO1xuXHRcdGNvbnN0IG5leHREZXAgPSBsaW5rLm5leHREZXA7XG5cdFx0Y29uc3QgbmV4dFN1YiA9IGxpbmsubmV4dFN1Yjtcblx0XHRjb25zdCBwcmV2U3ViID0gbGluay5wcmV2U3ViO1xuXHRcdGlmIChuZXh0RGVwICE9PSB2b2lkIDApIG5leHREZXAucHJldkRlcCA9IHByZXZEZXA7XG5cdFx0ZWxzZSBzdWIuZGVwc1RhaWwgPSBwcmV2RGVwO1xuXHRcdGlmIChwcmV2RGVwICE9PSB2b2lkIDApIHByZXZEZXAubmV4dERlcCA9IG5leHREZXA7XG5cdFx0ZWxzZSBzdWIuZGVwcyA9IG5leHREZXA7XG5cdFx0aWYgKG5leHRTdWIgIT09IHZvaWQgMCkgbmV4dFN1Yi5wcmV2U3ViID0gcHJldlN1Yjtcblx0XHRlbHNlIGRlcC5zdWJzVGFpbCA9IHByZXZTdWI7XG5cdFx0aWYgKHByZXZTdWIgIT09IHZvaWQgMCkgcHJldlN1Yi5uZXh0U3ViID0gbmV4dFN1Yjtcblx0XHRlbHNlIGlmICgoZGVwLnN1YnMgPSBuZXh0U3ViKSA9PT0gdm9pZCAwKSB1bndhdGNoZWQoZGVwKTtcblx0XHRyZXR1cm4gbmV4dERlcDtcblx0fVxuXHRmdW5jdGlvbiBwcm9wYWdhdGUobGluaykge1xuXHRcdGxldCBuZXh0ID0gbGluay5uZXh0U3ViO1xuXHRcdGxldCBzdGFjaztcblx0XHR0b3A6IGRvIHtcblx0XHRcdGNvbnN0IHN1YiA9IGxpbmsuc3ViO1xuXHRcdFx0bGV0IGZsYWdzID0gc3ViLmZsYWdzO1xuXHRcdFx0aWYgKCEoZmxhZ3MgJiA2MCkpIHN1Yi5mbGFncyA9IGZsYWdzIHwgMzI7XG5cdFx0XHRlbHNlIGlmICghKGZsYWdzICYgKDQgfCA4KSkpIGZsYWdzID0gMDtcblx0XHRcdGVsc2UgaWYgKCEoZmxhZ3MgJiA0KSkgc3ViLmZsYWdzID0gZmxhZ3MgJiB+OCB8IDMyO1xuXHRcdFx0ZWxzZSBpZiAoIShmbGFncyAmICgxNiB8IDMyKSkgJiYgaXNWYWxpZExpbmsobGluaywgc3ViKSkge1xuXHRcdFx0XHRzdWIuZmxhZ3MgPSBmbGFncyB8ICg4IHwgMzIpO1xuXHRcdFx0XHRmbGFncyAmPSAxO1xuXHRcdFx0fSBlbHNlIGZsYWdzID0gMDtcblx0XHRcdGlmIChmbGFncyAmIDIpIG5vdGlmeShzdWIpO1xuXHRcdFx0aWYgKGZsYWdzICYgMSkge1xuXHRcdFx0XHRjb25zdCBzdWJTdWJzID0gc3ViLnN1YnM7XG5cdFx0XHRcdGlmIChzdWJTdWJzICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRjb25zdCBuZXh0U3ViID0gKGxpbmsgPSBzdWJTdWJzKS5uZXh0U3ViO1xuXHRcdFx0XHRcdGlmIChuZXh0U3ViICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRcdHN0YWNrID0ge1xuXHRcdFx0XHRcdFx0XHR2YWx1ZTogbmV4dCxcblx0XHRcdFx0XHRcdFx0cHJldjogc3RhY2tcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRuZXh0ID0gbmV4dFN1Yjtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0Y29udGludWU7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmICgobGluayA9IG5leHQpICE9PSB2b2lkIDApIHtcblx0XHRcdFx0bmV4dCA9IGxpbmsubmV4dFN1Yjtcblx0XHRcdFx0Y29udGludWU7XG5cdFx0XHR9XG5cdFx0XHR3aGlsZSAoc3RhY2sgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRsaW5rID0gc3RhY2sudmFsdWU7XG5cdFx0XHRcdHN0YWNrID0gc3RhY2sucHJldjtcblx0XHRcdFx0aWYgKGxpbmsgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdG5leHQgPSBsaW5rLm5leHRTdWI7XG5cdFx0XHRcdFx0Y29udGludWUgdG9wO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRicmVhaztcblx0XHR9IHdoaWxlICh0cnVlKTtcblx0fVxuXHRmdW5jdGlvbiBjaGVja0RpcnR5KGxpbmssIHN1Yikge1xuXHRcdGxldCBzdGFjaztcblx0XHRsZXQgY2hlY2tEZXB0aCA9IDA7XG5cdFx0bGV0IGRpcnR5ID0gZmFsc2U7XG5cdFx0dG9wOiBkbyB7XG5cdFx0XHRjb25zdCBkZXAgPSBsaW5rLmRlcDtcblx0XHRcdGNvbnN0IGZsYWdzID0gZGVwLmZsYWdzO1xuXHRcdFx0aWYgKHN1Yi5mbGFncyAmIDE2KSBkaXJ0eSA9IHRydWU7XG5cdFx0XHRlbHNlIGlmICgoZmxhZ3MgJiAoMSB8IDE2KSkgPT09ICgxIHwgMTYpKSB7XG5cdFx0XHRcdGlmICh1cGRhdGUoZGVwKSkge1xuXHRcdFx0XHRcdGNvbnN0IHN1YnMgPSBkZXAuc3Vicztcblx0XHRcdFx0XHRpZiAoc3Vicy5uZXh0U3ViICE9PSB2b2lkIDApIHNoYWxsb3dQcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdFx0ZGlydHkgPSB0cnVlO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgaWYgKChmbGFncyAmICgxIHwgMzIpKSA9PT0gKDEgfCAzMikpIHtcblx0XHRcdFx0aWYgKGxpbmsubmV4dFN1YiAhPT0gdm9pZCAwIHx8IGxpbmsucHJldlN1YiAhPT0gdm9pZCAwKSBzdGFjayA9IHtcblx0XHRcdFx0XHR2YWx1ZTogbGluayxcblx0XHRcdFx0XHRwcmV2OiBzdGFja1xuXHRcdFx0XHR9O1xuXHRcdFx0XHRsaW5rID0gZGVwLmRlcHM7XG5cdFx0XHRcdHN1YiA9IGRlcDtcblx0XHRcdFx0KytjaGVja0RlcHRoO1xuXHRcdFx0XHRjb250aW51ZTtcblx0XHRcdH1cblx0XHRcdGlmICghZGlydHkpIHtcblx0XHRcdFx0Y29uc3QgbmV4dERlcCA9IGxpbmsubmV4dERlcDtcblx0XHRcdFx0aWYgKG5leHREZXAgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdGxpbmsgPSBuZXh0RGVwO1xuXHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHR3aGlsZSAoY2hlY2tEZXB0aC0tKSB7XG5cdFx0XHRcdGNvbnN0IGZpcnN0U3ViID0gc3ViLnN1YnM7XG5cdFx0XHRcdGNvbnN0IGhhc011bHRpcGxlU3VicyA9IGZpcnN0U3ViLm5leHRTdWIgIT09IHZvaWQgMDtcblx0XHRcdFx0aWYgKGhhc011bHRpcGxlU3Vicykge1xuXHRcdFx0XHRcdGxpbmsgPSBzdGFjay52YWx1ZTtcblx0XHRcdFx0XHRzdGFjayA9IHN0YWNrLnByZXY7XG5cdFx0XHRcdH0gZWxzZSBsaW5rID0gZmlyc3RTdWI7XG5cdFx0XHRcdGlmIChkaXJ0eSkge1xuXHRcdFx0XHRcdGlmICh1cGRhdGUoc3ViKSkge1xuXHRcdFx0XHRcdFx0aWYgKGhhc011bHRpcGxlU3Vicykgc2hhbGxvd1Byb3BhZ2F0ZShmaXJzdFN1Yik7XG5cdFx0XHRcdFx0XHRzdWIgPSBsaW5rLnN1Yjtcblx0XHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRkaXJ0eSA9IGZhbHNlO1xuXHRcdFx0XHR9IGVsc2Ugc3ViLmZsYWdzICY9IH4zMjtcblx0XHRcdFx0c3ViID0gbGluay5zdWI7XG5cdFx0XHRcdGNvbnN0IG5leHREZXAgPSBsaW5rLm5leHREZXA7XG5cdFx0XHRcdGlmIChuZXh0RGVwICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRsaW5rID0gbmV4dERlcDtcblx0XHRcdFx0XHRjb250aW51ZSB0b3A7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdHJldHVybiBkaXJ0eTtcblx0XHR9IHdoaWxlICh0cnVlKTtcblx0fVxuXHRmdW5jdGlvbiBzaGFsbG93UHJvcGFnYXRlKGxpbmspIHtcblx0XHRkbyB7XG5cdFx0XHRjb25zdCBzdWIgPSBsaW5rLnN1Yjtcblx0XHRcdGNvbnN0IGZsYWdzID0gc3ViLmZsYWdzO1xuXHRcdFx0aWYgKChmbGFncyAmICgzMiB8IDE2KSkgPT09IDMyKSB7XG5cdFx0XHRcdHN1Yi5mbGFncyA9IGZsYWdzIHwgMTY7XG5cdFx0XHRcdGlmICgoZmxhZ3MgJiAoMiB8IDQpKSA9PT0gMikgbm90aWZ5KHN1Yik7XG5cdFx0XHR9XG5cdFx0fSB3aGlsZSAoKGxpbmsgPSBsaW5rLm5leHRTdWIpICE9PSB2b2lkIDApO1xuXHR9XG5cdGZ1bmN0aW9uIGlzVmFsaWRMaW5rKGNoZWNrTGluaywgc3ViKSB7XG5cdFx0bGV0IGxpbmsgPSBzdWIuZGVwc1RhaWw7XG5cdFx0d2hpbGUgKGxpbmsgIT09IHZvaWQgMCkge1xuXHRcdFx0aWYgKGxpbmsgPT09IGNoZWNrTGluaykgcmV0dXJuIHRydWU7XG5cdFx0XHRsaW5rID0gbGluay5wcmV2RGVwO1xuXHRcdH1cblx0XHRyZXR1cm4gZmFsc2U7XG5cdH1cbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjcmVhdGVSZWFjdGl2ZVN5c3RlbSB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YWxpZW4uanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlUmVhY3RpdmVTeXN0ZW0gfSBmcm9tIFwiLi9hbGllbi5qc1wiO1xuXG4vLyNyZWdpb24gc3JjL2F0b20udHNcbmZ1bmN0aW9uIHRvT2JzZXJ2ZXIobmV4dEhhbmRsZXIsIGVycm9ySGFuZGxlciwgY29tcGxldGlvbkhhbmRsZXIpIHtcblx0Y29uc3QgaXNPYnNlcnZlciA9IHR5cGVvZiBuZXh0SGFuZGxlciA9PT0gXCJvYmplY3RcIjtcblx0Y29uc3Qgc2VsZiA9IGlzT2JzZXJ2ZXIgPyBuZXh0SGFuZGxlciA6IHZvaWQgMDtcblx0cmV0dXJuIHtcblx0XHRuZXh0OiAoaXNPYnNlcnZlciA/IG5leHRIYW5kbGVyLm5leHQgOiBuZXh0SGFuZGxlcik/LmJpbmQoc2VsZiksXG5cdFx0ZXJyb3I6IChpc09ic2VydmVyID8gbmV4dEhhbmRsZXIuZXJyb3IgOiBlcnJvckhhbmRsZXIpPy5iaW5kKHNlbGYpLFxuXHRcdGNvbXBsZXRlOiAoaXNPYnNlcnZlciA/IG5leHRIYW5kbGVyLmNvbXBsZXRlIDogY29tcGxldGlvbkhhbmRsZXIpPy5iaW5kKHNlbGYpXG5cdH07XG59XG5jb25zdCBxdWV1ZWRFZmZlY3RzID0gW107XG5sZXQgY3ljbGUgPSAwO1xuY29uc3QgeyBsaW5rLCB1bmxpbmssIHByb3BhZ2F0ZSwgY2hlY2tEaXJ0eSwgc2hhbGxvd1Byb3BhZ2F0ZSB9ID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZVJlYWN0aXZlU3lzdGVtKHtcblx0dXBkYXRlKGF0b20pIHtcblx0XHRyZXR1cm4gYXRvbS5fdXBkYXRlKCk7XG5cdH0sXG5cdG5vdGlmeShlZmZlY3QpIHtcblx0XHRxdWV1ZWRFZmZlY3RzW3F1ZXVlZEVmZmVjdHNMZW5ndGgrK10gPSBlZmZlY3Q7XG5cdFx0ZWZmZWN0LmZsYWdzICY9IH4yO1xuXHR9LFxuXHR1bndhdGNoZWQoYXRvbSkge1xuXHRcdGlmIChhdG9tLmRlcHNUYWlsICE9PSB2b2lkIDApIHtcblx0XHRcdGF0b20uZGVwc1RhaWwgPSB2b2lkIDA7XG5cdFx0XHRhdG9tLmZsYWdzID0gMSB8IDE2O1xuXHRcdFx0cHVyZ2VEZXBzKGF0b20pO1xuXHRcdH1cblx0fVxufSk7XG5sZXQgbm90aWZ5SW5kZXggPSAwO1xubGV0IHF1ZXVlZEVmZmVjdHNMZW5ndGggPSAwO1xubGV0IGFjdGl2ZVN1YjtcbmxldCBiYXRjaERlcHRoID0gMDtcbmZ1bmN0aW9uIGJhdGNoKGZuKSB7XG5cdHRyeSB7XG5cdFx0KytiYXRjaERlcHRoO1xuXHRcdGZuKCk7XG5cdH0gZmluYWxseSB7XG5cdFx0aWYgKCEtLWJhdGNoRGVwdGgpIGZsdXNoKCk7XG5cdH1cbn1cbmZ1bmN0aW9uIHB1cmdlRGVwcyhzdWIpIHtcblx0Y29uc3QgZGVwc1RhaWwgPSBzdWIuZGVwc1RhaWw7XG5cdGxldCBkZXAgPSBkZXBzVGFpbCAhPT0gdm9pZCAwID8gZGVwc1RhaWwubmV4dERlcCA6IHN1Yi5kZXBzO1xuXHR3aGlsZSAoZGVwICE9PSB2b2lkIDApIGRlcCA9IHVubGluayhkZXAsIHN1Yik7XG59XG5mdW5jdGlvbiBmbHVzaCgpIHtcblx0aWYgKGJhdGNoRGVwdGggPiAwKSByZXR1cm47XG5cdHdoaWxlIChub3RpZnlJbmRleCA8IHF1ZXVlZEVmZmVjdHNMZW5ndGgpIHtcblx0XHRjb25zdCBlZmZlY3QgPSBxdWV1ZWRFZmZlY3RzW25vdGlmeUluZGV4XTtcblx0XHRxdWV1ZWRFZmZlY3RzW25vdGlmeUluZGV4KytdID0gdm9pZCAwO1xuXHRcdGVmZmVjdC5ub3RpZnkoKTtcblx0fVxuXHRub3RpZnlJbmRleCA9IDA7XG5cdHF1ZXVlZEVmZmVjdHNMZW5ndGggPSAwO1xufVxuZnVuY3Rpb24gY3JlYXRlQXN5bmNBdG9tKGdldFZhbHVlLCBvcHRpb25zKSB7XG5cdGNvbnN0IHJlZiA9IHt9O1xuXHRjb25zdCBhdG9tID0gY3JlYXRlQXRvbSgoKSA9PiB7XG5cdFx0Z2V0VmFsdWUoKS50aGVuKChkYXRhKSA9PiB7XG5cdFx0XHRjb25zdCBpbnRlcm5hbEF0b20gPSByZWYuY3VycmVudDtcblx0XHRcdGlmIChpbnRlcm5hbEF0b20uX3VwZGF0ZSh7XG5cdFx0XHRcdHN0YXR1czogXCJkb25lXCIsXG5cdFx0XHRcdGRhdGFcblx0XHRcdH0pKSB7XG5cdFx0XHRcdGNvbnN0IHN1YnMgPSBpbnRlcm5hbEF0b20uc3Vicztcblx0XHRcdFx0aWYgKHN1YnMgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRcdHByb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0XHRzaGFsbG93UHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHRcdGZsdXNoKCk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9LCAoZXJyb3IpID0+IHtcblx0XHRcdGNvbnN0IGludGVybmFsQXRvbSA9IHJlZi5jdXJyZW50O1xuXHRcdFx0aWYgKGludGVybmFsQXRvbS5fdXBkYXRlKHtcblx0XHRcdFx0c3RhdHVzOiBcImVycm9yXCIsXG5cdFx0XHRcdGVycm9yXG5cdFx0XHR9KSkge1xuXHRcdFx0XHRjb25zdCBzdWJzID0gaW50ZXJuYWxBdG9tLnN1YnM7XG5cdFx0XHRcdGlmIChzdWJzICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRwcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdFx0c2hhbGxvd1Byb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0XHRmbHVzaCgpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHsgc3RhdHVzOiBcInBlbmRpbmdcIiB9O1xuXHR9LCBvcHRpb25zKTtcblx0cmVmLmN1cnJlbnQgPSBhdG9tO1xuXHRyZXR1cm4gYXRvbTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUF0b20odmFsdWVPckZuLCBvcHRpb25zKSB7XG5cdGNvbnN0IGlzQ29tcHV0ZWQgPSB0eXBlb2YgdmFsdWVPckZuID09PSBcImZ1bmN0aW9uXCI7XG5cdGNvbnN0IGdldHRlciA9IHZhbHVlT3JGbjtcblx0Y29uc3QgYXRvbSA9IHtcblx0XHRfc25hcHNob3Q6IGlzQ29tcHV0ZWQgPyB2b2lkIDAgOiB2YWx1ZU9yRm4sXG5cdFx0c3Viczogdm9pZCAwLFxuXHRcdHN1YnNUYWlsOiB2b2lkIDAsXG5cdFx0ZGVwczogdm9pZCAwLFxuXHRcdGRlcHNUYWlsOiB2b2lkIDAsXG5cdFx0ZmxhZ3M6IGlzQ29tcHV0ZWQgPyAwIDogMSxcblx0XHRnZXQoKSB7XG5cdFx0XHRpZiAoYWN0aXZlU3ViICE9PSB2b2lkIDApIGxpbmsoYXRvbSwgYWN0aXZlU3ViLCBjeWNsZSk7XG5cdFx0XHRyZXR1cm4gYXRvbS5fc25hcHNob3Q7XG5cdFx0fSxcblx0XHRzdWJzY3JpYmUob2JzZXJ2ZXJPckZuKSB7XG5cdFx0XHRjb25zdCBvYnMgPSB0b09ic2VydmVyKG9ic2VydmVyT3JGbik7XG5cdFx0XHRjb25zdCBvYnNlcnZlZCA9IHsgY3VycmVudDogZmFsc2UgfTtcblx0XHRcdGNvbnN0IGUgPSBlZmZlY3QoKCkgPT4ge1xuXHRcdFx0XHRhdG9tLmdldCgpO1xuXHRcdFx0XHRpZiAoIW9ic2VydmVkLmN1cnJlbnQpIG9ic2VydmVkLmN1cnJlbnQgPSB0cnVlO1xuXHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRhY3RpdmVTdWIgPSB2b2lkIDA7XG5cdFx0XHRcdFx0b2JzLm5leHQ/LihhdG9tLl9zbmFwc2hvdCk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIHsgdW5zdWJzY3JpYmU6ICgpID0+IHtcblx0XHRcdFx0ZS5zdG9wKCk7XG5cdFx0XHR9IH07XG5cdFx0fSxcblx0XHRfdXBkYXRlKGdldFZhbHVlKSB7XG5cdFx0XHRjb25zdCBwcmV2U3ViID0gYWN0aXZlU3ViO1xuXHRcdFx0Y29uc3QgY29tcGFyZSA9IG9wdGlvbnM/LmNvbXBhcmUgPz8gT2JqZWN0LmlzO1xuXHRcdFx0aWYgKGlzQ29tcHV0ZWQpIHtcblx0XHRcdFx0YWN0aXZlU3ViID0gYXRvbTtcblx0XHRcdFx0KytjeWNsZTtcblx0XHRcdFx0YXRvbS5kZXBzVGFpbCA9IHZvaWQgMDtcblx0XHRcdH0gZWxzZSBpZiAoZ2V0VmFsdWUgPT09IHZvaWQgMCkgcmV0dXJuIGZhbHNlO1xuXHRcdFx0aWYgKGlzQ29tcHV0ZWQpIGF0b20uZmxhZ3MgPSAxIHwgNDtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IG9sZFZhbHVlID0gYXRvbS5fc25hcHNob3Q7XG5cdFx0XHRcdGNvbnN0IG5ld1ZhbHVlID0gdHlwZW9mIGdldFZhbHVlID09PSBcImZ1bmN0aW9uXCIgPyBnZXRWYWx1ZShvbGRWYWx1ZSkgOiBnZXRWYWx1ZSA9PT0gdm9pZCAwICYmIGlzQ29tcHV0ZWQgPyBnZXR0ZXIob2xkVmFsdWUpIDogZ2V0VmFsdWU7XG5cdFx0XHRcdGlmIChvbGRWYWx1ZSA9PT0gdm9pZCAwIHx8ICFjb21wYXJlKG9sZFZhbHVlLCBuZXdWYWx1ZSkpIHtcblx0XHRcdFx0XHRhdG9tLl9zbmFwc2hvdCA9IG5ld1ZhbHVlO1xuXHRcdFx0XHRcdHJldHVybiB0cnVlO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBmYWxzZTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdGFjdGl2ZVN1YiA9IHByZXZTdWI7XG5cdFx0XHRcdGlmIChpc0NvbXB1dGVkKSBhdG9tLmZsYWdzICY9IH40O1xuXHRcdFx0XHRwdXJnZURlcHMoYXRvbSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xuXHRpZiAoaXNDb21wdXRlZCkge1xuXHRcdGF0b20uZmxhZ3MgPSAxIHwgMTY7XG5cdFx0YXRvbS5nZXQgPSBmdW5jdGlvbigpIHtcblx0XHRcdGNvbnN0IGZsYWdzID0gYXRvbS5mbGFncztcblx0XHRcdGlmIChmbGFncyAmIDE2IHx8IGZsYWdzICYgMzIgJiYgY2hlY2tEaXJ0eShhdG9tLmRlcHMsIGF0b20pKSB7XG5cdFx0XHRcdGlmIChhdG9tLl91cGRhdGUoKSkge1xuXHRcdFx0XHRcdGNvbnN0IHN1YnMgPSBhdG9tLnN1YnM7XG5cdFx0XHRcdFx0aWYgKHN1YnMgIT09IHZvaWQgMCkgc2hhbGxvd1Byb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmIChmbGFncyAmIDMyKSBhdG9tLmZsYWdzID0gZmxhZ3MgJiB+MzI7XG5cdFx0XHRpZiAoYWN0aXZlU3ViICE9PSB2b2lkIDApIGxpbmsoYXRvbSwgYWN0aXZlU3ViLCBjeWNsZSk7XG5cdFx0XHRyZXR1cm4gYXRvbS5fc25hcHNob3Q7XG5cdFx0fTtcblx0fSBlbHNlIGF0b20uc2V0ID0gZnVuY3Rpb24odmFsdWVPckZuKSB7XG5cdFx0aWYgKGF0b20uX3VwZGF0ZSh2YWx1ZU9yRm4pKSB7XG5cdFx0XHRjb25zdCBzdWJzID0gYXRvbS5zdWJzO1xuXHRcdFx0aWYgKHN1YnMgIT09IHZvaWQgMCkge1xuXHRcdFx0XHRwcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdHNoYWxsb3dQcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdGZsdXNoKCk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9O1xuXHRyZXR1cm4gYXRvbTtcbn1cbmZ1bmN0aW9uIGVmZmVjdChmbikge1xuXHRjb25zdCBydW4gPSAoKSA9PiB7XG5cdFx0Y29uc3QgcHJldlN1YiA9IGFjdGl2ZVN1Yjtcblx0XHRhY3RpdmVTdWIgPSBlZmZlY3RPYmo7XG5cdFx0KytjeWNsZTtcblx0XHRlZmZlY3RPYmouZGVwc1RhaWwgPSB2b2lkIDA7XG5cdFx0ZWZmZWN0T2JqLmZsYWdzID0gMiB8IDQ7XG5cdFx0dHJ5IHtcblx0XHRcdHJldHVybiBmbigpO1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRhY3RpdmVTdWIgPSBwcmV2U3ViO1xuXHRcdFx0ZWZmZWN0T2JqLmZsYWdzICY9IH40O1xuXHRcdFx0cHVyZ2VEZXBzKGVmZmVjdE9iaik7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBlZmZlY3RPYmogPSB7XG5cdFx0ZGVwczogdm9pZCAwLFxuXHRcdGRlcHNUYWlsOiB2b2lkIDAsXG5cdFx0c3Viczogdm9pZCAwLFxuXHRcdHN1YnNUYWlsOiB2b2lkIDAsXG5cdFx0ZmxhZ3M6IDIgfCA0LFxuXHRcdG5vdGlmeSgpIHtcblx0XHRcdGNvbnN0IGZsYWdzID0gdGhpcy5mbGFncztcblx0XHRcdGlmIChmbGFncyAmIDE2IHx8IGZsYWdzICYgMzIgJiYgY2hlY2tEaXJ0eSh0aGlzLmRlcHMsIHRoaXMpKSBydW4oKTtcblx0XHRcdGVsc2UgdGhpcy5mbGFncyA9IDI7XG5cdFx0fSxcblx0XHRzdG9wKCkge1xuXHRcdFx0dGhpcy5mbGFncyA9IDA7XG5cdFx0XHR0aGlzLmRlcHNUYWlsID0gdm9pZCAwO1xuXHRcdFx0cHVyZ2VEZXBzKHRoaXMpO1xuXHRcdH1cblx0fTtcblx0cnVuKCk7XG5cdHJldHVybiBlZmZlY3RPYmo7XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgYmF0Y2gsIGNyZWF0ZUFzeW5jQXRvbSwgY3JlYXRlQXRvbSwgZmx1c2gsIHRvT2JzZXJ2ZXIgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWF0b20uanMubWFwIiwiLyoqXG4gKiBAbGljZW5zZSBSZWFjdFxuICogdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS5kZXZlbG9wbWVudC5qc1xuICpcbiAqIENvcHlyaWdodCAoYykgTWV0YSBQbGF0Zm9ybXMsIEluYy4gYW5kIGFmZmlsaWF0ZXMuXG4gKlxuICogVGhpcyBzb3VyY2UgY29kZSBpcyBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGxpY2Vuc2UgZm91bmQgaW4gdGhlXG4gKiBMSUNFTlNFIGZpbGUgaW4gdGhlIHJvb3QgZGlyZWN0b3J5IG9mIHRoaXMgc291cmNlIHRyZWUuXG4gKi9cblxuXCJ1c2Ugc3RyaWN0XCI7XG5cInByb2R1Y3Rpb25cIiAhPT0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgJiZcbiAgKGZ1bmN0aW9uICgpIHtcbiAgICBmdW5jdGlvbiBpcyh4LCB5KSB7XG4gICAgICByZXR1cm4gKHggPT09IHkgJiYgKDAgIT09IHggfHwgMSAvIHggPT09IDEgLyB5KSkgfHwgKHggIT09IHggJiYgeSAhPT0geSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHVzZVN5bmNFeHRlcm5hbFN0b3JlJDIoc3Vic2NyaWJlLCBnZXRTbmFwc2hvdCkge1xuICAgICAgZGlkV2Fybk9sZDE4QWxwaGEgfHxcbiAgICAgICAgdm9pZCAwID09PSBSZWFjdC5zdGFydFRyYW5zaXRpb24gfHxcbiAgICAgICAgKChkaWRXYXJuT2xkMThBbHBoYSA9ICEwKSxcbiAgICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgICBcIllvdSBhcmUgdXNpbmcgYW4gb3V0ZGF0ZWQsIHByZS1yZWxlYXNlIGFscGhhIG9mIFJlYWN0IDE4IHRoYXQgZG9lcyBub3Qgc3VwcG9ydCB1c2VTeW5jRXh0ZXJuYWxTdG9yZS4gVGhlIHVzZS1zeW5jLWV4dGVybmFsLXN0b3JlIHNoaW0gd2lsbCBub3Qgd29yayBjb3JyZWN0bHkuIFVwZ3JhZGUgdG8gYSBuZXdlciBwcmUtcmVsZWFzZS5cIlxuICAgICAgICApKTtcbiAgICAgIHZhciB2YWx1ZSA9IGdldFNuYXBzaG90KCk7XG4gICAgICBpZiAoIWRpZFdhcm5VbmNhY2hlZEdldFNuYXBzaG90KSB7XG4gICAgICAgIHZhciBjYWNoZWRWYWx1ZSA9IGdldFNuYXBzaG90KCk7XG4gICAgICAgIG9iamVjdElzKHZhbHVlLCBjYWNoZWRWYWx1ZSkgfHxcbiAgICAgICAgICAoY29uc29sZS5lcnJvcihcbiAgICAgICAgICAgIFwiVGhlIHJlc3VsdCBvZiBnZXRTbmFwc2hvdCBzaG91bGQgYmUgY2FjaGVkIHRvIGF2b2lkIGFuIGluZmluaXRlIGxvb3BcIlxuICAgICAgICAgICksXG4gICAgICAgICAgKGRpZFdhcm5VbmNhY2hlZEdldFNuYXBzaG90ID0gITApKTtcbiAgICAgIH1cbiAgICAgIGNhY2hlZFZhbHVlID0gdXNlU3RhdGUoe1xuICAgICAgICBpbnN0OiB7IHZhbHVlOiB2YWx1ZSwgZ2V0U25hcHNob3Q6IGdldFNuYXBzaG90IH1cbiAgICAgIH0pO1xuICAgICAgdmFyIGluc3QgPSBjYWNoZWRWYWx1ZVswXS5pbnN0LFxuICAgICAgICBmb3JjZVVwZGF0ZSA9IGNhY2hlZFZhbHVlWzFdO1xuICAgICAgdXNlTGF5b3V0RWZmZWN0KFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaW5zdC52YWx1ZSA9IHZhbHVlO1xuICAgICAgICAgIGluc3QuZ2V0U25hcHNob3QgPSBnZXRTbmFwc2hvdDtcbiAgICAgICAgICBjaGVja0lmU25hcHNob3RDaGFuZ2VkKGluc3QpICYmIGZvcmNlVXBkYXRlKHsgaW5zdDogaW5zdCB9KTtcbiAgICAgICAgfSxcbiAgICAgICAgW3N1YnNjcmliZSwgdmFsdWUsIGdldFNuYXBzaG90XVxuICAgICAgKTtcbiAgICAgIHVzZUVmZmVjdChcbiAgICAgICAgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGNoZWNrSWZTbmFwc2hvdENoYW5nZWQoaW5zdCkgJiYgZm9yY2VVcGRhdGUoeyBpbnN0OiBpbnN0IH0pO1xuICAgICAgICAgIHJldHVybiBzdWJzY3JpYmUoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgY2hlY2tJZlNuYXBzaG90Q2hhbmdlZChpbnN0KSAmJiBmb3JjZVVwZGF0ZSh7IGluc3Q6IGluc3QgfSk7XG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIFtzdWJzY3JpYmVdXG4gICAgICApO1xuICAgICAgdXNlRGVidWdWYWx1ZSh2YWx1ZSk7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNoZWNrSWZTbmFwc2hvdENoYW5nZWQoaW5zdCkge1xuICAgICAgdmFyIGxhdGVzdEdldFNuYXBzaG90ID0gaW5zdC5nZXRTbmFwc2hvdDtcbiAgICAgIGluc3QgPSBpbnN0LnZhbHVlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmFyIG5leHRWYWx1ZSA9IGxhdGVzdEdldFNuYXBzaG90KCk7XG4gICAgICAgIHJldHVybiAhb2JqZWN0SXMoaW5zdCwgbmV4dFZhbHVlKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiAhMDtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gdXNlU3luY0V4dGVybmFsU3RvcmUkMShzdWJzY3JpYmUsIGdldFNuYXBzaG90KSB7XG4gICAgICByZXR1cm4gZ2V0U25hcHNob3QoKTtcbiAgICB9XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydCAmJlxuICAgICAgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydChFcnJvcigpKTtcbiAgICB2YXIgUmVhY3QgPSByZXF1aXJlKFwicmVhY3RcIiksXG4gICAgICBvYmplY3RJcyA9IFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIE9iamVjdC5pcyA/IE9iamVjdC5pcyA6IGlzLFxuICAgICAgdXNlU3RhdGUgPSBSZWFjdC51c2VTdGF0ZSxcbiAgICAgIHVzZUVmZmVjdCA9IFJlYWN0LnVzZUVmZmVjdCxcbiAgICAgIHVzZUxheW91dEVmZmVjdCA9IFJlYWN0LnVzZUxheW91dEVmZmVjdCxcbiAgICAgIHVzZURlYnVnVmFsdWUgPSBSZWFjdC51c2VEZWJ1Z1ZhbHVlLFxuICAgICAgZGlkV2Fybk9sZDE4QWxwaGEgPSAhMSxcbiAgICAgIGRpZFdhcm5VbmNhY2hlZEdldFNuYXBzaG90ID0gITEsXG4gICAgICBzaGltID1cbiAgICAgICAgXCJ1bmRlZmluZWRcIiA9PT0gdHlwZW9mIHdpbmRvdyB8fFxuICAgICAgICBcInVuZGVmaW5lZFwiID09PSB0eXBlb2Ygd2luZG93LmRvY3VtZW50IHx8XG4gICAgICAgIFwidW5kZWZpbmVkXCIgPT09IHR5cGVvZiB3aW5kb3cuZG9jdW1lbnQuY3JlYXRlRWxlbWVudFxuICAgICAgICAgID8gdXNlU3luY0V4dGVybmFsU3RvcmUkMVxuICAgICAgICAgIDogdXNlU3luY0V4dGVybmFsU3RvcmUkMjtcbiAgICBleHBvcnRzLnVzZVN5bmNFeHRlcm5hbFN0b3JlID1cbiAgICAgIHZvaWQgMCAhPT0gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUgPyBSZWFjdC51c2VTeW5jRXh0ZXJuYWxTdG9yZSA6IHNoaW07XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdG9wICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AoRXJyb3IoKSk7XG4gIH0pKCk7XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi4vY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXNoaW0ucHJvZHVjdGlvbi5qcycpO1xufSBlbHNlIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuLi9janMvdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS5kZXZlbG9wbWVudC5qcycpO1xufVxuIiwiLyoqXG4gKiBAbGljZW5zZSBSZWFjdFxuICogdXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUtc2hpbS93aXRoLXNlbGVjdG9yLmRldmVsb3BtZW50LmpzXG4gKlxuICogQ29weXJpZ2h0IChjKSBNZXRhIFBsYXRmb3JtcywgSW5jLiBhbmQgYWZmaWxpYXRlcy5cbiAqXG4gKiBUaGlzIHNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIHVuZGVyIHRoZSBNSVQgbGljZW5zZSBmb3VuZCBpbiB0aGVcbiAqIExJQ0VOU0UgZmlsZSBpbiB0aGUgcm9vdCBkaXJlY3Rvcnkgb2YgdGhpcyBzb3VyY2UgdHJlZS5cbiAqL1xuXG5cInVzZSBzdHJpY3RcIjtcblwicHJvZHVjdGlvblwiICE9PSBwcm9jZXNzLmVudi5OT0RFX0VOViAmJlxuICAoZnVuY3Rpb24gKCkge1xuICAgIGZ1bmN0aW9uIGlzKHgsIHkpIHtcbiAgICAgIHJldHVybiAoeCA9PT0geSAmJiAoMCAhPT0geCB8fCAxIC8geCA9PT0gMSAvIHkpKSB8fCAoeCAhPT0geCAmJiB5ICE9PSB5KTtcbiAgICB9XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydCAmJlxuICAgICAgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdGFydChFcnJvcigpKTtcbiAgICB2YXIgUmVhY3QgPSByZXF1aXJlKFwicmVhY3RcIiksXG4gICAgICBzaGltID0gcmVxdWlyZShcInVzZS1zeW5jLWV4dGVybmFsLXN0b3JlL3NoaW1cIiksXG4gICAgICBvYmplY3RJcyA9IFwiZnVuY3Rpb25cIiA9PT0gdHlwZW9mIE9iamVjdC5pcyA/IE9iamVjdC5pcyA6IGlzLFxuICAgICAgdXNlU3luY0V4dGVybmFsU3RvcmUgPSBzaGltLnVzZVN5bmNFeHRlcm5hbFN0b3JlLFxuICAgICAgdXNlUmVmID0gUmVhY3QudXNlUmVmLFxuICAgICAgdXNlRWZmZWN0ID0gUmVhY3QudXNlRWZmZWN0LFxuICAgICAgdXNlTWVtbyA9IFJlYWN0LnVzZU1lbW8sXG4gICAgICB1c2VEZWJ1Z1ZhbHVlID0gUmVhY3QudXNlRGVidWdWYWx1ZTtcbiAgICBleHBvcnRzLnVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yID0gZnVuY3Rpb24gKFxuICAgICAgc3Vic2NyaWJlLFxuICAgICAgZ2V0U25hcHNob3QsXG4gICAgICBnZXRTZXJ2ZXJTbmFwc2hvdCxcbiAgICAgIHNlbGVjdG9yLFxuICAgICAgaXNFcXVhbFxuICAgICkge1xuICAgICAgdmFyIGluc3RSZWYgPSB1c2VSZWYobnVsbCk7XG4gICAgICBpZiAobnVsbCA9PT0gaW5zdFJlZi5jdXJyZW50KSB7XG4gICAgICAgIHZhciBpbnN0ID0geyBoYXNWYWx1ZTogITEsIHZhbHVlOiBudWxsIH07XG4gICAgICAgIGluc3RSZWYuY3VycmVudCA9IGluc3Q7XG4gICAgICB9IGVsc2UgaW5zdCA9IGluc3RSZWYuY3VycmVudDtcbiAgICAgIGluc3RSZWYgPSB1c2VNZW1vKFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgZnVuY3Rpb24gbWVtb2l6ZWRTZWxlY3RvcihuZXh0U25hcHNob3QpIHtcbiAgICAgICAgICAgIGlmICghaGFzTWVtbykge1xuICAgICAgICAgICAgICBoYXNNZW1vID0gITA7XG4gICAgICAgICAgICAgIG1lbW9pemVkU25hcHNob3QgPSBuZXh0U25hcHNob3Q7XG4gICAgICAgICAgICAgIG5leHRTbmFwc2hvdCA9IHNlbGVjdG9yKG5leHRTbmFwc2hvdCk7XG4gICAgICAgICAgICAgIGlmICh2b2lkIDAgIT09IGlzRXF1YWwgJiYgaW5zdC5oYXNWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHZhciBjdXJyZW50U2VsZWN0aW9uID0gaW5zdC52YWx1ZTtcbiAgICAgICAgICAgICAgICBpZiAoaXNFcXVhbChjdXJyZW50U2VsZWN0aW9uLCBuZXh0U25hcHNob3QpKVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIChtZW1vaXplZFNlbGVjdGlvbiA9IGN1cnJlbnRTZWxlY3Rpb24pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIHJldHVybiAobWVtb2l6ZWRTZWxlY3Rpb24gPSBuZXh0U25hcHNob3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY3VycmVudFNlbGVjdGlvbiA9IG1lbW9pemVkU2VsZWN0aW9uO1xuICAgICAgICAgICAgaWYgKG9iamVjdElzKG1lbW9pemVkU25hcHNob3QsIG5leHRTbmFwc2hvdCkpXG4gICAgICAgICAgICAgIHJldHVybiBjdXJyZW50U2VsZWN0aW9uO1xuICAgICAgICAgICAgdmFyIG5leHRTZWxlY3Rpb24gPSBzZWxlY3RvcihuZXh0U25hcHNob3QpO1xuICAgICAgICAgICAgaWYgKHZvaWQgMCAhPT0gaXNFcXVhbCAmJiBpc0VxdWFsKGN1cnJlbnRTZWxlY3Rpb24sIG5leHRTZWxlY3Rpb24pKVxuICAgICAgICAgICAgICByZXR1cm4gKG1lbW9pemVkU25hcHNob3QgPSBuZXh0U25hcHNob3QpLCBjdXJyZW50U2VsZWN0aW9uO1xuICAgICAgICAgICAgbWVtb2l6ZWRTbmFwc2hvdCA9IG5leHRTbmFwc2hvdDtcbiAgICAgICAgICAgIHJldHVybiAobWVtb2l6ZWRTZWxlY3Rpb24gPSBuZXh0U2VsZWN0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFyIGhhc01lbW8gPSAhMSxcbiAgICAgICAgICAgIG1lbW9pemVkU25hcHNob3QsXG4gICAgICAgICAgICBtZW1vaXplZFNlbGVjdGlvbixcbiAgICAgICAgICAgIG1heWJlR2V0U2VydmVyU25hcHNob3QgPVxuICAgICAgICAgICAgICB2b2lkIDAgPT09IGdldFNlcnZlclNuYXBzaG90ID8gbnVsbCA6IGdldFNlcnZlclNuYXBzaG90O1xuICAgICAgICAgIHJldHVybiBbXG4gICAgICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgIHJldHVybiBtZW1vaXplZFNlbGVjdG9yKGdldFNuYXBzaG90KCkpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG51bGwgPT09IG1heWJlR2V0U2VydmVyU25hcHNob3RcbiAgICAgICAgICAgICAgPyB2b2lkIDBcbiAgICAgICAgICAgICAgOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gbWVtb2l6ZWRTZWxlY3RvcihtYXliZUdldFNlcnZlclNuYXBzaG90KCkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICBdO1xuICAgICAgICB9LFxuICAgICAgICBbZ2V0U25hcHNob3QsIGdldFNlcnZlclNuYXBzaG90LCBzZWxlY3RvciwgaXNFcXVhbF1cbiAgICAgICk7XG4gICAgICB2YXIgdmFsdWUgPSB1c2VTeW5jRXh0ZXJuYWxTdG9yZShzdWJzY3JpYmUsIGluc3RSZWZbMF0sIGluc3RSZWZbMV0pO1xuICAgICAgdXNlRWZmZWN0KFxuICAgICAgICBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgaW5zdC5oYXNWYWx1ZSA9ICEwO1xuICAgICAgICAgIGluc3QudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgfSxcbiAgICAgICAgW3ZhbHVlXVxuICAgICAgKTtcbiAgICAgIHVzZURlYnVnVmFsdWUodmFsdWUpO1xuICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH07XG4gICAgXCJ1bmRlZmluZWRcIiAhPT0gdHlwZW9mIF9fUkVBQ1RfREVWVE9PTFNfR0xPQkFMX0hPT0tfXyAmJlxuICAgICAgXCJmdW5jdGlvblwiID09PVxuICAgICAgICB0eXBlb2YgX19SRUFDVF9ERVZUT09MU19HTE9CQUxfSE9PS19fLnJlZ2lzdGVySW50ZXJuYWxNb2R1bGVTdG9wICYmXG4gICAgICBfX1JFQUNUX0RFVlRPT0xTX0dMT0JBTF9IT09LX18ucmVnaXN0ZXJJbnRlcm5hbE1vZHVsZVN0b3AoRXJyb3IoKSk7XG4gIH0pKCk7XG4iLCIndXNlIHN0cmljdCc7XG5cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gJ3Byb2R1Y3Rpb24nKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi4vY2pzL3VzZS1zeW5jLWV4dGVybmFsLXN0b3JlLXNoaW0vd2l0aC1zZWxlY3Rvci5wcm9kdWN0aW9uLmpzJyk7XG59IGVsc2Uge1xuICBtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4uL2Nqcy91c2Utc3luYy1leHRlcm5hbC1zdG9yZS1zaGltL3dpdGgtc2VsZWN0b3IuZGV2ZWxvcG1lbnQuanMnKTtcbn1cbiIsImltcG9ydCB7IHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvciB9IGZyb20gXCJ1c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltL3dpdGgtc2VsZWN0b3JcIjtcblxuLy8jcmVnaW9uIHNyYy91c2VTZWxlY3Rvci50c1xuZnVuY3Rpb24gZGVmYXVsdENvbXBhcmUoYSwgYikge1xuXHRyZXR1cm4gYSA9PT0gYjtcbn1cbi8qKlxuKiBTZWxlY3RzIGEgc2xpY2Ugb2Ygc3RhdGUgZnJvbSBhbiBhdG9tIG9yIHN0b3JlIGFuZCBzdWJzY3JpYmVzIHRoZSBjb21wb25lbnRcbiogdG8gdGhhdCBzZWxlY3Rpb24uXG4qXG4qIFRoaXMgaXMgdGhlIHByaW1hcnkgUmVhY3QgcmVhZCBob29rIGZvciBUYW5TdGFjayBTdG9yZS4gSXQgd29ya3Mgd2l0aCBhbnlcbiogc291cmNlIHRoYXQgZXhwb3NlcyBgZ2V0KClgIGFuZCBgc3Vic2NyaWJlKClgLCBpbmNsdWRpbmcgYXRvbXMsIHJlYWRvbmx5XG4qIGF0b21zLCBzdG9yZXMsIGFuZCByZWFkb25seSBzdG9yZXMuXG4qXG4qIE9taXQgdGhlIHNlbGVjdG9yIHRvIHN1YnNjcmliZSB0byB0aGUgd2hvbGUgdmFsdWUuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBjb25zdCBjb3VudCA9IHVzZVNlbGVjdG9yKGNvdW50ZXJTdG9yZSwgKHN0YXRlKSA9PiBzdGF0ZS5jb3VudClcbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBjb25zdCB2YWx1ZSA9IHVzZVNlbGVjdG9yKGNvdW50QXRvbSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlU2VsZWN0b3Ioc291cmNlLCBzZWxlY3RvciA9IChzKSA9PiBzLCBvcHRpb25zKSB7XG5cdGNvbnN0IGNvbXBhcmUgPSBvcHRpb25zPy5jb21wYXJlID8/IGRlZmF1bHRDb21wYXJlO1xuXHRjb25zdCBzdWJzY3JpYmUgPSB1c2VDYWxsYmFjaygoaGFuZGxlU3RvcmVDaGFuZ2UpID0+IHtcblx0XHRjb25zdCB7IHVuc3Vic2NyaWJlIH0gPSBzb3VyY2Uuc3Vic2NyaWJlKGhhbmRsZVN0b3JlQ2hhbmdlKTtcblx0XHRyZXR1cm4gdW5zdWJzY3JpYmU7XG5cdH0sIFtzb3VyY2VdKTtcblx0Y29uc3QgZ2V0U25hcHNob3QgPSB1c2VDYWxsYmFjaygoKSA9PiBzb3VyY2UuZ2V0KCksIFtzb3VyY2VdKTtcblx0cmV0dXJuIHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yKHN1YnNjcmliZSwgZ2V0U25hcHNob3QsIGdldFNuYXBzaG90LCBzZWxlY3RvciwgY29tcGFyZSk7XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU2VsZWN0b3IgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVNlbGVjdG9yLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZHVtbXlNYXRjaENvbnRleHQsIG1hdGNoQ29udGV4dCB9IGZyb20gXCIuL21hdGNoQ29udGV4dC5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBpbnZhcmlhbnQsIHJlcGxhY2VFcXVhbERlZXAgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTWF0Y2gudHN4XG52YXIgZHVtbXlNYXRjaCA9IHt9O1xuZnVuY3Rpb24gdXNlU3RydWN0dXJhbFNoYXJpbmcob3B0cywgcm91dGVyKSB7XG5cdGNvbnN0IHByZXZpb3VzUmVzdWx0ID0gUmVhY3QkMS51c2VSZWYoKTtcblx0cmV0dXJuIChzbGljZSkgPT4ge1xuXHRcdGNvbnN0IHNlbGVjdGVkID0gb3B0cz8uc2VsZWN0ID8gb3B0cy5zZWxlY3Qoc2xpY2UpIDogc2xpY2U7XG5cdFx0aWYgKG9wdHM/LnN0cnVjdHVyYWxTaGFyaW5nID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRTdHJ1Y3R1cmFsU2hhcmluZykgcmV0dXJuIHByZXZpb3VzUmVzdWx0LmN1cnJlbnQgPSByZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzUmVzdWx0LmN1cnJlbnQsIHNlbGVjdGVkKTtcblx0XHRyZXR1cm4gc2VsZWN0ZWQ7XG5cdH07XG59XG4vKipcbiogUmVhZCBhbmQgc2VsZWN0IHRoZSBuZWFyZXN0IG9yIHRhcmdldGVkIHJvdXRlIG1hdGNoLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlTWF0Y2hIb29rXG4qL1xuZnVuY3Rpb24gdXNlTWF0Y2gob3B0cykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3QgbmVhcmVzdFJvdXRlSWQgPSBSZWFjdCQxLnVzZUNvbnRleHQob3B0cy5mcm9tID8gZHVtbXlNYXRjaENvbnRleHQgOiBtYXRjaENvbnRleHQpO1xuXHRjb25zdCByb3V0ZUlkID0gb3B0cy5mcm9tID8/IG5lYXJlc3RSb3V0ZUlkO1xuXHRjb25zdCBtYXRjaFN0b3JlID0gcm91dGVyLnN0b3Jlcy5nZXRNYXRjaFN0b3JlKHJvdXRlSWQpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaFN0b3JlLmdldCgpO1xuXHRcdGlmICghbWF0Y2gpIHtcblx0XHRcdGlmIChvcHRzLnNob3VsZFRocm93ID8/IHRydWUpIHtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhyb3cgbmV3IEVycm9yKGBJbnZhcmlhbnQgZmFpbGVkOiBDb3VsZCBub3QgZmluZCAke29wdHMuZnJvbSA/IGBhbiBhY3RpdmUgbWF0Y2ggZnJvbSBcIiR7b3B0cy5mcm9tfVwiYCA6IFwiYSBuZWFyZXN0IG1hdGNoIVwifWApO1xuXHRcdFx0XHRpbnZhcmlhbnQoKTtcblx0XHRcdH1cblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0cmV0dXJuIG9wdHMuc2VsZWN0ID8gb3B0cy5zZWxlY3QobWF0Y2gpIDogbWF0Y2g7XG5cdH1cblx0Y29uc3Qgc2VsZWN0b3IgPSB1c2VTdHJ1Y3R1cmFsU2hhcmluZyhvcHRzLCByb3V0ZXIpO1xuXHRjb25zdCBtYXRjaFNlbGVjdGlvbiA9IHVzZVNlbGVjdG9yKG1hdGNoU3RvcmUsIChtYXRjaCkgPT4gbWF0Y2ggPyBzZWxlY3RvcihtYXRjaCkgOiBkdW1teU1hdGNoKTtcblx0aWYgKG1hdGNoU2VsZWN0aW9uICE9PSBkdW1teU1hdGNoKSByZXR1cm4gbWF0Y2hTZWxlY3Rpb247XG5cdGlmIChvcHRzLnNob3VsZFRocm93ID8/IHRydWUpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IoYEludmFyaWFudCBmYWlsZWQ6IENvdWxkIG5vdCBmaW5kICR7b3B0cy5mcm9tID8gYGFuIGFjdGl2ZSBtYXRjaCBmcm9tIFwiJHtvcHRzLmZyb219XCJgIDogXCJhIG5lYXJlc3QgbWF0Y2ghXCJ9YCk7XG5cdFx0aW52YXJpYW50KCk7XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTWF0Y2gsIHVzZVN0cnVjdHVyYWxTaGFyaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU1hdGNoLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTG9hZGVyRGF0YS50c3hcbi8qKlxuKiBSZWFkIGFuZCBzZWxlY3QgdGhlIGN1cnJlbnQgcm91dGUncyBsb2FkZXIgZGF0YSB3aXRoIHR5cGXigJFzYWZldHkuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYGZyb21gL2BzdHJpY3RgOiBDaG9vc2Ugd2hpY2ggcm91dGUncyBkYXRhIHRvIHJlYWQgYW5kIHN0cmljdG5lc3NcbiogLSBgc2VsZWN0YDogTWFwIHRoZSBsb2FkZXIgZGF0YSB0byBhIGRlcml2ZWQgdmFsdWVcbiogLSBgc3RydWN0dXJhbFNoYXJpbmdgOiBFbmFibGUgc3RydWN0dXJhbCBzaGFyaW5nIGZvciBzdGFibGUgcmVmZXJlbmNlc1xuKlxuKiBAcmV0dXJucyBUaGUgbG9hZGVyIGRhdGEgKG9yIHNlbGVjdGVkIHZhbHVlKSBmb3IgdGhlIG1hdGNoZWQgcm91dGUuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci91c2VMb2FkZXJEYXRhSG9va1xuKi9cbmZ1bmN0aW9uIHVzZUxvYWRlckRhdGEob3B0cykge1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRzdHJpY3Q6IG9wdHMuc3RyaWN0LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzLnN0cnVjdHVyYWxTaGFyaW5nLFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiB7XG5cdFx0XHRyZXR1cm4gb3B0cy5zZWxlY3QgPyBvcHRzLnNlbGVjdChtYXRjaC5sb2FkZXJEYXRhKSA6IG1hdGNoLmxvYWRlckRhdGE7XG5cdFx0fVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTG9hZGVyRGF0YSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VMb2FkZXJEYXRhLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTG9hZGVyRGVwcy50c3hcbi8qKlxuKiBSZWFkIGFuZCBzZWxlY3QgdGhlIGN1cnJlbnQgcm91dGUncyBsb2FkZXIgZGVwZW5kZW5jaWVzIG9iamVjdC5cbipcbiogT3B0aW9uczpcbiogLSBgZnJvbWA6IENob29zZSB3aGljaCByb3V0ZSdzIGxvYWRlciBkZXBzIHRvIHJlYWRcbiogLSBgc2VsZWN0YDogTWFwIHRoZSBkZXBzIHRvIGEgZGVyaXZlZCB2YWx1ZVxuKiAtIGBzdHJ1Y3R1cmFsU2hhcmluZ2A6IEVuYWJsZSBzdHJ1Y3R1cmFsIHNoYXJpbmcgZm9yIHN0YWJsZSByZWZlcmVuY2VzXG4qXG4qIEByZXR1cm5zIFRoZSBsb2FkZXIgZGVwcyAob3Igc2VsZWN0ZWQgdmFsdWUpIGZvciB0aGUgbWF0Y2hlZCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZUxvYWRlckRlcHNIb29rXG4qL1xuZnVuY3Rpb24gdXNlTG9hZGVyRGVwcyhvcHRzKSB7XG5cdGNvbnN0IHsgc2VsZWN0LCAuLi5yZXN0IH0gPSBvcHRzO1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdC4uLnJlc3QsXG5cdFx0c2VsZWN0OiAobWF0Y2gpID0+IHtcblx0XHRcdHJldHVybiBzZWxlY3QgPyBzZWxlY3QobWF0Y2gubG9hZGVyRGVwcykgOiBtYXRjaC5sb2FkZXJEZXBzO1xuXHRcdH1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZUxvYWRlckRlcHMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTG9hZGVyRGVwcy5qcy5tYXAiLCJpbXBvcnQgeyB1c2VNYXRjaCB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG4vLyNyZWdpb24gc3JjL3VzZVBhcmFtcy50c3hcbi8qKlxuKiBBY2Nlc3MgdGhlIGN1cnJlbnQgcm91dGUncyBwYXRoIHBhcmFtZXRlcnMgd2l0aCB0eXBlLXNhZmV0eS5cbipcbiogT3B0aW9uczpcbiogLSBgZnJvbWAvYHN0cmljdGA6IFNwZWNpZnkgdGhlIG1hdGNoZWQgcm91dGUgYW5kIHdoZXRoZXIgdG8gZW5mb3JjZSBzdHJpY3QgdHlwaW5nXG4qIC0gYHNlbGVjdGA6IFByb2plY3QgdGhlIHBhcmFtcyBvYmplY3QgdG8gYSBkZXJpdmVkIHZhbHVlIGZvciBtZW1vaXplZCByZW5kZXJzXG4qIC0gYHN0cnVjdHVyYWxTaGFyaW5nYDogRW5hYmxlIHN0cnVjdHVyYWwgc2hhcmluZyBmb3Igc3RhYmxlIHJlZmVyZW5jZXNcbiogLSBgc2hvdWxkVGhyb3dgOiBUaHJvdyBpZiB0aGUgcm91dGUgaXMgbm90IGZvdW5kIGluIHN0cmljdCBjb250ZXh0c1xuKlxuKiBAcmV0dXJucyBUaGUgcGFyYW1zIG9iamVjdCAob3Igc2VsZWN0ZWQgdmFsdWUpIGZvciB0aGUgbWF0Y2hlZCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZVBhcmFtc0hvb2tcbiovXG5mdW5jdGlvbiB1c2VQYXJhbXMob3B0cykge1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRzaG91bGRUaHJvdzogb3B0cy5zaG91bGRUaHJvdyxcblx0XHRzdHJ1Y3R1cmFsU2hhcmluZzogb3B0cy5zdHJ1Y3R1cmFsU2hhcmluZyxcblx0XHRzdHJpY3Q6IG9wdHMuc3RyaWN0LFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiB7XG5cdFx0XHRjb25zdCBwYXJhbXMgPSBvcHRzLnN0cmljdCA9PT0gZmFsc2UgPyBtYXRjaC5wYXJhbXMgOiBtYXRjaC5fc3RyaWN0UGFyYW1zO1xuXHRcdFx0cmV0dXJuIG9wdHMuc2VsZWN0ID8gb3B0cy5zZWxlY3QocGFyYW1zKSA6IHBhcmFtcztcblx0XHR9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VQYXJhbXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUGFyYW1zLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlU2VhcmNoLnRzeFxuLyoqXG4qIFJlYWQgYW5kIHNlbGVjdCB0aGUgY3VycmVudCByb3V0ZSdzIHNlYXJjaCBwYXJhbWV0ZXJzIHdpdGggdHlwZS1zYWZldHkuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYGZyb21gL2BzdHJpY3RgOiBDb250cm9sIHdoaWNoIHJvdXRlJ3Mgc2VhcmNoIGlzIHJlYWQgYW5kIGhvdyBzdHJpY3RseSBpdCdzIHR5cGVkXG4qIC0gYHNlbGVjdGA6IE1hcCB0aGUgc2VhcmNoIG9iamVjdCB0byBhIGRlcml2ZWQgdmFsdWUgZm9yIHJlbmRlciBvcHRpbWl6YXRpb25cbiogLSBgc3RydWN0dXJhbFNoYXJpbmdgOiBFbmFibGUgc3RydWN0dXJhbCBzaGFyaW5nIGZvciBzdGFibGUgcmVmZXJlbmNlc1xuKiAtIGBzaG91bGRUaHJvd2A6IFRocm93IHdoZW4gdGhlIHJvdXRlIGlzIG5vdCBmb3VuZCAoc3RyaWN0IGNvbnRleHRzKVxuKlxuKiBAcmV0dXJucyBUaGUgc2VhcmNoIG9iamVjdCAob3Igc2VsZWN0ZWQgdmFsdWUpIGZvciB0aGUgbWF0Y2hlZCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZVNlYXJjaEhvb2tcbiovXG5mdW5jdGlvbiB1c2VTZWFyY2gob3B0cykge1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRzdHJpY3Q6IG9wdHMuc3RyaWN0LFxuXHRcdHNob3VsZFRocm93OiBvcHRzLnNob3VsZFRocm93LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzLnN0cnVjdHVyYWxTaGFyaW5nLFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiB7XG5cdFx0XHRyZXR1cm4gb3B0cy5zZWxlY3QgPyBvcHRzLnNlbGVjdChtYXRjaC5zZWFyY2gpIDogbWF0Y2guc2VhcmNoO1xuXHRcdH1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVNlYXJjaCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTZWFyY2guanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuLy8jcmVnaW9uIHNyYy91c2VOYXZpZ2F0ZS50c3hcbi8qKlxuKiBJbXBlcmF0aXZlIG5hdmlnYXRpb24gaG9vay5cbipcbiogUmV0dXJucyBhIHN0YWJsZSBgbmF2aWdhdGUob3B0aW9ucylgIGZ1bmN0aW9uIHRvIGNoYW5nZSB0aGUgY3VycmVudCBsb2NhdGlvblxuKiBwcm9ncmFtbWF0aWNhbGx5LiBQcmVmZXIgdGhlIGBMaW5rYCBjb21wb25lbnQgZm9yIHVzZXItaW5pdGlhdGVkIG5hdmlnYXRpb24sXG4qIGFuZCB1c2UgdGhpcyBob29rIGZyb20gZWZmZWN0cywgY2FsbGJhY2tzLCBvciBoYW5kbGVycyB3aGVyZSBpbXBlcmF0aXZlXG4qIG5hdmlnYXRpb24gaXMgcmVxdWlyZWQuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYGZyb21gOiBPcHRpb25hbCByb3V0ZSBiYXNlIHVzZWQgdG8gcmVzb2x2ZSByZWxhdGl2ZSBgdG9gIHBhdGhzLlxuKlxuKiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgYWNjZXB0cyBgTmF2aWdhdGVPcHRpb25zYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZU5hdmlnYXRlSG9va1xuKi9cbmZ1bmN0aW9uIHVzZU5hdmlnYXRlKF9kZWZhdWx0T3B0cykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0cmV0dXJuIFJlYWN0JDEudXNlQ2FsbGJhY2soKG9wdGlvbnMpID0+IHtcblx0XHRyZXR1cm4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRmcm9tOiBvcHRpb25zLmZyb20gPz8gX2RlZmF1bHRPcHRzPy5mcm9tXG5cdFx0fSk7XG5cdH0sIFtfZGVmYXVsdE9wdHM/LmZyb20sIHJvdXRlcl0pO1xufVxuLyoqXG4qIENvbXBvbmVudCB0aGF0IHRyaWdnZXJzIGEgbmF2aWdhdGlvbiB3aGVuIHJlbmRlcmVkLiBOYXZpZ2F0aW9uIGV4ZWN1dGVzXG4qIGluIGFuIGVmZmVjdCBhZnRlciBtb3VudC91cGRhdGUuXG4qXG4qIFByb3BzIGFyZSB0aGUgc2FtZSBhcyBgTmF2aWdhdGVPcHRpb25zYCB1c2VkIGJ5IGBuYXZpZ2F0ZSgpYC5cbipcbiogQHJldHVybnMgbnVsbFxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvbmF2aWdhdGVDb21wb25lbnRcbiovXG5mdW5jdGlvbiBOYXZpZ2F0ZShwcm9wcykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXHRjb25zdCBwcmV2aW91c1Byb3BzUmVmID0gUmVhY3QkMS51c2VSZWYobnVsbCk7XG5cdHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKHByZXZpb3VzUHJvcHNSZWYuY3VycmVudCAhPT0gcHJvcHMpIHtcblx0XHRcdG5hdmlnYXRlKHByb3BzKTtcblx0XHRcdHByZXZpb3VzUHJvcHNSZWYuY3VycmVudCA9IHByb3BzO1xuXHRcdH1cblx0fSwgW1xuXHRcdHJvdXRlcixcblx0XHRwcm9wcyxcblx0XHRuYXZpZ2F0ZVxuXHRdKTtcblx0cmV0dXJuIG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE5hdmlnYXRlLCB1c2VOYXZpZ2F0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VOYXZpZ2F0ZS5qcy5tYXAiLCJpbXBvcnQgeyB1c2VNYXRjaCB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG4vLyNyZWdpb24gc3JjL3VzZVJvdXRlQ29udGV4dC50c1xuZnVuY3Rpb24gdXNlUm91dGVDb250ZXh0KG9wdHMpIHtcblx0cmV0dXJuIHVzZU1hdGNoKHtcblx0XHQuLi5vcHRzLFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiBvcHRzLnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoLmNvbnRleHQpIDogbWF0Y2guY29udGV4dFxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlUm91dGVDb250ZXh0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVJvdXRlQ29udGV4dC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUh5ZHJhdGVkIH0gZnJvbSBcIi4vQ2xpZW50T25seS5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBkZWVwRXF1YWwsIGZ1bmN0aW9uYWxVcGRhdGUsIGdldFVybFNjaGVtZSwgaXNEYW5nZXJvdXNQcm90b2NvbCwgcHJlbG9hZFdhcm5pbmcsIHJlbW92ZVRyYWlsaW5nU2xhc2ggfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy9saW5rLnRzeFxuZnVuY3Rpb24gdXNlU3RhYmxlVmFsdWVzKC4uLnZhbHVlcykge1xuXHRjb25zdCByZWYgPSBSZWFjdCQxLnVzZVJlZih2YWx1ZXMpO1xuXHRjb25zdCBzdGFibGUgPSByZWYuY3VycmVudDtcblx0dmFsdWVzLmZvckVhY2goKHZhbHVlLCBpbmRleCkgPT4ge1xuXHRcdGlmICghZGVlcEVxdWFsKHN0YWJsZVtpbmRleF0sIHZhbHVlLCBmYWxzZSwgdHJ1ZSkpIHN0YWJsZVtpbmRleF0gPSB2YWx1ZTtcblx0fSk7XG5cdHJldHVybiByZWYuY3VycmVudDtcbn1cbmZ1bmN0aW9uIHByZWxvYWRMaW5rKHJvdXRlciwgb3B0aW9ucykge1xuXHRyb3V0ZXIucHJlbG9hZFJvdXRlKG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcblx0XHRjb25zb2xlLndhcm4oZXJyKTtcblx0XHRjb25zb2xlLndhcm4ocHJlbG9hZFdhcm5pbmcpO1xuXHR9KTtcbn1cbnZhciBMSU5LX1NFTEVDVE9SX09QVElPTlMgPSB7IGNvbXBhcmU6IChhLCBiKSA9PiBhWzBdID09PSBiWzBdICYmIGFbMV0gPT09IGJbMV0gfTtcbmZ1bmN0aW9uIHJlc29sdmVFeHRlcm5hbExpbmsodG8sIHByb3RvY29sQWxsb3dsaXN0KSB7XG5cdGNvbnN0IHNjaGVtZSA9IHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIiAmJiBnZXRVcmxTY2hlbWUodG8pO1xuXHRpZiAoIXNjaGVtZSkgcmV0dXJuO1xuXHRpZiAoIXByb3RvY29sQWxsb3dsaXN0LmhhcyhzY2hlbWUpKSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS53YXJuKGBCbG9ja2VkIExpbmsgd2l0aCBkYW5nZXJvdXMgcHJvdG9jb2w6ICR7dG99YCk7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cblx0cmV0dXJuIHRvO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUlzQWN0aXZlKGxvY2F0aW9uLCBuZXh0LCBhY3RpdmVPcHRpb25zLCBiYXNlcGF0aCwgaXNIeWRyYXRlZCkge1xuXHRjb25zdCBjdXJyZW50UGF0aCA9IHJlbW92ZVRyYWlsaW5nU2xhc2gobG9jYXRpb24ucGF0aG5hbWUsIGJhc2VwYXRoKTtcblx0Y29uc3QgbmV4dFBhdGggPSByZW1vdmVUcmFpbGluZ1NsYXNoKG5leHQucGF0aG5hbWUsIGJhc2VwYXRoKTtcblx0aWYgKGFjdGl2ZU9wdGlvbnM/LmV4YWN0ID8gY3VycmVudFBhdGggIT09IG5leHRQYXRoIDogIShjdXJyZW50UGF0aC5zdGFydHNXaXRoKG5leHRQYXRoKSAmJiAoY3VycmVudFBhdGgubGVuZ3RoID09PSBuZXh0UGF0aC5sZW5ndGggfHwgY3VycmVudFBhdGhbbmV4dFBhdGgubGVuZ3RoXSA9PT0gXCIvXCIpKSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoYWN0aXZlT3B0aW9ucz8uaW5jbHVkZVNlYXJjaCA/PyB0cnVlKSB7XG5cdFx0aWYgKCFkZWVwRXF1YWwobG9jYXRpb24uc2VhcmNoLCBuZXh0LnNlYXJjaCwgIWFjdGl2ZU9wdGlvbnM/LmV4YWN0LCBhY3RpdmVPcHRpb25zPy5leHBsaWNpdFVuZGVmaW5lZCkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRpZiAoYWN0aXZlT3B0aW9ucz8uaW5jbHVkZUhhc2gpIHJldHVybiBpc0h5ZHJhdGVkICYmIGxvY2F0aW9uLmhhc2ggPT09IG5leHQuaGFzaDtcblx0cmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiB1c2VMaW5rUHJvcHMob3B0aW9ucywgZm9yd2FyZGVkUmVmLCBob3N0KSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSByZXR1cm4gZ2V0U2VydmVyTGlua1Byb3BzKHJvdXRlciwgb3B0aW9ucywgZm9yd2FyZGVkUmVmLCBob3N0KTtcblx0Y29uc3QgaW5uZXJSZWYgPSBSZWFjdCQxLnVzZVJlZihudWxsKTtcblx0Y29uc3QgbWVyZ2VkUmVmID0gUmVhY3QkMS51c2VDYWxsYmFjaygoZWxlbWVudCkgPT4ge1xuXHRcdGlubmVyUmVmLmN1cnJlbnQgPSBlbGVtZW50O1xuXHRcdGlmICh0eXBlb2YgZm9yd2FyZGVkUmVmID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiBmb3J3YXJkZWRSZWYoZWxlbWVudCk7XG5cdFx0aWYgKGZvcndhcmRlZFJlZikgZm9yd2FyZGVkUmVmLmN1cnJlbnQgPSBlbGVtZW50O1xuXHR9LCBbZm9yd2FyZGVkUmVmXSk7XG5cdGNvbnN0IHsgYWN0aXZlT3B0aW9ucywgdG8sIHByZWxvYWQ6IHVzZXJQcmVsb2FkLCBwcmVsb2FkRGVsYXk6IHVzZXJQcmVsb2FkRGVsYXksIGhhc2hTY3JvbGxJbnRvVmlldywgcmVwbGFjZSwgc3RhcnRUcmFuc2l0aW9uLCByZXNldFNjcm9sbCwgdmlld1RyYW5zaXRpb24sIGlnbm9yZUJsb2NrZXIsIGRpc2FibGVkLCB0YXJnZXQsIG9uQ2xpY2ssIG9uQmx1ciwgb25Gb2N1cywgb25Nb3VzZUVudGVyLCBvbk1vdXNlTGVhdmUsIG9uVG91Y2hTdGFydCB9ID0gb3B0aW9ucztcblx0Y29uc3QgaXNIeWRyYXRlZCA9IHVzZUh5ZHJhdGVkKCEhYWN0aXZlT3B0aW9ucz8uaW5jbHVkZUhhc2gpO1xuXHRjb25zdCBbc3RhYmxlU2VhcmNoLCBzdGFibGVQYXJhbXMsIHN0YWJsZUFjdGl2ZU9wdGlvbnNdID0gdXNlU3RhYmxlVmFsdWVzKG9wdGlvbnMuc2VhcmNoLCBvcHRpb25zLnBhcmFtcywgYWN0aXZlT3B0aW9ucyk7XG5cdGNvbnN0IFtfb3B0aW9ucywgZGVzdF0gPSBSZWFjdCQxLnVzZU1lbW8oKCkgPT4gW29wdGlvbnMsIHsgLi4ub3B0aW9ucyB9XSwgW1xuXHRcdHJvdXRlcixcblx0XHRvcHRpb25zLmZyb20sXG5cdFx0b3B0aW9ucy5fZnJvbUxvY2F0aW9uLFxuXHRcdG9wdGlvbnMuaGFzaCxcblx0XHRvcHRpb25zLnRvLFxuXHRcdHN0YWJsZVNlYXJjaCxcblx0XHRzdGFibGVQYXJhbXMsXG5cdFx0b3B0aW9ucy5zdGF0ZSxcblx0XHRvcHRpb25zLm1hc2ssXG5cdFx0b3B0aW9ucy51bnNhZmVSZWxhdGl2ZVxuXHRdKTtcblx0Y29uc3Qgc2VsZWN0TGlua1N0YXRlID0gUmVhY3QkMS51c2VNZW1vKCgpID0+IHtcblx0XHRjb25zdCBkaXJlY3RFeHRlcm5hbExpbmsgPSByZXNvbHZlRXh0ZXJuYWxMaW5rKHRvLCByb3V0ZXIucHJvdG9jb2xBbGxvd2xpc3QpO1xuXHRcdGlmIChkaXJlY3RFeHRlcm5hbExpbmsgIT09IHZvaWQgMCkge1xuXHRcdFx0Y29uc3Qgc3RhdGUgPSBbZGlyZWN0RXh0ZXJuYWxMaW5rID8/IHZvaWQgMF07XG5cdFx0XHRyZXR1cm4gKCkgPT4gc3RhdGU7XG5cdFx0fVxuXHRcdGxldCBpbmFjdGl2ZTtcblx0XHRsZXQgYWN0aXZlO1xuXHRcdHJldHVybiAobG9jYXRpb24pID0+IHtcblx0XHRcdGlmICghX29wdGlvbnMuX2Zyb21Mb2NhdGlvbikgZGVzdC5fZnJvbUxvY2F0aW9uID0gbG9jYXRpb247XG5cdFx0XHRjb25zdCBuZXh0ID0gcm91dGVyLmJ1aWxkTG9jYXRpb24oZGVzdCk7XG5cdFx0XHRjb25zdCBocmVmID0gZ2V0SHJlZk9wdGlvbihuZXh0LCByb3V0ZXIsIGRpc2FibGVkKTtcblx0XHRcdGlmICghaW5hY3RpdmUgfHwgaW5hY3RpdmVbMF0gIT09IGhyZWYpIHtcblx0XHRcdFx0aW5hY3RpdmUgPSBbaHJlZiwgIShkaXNhYmxlZCB8fCBocmVmICYmICFnZXRVcmxTY2hlbWUoaHJlZikpICYmIHZvaWQgMF07XG5cdFx0XHRcdGFjdGl2ZSA9IFtocmVmLCB0cnVlXTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBpbmFjdGl2ZVsxXSAhPT0gdm9pZCAwICYmIHJlc29sdmVJc0FjdGl2ZShsb2NhdGlvbiwgbmV4dCwgc3RhYmxlQWN0aXZlT3B0aW9ucywgcm91dGVyLmJhc2VwYXRoLCBpc0h5ZHJhdGVkKSA/IGFjdGl2ZSA6IGluYWN0aXZlO1xuXHRcdH07XG5cdH0sIFtcblx0XHRzdGFibGVBY3RpdmVPcHRpb25zLFxuXHRcdGRpc2FibGVkLFxuXHRcdGlzSHlkcmF0ZWQsXG5cdFx0X29wdGlvbnMsXG5cdFx0ZGVzdCxcblx0XHRyb3V0ZXIsXG5cdFx0dG9cblx0XSk7XG5cdGNvbnN0IFtocmVmLCBpc0FjdGl2ZV0gPSB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLCBzZWxlY3RMaW5rU3RhdGUsIExJTktfU0VMRUNUT1JfT1BUSU9OUyk7XG5cdGNvbnN0IGV4dGVybmFsTGluayA9IGlzQWN0aXZlID09PSB2b2lkIDAgJiYgaHJlZjtcblx0Y29uc3QgbGlua0Rpc2FibGVkID0gZGlzYWJsZWQgfHwgaHJlZiA9PT0gdm9pZCAwO1xuXHRjb25zdCBoYXNSZW5kZXJGZXRjaGVkID0gUmVhY3QkMS51c2VSZWYoZmFsc2UpO1xuXHRjb25zdCBwcmVsb2FkID0gb3B0aW9ucy5yZWxvYWREb2N1bWVudCB8fCBleHRlcm5hbExpbmsgfHwgbGlua0Rpc2FibGVkID8gZmFsc2UgOiB1c2VyUHJlbG9hZCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UHJlbG9hZDtcblx0Y29uc3QgcHJlbG9hZERlbGF5ID0gdXNlclByZWxvYWREZWxheSA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UHJlbG9hZERlbGF5ID8/IDA7XG5cdGNvbnN0IGVucXVldWVQcmVsb2FkID0gUmVhY3QkMS51c2VDYWxsYmFjaygoZSkgPT4ge1xuXHRcdGNvbnN0IGlzSW50ZXJzZWN0aW5nID0gZT8uaXNJbnRlcnNlY3Rpbmc7XG5cdFx0aWYgKCEoaXNJbnRlcnNlY3RpbmcgPz8gcHJlbG9hZCA9PT0gXCJpbnRlbnRcIikpIHtcblx0XHRcdGlmIChpc0ludGVyc2VjdGluZyA9PT0gZmFsc2UpIGNhbmNlbFByZWxvYWQoaW5uZXJSZWYpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAoIXByZWxvYWREZWxheSkge1xuXHRcdFx0cHJlbG9hZExpbmsocm91dGVyLCBfb3B0aW9ucyk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmICh0aW1lb3V0TWFwLmhhcyhpbm5lclJlZikpIHJldHVybjtcblx0XHR0aW1lb3V0TWFwLnNldChpbm5lclJlZiwgc2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHR0aW1lb3V0TWFwLmRlbGV0ZShpbm5lclJlZik7XG5cdFx0XHRwcmVsb2FkTGluayhyb3V0ZXIsIF9vcHRpb25zKTtcblx0XHR9LCBwcmVsb2FkRGVsYXkpKTtcblx0fSwgW1xuXHRcdHJvdXRlcixcblx0XHRfb3B0aW9ucyxcblx0XHRpbm5lclJlZixcblx0XHRwcmVsb2FkLFxuXHRcdHByZWxvYWREZWxheVxuXHRdKTtcblx0UmVhY3QkMS51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGlmICghcHJlbG9hZCkgcmV0dXJuO1xuXHRcdGlmIChwcmVsb2FkID09PSBcInJlbmRlclwiICYmICFoYXNSZW5kZXJGZXRjaGVkLmN1cnJlbnQpIHtcblx0XHRcdGhhc1JlbmRlckZldGNoZWQuY3VycmVudCA9IHRydWU7XG5cdFx0XHRwcmVsb2FkTGluayhyb3V0ZXIsIF9vcHRpb25zKTtcblx0XHR9XG5cdFx0bGV0IGFjdGl2ZSA9IHRydWU7XG5cdFx0bGV0IG9ic2VydmVyO1xuXHRcdGlmIChwcmVsb2FkID09PSBcInZpZXdwb3J0XCIgJiYgaW5uZXJSZWYuY3VycmVudCAmJiB0eXBlb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPT09IFwiZnVuY3Rpb25cIikge1xuXHRcdFx0b2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcblx0XHRcdFx0aWYgKGFjdGl2ZSkgZW5xdWV1ZVByZWxvYWQoZW50cmllcy5wb3AoKSk7XG5cdFx0XHR9LCB7IHJvb3RNYXJnaW46IFwiMTAwcHhcIiB9KTtcblx0XHRcdG9ic2VydmVyLm9ic2VydmUoaW5uZXJSZWYuY3VycmVudCk7XG5cdFx0fVxuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRhY3RpdmUgPSBmYWxzZTtcblx0XHRcdG9ic2VydmVyPy5kaXNjb25uZWN0KCk7XG5cdFx0XHRjYW5jZWxQcmVsb2FkKGlubmVyUmVmKTtcblx0XHR9O1xuXHR9LCBbXG5cdFx0cm91dGVyLFxuXHRcdF9vcHRpb25zLFxuXHRcdHByZWxvYWQsXG5cdFx0ZW5xdWV1ZVByZWxvYWQsXG5cdFx0aW5uZXJSZWZcblx0XSk7XG5cdGNvbnN0IHByb3BzID0gY29sbGVjdEVsZW1lbnRQcm9wcyhvcHRpb25zLCBob3N0KTtcblx0cHJvcHMucmVmID0gZm9yd2FyZGVkUmVmID8gbWVyZ2VkUmVmIDogaW5uZXJSZWY7XG5cdGlmIChleHRlcm5hbExpbmspIHtcblx0XHRwcm9wcy5ocmVmID0gZXh0ZXJuYWxMaW5rO1xuXHRcdHJldHVybiBwcm9wcztcblx0fVxuXHRjb25zdCBoYW5kbGVDbGljayA9IChlKSA9PiB7XG5cdFx0Y29uc3QgZWZmZWN0aXZlVGFyZ2V0ID0gdGFyZ2V0ID8/IGUuY3VycmVudFRhcmdldC5nZXRBdHRyaWJ1dGUoXCJ0YXJnZXRcIik7XG5cdFx0aWYgKCFsaW5rRGlzYWJsZWQgJiYgIShlLm1ldGFLZXkgfHwgZS5hbHRLZXkgfHwgZS5jdHJsS2V5IHx8IGUuc2hpZnRLZXkpICYmICFlLmRlZmF1bHRQcmV2ZW50ZWQgJiYgKCFlZmZlY3RpdmVUYXJnZXQgfHwgZWZmZWN0aXZlVGFyZ2V0ID09PSBcIl9zZWxmXCIpICYmIGUuYnV0dG9uID09PSAwKSB7XG5cdFx0XHRlLnByZXZlbnREZWZhdWx0KCk7XG5cdFx0XHRyb3V0ZXIubmF2aWdhdGUoe1xuXHRcdFx0XHQuLi5fb3B0aW9ucyxcblx0XHRcdFx0cmVwbGFjZSxcblx0XHRcdFx0cmVzZXRTY3JvbGwsXG5cdFx0XHRcdGhhc2hTY3JvbGxJbnRvVmlldyxcblx0XHRcdFx0c3RhcnRUcmFuc2l0aW9uLFxuXHRcdFx0XHR2aWV3VHJhbnNpdGlvbixcblx0XHRcdFx0aWdub3JlQmxvY2tlclxuXHRcdFx0fSk7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBoYW5kbGVUb3VjaFN0YXJ0ID0gKCkgPT4ge1xuXHRcdGlmIChwcmVsb2FkID09PSBcImludGVudFwiKSBwcmVsb2FkTGluayhyb3V0ZXIsIF9vcHRpb25zKTtcblx0fTtcblx0Y29uc3QgaGFuZGxlTGVhdmUgPSAoKSA9PiB7XG5cdFx0aWYgKHByZWxvYWQgPT09IFwiaW50ZW50XCIpIGNhbmNlbFByZWxvYWQoaW5uZXJSZWYpO1xuXHR9O1xuXHRwcm9wcy5vbkNsaWNrID0gY29tcG9zZUhhbmRsZXJzKG9uQ2xpY2ssIGhhbmRsZUNsaWNrKTtcblx0cHJvcHMub25CbHVyID0gY29tcG9zZUhhbmRsZXJzKG9uQmx1ciwgaGFuZGxlTGVhdmUpO1xuXHRwcm9wcy5vbkZvY3VzID0gY29tcG9zZUhhbmRsZXJzKG9uRm9jdXMsIGVucXVldWVQcmVsb2FkKTtcblx0cHJvcHMub25Nb3VzZUVudGVyID0gY29tcG9zZUhhbmRsZXJzKG9uTW91c2VFbnRlciwgZW5xdWV1ZVByZWxvYWQpO1xuXHRwcm9wcy5vbk1vdXNlTGVhdmUgPSBjb21wb3NlSGFuZGxlcnMob25Nb3VzZUxlYXZlLCBoYW5kbGVMZWF2ZSk7XG5cdHByb3BzLm9uVG91Y2hTdGFydCA9IGNvbXBvc2VIYW5kbGVycyhvblRvdWNoU3RhcnQsIGhhbmRsZVRvdWNoU3RhcnQpO1xuXHRyZXR1cm4gYXBwbHlMaW5rU3RhdGUocHJvcHMsIG9wdGlvbnMsIGlzQWN0aXZlLCBocmVmLCBsaW5rRGlzYWJsZWQsIGhvc3QpO1xufVxudmFyIFNUQVRJQ19FTVBUWV9PQkpFQ1QgPSB7fTtcbnZhciBTVEFUSUNfQUNUSVZFX09CSkVDVCA9IHsgY2xhc3NOYW1lOiBcImFjdGl2ZVwiIH07XG52YXIgUk9VVEVSX09QVElPTl9LRVlTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuXHRcInRvXCIsXG5cdFwicGFyYW1zXCIsXG5cdFwic2VhcmNoXCIsXG5cdFwiaGFzaFwiLFxuXHRcInN0YXRlXCIsXG5cdFwibWFza1wiLFxuXHRcImZyb21cIixcblx0XCJ1bnNhZmVSZWxhdGl2ZVwiLFxuXHRcIl9mcm9tTG9jYXRpb25cIixcblx0XCJyZWxvYWREb2N1bWVudFwiLFxuXHRcInByZWxvYWRcIixcblx0XCJwcmVsb2FkRGVsYXlcIixcblx0XCJwcmVsb2FkSW50ZW50UHJveGltaXR5XCIsXG5cdFwiaGFzaFNjcm9sbEludG9WaWV3XCIsXG5cdFwicmVwbGFjZVwiLFxuXHRcInN0YXJ0VHJhbnNpdGlvblwiLFxuXHRcInJlc2V0U2Nyb2xsXCIsXG5cdFwidmlld1RyYW5zaXRpb25cIixcblx0XCJpZ25vcmVCbG9ja2VyXCIsXG5cdFwiYWN0aXZlUHJvcHNcIixcblx0XCJpbmFjdGl2ZVByb3BzXCIsXG5cdFwiYWN0aXZlT3B0aW9uc1wiLFxuXHRcIl9hc0NoaWxkXCJcbl0pO1xuZnVuY3Rpb24gY29sbGVjdEVsZW1lbnRQcm9wcyhvcHRpb25zLCBob3N0KSB7XG5cdGNvbnN0IHByb3BzID0ge307XG5cdGZvciAoY29uc3Qga2V5IGluIG9wdGlvbnMpIHtcblx0XHRpZiAoUk9VVEVSX09QVElPTl9LRVlTLmhhcyhrZXkpIHx8IGtleSA9PT0gXCJ0eXBlXCIgJiYgaG9zdCAhPT0gdm9pZCAwIHx8IGtleSA9PT0gXCJkaXNhYmxlZFwiICYmIGhvc3QgPT09IFwiYVwiKSBjb250aW51ZTtcblx0XHRwcm9wc1trZXldID0gb3B0aW9uc1trZXldO1xuXHR9XG5cdHJldHVybiBwcm9wcztcbn1cbmZ1bmN0aW9uIGFwcGx5TGlua1N0YXRlKHByb3BzLCBvcHRpb25zLCBpc0FjdGl2ZSwgaHJlZiwgbGlua0Rpc2FibGVkLCBob3N0KSB7XG5cdGNvbnN0IHsgYWN0aXZlUHJvcHMsIGluYWN0aXZlUHJvcHMsIGNsYXNzTmFtZSwgc3R5bGUsIHRhcmdldCB9ID0gb3B0aW9ucztcblx0Y29uc3Qgc3RhdGVQcm9wcyA9IGZ1bmN0aW9uYWxVcGRhdGUoaXNBY3RpdmUgPyBhY3RpdmVQcm9wcyA6IGluYWN0aXZlUHJvcHMsIHt9KSA/PyAoaXNBY3RpdmUgPyBTVEFUSUNfQUNUSVZFX09CSkVDVCA6IFNUQVRJQ19FTVBUWV9PQkpFQ1QpO1xuXHRPYmplY3QuYXNzaWduKHByb3BzLCBzdGF0ZVByb3BzKTtcblx0cHJvcHMuaHJlZiA9IGhyZWY7XG5cdGlmIChob3N0ICE9PSBcImFcIikgcHJvcHMuZGlzYWJsZWQgPSBsaW5rRGlzYWJsZWQ7XG5cdHByb3BzLnRhcmdldCA9IHRhcmdldDtcblx0Y29uc3Qgc3RhdGVTdHlsZSA9IHN0YXRlUHJvcHMuc3R5bGU7XG5cdGlmIChzdHlsZSB8fCBzdGF0ZVN0eWxlKSBwcm9wcy5zdHlsZSA9IHN0eWxlICYmIHN0YXRlU3R5bGUgPyB7XG5cdFx0Li4uc3R5bGUsXG5cdFx0Li4uc3RhdGVTdHlsZVxuXHR9IDogc3R5bGUgfHwgc3RhdGVTdHlsZTtcblx0Y29uc3Qgc3RhdGVDbGFzc05hbWUgPSBzdGF0ZVByb3BzLmNsYXNzTmFtZTtcblx0aWYgKGNsYXNzTmFtZSB8fCBzdGF0ZUNsYXNzTmFtZSkgcHJvcHMuY2xhc3NOYW1lID0gY2xhc3NOYW1lID8gc3RhdGVDbGFzc05hbWUgPyBgJHtjbGFzc05hbWV9ICR7c3RhdGVDbGFzc05hbWV9YCA6IGNsYXNzTmFtZSA6IHN0YXRlQ2xhc3NOYW1lO1xuXHRpZiAobGlua0Rpc2FibGVkKSB7XG5cdFx0cHJvcHMucm9sZSA9IFwibGlua1wiO1xuXHRcdHByb3BzW1wiYXJpYS1kaXNhYmxlZFwiXSA9IHRydWU7XG5cdH1cblx0aWYgKGlzQWN0aXZlKSB7XG5cdFx0cHJvcHNbXCJkYXRhLXN0YXR1c1wiXSA9IFwiYWN0aXZlXCI7XG5cdFx0cHJvcHNbXCJhcmlhLWN1cnJlbnRcIl0gPSBcInBhZ2VcIjtcblx0fVxuXHRyZXR1cm4gcHJvcHM7XG59XG5mdW5jdGlvbiBnZXRTZXJ2ZXJMaW5rUHJvcHMocm91dGVyLCBvcHRpb25zLCBmb3J3YXJkZWRSZWYsIGhvc3QpIHtcblx0Y29uc3QgeyB0bywgZGlzYWJsZWQsIGFjdGl2ZU9wdGlvbnMgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IGRpcmVjdEV4dGVybmFsTGluayA9IHJlc29sdmVFeHRlcm5hbExpbmsodG8sIHJvdXRlci5wcm90b2NvbEFsbG93bGlzdCk7XG5cdGNvbnN0IG5leHQgPSBkaXJlY3RFeHRlcm5hbExpbmsgPT09IHZvaWQgMCA/IHJvdXRlci5idWlsZExvY2F0aW9uKG9wdGlvbnMpIDogdm9pZCAwO1xuXHRjb25zdCBocmVmT3B0aW9uID0gbmV4dCA/IGdldEhyZWZPcHRpb24obmV4dCwgcm91dGVyLCBkaXNhYmxlZCkgOiBkaXJlY3RFeHRlcm5hbExpbmsgPz8gdm9pZCAwO1xuXHRjb25zdCBsaW5rRGlzYWJsZWQgPSBkaXNhYmxlZCB8fCAhaHJlZk9wdGlvbjtcblx0Y29uc3QgZXh0ZXJuYWxMaW5rID0gZGlyZWN0RXh0ZXJuYWxMaW5rID8/IChocmVmT3B0aW9uICYmIGdldFVybFNjaGVtZShocmVmT3B0aW9uKSA/IGhyZWZPcHRpb24gOiB2b2lkIDApO1xuXHRjb25zdCBwcm9wcyA9IGNvbGxlY3RFbGVtZW50UHJvcHMob3B0aW9ucywgaG9zdCk7XG5cdHByb3BzLnJlZiA9IGZvcndhcmRlZFJlZjtcblx0aWYgKGV4dGVybmFsTGluaykge1xuXHRcdHByb3BzLmhyZWYgPSBleHRlcm5hbExpbms7XG5cdFx0cmV0dXJuIHByb3BzO1xuXHR9XG5cdHJldHVybiBhcHBseUxpbmtTdGF0ZShwcm9wcywgb3B0aW9ucywgISFuZXh0ICYmICEoIWRpc2FibGVkICYmICFocmVmT3B0aW9uKSAmJiByZXNvbHZlSXNBY3RpdmUocm91dGVyLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKSwgbmV4dCwgYWN0aXZlT3B0aW9ucywgcm91dGVyLmJhc2VwYXRoLCBmYWxzZSksIGhyZWZPcHRpb24sIGxpbmtEaXNhYmxlZCwgaG9zdCk7XG59XG52YXIgdGltZW91dE1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xudmFyIGNhbmNlbFByZWxvYWQgPSAoZXZlbnRUYXJnZXQpID0+IHtcblx0Y2xlYXJUaW1lb3V0KHRpbWVvdXRNYXAuZ2V0KGV2ZW50VGFyZ2V0KSk7XG5cdHRpbWVvdXRNYXAuZGVsZXRlKGV2ZW50VGFyZ2V0KTtcbn07XG52YXIgY29tcG9zZUhhbmRsZXJzID0gKGZpcnN0LCBzZWNvbmQpID0+IHtcblx0aWYgKCFmaXJzdCkgcmV0dXJuIHNlY29uZDtcblx0cmV0dXJuIChldmVudCkgPT4gZXZlbnQuZGVmYXVsdFByZXZlbnRlZCB8fCAoZmlyc3QoZXZlbnQpLCBldmVudC5kZWZhdWx0UHJldmVudGVkIHx8IHNlY29uZChldmVudCkpO1xufTtcbmZ1bmN0aW9uIGdldEhyZWZPcHRpb24obmV4dCwgcm91dGVyLCBkaXNhYmxlZCkge1xuXHRpZiAoZGlzYWJsZWQpIHJldHVybjtcblx0Y29uc3QgbG9jYXRpb24gPSBuZXh0Lm1hc2tlZExvY2F0aW9uID8/IG5leHQ7XG5cdGNvbnN0IGhyZWYgPSBsb2NhdGlvbi5leHRlcm5hbCA/IGxvY2F0aW9uLnB1YmxpY0hyZWYgOiByb3V0ZXIuaGlzdG9yeS5jcmVhdGVIcmVmKGxvY2F0aW9uLnB1YmxpY0hyZWYpIHx8IFwiL1wiO1xuXHRpZiAoKGxvY2F0aW9uLmV4dGVybmFsIHx8IGhyZWYgIT09IGxvY2F0aW9uLnB1YmxpY0hyZWYpICYmIGlzRGFuZ2Vyb3VzUHJvdG9jb2woaHJlZiwgcm91dGVyLnByb3RvY29sQWxsb3dsaXN0KSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihgQmxvY2tlZCBMaW5rIHdpdGggZGFuZ2Vyb3VzIHByb3RvY29sOiAke2hyZWZ9YCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJldHVybiBocmVmO1xufVxuLyoqXG4qIENyZWF0ZXMgYSB0eXBlZCBMaW5rLWxpa2UgY29tcG9uZW50IHRoYXQgcHJlc2VydmVzIFRhblN0YWNrIFJvdXRlcidzXG4qIG5hdmlnYXRpb24gc2VtYW50aWNzIGFuZCB0eXBlLXNhZmV0eSB3aGlsZSBkZWxlZ2F0aW5nIHJlbmRlcmluZyB0byB0aGVcbiogcHJvdmlkZWQgaG9zdCBjb21wb25lbnQuXG4qXG4qIFVzZWZ1bCBmb3IgaW50ZWdyYXRpbmcgZGVzaWduIHN5c3RlbSBhbmNob3JzL2J1dHRvbnMgd2hpbGUga2VlcGluZ1xuKiByb3V0ZXItYXdhcmUgcHJvcHMgKGVnLiBgdG9gLCBgcGFyYW1zYCwgYHNlYXJjaGAsIGBwcmVsb2FkYCkuXG4qXG4qIEBwYXJhbSBDb21wIFRoZSBob3N0IGNvbXBvbmVudCB0byByZW5kZXIgKGVnLiBhIGRlc2lnbi1zeXN0ZW0gTGluay9CdXR0b24pXG4qIEByZXR1cm5zIEEgcm91dGVyLWF3YXJlIGNvbXBvbmVudCB3aXRoIHRoZSBzYW1lIEFQSSBhcyBgTGlua2AuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGUvY3VzdG9tLWxpbmtcbiovXG5mdW5jdGlvbiBjcmVhdGVMaW5rKENvbXApIHtcblx0cmV0dXJuIFJlYWN0JDEuZm9yd2FyZFJlZihmdW5jdGlvbiBDcmVhdGVkTGluayhwcm9wcywgcmVmKSB7XG5cdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTGluaywge1xuXHRcdFx0Li4ucHJvcHMsXG5cdFx0XHRfYXNDaGlsZDogQ29tcCxcblx0XHRcdHJlZlxuXHRcdH0pO1xuXHR9KTtcbn1cbi8qKlxuKiBBIHN0cm9uZ2x5LXR5cGVkIGFuY2hvciBjb21wb25lbnQgZm9yIGRlY2xhcmF0aXZlIG5hdmlnYXRpb24uXG4qIEhhbmRsZXMgcGF0aCwgc2VhcmNoLCBoYXNoIGFuZCBzdGF0ZSB1cGRhdGVzIHdpdGggb3B0aW9uYWwgcm91dGUgcHJlbG9hZGluZ1xuKiBhbmQgYWN0aXZlLXN0YXRlIHN0eWxpbmcuXG4qXG4qIFByb3BzOlxuKiAtIGBwcmVsb2FkYDogQ29udHJvbHMgcm91dGUgcHJlbG9hZGluZyAoZWcuICdpbnRlbnQnLCAncmVuZGVyJywgJ3ZpZXdwb3J0JywgdHJ1ZS9mYWxzZSlcbiogLSBgcHJlbG9hZERlbGF5YDogRGVsYXkgaW4gbXMgYmVmb3JlIHByZWxvYWRpbmcgb24gZm9jdXMsIGhvdmVyLCBvciB2aWV3cG9ydCBlbnRyeVxuKiAtIGBhY3RpdmVQcm9wc2AvYGluYWN0aXZlUHJvcHNgOiBBZGRpdGlvbmFsIHByb3BzIG1lcmdlZCB3aGVuIGxpbmsgaXMgYWN0aXZlL2luYWN0aXZlXG4qIC0gYHJlc2V0U2Nyb2xsYC9gaGFzaFNjcm9sbEludG9WaWV3YDogQ29udHJvbCBzY3JvbGwgYmVoYXZpb3Igb24gbmF2aWdhdGlvblxuKiAtIGB2aWV3VHJhbnNpdGlvbmAvYHN0YXJ0VHJhbnNpdGlvbmA6IFVzZSBWaWV3IFRyYW5zaXRpb25zL1JlYWN0IHRyYW5zaXRpb25zIGZvciBuYXZpZ2F0aW9uXG4qIC0gYGlnbm9yZUJsb2NrZXJgOiBCeXBhc3MgcmVnaXN0ZXJlZCBibG9ja2Vyc1xuKlxuKiBAcmV0dXJucyBBbiBhbmNob3ItbGlrZSBlbGVtZW50IHRoYXQgbmF2aWdhdGVzIHdpdGhvdXQgZnVsbCBwYWdlIHJlbG9hZHMuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9saW5rQ29tcG9uZW50XG4qL1xudmFyIExpbmsgPSBSZWFjdCQxLm1lbW8oUmVhY3QkMS5mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG5cdGNvbnN0IGhvc3QgPSBwcm9wcy5fYXNDaGlsZCB8fCBcImFcIjtcblx0Y29uc3QgbGlua1Byb3BzID0gdXNlTGlua1Byb3BzKHByb3BzLCByZWYsIGhvc3QpO1xuXHRjb25zdCBjaGlsZHJlbiA9IHR5cGVvZiBwcm9wcy5jaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiID8gcHJvcHMuY2hpbGRyZW4oeyBpc0FjdGl2ZTogbGlua1Byb3BzW1wiZGF0YS1zdGF0dXNcIl0gPT09IFwiYWN0aXZlXCIgfSkgOiBwcm9wcy5jaGlsZHJlbjtcblx0cmV0dXJuIFJlYWN0JDEuY3JlYXRlRWxlbWVudChob3N0LCBsaW5rUHJvcHMsIGNoaWxkcmVuKTtcbn0pLCBhcmVMaW5rUHJvcHNFcXVhbCk7XG5mdW5jdGlvbiBhcmVMaW5rUHJvcHNFcXVhbChwcmV2LCBuZXh0KSB7XG5cdGxldCBleHRyYUtleXMgPSAwO1xuXHRmb3IgKGNvbnN0IGtleSBpbiBuZXh0KSB7XG5cdFx0ZXh0cmFLZXlzKys7XG5cdFx0aWYgKHByZXZba2V5XSA9PT0gbmV4dFtrZXldKSBjb250aW51ZTtcblx0XHRpZiAoIVJPVVRFUl9PUFRJT05fS0VZUy5oYXMoa2V5KSB8fCAhZGVlcEVxdWFsKHByZXZba2V5XSwgbmV4dFtrZXldLCBmYWxzZSwgdHJ1ZSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRmb3IgKGNvbnN0IF9rZXkgaW4gcHJldikgZXh0cmFLZXlzLS07XG5cdHJldHVybiBleHRyYUtleXMgPT09IDA7XG59XG4vKipcbiogVmFsaWRhdGUgYW5kIHJldXNlIG5hdmlnYXRpb24gb3B0aW9ucyBmb3IgYExpbmtgLCBgbmF2aWdhdGVgIG9yIGByZWRpcmVjdGAuXG4qIEFjY2VwdHMgYSBsaXRlcmFsIG9wdGlvbnMgb2JqZWN0IGFuZCByZXR1cm5zIGl0IHR5cGVkIGZvciBsYXRlciBzcHJlYWRpbmcuXG4qIEBleGFtcGxlXG4qIGNvbnN0IG9wdHMgPSBsaW5rT3B0aW9ucyh7IHRvOiAnL2Rhc2hib2FyZCcsIHNlYXJjaDogeyB0YWI6ICdob21lJyB9IH0pXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9saW5rT3B0aW9uc1xuKi9cbnZhciBsaW5rT3B0aW9ucyA9IChvcHRpb25zKSA9PiB7XG5cdHJldHVybiBvcHRpb25zO1xufTtcbi8qKlxuKiBUeXBlLWNoZWNrIGEgbGl0ZXJhbCBvYmplY3QgZm9yIHVzZSB3aXRoIGBMaW5rYCwgYG5hdmlnYXRlYCBvciBgcmVkaXJlY3RgLlxuKiBVc2UgdG8gdmFsaWRhdGUgYW5kIHJldXNlIG5hdmlnYXRpb24gb3B0aW9ucyBhY3Jvc3MgeW91ciBhcHAuXG4qIEBleGFtcGxlXG4qIGNvbnN0IG9wdHMgPSBsaW5rT3B0aW9ucyh7IHRvOiAnL2Rhc2hib2FyZCcsIHNlYXJjaDogeyB0YWI6ICdob21lJyB9IH0pXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9saW5rT3B0aW9uc1xuKi9cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTGluaywgY3JlYXRlTGluaywgbGlua09wdGlvbnMsIHVzZUxpbmtQcm9wcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1saW5rLmpzLm1hcCIsImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgdXNlTWF0Y2ggfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuaW1wb3J0IHsgdXNlTG9hZGVyRGF0YSB9IGZyb20gXCIuL3VzZUxvYWRlckRhdGEuanNcIjtcbmltcG9ydCB7IHVzZUxvYWRlckRlcHMgfSBmcm9tIFwiLi91c2VMb2FkZXJEZXBzLmpzXCI7XG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwiLi91c2VQYXJhbXMuanNcIjtcbmltcG9ydCB7IHVzZVNlYXJjaCB9IGZyb20gXCIuL3VzZVNlYXJjaC5qc1wiO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwiLi91c2VOYXZpZ2F0ZS5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVDb250ZXh0IH0gZnJvbSBcIi4vdXNlUm91dGVDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyBMaW5rIH0gZnJvbSBcIi4vbGluay5qc1wiO1xuaW1wb3J0IHsgQmFzZVJvb3RSb3V0ZSwgQmFzZVJvdXRlLCBCYXNlUm91dGVBcGksIG5vdEZvdW5kIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlLnRzeFxuLyoqXG4qIFJldHVybnMgYSByb3V0ZS1zcGVjaWZpYyBBUEkgdGhhdCBleHBvc2VzIHR5cGUtc2FmZSBob29rcyBwcmUtYm91bmRcbiogdG8gYSBzaW5nbGUgcm91dGUgSUQuIFVzZWZ1bCBmb3IgY29uc3VtaW5nIGEgcm91dGUncyBBUElzIGZyb20gZmlsZXNcbiogd2hlcmUgdGhlIHJvdXRlIG9iamVjdCBpc24ndCBkaXJlY3RseSBpbXBvcnRlZCAoZS5nLiBjb2RlLXNwbGl0IGZpbGVzKS5cbipcbiogQHBhcmFtIGlkIFJvdXRlIElEIHN0cmluZyBsaXRlcmFsIGZvciB0aGUgdGFyZ2V0IHJvdXRlLlxuKiBAcmV0dXJucyBBIGBSb3V0ZUFwaWAgaW5zdGFuY2UgYm91bmQgdG8gdGhlIGdpdmVuIHJvdXRlIElELlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvZ2V0Um91dGVBcGlGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGdldFJvdXRlQXBpKGlkKSB7XG5cdHJldHVybiBuZXcgUm91dGVBcGkoeyBpZCB9KTtcbn1cbnZhciBSb3V0ZUFwaSA9IGNsYXNzIGV4dGVuZHMgQmFzZVJvdXRlQXBpIHtcblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHRoZSBgZ2V0Um91dGVBcGlgIGZ1bmN0aW9uIGluc3RlYWQuXG5cdCovXG5cdGNvbnN0cnVjdG9yKHsgaWQgfSkge1xuXHRcdHN1cGVyKHsgaWQgfSk7XG5cdFx0dGhpcy51c2VNYXRjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUm91dGVDb250ZXh0ID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VSb3V0ZUNvbnRleHQoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlU2VhcmNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VTZWFyY2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUGFyYW1zID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VQYXJhbXMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGVwcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGVwcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWQsXG5cdFx0XHRcdHN0cmljdDogZmFsc2Vcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEYXRhID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEYXRhKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZCxcblx0XHRcdFx0c3RyaWN0OiBmYWxzZVxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZU5hdmlnYXRlID0gKCkgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU5hdmlnYXRlKHsgZnJvbTogdXNlUm91dGVyKCkucm91dGVzQnlJZFt0aGlzLmlkXS5mdWxsUGF0aCB9KTtcblx0XHR9O1xuXHRcdHRoaXMubm90Rm91bmQgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIG5vdEZvdW5kKHtcblx0XHRcdFx0cm91dGVJZDogdGhpcy5pZCxcblx0XHRcdFx0Li4ub3B0c1xuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLkxpbmsgPSBSZWFjdC5mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG5cdFx0XHRjb25zdCBmdWxsUGF0aCA9IHVzZVJvdXRlcigpLnJvdXRlc0J5SWRbdGhpcy5pZF0uZnVsbFBhdGg7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChMaW5rLCB7XG5cdFx0XHRcdHJlZixcblx0XHRcdFx0ZnJvbTogZnVsbFBhdGgsXG5cdFx0XHRcdC4uLnByb3BzXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbnZhciBSb3V0ZSA9IGNsYXNzIGV4dGVuZHMgQmFzZVJvdXRlIHtcblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHRoZSBgY3JlYXRlUm91dGVgIGZ1bmN0aW9uIGluc3RlYWQuXG5cdCovXG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcihvcHRpb25zKTtcblx0XHR0aGlzLnVzZU1hdGNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VSb3V0ZUNvbnRleHQgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVJvdXRlQ29udGV4dCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VTZWFyY2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVNlYXJjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VQYXJhbXMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVBhcmFtcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEZXBzID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEZXBzKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRhdGEgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRhdGEoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTmF2aWdhdGUgPSAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTmF2aWdhdGUoeyBmcm9tOiB0aGlzLmZ1bGxQYXRoIH0pO1xuXHRcdH07XG5cdFx0dGhpcy5MaW5rID0gUmVhY3QuZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTGluaywge1xuXHRcdFx0XHRyZWYsXG5cdFx0XHRcdGZyb206IHRoaXMuZnVsbFBhdGgsXG5cdFx0XHRcdC4uLnByb3BzXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbi8qKlxuKiBDcmVhdGVzIGEgbm9uLXJvb3QgUm91dGUgaW5zdGFuY2UgZm9yIGNvZGUtYmFzZWQgcm91dGluZy5cbipcbiogVXNlIHRoaXMgdG8gZGVmaW5lIGEgcm91dGUgdGhhdCB3aWxsIGJlIGNvbXBvc2VkIGludG8gYSByb3V0ZSB0cmVlXG4qICh0eXBpY2FsbHkgdmlhIGEgcGFyZW50IHJvdXRlJ3MgYGFkZENoaWxkcmVuYCkuIElmIHlvdSdyZSB1c2luZyBmaWxlLWJhc2VkXG4qIHJvdXRpbmcsIHByZWZlciBgY3JlYXRlRmlsZVJvdXRlYC5cbipcbiogQHBhcmFtIG9wdGlvbnMgUm91dGUgb3B0aW9ucyAocGF0aCwgY29tcG9uZW50LCBsb2FkZXIsIGNvbnRleHQsIGV0Yy4pLlxuKiBAcmV0dXJucyBBIFJvdXRlIGluc3RhbmNlIHRvIGJlIGF0dGFjaGVkIHRvIHRoZSByb3V0ZSB0cmVlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvY3JlYXRlUm91dGVGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlKG9wdGlvbnMpIHtcblx0cmV0dXJuIG5ldyBSb3V0ZShvcHRpb25zKTtcbn1cbi8qKlxuKiBDcmVhdGVzIGEgcm9vdCByb3V0ZSBmYWN0b3J5IHRoYXQgcmVxdWlyZXMgYSByb3V0ZXIgY29udGV4dCB0eXBlLlxuKlxuKiBVc2Ugd2hlbiB5b3VyIHJvb3Qgcm91dGUgZXhwZWN0cyBgY29udGV4dGAgdG8gYmUgcHJvdmlkZWQgdG8gYGNyZWF0ZVJvdXRlcmAuXG4qIFRoZSByZXR1cm5lZCBmdW5jdGlvbiBiZWhhdmVzIGxpa2UgYGNyZWF0ZVJvb3RSb3V0ZWAgYnV0IGVuZm9yY2VzIGEgY29udGV4dCB0eXBlLlxuKlxuKiBAcmV0dXJucyBBIGZhY3RvcnkgZnVuY3Rpb24gdG8gY29uZmlndXJlIGFuZCByZXR1cm4gYSByb290IHJvdXRlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHRGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0KCkge1xuXHRyZXR1cm4gKG9wdGlvbnMpID0+IHtcblx0XHRyZXR1cm4gY3JlYXRlUm9vdFJvdXRlKG9wdGlvbnMpO1xuXHR9O1xufVxuLyoqXG4qIEBkZXByZWNhdGVkIFVzZSB0aGUgYGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0YCBmdW5jdGlvbiBpbnN0ZWFkLlxuKi9cbnZhciByb290Um91dGVXaXRoQ29udGV4dCA9IGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0O1xudmFyIFJvb3RSb3V0ZSA9IGNsYXNzIGV4dGVuZHMgQmFzZVJvb3RSb3V0ZSB7XG5cdC8qKlxuXHQqIEBkZXByZWNhdGVkIGBSb290Um91dGVgIGlzIG5vdyBhbiBpbnRlcm5hbCBpbXBsZW1lbnRhdGlvbiBkZXRhaWwuIFVzZSBgY3JlYXRlUm9vdFJvdXRlKClgIGluc3RlYWQuXG5cdCovXG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcihvcHRpb25zKTtcblx0XHR0aGlzLnVzZU1hdGNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VSb3V0ZUNvbnRleHQgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVJvdXRlQ29udGV4dCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VTZWFyY2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVNlYXJjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VQYXJhbXMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVBhcmFtcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEZXBzID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEZXBzKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRhdGEgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRhdGEoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTmF2aWdhdGUgPSAoKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTmF2aWdhdGUoeyBmcm9tOiB0aGlzLmZ1bGxQYXRoIH0pO1xuXHRcdH07XG5cdFx0dGhpcy5MaW5rID0gUmVhY3QuZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTGluaywge1xuXHRcdFx0XHRyZWYsXG5cdFx0XHRcdGZyb206IHRoaXMuZnVsbFBhdGgsXG5cdFx0XHRcdC4uLnByb3BzXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fVxufTtcbi8qKlxuKiBDcmVhdGVzIGEgcm9vdCBSb3V0ZSBpbnN0YW5jZSB1c2VkIHRvIGJ1aWxkIHlvdXIgcm91dGUgdHJlZS5cbipcbiogVHlwaWNhbGx5IHBhaXJlZCB3aXRoIGBjcmVhdGVSb3V0ZXIoeyByb3V0ZVRyZWUgfSlgLiBJZiB5b3UgbmVlZCB0byByZXF1aXJlXG4qIGEgdHlwZWQgcm91dGVyIGNvbnRleHQsIHVzZSBgY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHRgIGluc3RlYWQuXG4qXG4qIEBwYXJhbSBvcHRpb25zIFJvb3Qgcm91dGUgb3B0aW9ucyAoY29tcG9uZW50LCBlcnJvciwgcGVuZGluZywgZXRjLikuXG4qIEByZXR1cm5zIEEgcm9vdCByb3V0ZSBpbnN0YW5jZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZVJvb3RSb3V0ZUZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gY3JlYXRlUm9vdFJvdXRlKG9wdGlvbnMpIHtcblx0cmV0dXJuIG5ldyBSb290Um91dGUob3B0aW9ucyk7XG59XG5mdW5jdGlvbiBjcmVhdGVSb3V0ZU1hc2sob3B0cykge1xuXHRyZXR1cm4gb3B0cztcbn1cbnZhciBOb3RGb3VuZFJvdXRlID0gY2xhc3MgZXh0ZW5kcyBSb3V0ZSB7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcih7XG5cdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0aWQ6IFwiNDA0XCJcblx0XHR9KTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTm90Rm91bmRSb3V0ZSwgUm9vdFJvdXRlLCBSb3V0ZSwgUm91dGVBcGksIGNyZWF0ZVJvb3RSb3V0ZSwgY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHQsIGNyZWF0ZVJvdXRlLCBjcmVhdGVSb3V0ZU1hc2ssIGdldFJvdXRlQXBpLCByb290Um91dGVXaXRoQ29udGV4dCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yb3V0ZS5qcy5tYXAiLCJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbmltcG9ydCB7IHVzZUxvYWRlckRhdGEgfSBmcm9tIFwiLi91c2VMb2FkZXJEYXRhLmpzXCI7XG5pbXBvcnQgeyB1c2VMb2FkZXJEZXBzIH0gZnJvbSBcIi4vdXNlTG9hZGVyRGVwcy5qc1wiO1xuaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSBcIi4vdXNlUGFyYW1zLmpzXCI7XG5pbXBvcnQgeyB1c2VTZWFyY2ggfSBmcm9tIFwiLi91c2VTZWFyY2guanNcIjtcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSBcIi4vdXNlTmF2aWdhdGUuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlQ29udGV4dCB9IGZyb20gXCIuL3VzZVJvdXRlQ29udGV4dC5qc1wiO1xuaW1wb3J0IHsgY3JlYXRlUm91dGUgfSBmcm9tIFwiLi9yb3V0ZS5qc1wiO1xuLy8jcmVnaW9uIHNyYy9maWxlUm91dGUudHNcbi8qKlxuKiBDcmVhdGVzIGEgZmlsZS1iYXNlZCBSb3V0ZSBmYWN0b3J5IGZvciBhIGdpdmVuIHBhdGguXG4qXG4qIFVzZWQgYnkgVGFuU3RhY2sgUm91dGVyJ3MgZmlsZS1iYXNlZCByb3V0aW5nIHRvIGFzc29jaWF0ZSBhIGZpbGUgd2l0aCBhXG4qIHJvdXRlLiBUaGUgcmV0dXJuZWQgZnVuY3Rpb24gYWNjZXB0cyBzdGFuZGFyZCByb3V0ZSBvcHRpb25zLiBJbiBub3JtYWwgdXNhZ2VcbiogdGhlIGBwYXRoYCBzdHJpbmcgaXMgaW5zZXJ0ZWQgYW5kIG1haW50YWluZWQgYnkgdGhlIGB0c3JgIGdlbmVyYXRvci5cbipcbiogQHBhcmFtIHBhdGggRmlsZSBwYXRoIGxpdGVyYWwgZm9yIHRoZSByb3V0ZSAodXN1YWxseSBhdXRvLWdlbmVyYXRlZCkuXG4qIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCBhY2NlcHRzIFJvdXRlIG9wdGlvbnMgYW5kIHJldHVybnMgYSBSb3V0ZSBpbnN0YW5jZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZUZpbGVSb3V0ZUZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gY3JlYXRlRmlsZVJvdXRlKHBhdGgpIHtcblx0cmV0dXJuIChvcHRpb25zKSA9PiB7XG5cdFx0Y29uc3Qgcm91dGUgPSBjcmVhdGVSb3V0ZShvcHRpb25zKTtcblx0XHRyb3V0ZS5pc1Jvb3QgPSBmYWxzZTtcblx0XHRyZXR1cm4gcm91dGU7XG5cdH07XG59XG4vKiogXG5AZGVwcmVjYXRlZCBJdCdzIG5vIGxvbmdlciByZWNvbW1lbmRlZCB0byB1c2UgdGhlIGBGaWxlUm91dGVgIGNsYXNzIGRpcmVjdGx5LlxuSW5zdGVhZCwgdXNlIGBjcmVhdGVGaWxlUm91dGUoJy9wYXRoL3RvL2ZpbGUnKShvcHRpb25zKWAgdG8gY3JlYXRlIGEgZmlsZSByb3V0ZS5cbiovXG52YXIgRmlsZVJvdXRlID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcihwYXRoLCBfb3B0cykge1xuXHRcdHRoaXMucGF0aCA9IHBhdGg7XG5cdFx0dGhpcy5jcmVhdGVSb3V0ZSA9IChvcHRpb25zKSA9PiB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRcdGlmICghdGhpcy5zaWxlbnQpIGNvbnNvbGUud2FybihcIldhcm5pbmc6IEZpbGVSb3V0ZSBpcyBkZXByZWNhdGVkIGFuZCB3aWxsIGJlIHJlbW92ZWQgaW4gdGhlIG5leHQgbWFqb3IgdmVyc2lvbi4gVXNlIHRoZSBjcmVhdGVGaWxlUm91dGUocGF0aCkob3B0aW9ucykgZnVuY3Rpb24gaW5zdGVhZC5cIik7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCByb3V0ZSA9IGNyZWF0ZVJvdXRlKG9wdGlvbnMpO1xuXHRcdFx0cm91dGUuaXNSb290ID0gZmFsc2U7XG5cdFx0XHRyZXR1cm4gcm91dGU7XG5cdFx0fTtcblx0XHR0aGlzLnNpbGVudCA9IF9vcHRzPy5zaWxlbnQ7XG5cdH1cbn07XG4vKipcbkBkZXByZWNhdGVkIEl0J3MgcmVjb21tZW5kZWQgbm90IHRvIHNwbGl0IGxvYWRlcnMgaW50byBzZXBhcmF0ZSBmaWxlcy5cbkluc3RlYWQsIHBsYWNlIHRoZSBsb2FkZXIgZnVuY3Rpb24gaW4gdGhlIG1haW4gcm91dGUgZmlsZSB2aWEgYGNyZWF0ZUZpbGVSb3V0ZWAuXG4qL1xuZnVuY3Rpb24gRmlsZVJvdXRlTG9hZGVyKF9wYXRoKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihgV2FybmluZzogRmlsZVJvdXRlTG9hZGVyIGlzIGRlcHJlY2F0ZWQgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLiBQbGVhc2UgcGxhY2UgdGhlIGxvYWRlciBmdW5jdGlvbiBpbiB0aGUgbWFpbiByb3V0ZSBmaWxlLCBpbnNpZGUgdGhlIFxcYGNyZWF0ZUZpbGVSb3V0ZSgnL3BhdGgvdG8vZmlsZScpKG9wdGlvbnMpXFxgIG9wdGlvbnNgKTtcblx0cmV0dXJuIChsb2FkZXJGbikgPT4gbG9hZGVyRm47XG59XG52YXIgTGF6eVJvdXRlID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3RvcihvcHRzKSB7XG5cdFx0dGhpcy51c2VNYXRjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLm9wdGlvbnMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VSb3V0ZUNvbnRleHQgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVJvdXRlQ29udGV4dCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMub3B0aW9ucy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVNlYXJjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlU2VhcmNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5vcHRpb25zLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlUGFyYW1zID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VQYXJhbXMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLm9wdGlvbnMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEZXBzID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEZXBzKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5vcHRpb25zLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGF0YSA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGF0YSh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMub3B0aW9ucy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZU5hdmlnYXRlID0gKCkgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU5hdmlnYXRlKHsgZnJvbTogdXNlUm91dGVyKCkucm91dGVzQnlJZFt0aGlzLm9wdGlvbnMuaWRdLmZ1bGxQYXRoIH0pO1xuXHRcdH07XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0cztcblx0fVxufTtcbi8qKlxuKiBDcmVhdGVzIGEgbGF6aWx5LWNvbmZpZ3VyYWJsZSBjb2RlLWJhc2VkIHJvdXRlIHN0dWIgYnkgSUQuXG4qXG4qIFVzZSB0aGlzIGZvciBjb2RlLXNwbGl0dGluZyB3aXRoIGNvZGUtYmFzZWQgcm91dGVzLiBUaGUgcmV0dXJuZWQgZnVuY3Rpb25cbiogYWNjZXB0cyBvbmx5IG5vbi1jcml0aWNhbCByb3V0ZSBvcHRpb25zIGxpa2UgYGNvbXBvbmVudGAsIGBwZW5kaW5nQ29tcG9uZW50YCxcbiogYGVycm9yQ29tcG9uZW50YCwgYW5kIGBub3RGb3VuZENvbXBvbmVudGAgd2hpY2ggYXJlIGFwcGxpZWQgd2hlbiB0aGUgcm91dGVcbiogaXMgbWF0Y2hlZC5cbipcbiogQHBhcmFtIGlkIFJvdXRlIElEIHN0cmluZyBsaXRlcmFsIHRvIGFzc29jaWF0ZSB3aXRoIHRoZSBsYXp5IHJvdXRlLlxuKiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgYWNjZXB0cyBsYXp5IHJvdXRlIG9wdGlvbnMgYW5kIHJldHVybnMgYSBgTGF6eVJvdXRlYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZUxhenlSb3V0ZUZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gY3JlYXRlTGF6eVJvdXRlKGlkKSB7XG5cdHJldHVybiAob3B0cykgPT4ge1xuXHRcdHJldHVybiBuZXcgTGF6eVJvdXRlKHtcblx0XHRcdGlkLFxuXHRcdFx0Li4ub3B0c1xuXHRcdH0pO1xuXHR9O1xufVxuLyoqXG4qIENyZWF0ZXMgYSBsYXppbHktY29uZmlndXJhYmxlIGZpbGUtYmFzZWQgcm91dGUgc3R1YiBieSBmaWxlIHBhdGguXG4qXG4qIFVzZSB0aGlzIGZvciBjb2RlLXNwbGl0dGluZyB3aXRoIGZpbGUtYmFzZWQgcm91dGVzIChlZy4gYC5sYXp5LnRzeGAgZmlsZXMpLlxuKiBUaGUgcmV0dXJuZWQgZnVuY3Rpb24gYWNjZXB0cyBvbmx5IG5vbi1jcml0aWNhbCByb3V0ZSBvcHRpb25zIGxpa2VcbiogYGNvbXBvbmVudGAsIGBwZW5kaW5nQ29tcG9uZW50YCwgYGVycm9yQ29tcG9uZW50YCwgYW5kIGBub3RGb3VuZENvbXBvbmVudGAuXG4qXG4qIEBwYXJhbSBpZCBGaWxlIHBhdGggbGl0ZXJhbCBmb3IgdGhlIHJvdXRlIGZpbGUuXG4qIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCBhY2NlcHRzIGxhenkgcm91dGUgb3B0aW9ucyBhbmQgcmV0dXJucyBhIGBMYXp5Um91dGVgLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvY3JlYXRlTGF6eUZpbGVSb3V0ZUZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gY3JlYXRlTGF6eUZpbGVSb3V0ZShpZCkge1xuXHRpZiAodHlwZW9mIGlkID09PSBcIm9iamVjdFwiKSByZXR1cm4gbmV3IExhenlSb3V0ZShpZCk7XG5cdHJldHVybiAob3B0cykgPT4gbmV3IExhenlSb3V0ZSh7XG5cdFx0aWQsXG5cdFx0Li4ub3B0c1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgRmlsZVJvdXRlLCBGaWxlUm91dGVMb2FkZXIsIExhenlSb3V0ZSwgY3JlYXRlRmlsZVJvdXRlLCBjcmVhdGVMYXp5RmlsZVJvdXRlLCBjcmVhdGVMYXp5Um91dGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZmlsZVJvdXRlLmpzLm1hcCIsImltcG9ydCB7IHJlYWN0VXNlIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IGlzTW9kdWxlTm90Rm91bmRFcnJvciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbi8vI3JlZ2lvbiBzcmMvbGF6eVJvdXRlQ29tcG9uZW50LnRzeFxuLyoqXG4qIFdyYXAgYSBkeW5hbWljIGltcG9ydCB0byBjcmVhdGUgYSByb3V0ZSBjb21wb25lbnQgdGhhdCBzdXBwb3J0c1xuKiBgLnByZWxvYWQoKWAgYW5kIGZyaWVuZGx5IHJlbG9hZC1vbi1tb2R1bGUtbWlzc2luZyBiZWhhdmlvci5cbipcbiogQHBhcmFtIGltcG9ydGVyIEZ1bmN0aW9uIHJldHVybmluZyBhIG1vZHVsZSBwcm9taXNlXG4qIEBwYXJhbSBleHBvcnROYW1lIE5hbWVkIGV4cG9ydCB0byB1c2UgKGRlZmF1bHQ6IGBkZWZhdWx0YClcbiogQHJldHVybnMgQSBsYXp5IHJvdXRlIGNvbXBvbmVudCBjb21wYXRpYmxlIHdpdGggVGFuU3RhY2sgUm91dGVyXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9sYXp5Um91dGVDb21wb25lbnRGdW5jdGlvblxuKi9cbmZ1bmN0aW9uIGxhenlSb3V0ZUNvbXBvbmVudChpbXBvcnRlciwgZXhwb3J0TmFtZSkge1xuXHRsZXQgbG9hZFByb21pc2U7XG5cdGxldCBjb21wO1xuXHRsZXQgZXJyb3I7XG5cdGNvbnN0IGxvYWQgPSAoKSA9PiB7XG5cdFx0aWYgKCFsb2FkUHJvbWlzZSkge1xuXHRcdFx0ZXJyb3IgPSB2b2lkIDA7XG5cdFx0XHRsb2FkUHJvbWlzZSA9IGltcG9ydGVyKCkudGhlbigocmVzKSA9PiB7XG5cdFx0XHRcdGlmICghKGlzU2VydmVyID8/IHR5cGVvZiB3aW5kb3cgPT09IFwidW5kZWZpbmVkXCIpKSB7XG5cdFx0XHRcdFx0bG9hZFByb21pc2UgPSB2b2lkIDA7XG5cdFx0XHRcdFx0bGF6eUNvbXAucHJlbG9hZCA9IHZvaWQgMDtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb21wID0gcmVzW2V4cG9ydE5hbWUgPz8gXCJkZWZhdWx0XCJdO1xuXHRcdFx0fSkuY2F0Y2goKGVycikgPT4ge1xuXHRcdFx0XHRsb2FkUHJvbWlzZSA9IHZvaWQgMDtcblx0XHRcdFx0ZXJyb3IgPSBlcnI7XG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0cmV0dXJuIGxvYWRQcm9taXNlO1xuXHR9O1xuXHRjb25zdCBsYXp5Q29tcCA9IGZ1bmN0aW9uIExhenkocHJvcHMpIHtcblx0XHRpZiAoZXJyb3IpIHtcblx0XHRcdGlmIChpc01vZHVsZU5vdEZvdW5kRXJyb3IoZXJyb3IpICYmICEoaXNTZXJ2ZXIgPz8gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikgJiYgdHlwZW9mIHNlc3Npb25TdG9yYWdlICE9PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0XHRcdGNvbnN0IHN0b3JhZ2VLZXkgPSBgdGFuc3RhY2tfcm91dGVyX3JlbG9hZDoke2Vycm9yLm1lc3NhZ2V9YDtcblx0XHRcdFx0aWYgKCFzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKHN0b3JhZ2VLZXkpKSB7XG5cdFx0XHRcdFx0c2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbShzdG9yYWdlS2V5LCBcIjFcIik7XG5cdFx0XHRcdFx0d2luZG93LmxvY2F0aW9uLnJlbG9hZCgpO1xuXHRcdFx0XHRcdHRocm93IG5ldyBQcm9taXNlKCgpID0+IHt9KTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXHRcdGlmICghY29tcCkgaWYgKHJlYWN0VXNlKSByZWFjdFVzZShsb2FkKCkpO1xuXHRcdGVsc2UgdGhyb3cgbG9hZCgpO1xuXHRcdHJldHVybiBSZWFjdCQxLmNyZWF0ZUVsZW1lbnQoY29tcCwgcHJvcHMpO1xuXHR9O1xuXHRsYXp5Q29tcC5wcmVsb2FkID0gbG9hZDtcblx0cmV0dXJuIGxhenlDb21wO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBsYXp5Um91dGVDb21wb25lbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bGF6eVJvdXRlQ29tcG9uZW50LmpzLm1hcCIsImltcG9ydCB7IENhdGNoQm91bmRhcnkgfSBmcm9tIFwiLi9DYXRjaEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGlzTm90Rm91bmQgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy9ub3QtZm91bmQudHN4XG5mdW5jdGlvbiBDYXRjaE5vdEZvdW5kKHByb3BzKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0Y29uc3QgcmVzZXRLZXkgPSBgbm90LWZvdW5kLSR7cm91dGVyLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKS5wYXRobmFtZX0tJHtyb3V0ZXIuc3RvcmVzLnN0YXR1cy5nZXQoKX1gO1xuXHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KENhdGNoQm91bmRhcnksIHtcblx0XHRcdGdldFJlc2V0S2V5OiAoKSA9PiByZXNldEtleSxcblx0XHRcdG9uQ2F0Y2g6IChlcnJvciwgZXJyb3JJbmZvKSA9PiB7XG5cdFx0XHRcdGlmIChpc05vdEZvdW5kKGVycm9yKSkgcHJvcHMub25DYXRjaD8uKGVycm9yLCBlcnJvckluZm8pO1xuXHRcdFx0XHRlbHNlIHRocm93IGVycm9yO1xuXHRcdFx0fSxcblx0XHRcdGVycm9yQ29tcG9uZW50OiAoeyBlcnJvciB9KSA9PiB7XG5cdFx0XHRcdGlmIChpc05vdEZvdW5kKGVycm9yKSkgcmV0dXJuIHByb3BzLmZhbGxiYWNrPy4oZXJyb3IpO1xuXHRcdFx0XHRlbHNlIHRocm93IGVycm9yO1xuXHRcdFx0fSxcblx0XHRcdGNoaWxkcmVuOiBwcm9wcy5jaGlsZHJlblxuXHRcdH0pO1xuXHR9XG5cdGNvbnN0IHJlc2V0S2V5ID0gYG5vdC1mb3VuZC0ke3VzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubG9jYXRpb24sIChsb2NhdGlvbikgPT4gbG9jYXRpb24ucGF0aG5hbWUpfS0ke3VzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMuc3RhdHVzKX1gO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChDYXRjaEJvdW5kYXJ5LCB7XG5cdFx0Z2V0UmVzZXRLZXk6ICgpID0+IHJlc2V0S2V5LFxuXHRcdG9uQ2F0Y2g6IChlcnJvciwgZXJyb3JJbmZvKSA9PiB7XG5cdFx0XHRpZiAoaXNOb3RGb3VuZChlcnJvcikpIHByb3BzLm9uQ2F0Y2g/LihlcnJvciwgZXJyb3JJbmZvKTtcblx0XHRcdGVsc2UgdGhyb3cgZXJyb3I7XG5cdFx0fSxcblx0XHRlcnJvckNvbXBvbmVudDogKHsgZXJyb3IgfSkgPT4ge1xuXHRcdFx0aWYgKGlzTm90Rm91bmQoZXJyb3IpKSByZXR1cm4gcHJvcHMuZmFsbGJhY2s/LihlcnJvcik7XG5cdFx0XHRlbHNlIHRocm93IGVycm9yO1xuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IHByb3BzLmNoaWxkcmVuXG5cdH0pO1xufVxuZnVuY3Rpb24gRGVmYXVsdEdsb2JhbE5vdEZvdW5kKCkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInBcIiwgeyBjaGlsZHJlbjogXCJOb3QgRm91bmRcIiB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQ2F0Y2hOb3RGb3VuZCwgRGVmYXVsdEdsb2JhbE5vdEZvdW5kIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vdC1mb3VuZC5qcy5tYXAiLCJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL1NjcmlwdE9uY2UudHN4XG4vKipcbiogU2VydmVyLW9ubHkgaGVscGVyIHRvIGVtaXQgYSBzY3JpcHQgdGFnIGV4YWN0bHkgb25jZSBkdXJpbmcgU1NSLlxuKi9cbmZ1bmN0aW9uIFNjcmlwdE9uY2UoeyBjaGlsZHJlbiB9KSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRpZiAoIShpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpKSByZXR1cm4gbnVsbDtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzY3JpcHRcIiwge1xuXHRcdG5vbmNlOiByb3V0ZXIub3B0aW9ucy5zc3I/Lm5vbmNlLFxuXHRcdGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOiB7IF9faHRtbDogY2hpbGRyZW4gKyBcIjtkb2N1bWVudC5jdXJyZW50U2NyaXB0LnJlbW92ZSgpXCIgfVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgU2NyaXB0T25jZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1TY3JpcHRPbmNlLmpzLm1hcCIsImltcG9ydCB7IHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dCB9IGZyb20gXCIuL25vblJvdXRlQ29tcG9uZW50Q29udGV4dC5qc1wiO1xuaW1wb3J0IHsgRGVmYXVsdEdsb2JhbE5vdEZvdW5kIH0gZnJvbSBcIi4vbm90LWZvdW5kLmpzXCI7XG5pbXBvcnQgXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL3JlbmRlclJvdXRlTm90Rm91bmQudHN4XG4vKipcbiogUmVuZGVycyBhIG5vdCBmb3VuZCBjb21wb25lbnQgZm9yIGEgcm91dGUgd2hlbiBubyBtYXRjaGluZyByb3V0ZSBpcyBmb3VuZC5cbipcbiogQHBhcmFtIHJvdXRlciAtIFRoZSByb3V0ZXIgaW5zdGFuY2UgY29udGFpbmluZyB0aGUgcm91dGUgY29uZmlndXJhdGlvblxuKiBAcGFyYW0gcm91dGUgLSBUaGUgcm91dGUgdGhhdCB0cmlnZ2VyZWQgdGhlIG5vdCBmb3VuZCBzdGF0ZVxuKiBAcGFyYW0gZGF0YSAtIEFkZGl0aW9uYWwgZGF0YSB0byBwYXNzIHRvIHRoZSBub3QgZm91bmQgY29tcG9uZW50XG4qIEByZXR1cm5zIFRoZSByZW5kZXJlZCBub3QgZm91bmQgY29tcG9uZW50IG9yIGEgZGVmYXVsdCBmYWxsYmFjayBjb21wb25lbnRcbiovXG5mdW5jdGlvbiByZW5kZXJSb3V0ZU5vdEZvdW5kKHJvdXRlciwgcm91dGUsIGRhdGEpIHtcblx0aWYgKCFyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50KSB7XG5cdFx0aWYgKHJvdXRlci5vcHRpb25zLmRlZmF1bHROb3RGb3VuZENvbXBvbmVudCkge1xuXHRcdFx0Y29uc3Qgbm90Rm91bmRFbGVtZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChyb3V0ZXIub3B0aW9ucy5kZWZhdWx0Tm90Rm91bmRDb21wb25lbnQsIHsgLi4uZGF0YSB9KTtcblx0XHRcdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQobm90Rm91bmRFbGVtZW50LCBcIm5vdEZvdW5kQ29tcG9uZW50XCIpIDogbm90Rm91bmRFbGVtZW50O1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0XHRpZiAoIXJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQpIGNvbnNvbGUud2FybihgV2FybmluZzogQSBub3RGb3VuZEVycm9yIHdhcyBlbmNvdW50ZXJlZCBvbiB0aGUgcm91dGUgd2l0aCBJRCBcIiR7cm91dGUuaWR9XCIsIGJ1dCBhIG5vdEZvdW5kQ29tcG9uZW50IG9wdGlvbiB3YXMgbm90IGNvbmZpZ3VyZWQsIG5vciB3YXMgYSByb3V0ZXIgbGV2ZWwgZGVmYXVsdE5vdEZvdW5kQ29tcG9uZW50IGNvbmZpZ3VyZWQuIENvbnNpZGVyIGNvbmZpZ3VyaW5nIGF0IGxlYXN0IG9uZSBvZiB0aGVzZSB0byBhdm9pZCBUYW5TdGFjayBSb3V0ZXIncyBvdmVybHkgZ2VuZXJpYyBkZWZhdWx0Tm90Rm91bmRDb21wb25lbnQgKDxwPk5vdCBGb3VuZDwvcD4pYCk7XG5cdFx0fVxuXHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KERlZmF1bHRHbG9iYWxOb3RGb3VuZCwge30pO1xuXHR9XG5cdGNvbnN0IG5vdEZvdW5kRWxlbWVudCA9IC8qIEBfX1BVUkVfXyAqLyBqc3gocm91dGUub3B0aW9ucy5ub3RGb3VuZENvbXBvbmVudCwgeyAuLi5kYXRhIH0pO1xuXHRyZXR1cm4gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0KG5vdEZvdW5kRWxlbWVudCwgXCJub3RGb3VuZENvbXBvbmVudFwiKSA6IG5vdEZvdW5kRWxlbWVudDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcmVuZGVyUm91dGVOb3RGb3VuZCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZW5kZXJSb3V0ZU5vdEZvdW5kLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvc2Nyb2xsLXJlc3RvcmF0aW9uLXNjcmlwdC9jbGllbnQudHNcbmZ1bmN0aW9uIGdldFNjcm9sbFJlc3RvcmF0aW9uU2NyaXB0Rm9yUm91dGVyKF9yb3V0ZXIpIHtcblx0cmV0dXJuIG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGdldFNjcm9sbFJlc3RvcmF0aW9uU2NyaXB0Rm9yUm91dGVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNsaWVudC5qcy5tYXAiLCJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IFNjcmlwdE9uY2UgfSBmcm9tIFwiLi9TY3JpcHRPbmNlLmpzXCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmltcG9ydCB7IGdldFNjcm9sbFJlc3RvcmF0aW9uU2NyaXB0Rm9yUm91dGVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9zY3JvbGwtcmVzdG9yYXRpb24tc2NyaXB0XCI7XG4vLyNyZWdpb24gc3JjL3Njcm9sbC1yZXN0b3JhdGlvbi50c3hcbmZ1bmN0aW9uIFNjcm9sbFJlc3RvcmF0aW9uKCkge1xuXHRjb25zdCBzY3JpcHQgPSBnZXRTY3JvbGxSZXN0b3JhdGlvblNjcmlwdEZvclJvdXRlcih1c2VSb3V0ZXIoKSk7XG5cdGlmICghc2NyaXB0KSByZXR1cm4gbnVsbDtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goU2NyaXB0T25jZSwgeyBjaGlsZHJlbjogc2NyaXB0IH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBTY3JvbGxSZXN0b3JhdGlvbiB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zY3JvbGwtcmVzdG9yYXRpb24uanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyBub25Sb3V0ZUNvbXBvbmVudENvbnRleHQsIHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dCB9IGZyb20gXCIuL25vblJvdXRlQ29tcG9uZW50Q29udGV4dC5qc1wiO1xuaW1wb3J0IHsgQ2F0Y2hCb3VuZGFyeSwgRXJyb3JDb21wb25lbnQgfSBmcm9tIFwiLi9DYXRjaEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBDbGllbnRPbmx5IH0gZnJvbSBcIi4vQ2xpZW50T25seS5qc1wiO1xuaW1wb3J0IHsgbWF0Y2hDb250ZXh0IH0gZnJvbSBcIi4vbWF0Y2hDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IENhdGNoTm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCB7IHJlbmRlclJvdXRlTm90Rm91bmQgfSBmcm9tIFwiLi9yZW5kZXJSb3V0ZU5vdEZvdW5kLmpzXCI7XG5pbXBvcnQgeyBTY3JvbGxSZXN0b3JhdGlvbiB9IGZyb20gXCIuL3Njcm9sbC1yZXN0b3JhdGlvbi5qc1wiO1xuaW1wb3J0IHsgaXNOb3RGb3VuZCwgcm9vdFJvdXRlSWQgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBGcmFnbWVudCwganN4LCBqc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvTWF0Y2gudHN4XG5mdW5jdGlvbiByZW5kZXJQZW5kaW5nKHJvdXRlciwgcm91dGUpIHtcblx0Y29uc3QgUGVuZGluZ0NvbXBvbmVudCA9IHJvdXRlPy5vcHRpb25zLnBlbmRpbmdDb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFBlbmRpbmdDb21wb25lbnQ7XG5cdGlmICghUGVuZGluZ0NvbXBvbmVudCkgcmV0dXJuIG51bGw7XG5cdGNvbnN0IHBlbmRpbmdFbGVtZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChQZW5kaW5nQ29tcG9uZW50LCB7fSk7XG5cdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQocGVuZGluZ0VsZW1lbnQsIFwicGVuZGluZ0NvbXBvbmVudFwiKSA6IHBlbmRpbmdFbGVtZW50O1xufVxudmFyIG91dGxldE1hdGNoU2VsZWN0aW9uRXF1YWwgPSAoYSwgYikgPT4gYVswXSA9PT0gYlswXSAmJiBhWzFdID09PSBiWzFdO1xudmFyIGNhbldyYXBJblN1c3BlbnNlID0gKHJvdXRlciwgcm91dGUsIHNzcikgPT4gIXJvdXRlLmlzUm9vdCB8fCByb3V0ZS5vcHRpb25zLnNoZWxsQ29tcG9uZW50IHx8IHJvdXRlLm9wdGlvbnMud3JhcEluU3VzcGVuc2UgfHwgc3NyID09PSBmYWxzZSB8fCBzc3IgPT09IFwiZGF0YS1vbmx5XCIgfHwgISgoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB8fCByb3V0ZXIuc3NyKTtcbnZhciBNYXRjaCA9IFJlYWN0JDEubWVtbyhmdW5jdGlvbiBNYXRjaEltcGwoeyByb3V0ZUlkIH0pIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KE1hdGNoVmlldywge1xuXHRcdHJvdXRlcixcblx0XHRtYXRjaDogcm91dGVyLnN0b3Jlcy5ieVJvdXRlLmdldChyb3V0ZUlkKS5nZXQoKVxuXHR9KTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTWF0Y2hWaWV3LCB7XG5cdFx0cm91dGVyLFxuXHRcdG1hdGNoOiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLmdldE1hdGNoU3RvcmUocm91dGVJZCkpXG5cdH0pO1xufSk7XG5mdW5jdGlvbiBNYXRjaFZpZXcoeyByb3V0ZXIsIG1hdGNoIH0pIHtcblx0Y29uc3Qgcm91dGUgPSByb3V0ZXIucm91dGVzQnlJZFttYXRjaC5yb3V0ZUlkXTtcblx0Y29uc3QgcGVuZGluZ0VsZW1lbnQgPSByZW5kZXJQZW5kaW5nKHJvdXRlciwgcm91dGUpO1xuXHRjb25zdCByb3V0ZUVycm9yQ29tcG9uZW50ID0gcm91dGUub3B0aW9ucy5lcnJvckNvbXBvbmVudCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0RXJyb3JDb21wb25lbnQ7XG5cdGNvbnN0IHJvdXRlT25DYXRjaCA9IHJvdXRlLm9wdGlvbnMub25DYXRjaCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0T25DYXRjaDtcblx0Y29uc3Qgcm91dGVOb3RGb3VuZENvbXBvbmVudCA9IHJvdXRlLmlzUm9vdCA/IHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMubm90Rm91bmRSb3V0ZT8ub3B0aW9ucy5jb21wb25lbnQgOiByb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50O1xuXHRjb25zdCByZXNvbHZlZE5vU3NyID0gbWF0Y2guc3NyID09PSBmYWxzZSB8fCBtYXRjaC5zc3IgPT09IFwiZGF0YS1vbmx5XCI7XG5cdGNvbnN0IHdyYXBJblN1c3BlbnNlID0gY2FuV3JhcEluU3VzcGVuc2Uocm91dGVyLCByb3V0ZSwgbWF0Y2guc3NyKSAmJiAocm91dGUub3B0aW9ucy53cmFwSW5TdXNwZW5zZSA/PyBwZW5kaW5nRWxlbWVudCA/PyAocm91dGUub3B0aW9ucy5lcnJvckNvbXBvbmVudD8ucHJlbG9hZCB8fCByZXNvbHZlZE5vU3NyKSk7XG5cdGxldCBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChNYXRjaElubmVyLCB7IG1hdGNoIH0pO1xuXHRpZiAocmVzb2x2ZWROb1NzcikgY29udGVudCA9IC8qIEBfX1BVUkVfXyAqLyBqc3goQ2xpZW50T25seSwge1xuXHRcdGZhbGxiYWNrOiBwZW5kaW5nRWxlbWVudCxcblx0XHRjaGlsZHJlbjogY29udGVudFxuXHR9KTtcblx0aWYgKHJvdXRlTm90Rm91bmRDb21wb25lbnQpIGNvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KENhdGNoTm90Rm91bmQsIHtcblx0XHRmYWxsYmFjazogKGVycm9yKSA9PiB7XG5cdFx0XHRlcnJvci5yb3V0ZUlkID8/PSBtYXRjaC5yb3V0ZUlkO1xuXHRcdFx0aWYgKGVycm9yLnJvdXRlSWQgIT09IG1hdGNoLnJvdXRlSWQpIHRocm93IGVycm9yO1xuXHRcdFx0Y29uc3Qgbm90Rm91bmRFbGVtZW50ID0gUmVhY3QkMS5jcmVhdGVFbGVtZW50KHJvdXRlTm90Rm91bmRDb21wb25lbnQsIGVycm9yKTtcblx0XHRcdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQobm90Rm91bmRFbGVtZW50LCBcIm5vdEZvdW5kQ29tcG9uZW50XCIpIDogbm90Rm91bmRFbGVtZW50O1xuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IGNvbnRlbnRcblx0fSk7XG5cdGlmIChyb3V0ZUVycm9yQ29tcG9uZW50KSBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChDYXRjaEJvdW5kYXJ5LCB7XG5cdFx0Z2V0UmVzZXRLZXk6ICgpID0+IG1hdGNoLFxuXHRcdGVycm9yQ29tcG9uZW50OiByb3V0ZUVycm9yQ29tcG9uZW50LFxuXHRcdG9uQ2F0Y2g6IChlcnJvciwgZXJyb3JJbmZvKSA9PiB7XG5cdFx0XHRpZiAoaXNOb3RGb3VuZChlcnJvcikpIHtcblx0XHRcdFx0ZXJyb3Iucm91dGVJZCA/Pz0gbWF0Y2gucm91dGVJZDtcblx0XHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0XHR9XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLndhcm4oYFdhcm5pbmc6IEVycm9yIGluIHJvdXRlIG1hdGNoOiAke21hdGNoLmlkfWApO1xuXHRcdFx0cm91dGVPbkNhdGNoPy4oZXJyb3IsIGVycm9ySW5mbyk7XG5cdFx0fSxcblx0XHRjaGlsZHJlbjogY29udGVudFxuXHR9KTtcblx0aWYgKHdyYXBJblN1c3BlbnNlKSBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChSZWFjdCQxLlN1c3BlbnNlLCB7XG5cdFx0ZmFsbGJhY2s6IHBlbmRpbmdFbGVtZW50LFxuXHRcdGNoaWxkcmVuOiBjb250ZW50XG5cdH0pO1xuXHRjb25zdCBzY3JvbGxSZXN0b3JhdGlvbiA9IChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpICYmIHJvdXRlLnBhcmVudFJvdXRlPy5pZCA9PT0gcm9vdFJvdXRlSWQgJiYgcm91dGVyLm9wdGlvbnMuc2Nyb2xsUmVzdG9yYXRpb24gPyAvKiBAX19QVVJFX18gKi8ganN4KFNjcm9sbFJlc3RvcmF0aW9uLCB7fSkgOiBudWxsO1xuXHRjb25zdCBTaGVsbENvbXBvbmVudCA9IHJvdXRlLmlzUm9vdCA/IHJvdXRlLm9wdGlvbnMuc2hlbGxDb21wb25lbnQgOiB2b2lkIDA7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KG1hdGNoQ29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlOiBtYXRjaC5yb3V0ZUlkLFxuXHRcdGNoaWxkcmVuOiBTaGVsbENvbXBvbmVudCA/IC8qIEBfX1BVUkVfXyAqLyBqc3hzKFNoZWxsQ29tcG9uZW50LCB7IGNoaWxkcmVuOiBbY29udGVudCwgc2Nyb2xsUmVzdG9yYXRpb25dIH0pIDogLyogQF9fUFVSRV9fICovIGpzeHMoRnJhZ21lbnQsIHsgY2hpbGRyZW46IFtjb250ZW50LCBzY3JvbGxSZXN0b3JhdGlvbl0gfSlcblx0fSk7XG59XG52YXIgTWF0Y2hJbm5lciA9IFJlYWN0JDEubWVtbyhmdW5jdGlvbiBNYXRjaElubmVySW1wbCh7IG1hdGNoIH0pIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IHJvdXRlSWQgPSBtYXRjaC5yb3V0ZUlkO1xuXHRjb25zdCByb3V0ZSA9IHJvdXRlci5yb3V0ZXNCeUlkW3JvdXRlSWRdO1xuXHRjb25zdCBrZXkgPSBSZWFjdCQxLnVzZU1lbW8oKCkgPT4ge1xuXHRcdGNvbnN0IHJlbW91bnREZXBzID0gKHJvdXRlLm9wdGlvbnMucmVtb3VudERlcHMgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFJlbW91bnREZXBzKT8uKHtcblx0XHRcdHJvdXRlSWQsXG5cdFx0XHRsb2FkZXJEZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdFx0cGFyYW1zOiBtYXRjaC5fc3RyaWN0UGFyYW1zLFxuXHRcdFx0c2VhcmNoOiBtYXRjaC5fc3RyaWN0U2VhcmNoXG5cdFx0fSk7XG5cdFx0cmV0dXJuIHJlbW91bnREZXBzID8gSlNPTi5zdHJpbmdpZnkocmVtb3VudERlcHMpIDogdm9pZCAwO1xuXHR9LCBbXG5cdFx0cm91dGVJZCxcblx0XHRtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdG1hdGNoLl9zdHJpY3RQYXJhbXMsXG5cdFx0bWF0Y2guX3N0cmljdFNlYXJjaCxcblx0XHRyb3V0ZS5vcHRpb25zLnJlbW91bnREZXBzLFxuXHRcdHJvdXRlci5vcHRpb25zLmRlZmF1bHRSZW1vdW50RGVwc1xuXHRdKTtcblx0Y29uc3Qgb3V0ID0gUmVhY3QkMS51c2VNZW1vKCgpID0+IHtcblx0XHRjb25zdCBDb21wID0gcm91dGUub3B0aW9ucy5jb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdENvbXBvbmVudDtcblx0XHRyZXR1cm4gQ29tcCA/IC8qIEBfX1BVUkVfXyAqLyBqc3goQ29tcCwge30sIGtleSkgOiAvKiBAX19QVVJFX18gKi8ganN4KE91dGxldCwge30pO1xuXHR9LCBbXG5cdFx0a2V5LFxuXHRcdHJvdXRlLm9wdGlvbnMuY29tcG9uZW50LFxuXHRcdHJvdXRlci5vcHRpb25zLmRlZmF1bHRDb21wb25lbnRcblx0XSk7XG5cdGlmIChtYXRjaC5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB7XG5cdFx0aWYgKHJvdXRlci5zc3IgJiYgIWNhbldyYXBJblN1c3BlbnNlKHJvdXRlciwgcm91dGUsIG1hdGNoLnNzcikpIHJldHVybiBvdXQ7XG5cdFx0aWYgKHJvdXRlci5fdHgpIHRocm93IHJvdXRlci5fdHhbNV07XG5cdFx0cmV0dXJuIHJlbmRlclBlbmRpbmcocm91dGVyLCByb3V0ZSk7XG5cdH1cblx0aWYgKG1hdGNoLnN0YXR1cyA9PT0gXCJub3RGb3VuZFwiKSByZXR1cm4gcmVuZGVyUm91dGVOb3RGb3VuZChyb3V0ZXIsIHJvdXRlLCBtYXRjaC5lcnJvcik7XG5cdGlmIChtYXRjaC5zdGF0dXMgPT09IFwiZXJyb3JcIikge1xuXHRcdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRcdGNvbnN0IGVycm9yRWxlbWVudCA9IC8qIEBfX1BVUkVfXyAqLyBqc3goKHJvdXRlLm9wdGlvbnMuZXJyb3JDb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdEVycm9yQ29tcG9uZW50KSB8fCBFcnJvckNvbXBvbmVudCwge1xuXHRcdFx0XHRlcnJvcjogbWF0Y2guZXJyb3IsXG5cdFx0XHRcdHJlc2V0OiB2b2lkIDAsXG5cdFx0XHRcdGluZm86IHsgY29tcG9uZW50U3RhY2s6IFwiXCIgfVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0KGVycm9yRWxlbWVudCwgXCJlcnJvckNvbXBvbmVudFwiKSA6IGVycm9yRWxlbWVudDtcblx0XHR9XG5cdFx0dGhyb3cgbWF0Y2guZXJyb3I7XG5cdH1cblx0cmV0dXJuIG91dDtcbn0pO1xuLyoqXG4qIFJlbmRlciB0aGUgbmV4dCBjaGlsZCBtYXRjaCBpbiB0aGUgcm91dGUgdHJlZS4gVHlwaWNhbGx5IHVzZWQgaW5zaWRlXG4qIGEgcm91dGUgY29tcG9uZW50IHRvIHJlbmRlciBuZXN0ZWQgcm91dGVzLlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvb3V0bGV0Q29tcG9uZW50XG4qL1xudmFyIE91dGxldCA9IFJlYWN0JDEubWVtbyhmdW5jdGlvbiBPdXRsZXRJbXBsKCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0Y29uc3Qgbm9uUm91dGVDb21wb25lbnQgPSBSZWFjdCQxLnVzZUNvbnRleHQobm9uUm91dGVDb21wb25lbnRDb250ZXh0KTtcblx0XHRpZiAobm9uUm91dGVDb21wb25lbnQpIGNvbnNvbGUud2FybihgV2FybmluZzogQW4gPE91dGxldCAvPiB3YXMgcmVuZGVyZWQgaW5zaWRlIGEgJHtub25Sb3V0ZUNvbXBvbmVudH0uIDxPdXRsZXQgLz4gc2hvdWxkIG9ubHkgYmUgcmVuZGVyZWQgaW5zaWRlIGEgcm91dGUgY29tcG9uZW50LmApO1xuXHR9XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCByb3V0ZUlkID0gUmVhY3QkMS51c2VDb250ZXh0KG1hdGNoQ29udGV4dCk7XG5cdGxldCBwYXJlbnRHbG9iYWxOb3RGb3VuZDtcblx0bGV0IHBhcmVudE5vdEZvdW5kRXJyb3I7XG5cdGxldCBjaGlsZFJvdXRlSWQ7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRjb25zdCBtYXRjaGVzID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpO1xuXHRcdGNvbnN0IHBhcmVudEluZGV4ID0gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkID09PSByb3V0ZUlkKTtcblx0XHRjb25zdCBwYXJlbnRNYXRjaCA9IG1hdGNoZXNbcGFyZW50SW5kZXhdO1xuXHRcdHBhcmVudEdsb2JhbE5vdEZvdW5kID0gISFwYXJlbnRNYXRjaC5fbm90Rm91bmQ7XG5cdFx0cGFyZW50Tm90Rm91bmRFcnJvciA9IHBhcmVudE1hdGNoLmVycm9yO1xuXHRcdGNoaWxkUm91dGVJZCA9IG1hdGNoZXNbcGFyZW50SW5kZXggKyAxXT8ucm91dGVJZDtcblx0fSBlbHNlIHtcblx0XHRjb25zdCBwYXJlbnRNYXRjaFN0b3JlID0gcm91dGVyLnN0b3Jlcy5nZXRNYXRjaFN0b3JlKHJvdXRlSWQpO1xuXHRcdFtwYXJlbnRHbG9iYWxOb3RGb3VuZCwgcGFyZW50Tm90Rm91bmRFcnJvcl0gPSB1c2VTZWxlY3RvcihwYXJlbnRNYXRjaFN0b3JlLCAobWF0Y2gpID0+IFshIW1hdGNoLl9ub3RGb3VuZCwgbWF0Y2guZXJyb3JdLCB7IGNvbXBhcmU6IG91dGxldE1hdGNoU2VsZWN0aW9uRXF1YWwgfSk7XG5cdFx0Y2hpbGRSb3V0ZUlkID0gdXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5pZHMsIChpZHMpID0+IHtcblx0XHRcdHJldHVybiBpZHNbaWRzLmluZGV4T2Yocm91dGVJZCkgKyAxXTtcblx0XHR9KTtcblx0fVxuXHRpZiAocGFyZW50R2xvYmFsTm90Rm91bmQpIHJldHVybiByZW5kZXJSb3V0ZU5vdEZvdW5kKHJvdXRlciwgcm91dGVyLnJvdXRlc0J5SWRbcm91dGVJZF0sIHBhcmVudE5vdEZvdW5kRXJyb3IpO1xuXHRpZiAoIWNoaWxkUm91dGVJZCkgcmV0dXJuIG51bGw7XG5cdGNvbnN0IG5leHRNYXRjaCA9IC8qIEBfX1BVUkVfXyAqLyBqc3goTWF0Y2gsIHsgcm91dGVJZDogY2hpbGRSb3V0ZUlkIH0pO1xuXHRpZiAocm91dGVJZCA9PT0gcm9vdFJvdXRlSWQpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFJlYWN0JDEuU3VzcGVuc2UsIHtcblx0XHRmYWxsYmFjazogcmVuZGVyUGVuZGluZyhyb3V0ZXIpLFxuXHRcdGNoaWxkcmVuOiBuZXh0TWF0Y2hcblx0fSk7XG5cdHJldHVybiBuZXh0TWF0Y2g7XG59KTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTWF0Y2gsIE91dGxldCwgcmVuZGVyUGVuZGluZyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1NYXRjaC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUxheW91dEVmZmVjdCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGdldExvY2F0aW9uQ2hhbmdlSW5mbywgdHJpbVBhdGhSaWdodCB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL1RyYW5zaXRpb25lci50c3hcbmZ1bmN0aW9uIHNldHRsZU93bmVyKG93bmVyLCByZW5kZXJlZCkge1xuXHRjb25zdCBzZXR0bGUgPSBvd25lclsxXTtcblx0b3duZXIubGVuZ3RoID0gMDtcblx0c2V0dGxlPy4ocmVuZGVyZWQpO1xufVxuZnVuY3Rpb24gVHJhbnNpdGlvbmVyKHsgdCB9KSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBhY2tub3dsZWRnZW1lbnQgPSByb3V0ZXIuX3JlbmRlcmVkID8/PSBbXTtcblx0Y29uc3QgbW91bnRlZCA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFJlYWN0JDEudXNlUmVmKGZhbHNlKSA6IHZvaWQgMDtcblx0cm91dGVyLnN0YXJ0VHJhbnNpdGlvbiA9IChmbiwgZXhwZWN0ZWQpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0c2V0dGxlT3duZXIoYWNrbm93bGVkZ2VtZW50LCBmYWxzZSk7XG5cdFx0YWNrbm93bGVkZ2VtZW50LnB1c2goZXhwZWN0ZWQsIHJlc29sdmUpO1xuXHRcdHQocm91dGVyKTtcblx0XHRSZWFjdCQxLnN0YXJ0VHJhbnNpdGlvbihmbik7XG5cdH0pO1xuXHR1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuXHRcdGNvbnN0IHVuc3ViID0gcm91dGVyLmhpc3Rvcnkuc3Vic2NyaWJlKHJvdXRlci5sb2FkKTtcblx0XHRpZiAobW91bnRlZD8uY3VycmVudCkgcmV0dXJuIHVuc3ViO1xuXHRcdGlmIChtb3VudGVkKSBtb3VudGVkLmN1cnJlbnQgPSB0cnVlO1xuXHRcdHJvdXRlci51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdGNvbnN0IGxvY2F0aW9uID0gcm91dGVyLmxhdGVzdExvY2F0aW9uO1xuXHRcdGNvbnN0IG5leHRMb2NhdGlvbiA9IHJvdXRlci5idWlsZExvY2F0aW9uKHtcblx0XHRcdHRvOiBsb2NhdGlvbi5wYXRobmFtZSxcblx0XHRcdHNlYXJjaDogdHJ1ZSxcblx0XHRcdHBhcmFtczogdHJ1ZSxcblx0XHRcdGhhc2g6IHRydWUsXG5cdFx0XHRzdGF0ZTogdHJ1ZSxcblx0XHRcdF9pbmNsdWRlVmFsaWRhdGVTZWFyY2g6IHRydWVcblx0XHR9KTtcblx0XHRpZiAodHJpbVBhdGhSaWdodChsb2NhdGlvbi5wdWJsaWNIcmVmKSAhPT0gdHJpbVBhdGhSaWdodChuZXh0TG9jYXRpb24ucHVibGljSHJlZikpIHtcblx0XHRcdHJvdXRlci5jb21taXRMb2NhdGlvbih7XG5cdFx0XHRcdC4uLm5leHRMb2NhdGlvbixcblx0XHRcdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRcdFx0aWdub3JlQmxvY2tlcjogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gdW5zdWI7XG5cdFx0fVxuXHRcdGNvbnN0IHJlc29sdmVkTG9jYXRpb24gPSByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCk7XG5cdFx0aWYgKHJlc29sdmVkTG9jYXRpb24/LmhyZWYgPT09IGxvY2F0aW9uLmhyZWYgJiYgcmVzb2x2ZWRMb2NhdGlvbi5zdGF0ZS5fX1RTUl9rZXkgPT09IGxvY2F0aW9uLnN0YXRlLl9fVFNSX2tleSkgYWNrbm93bGVkZ2VtZW50LnB1c2gocm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpLCAocmVuZGVyZWQpID0+IHtcblx0XHRcdGlmIChyZW5kZXJlZCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uUmVuZGVyZWRcIixcblx0XHRcdFx0Li4uZ2V0TG9jYXRpb25DaGFuZ2VJbmZvKHJlc29sdmVkTG9jYXRpb24sIHJlc29sdmVkTG9jYXRpb24pXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRlbHNlIGlmICghcm91dGVyLl90eCkgcm91dGVyLmxvYWQoeyBzeW5jOiB0cnVlIH0pLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xuXHRcdHJldHVybiB1bnN1Yjtcblx0fSwgW3JvdXRlciwgcm91dGVyLmhpc3RvcnldKTtcblx0cmV0dXJuIG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFRyYW5zaXRpb25lciwgc2V0dGxlT3duZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9VHJhbnNpdGlvbmVyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IENhdGNoQm91bmRhcnkgfSBmcm9tIFwiLi9DYXRjaEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBtYXRjaENvbnRleHQgfSBmcm9tIFwiLi9tYXRjaENvbnRleHQuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgdXNlU3RydWN0dXJhbFNoYXJpbmcgfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuaW1wb3J0IHsgVHJhbnNpdGlvbmVyLCBzZXR0bGVPd25lciB9IGZyb20gXCIuL1RyYW5zaXRpb25lci5qc1wiO1xuaW1wb3J0IHsgTWF0Y2gsIHJlbmRlclBlbmRpbmcgfSBmcm9tIFwiLi9NYXRjaC5qc1wiO1xuaW1wb3J0IHsgcm9vdFJvdXRlSWQgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBGcmFnbWVudCwganN4LCBqc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvTWF0Y2hlcy50c3hcbi8qKlxuKiBJbnRlcm5hbCBjb21wb25lbnQgdGhhdCByZW5kZXJzIHRoZSByb3V0ZXIncyBhY3RpdmUgbWF0Y2ggdHJlZSB3aXRoXG4qIHN1c3BlbnNlLCBlcnJvciwgYW5kIG5vdC1mb3VuZCBib3VuZGFyaWVzLiBSZW5kZXJlZCBieSBgUm91dGVyUHJvdmlkZXJgLlxuKi9cbmZ1bmN0aW9uIE1hdGNoZXMoKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCByb290Um91dGUgPSByb3V0ZXIucm91dGVzQnlJZFtyb290Um91dGVJZF07XG5cdGNvbnN0IHBlbmRpbmdFbGVtZW50ID0gcmVuZGVyUGVuZGluZyhyb3V0ZXIsIHJvb3RSb3V0ZSk7XG5cdGNvbnN0IGlubmVyID0gLyogQF9fUFVSRV9fICovIGpzeHMoRnJhZ21lbnQsIHsgY2hpbGRyZW46IFshKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgJiYgLyogQF9fUFVSRV9fICovIGpzeChUcmFuc2l0aW9uZXIsIHsgdDogUmVhY3QkMS51c2VTdGF0ZSgpWzFdIH0pLCAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB8fCByb3V0ZXIuc3NyID8gLyogQF9fUFVSRV9fICovIGpzeChNYXRjaGVzSW5uZXIsIHt9KSA6IC8qIEBfX1BVUkVfXyAqLyBqc3goUmVhY3QkMS5TdXNwZW5zZSwge1xuXHRcdGZhbGxiYWNrOiBwZW5kaW5nRWxlbWVudCxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChNYXRjaGVzSW5uZXIsIHt9KVxuXHR9KV0gfSk7XG5cdHJldHVybiByb3V0ZXIub3B0aW9ucy5Jbm5lcldyYXAgPyAvKiBAX19QVVJFX18gKi8ganN4KHJvdXRlci5vcHRpb25zLklubmVyV3JhcCwgeyBjaGlsZHJlbjogaW5uZXIgfSkgOiBpbm5lcjtcbn1cbmZ1bmN0aW9uIE1hdGNoZXNJbm5lcigpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IGFja25vd2xlZGdlbWVudCA9IHJvdXRlci5fcmVuZGVyZWQ7XG5cdGNvbnN0IG1hdGNoZXMgPSBpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIgPyByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCkgOiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLm1hdGNoZXMsICh2YWx1ZSkgPT4gYWNrbm93bGVkZ2VtZW50WzBdID8/IHZhbHVlKTtcblx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzWzBdO1xuXHRjb25zdCByb3V0ZUlkID0gbWF0Y2g/LnJvdXRlSWQ7XG5cdHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKGFja25vd2xlZGdlbWVudFswXSA9PT0gbWF0Y2hlcykgc2V0dGxlT3duZXIoYWNrbm93bGVkZ2VtZW50LCB0cnVlKTtcblx0fSwgW2Fja25vd2xlZGdlbWVudCwgbWF0Y2hlc10pO1xuXHRjb25zdCBtYXRjaENvbXBvbmVudCA9IHJvdXRlSWQgPyAvKiBAX19QVVJFX18gKi8ganN4KE1hdGNoLCB7IHJvdXRlSWQgfSkgOiBudWxsO1xuXHRyZXR1cm4gcm91dGVyLm9wdGlvbnMuZGlzYWJsZUdsb2JhbENhdGNoQm91bmRhcnkgPyBtYXRjaENvbXBvbmVudCA6IC8qIEBfX1BVUkVfXyAqLyBqc3goQ2F0Y2hCb3VuZGFyeSwge1xuXHRcdGdldFJlc2V0S2V5OiAoKSA9PiBtYXRjaCxcblx0XHRvbkNhdGNoOiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAoZXJyb3IpID0+IHtcblx0XHRcdGNvbnNvbGUud2FybihgV2FybmluZzogVGhlIGZvbGxvd2luZyBlcnJvciB3YXNuJ3QgY2F1Z2h0IGJ5IGFueSByb3V0ZSEgQXQgdGhlIHZlcnkgbGVhc3QsIGNvbnNpZGVyIHNldHRpbmcgYW4gJ2Vycm9yQ29tcG9uZW50JyBpbiB5b3VyIFJvb3RSb3V0ZSFgKTtcblx0XHRcdGNvbnNvbGUud2FybihcIldhcm5pbmc6XCIsIGVycm9yKTtcblx0XHR9IDogdm9pZCAwLFxuXHRcdGNoaWxkcmVuOiBtYXRjaENvbXBvbmVudFxuXHR9KTtcbn1cbi8qKlxuKiBDcmVhdGUgYSBtYXRjaGVyIGZ1bmN0aW9uIGZvciB0ZXN0aW5nIGxvY2F0aW9ucyBhZ2FpbnN0IHJvdXRlIGRlZmluaXRpb25zLlxuKlxuKiBUaGUgcmV0dXJuZWQgZnVuY3Rpb24gYWNjZXB0cyBzdGFuZGFyZCBuYXZpZ2F0aW9uIG9wdGlvbnMgKGB0b2AsIGBwYXJhbXNgLFxuKiBgc2VhcmNoYCwgZXRjLikgYW5kIHJldHVybnMgZWl0aGVyIGBmYWxzZWAgKG5vIG1hdGNoKSBvciB0aGUgbWF0Y2hlZCBwYXJhbXNcbiogb2JqZWN0IHdoZW4gdGhlIHJvdXRlIG1hdGNoZXMgdGhlIGN1cnJlbnQgb3IgcGVuZGluZyBsb2NhdGlvbi5cbipcbiogVXNlZnVsIGZvciBjb25kaXRpb25hbCByZW5kZXJpbmcgYW5kIGFjdGl2ZSBVSSBzdGF0ZXMgYmVjYXVzZSBpdCBzdWJzY3JpYmVzXG4qIHRoZSBjb21wb25lbnQgdG8gdGhlIHJvdXRlciBzdGF0ZSB1c2VkIGZvciBtYXRjaGluZy4gVGhlIHJldHVybmVkIGZ1bmN0aW9uJ3NcbiogaWRlbnRpdHkgY2hhbmdlcyB3aGVuIHRoYXQgc3RhdGUgY2hhbmdlcy4gRm9yIGltcGVyYXRpdmUgY2hlY2tzIGluIGV2ZW50XG4qIGhhbmRsZXJzLCBnZXQgdGhlIHJvdXRlciB3aXRoIGB1c2VSb3V0ZXJgIGFuZCBjYWxsIGByb3V0ZXIubWF0Y2hSb3V0ZSguLi4pYFxuKiB0byBhdm9pZCB0aGF0IHN1YnNjcmlwdGlvbi5cbipcbiogQHJldHVybnMgQSBgbWF0Y2hSb3V0ZShvcHRpb25zKWAgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGBmYWxzZWAgb3IgcGFyYW1zLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlTWF0Y2hSb3V0ZUhvb2tcbiovXG5mdW5jdGlvbiB1c2VNYXRjaFJvdXRlKCkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgcmV0dXJuIChvcHRzKSA9PiB7XG5cdFx0Y29uc3QgeyBwZW5kaW5nLCBjYXNlU2Vuc2l0aXZlLCBmdXp6eSwgaW5jbHVkZVNlYXJjaCwgLi4ucmVzdCB9ID0gb3B0cztcblx0XHRyZXR1cm4gcm91dGVyLm1hdGNoUm91dGUocmVzdCwge1xuXHRcdFx0cGVuZGluZyxcblx0XHRcdGNhc2VTZW5zaXRpdmUsXG5cdFx0XHRmdXp6eSxcblx0XHRcdGluY2x1ZGVTZWFyY2hcblx0XHR9KTtcblx0fTtcblx0cmV0dXJuIFJlYWN0JDEudXNlQ2FsbGJhY2soKG9wdHMpID0+IHtcblx0XHRjb25zdCB7IHBlbmRpbmcsIGNhc2VTZW5zaXRpdmUsIGZ1enp5LCBpbmNsdWRlU2VhcmNoLCAuLi5yZXN0IH0gPSBvcHRzO1xuXHRcdHJldHVybiByb3V0ZXIubWF0Y2hSb3V0ZShyZXN0LCB7XG5cdFx0XHRwZW5kaW5nLFxuXHRcdFx0Y2FzZVNlbnNpdGl2ZSxcblx0XHRcdGZ1enp5LFxuXHRcdFx0aW5jbHVkZVNlYXJjaFxuXHRcdH0pO1xuXHR9LCBbXG5cdFx0cm91dGVyLFxuXHRcdHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubG9jYXRpb24sIChsb2NhdGlvbikgPT4gbG9jYXRpb24uaHJlZiksXG5cdFx0dXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLCAobG9jYXRpb24pID0+IGxvY2F0aW9uPy5ocmVmKSxcblx0XHR1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLnN0YXR1cylcblx0XSk7XG59XG4vKipcbiogQ29tcG9uZW50IHRoYXQgY29uZGl0aW9uYWxseSByZW5kZXJzIGl0cyBjaGlsZHJlbiBiYXNlZCBvbiB3aGV0aGVyIGEgcm91dGVcbiogbWF0Y2hlcyB0aGUgcHJvdmlkZWQgYGZyb21gL2B0b2Agb3B0aW9ucy4gSWYgYGNoaWxkcmVuYCBpcyBhIGZ1bmN0aW9uLCBpdFxuKiByZWNlaXZlcyB0aGUgbWF0Y2hlZCBwYXJhbXMgb2JqZWN0LlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvbWF0Y2hSb3V0ZUNvbXBvbmVudFxuKi9cbmZ1bmN0aW9uIE1hdGNoUm91dGUocHJvcHMpIHtcblx0Y29uc3QgcGFyYW1zID0gdXNlTWF0Y2hSb3V0ZSgpKHByb3BzKTtcblx0aWYgKHR5cGVvZiBwcm9wcy5jaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gcHJvcHMuY2hpbGRyZW4ocGFyYW1zKTtcblx0cmV0dXJuIHBhcmFtcyA/IHByb3BzLmNoaWxkcmVuIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHVzZU1hdGNoZXMob3B0cykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGNvbnN0IG1hdGNoZXMgPSByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCk7XG5cdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoZXMpIDogbWF0Y2hlcztcblx0fVxuXHRyZXR1cm4gdXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5tYXRjaGVzLCB1c2VTdHJ1Y3R1cmFsU2hhcmluZyhvcHRzLCByb3V0ZXIpKTtcbn1cbi8qKlxuKiBSZWFkIHRoZSBwcmVzZW50ZWQgcm91dGUgbWF0Y2hlcyBhYm92ZSB0aGUgY3VycmVudCBtYXRjaCwgb3Igc2VsZWN0IGFcbiogZGVyaXZlZCB2YWx1ZSBmcm9tIHRoZW0uXG4qL1xuZnVuY3Rpb24gdXNlUGFyZW50TWF0Y2hlcyhvcHRzKSB7XG5cdGNvbnN0IGNvbnRleHRSb3V0ZUlkID0gUmVhY3QkMS51c2VDb250ZXh0KG1hdGNoQ29udGV4dCk7XG5cdHJldHVybiB1c2VNYXRjaGVzKHtcblx0XHRzZWxlY3Q6IChtYXRjaGVzKSA9PiB7XG5cdFx0XHRtYXRjaGVzID0gbWF0Y2hlcy5zbGljZSgwLCBtYXRjaGVzLmZpbmRJbmRleCgoZCkgPT4gZC5yb3V0ZUlkID09PSBjb250ZXh0Um91dGVJZCkpO1xuXHRcdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoZXMpIDogbWF0Y2hlcztcblx0XHR9LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzPy5zdHJ1Y3R1cmFsU2hhcmluZ1xuXHR9KTtcbn1cbi8qKlxuKiBSZWFkIHRoZSBwcmVzZW50ZWQgcm91dGUgbWF0Y2hlcyBiZWxvdyB0aGUgY3VycmVudCBtYXRjaCwgb3Igc2VsZWN0IGFcbiogZGVyaXZlZCB2YWx1ZSBmcm9tIHRoZW0uXG4qL1xuZnVuY3Rpb24gdXNlQ2hpbGRNYXRjaGVzKG9wdHMpIHtcblx0Y29uc3QgY29udGV4dFJvdXRlSWQgPSBSZWFjdCQxLnVzZUNvbnRleHQobWF0Y2hDb250ZXh0KTtcblx0cmV0dXJuIHVzZU1hdGNoZXMoe1xuXHRcdHNlbGVjdDogKG1hdGNoZXMpID0+IHtcblx0XHRcdG1hdGNoZXMgPSBtYXRjaGVzLnNsaWNlKG1hdGNoZXMuZmluZEluZGV4KChkKSA9PiBkLnJvdXRlSWQgPT09IGNvbnRleHRSb3V0ZUlkKSArIDEpO1xuXHRcdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoZXMpIDogbWF0Y2hlcztcblx0XHR9LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzPy5zdHJ1Y3R1cmFsU2hhcmluZ1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTWF0Y2hSb3V0ZSwgTWF0Y2hlcywgdXNlQ2hpbGRNYXRjaGVzLCB1c2VNYXRjaFJvdXRlLCB1c2VNYXRjaGVzLCB1c2VQYXJlbnRNYXRjaGVzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPU1hdGNoZXMuanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlTm9uUmVhY3RpdmVNdXRhYmxlU3RvcmUsIGNyZWF0ZU5vblJlYWN0aXZlUmVhZG9ubHlTdG9yZSB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsgYmF0Y2gsIGNyZWF0ZUF0b20gfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlclN0b3Jlcy50c1xudmFyIGdldFN0b3JlRmFjdG9yeSA9IChvcHRzKSA9PiB7XG5cdGlmIChpc1NlcnZlciA/PyBvcHRzLmlzU2VydmVyKSByZXR1cm4ge1xuXHRcdGNyZWF0ZU11dGFibGVTdG9yZTogY3JlYXRlTm9uUmVhY3RpdmVNdXRhYmxlU3RvcmUsXG5cdFx0Y3JlYXRlUmVhZG9ubHlTdG9yZTogY3JlYXRlTm9uUmVhY3RpdmVSZWFkb25seVN0b3JlLFxuXHRcdGJhdGNoOiAoZm4pID0+IGZuKClcblx0fTtcblx0cmV0dXJuIHtcblx0XHRjcmVhdGVNdXRhYmxlU3RvcmU6IGNyZWF0ZUF0b20sXG5cdFx0Y3JlYXRlUmVhZG9ubHlTdG9yZTogY3JlYXRlQXRvbSxcblx0XHRiYXRjaFxuXHR9O1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZ2V0U3RvcmVGYWN0b3J5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlclN0b3Jlcy5qcy5tYXAiLCJpbXBvcnQgeyBnZXRTdG9yZUZhY3RvcnkgfSBmcm9tIFwiLi9yb3V0ZXJTdG9yZXMuanNcIjtcbmltcG9ydCB7IFJvdXRlckNvcmUgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlci50c1xuLyoqXG4qIENyZWF0ZXMgYSBuZXcgUm91dGVyIGluc3RhbmNlIGZvciBSZWFjdC5cbipcbiogUGFzcyB0aGUgcmV0dXJuZWQgcm91dGVyIHRvIGBSb3V0ZXJQcm92aWRlcmAgdG8gZW5hYmxlIHJvdXRpbmcuXG4qIE5vdGFibGUgb3B0aW9uczogYHJvdXRlVHJlZWAgKHlvdXIgcm91dGUgZGVmaW5pdGlvbnMpIGFuZCBgY29udGV4dGBcbiogKHJlcXVpcmVkIGlmIHRoZSByb290IHJvdXRlIHdhcyBjcmVhdGVkIHdpdGggYGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0YCkuXG4qXG4qIEBwYXJhbSBvcHRpb25zIFJvdXRlciBvcHRpb25zIHVzZWQgdG8gY29uZmlndXJlIHRoZSByb3V0ZXIuXG4qIEByZXR1cm5zIEEgUm91dGVyIGluc3RhbmNlIHRvIGJlIHByb3ZpZGVkIHRvIGBSb3V0ZXJQcm92aWRlcmAuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVSb3V0ZXJGdW5jdGlvblxuKi9cbnZhciBjcmVhdGVSb3V0ZXIgPSAob3B0aW9ucykgPT4ge1xuXHRyZXR1cm4gbmV3IFJvdXRlcihvcHRpb25zKTtcbn07XG52YXIgUm91dGVyID0gY2xhc3MgZXh0ZW5kcyBSb3V0ZXJDb3JlIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKG9wdGlvbnMsIGdldFN0b3JlRmFjdG9yeSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFJvdXRlciwgY3JlYXRlUm91dGVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHJvdXRlckNvbnRleHQgfSBmcm9tIFwiLi9yb3V0ZXJDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyBNYXRjaGVzIH0gZnJvbSBcIi4vTWF0Y2hlcy5qc1wiO1xuaW1wb3J0IHsgaGFzS2V5cyB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvUm91dGVyUHJvdmlkZXIudHN4XG4vKipcbiogTG93LWxldmVsIHByb3ZpZGVyIHRoYXQgcGxhY2VzIHRoZSByb3V0ZXIgaW50byBSZWFjdCBjb250ZXh0IGFuZCBvcHRpb25hbGx5XG4qIHVwZGF0ZXMgcm91dGVyIG9wdGlvbnMgZnJvbSBwcm9wcy4gTW9zdCBhcHBzIHNob3VsZCB1c2UgYFJvdXRlclByb3ZpZGVyYC5cbiovXG5mdW5jdGlvbiBSb3V0ZXJDb250ZXh0UHJvdmlkZXIoeyByb3V0ZXIsIGNoaWxkcmVuLCAuLi5yZXN0IH0pIHtcblx0aWYgKGhhc0tleXMocmVzdCkpIHJvdXRlci51cGRhdGUoe1xuXHRcdC4uLnJvdXRlci5vcHRpb25zLFxuXHRcdC4uLnJlc3QsXG5cdFx0Y29udGV4dDoge1xuXHRcdFx0Li4ucm91dGVyLm9wdGlvbnMuY29udGV4dCxcblx0XHRcdC4uLnJlc3QuY29udGV4dFxuXHRcdH1cblx0fSk7XG5cdGNvbnN0IHByb3ZpZGVyID0gLyogQF9fUFVSRV9fICovIGpzeChyb3V0ZXJDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IHJvdXRlcixcblx0XHRjaGlsZHJlblxuXHR9KTtcblx0aWYgKHJvdXRlci5vcHRpb25zLldyYXApIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KHJvdXRlci5vcHRpb25zLldyYXAsIHsgY2hpbGRyZW46IHByb3ZpZGVyIH0pO1xuXHRyZXR1cm4gcHJvdmlkZXI7XG59XG4vKipcbiogUmVuZGVycyB0aGUgY3VycmVudCBtYXRjaCBwcmVzZW50YXRpb24gYW5kIHByb3ZpZGVzIHRoZSByb3V0ZXIgdG8gdGhlIFJlYWN0XG4qIHRyZWUgdmlhIGNvbnRleHQuXG4qXG4qIEFjY2VwdHMgbXV0YWJsZSByb3V0ZXIgb3B0aW9ucyB2aWEgcHJvcHMuIENvbmZpZ3VyZSBpbml0aWFsaXphdGlvbi1vbmx5XG4qIG9wdGlvbnMgd2l0aCBgY3JlYXRlUm91dGVyYC5cbipcbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZVJvdXRlckZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gUm91dGVyUHJvdmlkZXIoeyByb3V0ZXIsIC4uLnJlc3QgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChSb3V0ZXJDb250ZXh0UHJvdmlkZXIsIHtcblx0XHRyb3V0ZXIsXG5cdFx0Li4ucmVzdCxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChNYXRjaGVzLCB7fSlcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFJvdXRlckNvbnRleHRQcm92aWRlciwgUm91dGVyUHJvdmlkZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Um91dGVyUHJvdmlkZXIuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBnZXRFbGVtZW50U2Nyb2xsUmVzdG9yYXRpb25FbnRyeSwgc2V0dXBTY3JvbGxSZXN0b3JhdGlvbiB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvU2Nyb2xsUmVzdG9yYXRpb24udHN4XG5mdW5jdGlvbiB1c2VTY3JvbGxSZXN0b3JhdGlvbigpIHtcblx0c2V0dXBTY3JvbGxSZXN0b3JhdGlvbih1c2VSb3V0ZXIoKSwgdHJ1ZSk7XG59XG4vKipcbiogQGRlcHJlY2F0ZWQgVXNlIHRoZSBgc2Nyb2xsUmVzdG9yYXRpb25gIHJvdXRlciBvcHRpb24gaW5zdGVhZC5cbiovXG5mdW5jdGlvbiBTY3JvbGxSZXN0b3JhdGlvbihfcHJvcHMpIHtcblx0dXNlU2Nyb2xsUmVzdG9yYXRpb24oKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcImRldmVsb3BtZW50XCIpIGNvbnNvbGUud2FybihcIlRoZSBTY3JvbGxSZXN0b3JhdGlvbiBjb21wb25lbnQgaXMgZGVwcmVjYXRlZC4gVXNlIGNyZWF0ZVJvdXRlcidzIGBzY3JvbGxSZXN0b3JhdGlvbmAgb3B0aW9uIGluc3RlYWQuXCIpO1xuXHRyZXR1cm4gbnVsbDtcbn1cbmZ1bmN0aW9uIHVzZUVsZW1lbnRTY3JvbGxSZXN0b3JhdGlvbihvcHRpb25zKSB7XG5cdHVzZVNjcm9sbFJlc3RvcmF0aW9uKCk7XG5cdHJldHVybiBnZXRFbGVtZW50U2Nyb2xsUmVzdG9yYXRpb25FbnRyeSh1c2VSb3V0ZXIoKSwgb3B0aW9ucyk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFNjcm9sbFJlc3RvcmF0aW9uLCB1c2VFbGVtZW50U2Nyb2xsUmVzdG9yYXRpb24gfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U2Nyb2xsUmVzdG9yYXRpb24uanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL3VzZUJsb2NrZXIudHN4XG5mdW5jdGlvbiBfcmVzb2x2ZUJsb2NrZXJPcHRzKG9wdHMsIGNvbmRpdGlvbikge1xuXHRpZiAob3B0cyA9PT0gdm9pZCAwKSByZXR1cm4ge1xuXHRcdHNob3VsZEJsb2NrRm46ICgpID0+IHRydWUsXG5cdFx0d2l0aFJlc29sdmVyOiBmYWxzZVxuXHR9O1xuXHRpZiAoXCJzaG91bGRCbG9ja0ZuXCIgaW4gb3B0cykgcmV0dXJuIG9wdHM7XG5cdGlmICh0eXBlb2Ygb3B0cyA9PT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0Y29uc3Qgc2hvdWxkQmxvY2sgPSBCb29sZWFuKGNvbmRpdGlvbiA/PyB0cnVlKTtcblx0XHRjb25zdCBfY3VzdG9tQmxvY2tlckZuID0gYXN5bmMgKCkgPT4ge1xuXHRcdFx0aWYgKHNob3VsZEJsb2NrKSByZXR1cm4gYXdhaXQgb3B0cygpO1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH07XG5cdFx0cmV0dXJuIHtcblx0XHRcdHNob3VsZEJsb2NrRm46IF9jdXN0b21CbG9ja2VyRm4sXG5cdFx0XHRlbmFibGVCZWZvcmVVbmxvYWQ6IHNob3VsZEJsb2NrLFxuXHRcdFx0d2l0aFJlc29sdmVyOiBmYWxzZVxuXHRcdH07XG5cdH1cblx0Y29uc3Qgc2hvdWxkQmxvY2sgPSBCb29sZWFuKG9wdHMuY29uZGl0aW9uID8/IHRydWUpO1xuXHRjb25zdCBmbiA9IG9wdHMuYmxvY2tlckZuO1xuXHRjb25zdCBfY3VzdG9tQmxvY2tlckZuID0gYXN5bmMgKCkgPT4ge1xuXHRcdGlmIChzaG91bGRCbG9jayAmJiBmbiAhPT0gdm9pZCAwKSByZXR1cm4gYXdhaXQgZm4oKTtcblx0XHRyZXR1cm4gc2hvdWxkQmxvY2s7XG5cdH07XG5cdHJldHVybiB7XG5cdFx0c2hvdWxkQmxvY2tGbjogX2N1c3RvbUJsb2NrZXJGbixcblx0XHRlbmFibGVCZWZvcmVVbmxvYWQ6IHNob3VsZEJsb2NrLFxuXHRcdHdpdGhSZXNvbHZlcjogZm4gPT09IHZvaWQgMFxuXHR9O1xufVxuZnVuY3Rpb24gdXNlQmxvY2tlcihvcHRzLCBjb25kaXRpb24pIHtcblx0Y29uc3QgeyBzaG91bGRCbG9ja0ZuLCBlbmFibGVCZWZvcmVVbmxvYWQgPSB0cnVlLCBkaXNhYmxlZCA9IGZhbHNlLCB3aXRoUmVzb2x2ZXIgPSBmYWxzZSB9ID0gX3Jlc29sdmVCbG9ja2VyT3B0cyhvcHRzLCBjb25kaXRpb24pO1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3QgeyBoaXN0b3J5IH0gPSByb3V0ZXI7XG5cdGNvbnN0IFtyZXNvbHZlciwgc2V0UmVzb2x2ZXJdID0gUmVhY3QkMS51c2VTdGF0ZSh7XG5cdFx0c3RhdHVzOiBcImlkbGVcIixcblx0XHRjdXJyZW50OiB2b2lkIDAsXG5cdFx0bmV4dDogdm9pZCAwLFxuXHRcdGFjdGlvbjogdm9pZCAwLFxuXHRcdHByb2NlZWQ6IHZvaWQgMCxcblx0XHRyZXNldDogdm9pZCAwXG5cdH0pO1xuXHRSZWFjdCQxLnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0Y29uc3QgYmxvY2tlckZuQ29tcG9zZWQgPSBhc3luYyAoYmxvY2tlckZuQXJncykgPT4ge1xuXHRcdFx0ZnVuY3Rpb24gZ2V0TG9jYXRpb24obG9jYXRpb24pIHtcblx0XHRcdFx0Y29uc3QgcGFyc2VkTG9jYXRpb24gPSByb3V0ZXIucGFyc2VMb2NhdGlvbihsb2NhdGlvbik7XG5cdFx0XHRcdGNvbnN0IFssIHJhd1BhcmFtcywgZm91bmRSb3V0ZV0gPSByb3V0ZXIuZ2V0TWF0Y2hlZFJvdXRlcyhwYXJzZWRMb2NhdGlvbi5wYXRobmFtZSk7XG5cdFx0XHRcdGlmIChmb3VuZFJvdXRlID09PSB2b2lkIDApIHJldHVybiB7XG5cdFx0XHRcdFx0cm91dGVJZDogXCJfX25vdEZvdW5kX19cIixcblx0XHRcdFx0XHRmdWxsUGF0aDogcGFyc2VkTG9jYXRpb24ucGF0aG5hbWUsXG5cdFx0XHRcdFx0cGF0aG5hbWU6IHBhcnNlZExvY2F0aW9uLnBhdGhuYW1lLFxuXHRcdFx0XHRcdHBhcmFtczogcmF3UGFyYW1zLFxuXHRcdFx0XHRcdHNlYXJjaDogcm91dGVyLm9wdGlvbnMucGFyc2VTZWFyY2gobG9jYXRpb24uc2VhcmNoKVxuXHRcdFx0XHR9O1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdHJvdXRlSWQ6IGZvdW5kUm91dGUuaWQsXG5cdFx0XHRcdFx0ZnVsbFBhdGg6IGZvdW5kUm91dGUuZnVsbFBhdGgsXG5cdFx0XHRcdFx0cGF0aG5hbWU6IHBhcnNlZExvY2F0aW9uLnBhdGhuYW1lLFxuXHRcdFx0XHRcdHBhcmFtczogcmF3UGFyYW1zLFxuXHRcdFx0XHRcdHNlYXJjaDogcm91dGVyLm9wdGlvbnMucGFyc2VTZWFyY2gobG9jYXRpb24uc2VhcmNoKVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgY3VycmVudCA9IGdldExvY2F0aW9uKGJsb2NrZXJGbkFyZ3MuY3VycmVudExvY2F0aW9uKTtcblx0XHRcdGNvbnN0IG5leHQgPSBnZXRMb2NhdGlvbihibG9ja2VyRm5BcmdzLm5leHRMb2NhdGlvbik7XG5cdFx0XHRpZiAoY3VycmVudC5yb3V0ZUlkID09PSBcIl9fbm90Rm91bmRfX1wiICYmIG5leHQucm91dGVJZCAhPT0gXCJfX25vdEZvdW5kX19cIikgcmV0dXJuIGZhbHNlO1xuXHRcdFx0Y29uc3Qgc2hvdWxkQmxvY2sgPSBhd2FpdCBzaG91bGRCbG9ja0ZuKHtcblx0XHRcdFx0YWN0aW9uOiBibG9ja2VyRm5BcmdzLmFjdGlvbixcblx0XHRcdFx0Y3VycmVudCxcblx0XHRcdFx0bmV4dFxuXHRcdFx0fSk7XG5cdFx0XHRpZiAoIXdpdGhSZXNvbHZlcikgcmV0dXJuIHNob3VsZEJsb2NrO1xuXHRcdFx0aWYgKCFzaG91bGRCbG9jaykgcmV0dXJuIGZhbHNlO1xuXHRcdFx0Y29uc3QgY2FuTmF2aWdhdGVBc3luYyA9IGF3YWl0IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRcdHNldFJlc29sdmVyKHtcblx0XHRcdFx0XHRzdGF0dXM6IFwiYmxvY2tlZFwiLFxuXHRcdFx0XHRcdGN1cnJlbnQsXG5cdFx0XHRcdFx0bmV4dCxcblx0XHRcdFx0XHRhY3Rpb246IGJsb2NrZXJGbkFyZ3MuYWN0aW9uLFxuXHRcdFx0XHRcdHByb2NlZWQ6ICgpID0+IHJlc29sdmUoZmFsc2UpLFxuXHRcdFx0XHRcdHJlc2V0OiAoKSA9PiByZXNvbHZlKHRydWUpXG5cdFx0XHRcdH0pO1xuXHRcdFx0fSk7XG5cdFx0XHRzZXRSZXNvbHZlcih7XG5cdFx0XHRcdHN0YXR1czogXCJpZGxlXCIsXG5cdFx0XHRcdGN1cnJlbnQ6IHZvaWQgMCxcblx0XHRcdFx0bmV4dDogdm9pZCAwLFxuXHRcdFx0XHRhY3Rpb246IHZvaWQgMCxcblx0XHRcdFx0cHJvY2VlZDogdm9pZCAwLFxuXHRcdFx0XHRyZXNldDogdm9pZCAwXG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBjYW5OYXZpZ2F0ZUFzeW5jO1xuXHRcdH07XG5cdFx0cmV0dXJuIGRpc2FibGVkID8gdm9pZCAwIDogaGlzdG9yeS5ibG9jayh7XG5cdFx0XHRibG9ja2VyRm46IGJsb2NrZXJGbkNvbXBvc2VkLFxuXHRcdFx0ZW5hYmxlQmVmb3JlVW5sb2FkXG5cdFx0fSk7XG5cdH0sIFtcblx0XHRzaG91bGRCbG9ja0ZuLFxuXHRcdGVuYWJsZUJlZm9yZVVubG9hZCxcblx0XHRkaXNhYmxlZCxcblx0XHR3aXRoUmVzb2x2ZXIsXG5cdFx0aGlzdG9yeSxcblx0XHRyb3V0ZXJcblx0XSk7XG5cdHJldHVybiByZXNvbHZlcjtcbn1cbnZhciBfcmVzb2x2ZVByb21wdEJsb2NrZXJBcmdzID0gKHByb3BzKSA9PiB7XG5cdGlmIChcInNob3VsZEJsb2NrRm5cIiBpbiBwcm9wcykgcmV0dXJuIHsgLi4ucHJvcHMgfTtcblx0Y29uc3Qgc2hvdWxkQmxvY2sgPSBCb29sZWFuKHByb3BzLmNvbmRpdGlvbiA/PyB0cnVlKTtcblx0Y29uc3QgZm4gPSBwcm9wcy5ibG9ja2VyRm47XG5cdGNvbnN0IF9jdXN0b21CbG9ja2VyRm4gPSBhc3luYyAoKSA9PiB7XG5cdFx0aWYgKHNob3VsZEJsb2NrICYmIGZuICE9PSB2b2lkIDApIHJldHVybiBhd2FpdCBmbigpO1xuXHRcdHJldHVybiBzaG91bGRCbG9jaztcblx0fTtcblx0cmV0dXJuIHtcblx0XHRzaG91bGRCbG9ja0ZuOiBfY3VzdG9tQmxvY2tlckZuLFxuXHRcdGVuYWJsZUJlZm9yZVVubG9hZDogc2hvdWxkQmxvY2ssXG5cdFx0d2l0aFJlc29sdmVyOiBmbiA9PT0gdm9pZCAwXG5cdH07XG59O1xuZnVuY3Rpb24gQmxvY2sob3B0cykge1xuXHRjb25zdCB7IGNoaWxkcmVuLCAuLi5yZXN0IH0gPSBvcHRzO1xuXHRjb25zdCByZXNvbHZlciA9IHVzZUJsb2NrZXIoX3Jlc29sdmVQcm9tcHRCbG9ja2VyQXJncyhyZXN0KSk7XG5cdHJldHVybiBjaGlsZHJlbiA/IHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiID8gY2hpbGRyZW4ocmVzb2x2ZXIpIDogY2hpbGRyZW4gOiBudWxsO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBCbG9jaywgdXNlQmxvY2tlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VCbG9ja2VyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VTdHJ1Y3R1cmFsU2hhcmluZyB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VSb3V0ZXJTdGF0ZS50c3hcbi8qKlxuKiBTdWJzY3JpYmUgdG8gdGhlIHJvdXRlcidzIHN0YXRlIHN0b3JlIHdpdGggb3B0aW9uYWwgc2VsZWN0aW9uIGFuZFxuKiBzdHJ1Y3R1cmFsIHNoYXJpbmcgZm9yIHJlbmRlciBvcHRpbWl6YXRpb24uXG4qXG4qIE9wdGlvbnM6XG4qIC0gYHNlbGVjdGA6IFByb2plY3QgdGhlIGZ1bGwgcm91dGVyIHN0YXRlIHRvIGEgZGVyaXZlZCBzbGljZVxuKiAtIGBzdHJ1Y3R1cmFsU2hhcmluZ2A6IFJlcGxhY2UtZXF1YWwgc2VtYW50aWNzIGZvciBzdGFibGUgcmVmZXJlbmNlc1xuKiAtIGByb3V0ZXJgOiBSZWFkIHN0YXRlIGZyb20gYSBzcGVjaWZpYyByb3V0ZXIgaW5zdGFuY2UgaW5zdGVhZCBvZiBjb250ZXh0XG4qXG4qIEByZXR1cm5zIFRoZSBzZWxlY3RlZCByb3V0ZXIgc3RhdGUgKG9yIHRoZSBmdWxsIHN0YXRlIGJ5IGRlZmF1bHQpLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlUm91dGVyU3RhdGVIb29rXG4qL1xuZnVuY3Rpb24gdXNlUm91dGVyU3RhdGUob3B0cykge1xuXHRjb25zdCBjb250ZXh0Um91dGVyID0gdXNlUm91dGVyKHsgd2Fybjogb3B0cz8ucm91dGVyID09PSB2b2lkIDAgfSk7XG5cdGNvbnN0IHJvdXRlciA9IG9wdHM/LnJvdXRlciB8fCBjb250ZXh0Um91dGVyO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0Y29uc3Qgc3RhdGUgPSByb3V0ZXIuc3RvcmVzLl9fc3RvcmUuZ2V0KCk7XG5cdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KHN0YXRlKSA6IHN0YXRlO1xuXHR9XG5cdHJldHVybiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLl9fc3RvcmUsIHVzZVN0cnVjdHVyYWxTaGFyaW5nKG9wdHMsIHJvdXRlcikpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VSb3V0ZXJTdGF0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VSb3V0ZXJTdGF0ZS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgdXNlU3RydWN0dXJhbFNoYXJpbmcgfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTG9jYXRpb24udHN4XG4vKipcbiogUmVhZCB0aGUgY3VycmVudCBsb2NhdGlvbiBmcm9tIHRoZSByb3V0ZXIgc3RhdGUgd2l0aCBvcHRpb25hbCBzZWxlY3Rpb24uXG4qIFVzZWZ1bCBmb3Igc3Vic2NyaWJpbmcgdG8ganVzdCB0aGUgcGllY2VzIG9mIGxvY2F0aW9uIHlvdSBjYXJlIGFib3V0LlxuKlxuKiBPcHRpb25zOlxuKiAtIGBzZWxlY3RgOiBQcm9qZWN0IHRoZSBgbG9jYXRpb25gIG9iamVjdCB0byBhIGRlcml2ZWQgdmFsdWVcbiogLSBgc3RydWN0dXJhbFNoYXJpbmdgOiBFbmFibGUgc3RydWN0dXJhbCBzaGFyaW5nIGZvciBzdGFibGUgcmVmZXJlbmNlc1xuKlxuKiBAcmV0dXJucyBUaGUgY3VycmVudCBsb2NhdGlvbiAob3Igc2VsZWN0ZWQgdmFsdWUpLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlTG9jYXRpb25Ib29rXG4qL1xuZnVuY3Rpb24gdXNlTG9jYXRpb24ob3B0cykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGNvbnN0IGxvY2F0aW9uID0gcm91dGVyLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKTtcblx0XHRyZXR1cm4gb3B0cz8uc2VsZWN0ID8gb3B0cy5zZWxlY3QobG9jYXRpb24pIDogbG9jYXRpb247XG5cdH1cblx0cmV0dXJuIHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubG9jYXRpb24sIHVzZVN0cnVjdHVyYWxTaGFyaW5nKG9wdHMsIHJvdXRlcikpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VMb2NhdGlvbiB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VMb2NhdGlvbi5qcy5tYXAiLCJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZUNhbkdvQmFjay50c1xuZnVuY3Rpb24gdXNlQ2FuR29CYWNrKCkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgcmV0dXJuIHJvdXRlci5zdG9yZXMubG9jYXRpb24uZ2V0KCkuc3RhdGUuX19UU1JfaW5kZXggIT09IDA7XG5cdHJldHVybiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLCAobG9jYXRpb24pID0+IGxvY2F0aW9uLnN0YXRlLl9fVFNSX2luZGV4ICE9PSAwKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlQ2FuR29CYWNrIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUNhbkdvQmFjay5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUh5ZHJhdGVkIH0gZnJvbSBcIi4vQ2xpZW50T25seS5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvQXNzZXQudHN4XG52YXIgSU5MSU5FX0NTU19IWURSQVRJT05fQVRUUiA9IFwiZGF0YS10c3ItaW5saW5lLWNzc1wiO1xudmFyIG5vb3BTY3JpcHRIYW5kbGVyID0gKCkgPT4ge307XG5mdW5jdGlvbiBzZXRTY3JpcHRBdHRycyhzY3JpcHQsIGF0dHJzKSB7XG5cdGlmICghYXR0cnMpIHJldHVybjtcblx0Zm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoYXR0cnMpKSBpZiAoa2V5ICE9PSBcInN1cHByZXNzSHlkcmF0aW9uV2FybmluZ1wiICYmIHZhbHVlICE9PSB2b2lkIDAgJiYgdmFsdWUgIT09IGZhbHNlKSBzY3JpcHQuc2V0QXR0cmlidXRlKGtleSwgdHlwZW9mIHZhbHVlID09PSBcImJvb2xlYW5cIiA/IFwiXCIgOiBTdHJpbmcodmFsdWUpKTtcbn1cbmZ1bmN0aW9uIEFzc2V0KGFzc2V0KSB7XG5cdGNvbnN0IHsgYXR0cnMsIGNoaWxkcmVuLCBub25jZSwgcHJldmVudFNjcmlwdEhvaXN0IH0gPSBhc3NldDtcblx0Y29uc3QgaW5uZXJIVE1MID0gUmVhY3QkMS51c2VNZW1vKCgpID0+IGNoaWxkcmVuID09PSB2b2lkIDAgPyB2b2lkIDAgOiB7IF9faHRtbDogY2hpbGRyZW4gfSwgW2NoaWxkcmVuXSk7XG5cdHN3aXRjaCAoYXNzZXQudGFnKSB7XG5cdFx0Y2FzZSBcInRpdGxlXCI6IHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwidGl0bGVcIiwge1xuXHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUsXG5cdFx0XHRjaGlsZHJlblxuXHRcdH0pO1xuXHRcdGNhc2UgXCJtZXRhXCI6IHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwibWV0YVwiLCB7XG5cdFx0XHQuLi5hdHRycyxcblx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHRcdH0pO1xuXHRcdGNhc2UgXCJsaW5rXCI6IHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwibGlua1wiLCB7XG5cdFx0XHQuLi5hdHRycyxcblx0XHRcdHByZWNlZGVuY2U6IGF0dHJzPy5wcmVjZWRlbmNlID8/IChhdHRycz8ucmVsID09PSBcInN0eWxlc2hlZXRcIiA/IFwiZGVmYXVsdFwiIDogdm9pZCAwKSxcblx0XHRcdG5vbmNlLFxuXHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdFx0fSk7XG5cdFx0Y2FzZSBcInN0eWxlXCI6XG5cdFx0XHRpZiAoYXNzZXQuaW5saW5lQ3NzICYmIChwcm9jZXNzLmVudi5UU1NfSU5MSU5FX0NTU19FTkFCTEVEID09PSBcInRydWVcIiB8fCBwcm9jZXNzLmVudi5UU1NfSU5MSU5FX0NTU19FTkFCTEVEID09PSB2b2lkIDAgJiYgaXNTZXJ2ZXIpKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChJbmxpbmVDc3NTdHlsZSwge1xuXHRcdFx0XHRhdHRycyxcblx0XHRcdFx0bm9uY2UsXG5cdFx0XHRcdGNoaWxkcmVuXG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic3R5bGVcIiwge1xuXHRcdFx0XHQuLi5hdHRycyxcblx0XHRcdFx0ZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6IGlubmVySFRNTCxcblx0XHRcdFx0bm9uY2Vcblx0XHRcdH0pO1xuXHRcdGNhc2UgXCJzY3JpcHRcIjogcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goU2NyaXB0LCB7XG5cdFx0XHRhdHRycyxcblx0XHRcdHByZXZlbnRTY3JpcHRIb2lzdCxcblx0XHRcdGNoaWxkcmVuXG5cdFx0fSk7XG5cdFx0ZGVmYXVsdDogcmV0dXJuIG51bGw7XG5cdH1cbn1cbmZ1bmN0aW9uIElubGluZUNzc1N0eWxlKHsgYXR0cnMsIGNoaWxkcmVuLCBub25jZSB9KSB7XG5cdGNvbnN0IGlzSW5saW5lQ3NzUGxhY2Vob2xkZXIgPSBjaGlsZHJlbiA9PT0gdm9pZCAwO1xuXHRjb25zdCBbaHlkcmF0ZWRJbmxpbmVDc3NdID0gUmVhY3QkMS51c2VTdGF0ZSgoKSA9PiB7XG5cdFx0aWYgKCFpc0lubGluZUNzc1BsYWNlaG9sZGVyIHx8IHR5cGVvZiBkb2N1bWVudCA9PT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuO1xuXHRcdHJldHVybiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGBzdHlsZVske0lOTElORV9DU1NfSFlEUkFUSU9OX0FUVFJ9XWApPy50ZXh0Q29udGVudCA/PyB2b2lkIDA7XG5cdH0pO1xuXHRjb25zdCBodG1sID0gaXNJbmxpbmVDc3NQbGFjZWhvbGRlciA/IGh5ZHJhdGVkSW5saW5lQ3NzID8/IFwiXCIgOiBjaGlsZHJlbiA/PyBcIlwiO1xuXHRjb25zdCBpbm5lckhUTUwgPSBSZWFjdCQxLnVzZU1lbW8oKCkgPT4gKHsgX19odG1sOiBodG1sIH0pLCBbaHRtbF0pO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInN0eWxlXCIsIHtcblx0XHQuLi5hdHRycyxcblx0XHRbSU5MSU5FX0NTU19IWURSQVRJT05fQVRUUl06IFwiXCIsXG5cdFx0ZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6IGlubmVySFRNTCxcblx0XHRub25jZSxcblx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0fSk7XG59XG5mdW5jdGlvbiBTY3JpcHQoeyBhdHRycywgY2hpbGRyZW4sIHByZXZlbnRTY3JpcHRIb2lzdCB9KSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBoeWRyYXRlZCA9IHVzZUh5ZHJhdGVkKCk7XG5cdGNvbnN0IGlubmVySFRNTCA9IFJlYWN0JDEudXNlTWVtbygoKSA9PiBjaGlsZHJlbiA9PT0gdm9pZCAwID8gdm9pZCAwIDogeyBfX2h0bWw6IGNoaWxkcmVuIH0sIFtjaGlsZHJlbl0pO1xuXHRjb25zdCBkYXRhU2NyaXB0ID0gdHlwZW9mIGF0dHJzPy50eXBlID09PSBcInN0cmluZ1wiICYmIGF0dHJzLnR5cGUgIT09IFwiXCIgJiYgYXR0cnMudHlwZSAhPT0gXCJ0ZXh0L2phdmFzY3JpcHRcIiAmJiBhdHRycy50eXBlICE9PSBcIm1vZHVsZVwiO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGF0dHJzPy5zcmMgJiYgdHlwZW9mIGNoaWxkcmVuID09PSBcInN0cmluZ1wiICYmIGNoaWxkcmVuLnRyaW0oKS5sZW5ndGgpIGNvbnNvbGUud2FybihcIltUYW5TdGFjayBSb3V0ZXJdIDxTY3JpcHQ+IHJlY2VpdmVkIGJvdGggYHNyY2AgYW5kIGBjaGlsZHJlbmAuIFRoZSBgY2hpbGRyZW5gIGNvbnRlbnQgd2lsbCBiZSBpZ25vcmVkLiBSZW1vdmUgYGNoaWxkcmVuYCBvciByZW1vdmUgYHNyY2AuXCIpO1xuXHRSZWFjdCQxLnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKGRhdGFTY3JpcHQpIHJldHVybjtcblx0XHRpZiAoYXR0cnM/LnNyYykge1xuXHRcdFx0Y29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJhXCIpO1xuXHRcdFx0bGluay5ocmVmID0gYXR0cnMuc3JjO1xuXHRcdFx0Y29uc3Qgbm9ybVNyYyA9IGxpbmsuaHJlZjtcblx0XHRcdGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQuc2NyaXB0cykgaWYgKGVsLnNyYyA9PT0gbm9ybVNyYykgcmV0dXJuO1xuXHRcdFx0Y29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKTtcblx0XHRcdHNldFNjcmlwdEF0dHJzKHNjcmlwdCwgYXR0cnMpO1xuXHRcdFx0ZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzY3JpcHQpO1xuXHRcdFx0cmV0dXJuICgpID0+IHNjcmlwdC5yZW1vdmUoKTtcblx0XHR9XG5cdFx0aWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0Y29uc3QgdHlwZUF0dHIgPSB0eXBlb2YgYXR0cnM/LnR5cGUgPT09IFwic3RyaW5nXCIgPyBhdHRycy50eXBlIDogXCJ0ZXh0L2phdmFzY3JpcHRcIjtcblx0XHRcdGNvbnN0IG5vbmNlQXR0ciA9IHR5cGVvZiBhdHRycz8ubm9uY2UgPT09IFwic3RyaW5nXCIgPyBhdHRycy5ub25jZSA6IHZvaWQgMDtcblx0XHRcdGZvciAoY29uc3QgZWwgb2YgZG9jdW1lbnQuc2NyaXB0cykge1xuXHRcdFx0XHRpZiAoZWwuaGFzQXR0cmlidXRlKFwic3JjXCIpKSBjb250aW51ZTtcblx0XHRcdFx0Y29uc3Qgc1R5cGUgPSBlbC5nZXRBdHRyaWJ1dGUoXCJ0eXBlXCIpID8/IFwidGV4dC9qYXZhc2NyaXB0XCI7XG5cdFx0XHRcdGNvbnN0IHNOb25jZSA9IGVsLmdldEF0dHJpYnV0ZShcIm5vbmNlXCIpID8/IHZvaWQgMDtcblx0XHRcdFx0aWYgKGVsLnRleHRDb250ZW50ID09PSBjaGlsZHJlbiAmJiBzVHlwZSA9PT0gdHlwZUF0dHIgJiYgc05vbmNlID09PSBub25jZUF0dHIpIHJldHVybjtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIik7XG5cdFx0XHRzY3JpcHQudGV4dENvbnRlbnQgPSBjaGlsZHJlbjtcblx0XHRcdHNldFNjcmlwdEF0dHJzKHNjcmlwdCwgYXR0cnMpO1xuXHRcdFx0ZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzY3JpcHQpO1xuXHRcdFx0cmV0dXJuICgpID0+IHNjcmlwdC5yZW1vdmUoKTtcblx0XHR9XG5cdH0sIFtcblx0XHRhdHRycyxcblx0XHRjaGlsZHJlbixcblx0XHRkYXRhU2NyaXB0XG5cdF0pO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0aWYgKGF0dHJzPy5zcmMpIHtcblx0XHRcdGlmICghcHJldmVudFNjcmlwdEhvaXN0KSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInNjcmlwdFwiLCB7XG5cdFx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzY3JpcHRcIiwge1xuXHRcdFx0XHQuLi5hdHRycyxcblx0XHRcdFx0b25Mb2FkOiBub29wU2NyaXB0SGFuZGxlcixcblx0XHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0aWYgKHR5cGVvZiBjaGlsZHJlbiA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzY3JpcHRcIiwge1xuXHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRkYW5nZXJvdXNseVNldElubmVySFRNTDogaW5uZXJIVE1MLFxuXHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdFx0fSk7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cblx0aWYgKGRhdGFTY3JpcHQgJiYgdHlwZW9mIGNoaWxkcmVuID09PSBcInN0cmluZ1wiKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInNjcmlwdFwiLCB7XG5cdFx0Li4uYXR0cnMsXG5cdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlLFxuXHRcdGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOiBpbm5lckhUTUxcblx0fSk7XG5cdGlmICghaHlkcmF0ZWQpIHtcblx0XHRpZiAoYXR0cnM/LnNyYykgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzY3JpcHRcIiwge1xuXHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0XHR9KTtcblx0XHRpZiAodHlwZW9mIGNoaWxkcmVuID09PSBcInN0cmluZ1wiKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInNjcmlwdFwiLCB7XG5cdFx0XHQuLi5hdHRycyxcblx0XHRcdGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOiBpbm5lckhUTUwsXG5cdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQXNzZXQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9QXNzZXQuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBfZ2V0QXNzZXRNYXRjaGVzLCBhcHBlbmRVbmlxdWVVc2VyVGFncywgZGVlcEVxdWFsLCBlc2NhcGVIdG1sLCBnZXRBc3NldENyb3NzT3JpZ2luLCBnZXRTY3JpcHRQcmVsb2FkQXR0cnMsIHJlc29sdmVNYW5pZmVzdENzc0xpbmsgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvaGVhZENvbnRlbnRVdGlscy50c3hcbmZ1bmN0aW9uIGJ1aWxkVGFnc0Zyb21NYXRjaGVzKHJvdXRlciwgbm9uY2UsIG1hdGNoZXMsIGFzc2V0Q3Jvc3NPcmlnaW4pIHtcblx0bWF0Y2hlcyA9IF9nZXRBc3NldE1hdGNoZXMobWF0Y2hlcyk7XG5cdGNvbnN0IHJvdXRlTWV0YSA9IG1hdGNoZXMubWFwKChtYXRjaCkgPT4gbWF0Y2gubWV0YSkuZmlsdGVyKChtZXRhKSA9PiBtZXRhICE9PSB2b2lkIDApO1xuXHRjb25zdCByZXN1bHRNZXRhID0gW107XG5cdGNvbnN0IG1ldGFCeUF0dHJpYnV0ZSA9IHt9O1xuXHRsZXQgdGl0bGU7XG5cdGZvciAobGV0IGkgPSByb3V0ZU1ldGEubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRjb25zdCBtZXRhcyA9IHJvdXRlTWV0YVtpXTtcblx0XHRmb3IgKGxldCBqID0gbWV0YXMubGVuZ3RoIC0gMTsgaiA+PSAwOyBqLS0pIHtcblx0XHRcdGNvbnN0IG0gPSBtZXRhc1tqXTtcblx0XHRcdGlmICghbSkgY29udGludWU7XG5cdFx0XHRpZiAobS50aXRsZSkge1xuXHRcdFx0XHRpZiAoIXRpdGxlKSB0aXRsZSA9IHtcblx0XHRcdFx0XHR0YWc6IFwidGl0bGVcIixcblx0XHRcdFx0XHRjaGlsZHJlbjogbS50aXRsZVxuXHRcdFx0XHR9O1xuXHRcdFx0fSBlbHNlIGlmIChcInNjcmlwdDpsZCtqc29uXCIgaW4gbSkgdHJ5IHtcblx0XHRcdFx0Y29uc3QganNvbiA9IEpTT04uc3RyaW5naWZ5KG1bXCJzY3JpcHQ6bGQranNvblwiXSk7XG5cdFx0XHRcdHJlc3VsdE1ldGEucHVzaCh7XG5cdFx0XHRcdFx0dGFnOiBcInNjcmlwdFwiLFxuXHRcdFx0XHRcdGF0dHJzOiB7IHR5cGU6IFwiYXBwbGljYXRpb24vbGQranNvblwiIH0sXG5cdFx0XHRcdFx0Y2hpbGRyZW46IGVzY2FwZUh0bWwoanNvbilcblx0XHRcdFx0fSk7XG5cdFx0XHR9IGNhdGNoIHt9XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0Y29uc3QgYXR0cmlidXRlID0gbS5uYW1lID8/IG0ucHJvcGVydHk7XG5cdFx0XHRcdGlmIChhdHRyaWJ1dGUpIGlmIChtZXRhQnlBdHRyaWJ1dGVbYXR0cmlidXRlXSkgY29udGludWU7XG5cdFx0XHRcdGVsc2UgbWV0YUJ5QXR0cmlidXRlW2F0dHJpYnV0ZV0gPSB0cnVlO1xuXHRcdFx0XHRyZXN1bHRNZXRhLnB1c2goe1xuXHRcdFx0XHRcdHRhZzogXCJtZXRhXCIsXG5cdFx0XHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0XHRcdC4uLm0sXG5cdFx0XHRcdFx0XHRub25jZVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGlmICh0aXRsZSkgcmVzdWx0TWV0YS5wdXNoKHRpdGxlKTtcblx0aWYgKG5vbmNlKSByZXN1bHRNZXRhLnB1c2goe1xuXHRcdHRhZzogXCJtZXRhXCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdHByb3BlcnR5OiBcImNzcC1ub25jZVwiLFxuXHRcdFx0Y29udGVudDogbm9uY2Vcblx0XHR9XG5cdH0pO1xuXHRyZXN1bHRNZXRhLnJldmVyc2UoKTtcblx0Y29uc3QgY29uc3RydWN0ZWRMaW5rcyA9IG1hdGNoZXMuZmxhdE1hcCgobWF0Y2gpID0+IG1hdGNoLmxpbmtzID8/IFtdKS5maWx0ZXIoKGxpbmspID0+IGxpbmsgIT09IHZvaWQgMCkubWFwKChsaW5rKSA9PiAoe1xuXHRcdHRhZzogXCJsaW5rXCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdC4uLmxpbmssXG5cdFx0XHRub25jZVxuXHRcdH1cblx0fSkpO1xuXHRjb25zdCBtYW5pZmVzdCA9IHJvdXRlci5zc3I/Lm1hbmlmZXN0O1xuXHRjb25zdCBtYW5pZmVzdENzc1RhZ3MgPSBbXTtcblx0aWYgKG1hbmlmZXN0KSB7XG5cdFx0bWF0Y2hlcy5mb3JFYWNoKChtYXRjaCkgPT4ge1xuXHRcdFx0KG1hbmlmZXN0LnJvdXRlc1ttYXRjaC5yb3V0ZUlkXT8uY3NzKT8uZm9yRWFjaCgobGluaykgPT4ge1xuXHRcdFx0XHRjb25zdCByZXNvbHZlZExpbmsgPSByZXNvbHZlTWFuaWZlc3RDc3NMaW5rKGxpbmspO1xuXHRcdFx0XHRtYW5pZmVzdENzc1RhZ3MucHVzaCh7XG5cdFx0XHRcdFx0dGFnOiBcImxpbmtcIixcblx0XHRcdFx0XHRhdHRyczoge1xuXHRcdFx0XHRcdFx0cmVsOiBcInN0eWxlc2hlZXRcIixcblx0XHRcdFx0XHRcdC4uLnJlc29sdmVkTGluayxcblx0XHRcdFx0XHRcdGNyb3NzT3JpZ2luOiBnZXRBc3NldENyb3NzT3JpZ2luKGFzc2V0Q3Jvc3NPcmlnaW4sIFwic3R5bGVzaGVldFwiKSA/PyByZXNvbHZlZExpbmsuY3Jvc3NPcmlnaW4sXG5cdFx0XHRcdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUsXG5cdFx0XHRcdFx0XHRub25jZVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRpZiAobWFuaWZlc3QuaW5saW5lU3R5bGUpIG1hbmlmZXN0Q3NzVGFncy5wdXNoKHtcblx0XHRcdHRhZzogXCJzdHlsZVwiLFxuXHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0Li4ubWFuaWZlc3QuaW5saW5lU3R5bGUuYXR0cnMsXG5cdFx0XHRcdG5vbmNlXG5cdFx0XHR9LFxuXHRcdFx0Y2hpbGRyZW46IG1hbmlmZXN0LmlubGluZVN0eWxlLmNoaWxkcmVuLFxuXHRcdFx0aW5saW5lQ3NzOiB0cnVlXG5cdFx0fSk7XG5cdH1cblx0Y29uc3QgcHJlbG9hZExpbmtzID0gW107XG5cdGlmIChtYW5pZmVzdCkgbWF0Y2hlcy5mb3JFYWNoKChtYXRjaCkgPT4ge1xuXHRcdG1hbmlmZXN0LnJvdXRlc1ttYXRjaC5yb3V0ZUlkXT8ucHJlbG9hZHM/LmZvckVhY2goKHByZWxvYWQpID0+IHtcblx0XHRcdHByZWxvYWRMaW5rcy5wdXNoKHtcblx0XHRcdFx0dGFnOiBcImxpbmtcIixcblx0XHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0XHQuLi5nZXRTY3JpcHRQcmVsb2FkQXR0cnMobWFuaWZlc3QsIHByZWxvYWQsIGFzc2V0Q3Jvc3NPcmlnaW4pLFxuXHRcdFx0XHRcdG5vbmNlXG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9KTtcblx0Y29uc3Qgc3R5bGVzID0gbWF0Y2hlcy5mbGF0TWFwKChtYXRjaCkgPT4gbWF0Y2guc3R5bGVzID8/IFtdKS5maWx0ZXIoKHN0eWxlKSA9PiBzdHlsZSAhPT0gdm9pZCAwKS5tYXAoKHsgY2hpbGRyZW4sIC4uLmF0dHJzIH0pID0+ICh7XG5cdFx0dGFnOiBcInN0eWxlXCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0bm9uY2Vcblx0XHR9LFxuXHRcdGNoaWxkcmVuXG5cdH0pKTtcblx0Y29uc3QgaGVhZFNjcmlwdHMgPSBtYXRjaGVzLmZsYXRNYXAoKG1hdGNoKSA9PiBtYXRjaC5oZWFkU2NyaXB0cyA/PyBbXSkuZmlsdGVyKChzY3JpcHQpID0+IHNjcmlwdCAhPT0gdm9pZCAwKS5tYXAoKHsgY2hpbGRyZW4sIC4uLnNjcmlwdCB9KSA9PiAoe1xuXHRcdHRhZzogXCJzY3JpcHRcIixcblx0XHRhdHRyczoge1xuXHRcdFx0Li4uc2NyaXB0LFxuXHRcdFx0bm9uY2Vcblx0XHR9LFxuXHRcdGNoaWxkcmVuXG5cdH0pKTtcblx0Y29uc3QgdGFncyA9IFtdO1xuXHRhcHBlbmRVbmlxdWVVc2VyVGFncyh0YWdzLCByZXN1bHRNZXRhKTtcblx0dGFncy5wdXNoKC4uLnByZWxvYWRMaW5rcyk7XG5cdGFwcGVuZFVuaXF1ZVVzZXJUYWdzKHRhZ3MsIGNvbnN0cnVjdGVkTGlua3MpO1xuXHR0YWdzLnB1c2goLi4ubWFuaWZlc3RDc3NUYWdzKTtcblx0YXBwZW5kVW5pcXVlVXNlclRhZ3ModGFncywgc3R5bGVzKTtcblx0YXBwZW5kVW5pcXVlVXNlclRhZ3ModGFncywgaGVhZFNjcmlwdHMpO1xuXHRyZXR1cm4gdGFncztcbn1cbi8qKlxuKiBCdWlsZCB0aGUgaGVhZC9saW5rL21ldGEvc2NyaXB0IHRhZ3MgZnJvbSB0aGUgcmVuZGVyYWJsZSBwcmVzZW50ZWQgcHJlZml4LlxuKiBVc2VkIGludGVybmFsbHkgYnkgYEhlYWRDb250ZW50YC5cbiovXG52YXIgdXNlVGFncyA9IChhc3NldENyb3NzT3JpZ2luKSA9PiB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBub25jZSA9IHJvdXRlci5vcHRpb25zLnNzcj8ubm9uY2U7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHJldHVybiBidWlsZFRhZ3NGcm9tTWF0Y2hlcyhyb3V0ZXIsIG5vbmNlLCByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCksIGFzc2V0Q3Jvc3NPcmlnaW4pO1xuXHRjb25zdCBzZWxlY3RUYWdzID0gUmVhY3QkMS51c2VDYWxsYmFjaygobWF0Y2hlcykgPT4gYnVpbGRUYWdzRnJvbU1hdGNoZXMocm91dGVyLCBub25jZSwgbWF0Y2hlcywgYXNzZXRDcm9zc09yaWdpbiksIFtcblx0XHRhc3NldENyb3NzT3JpZ2luLFxuXHRcdG5vbmNlLFxuXHRcdHJvdXRlclxuXHRdKTtcblx0cmV0dXJuIHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubWF0Y2hlcywgc2VsZWN0VGFncywgeyBjb21wYXJlOiBkZWVwRXF1YWwgfSk7XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VUYWdzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWhlYWRDb250ZW50VXRpbHMuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBBc3NldCB9IGZyb20gXCIuL0Fzc2V0LmpzXCI7XG5pbXBvcnQgeyBjb21wb3NlU3NyQm9keVNjcmlwdHMsIGRlZXBFcXVhbCwgZ2V0U3NyQm9keVNjcmlwdFBhcnRzIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0IHsgY3JlYXRlRWxlbWVudCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBGcmFnbWVudCwganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvU2NyaXB0cy50c3hcbnZhciByb3V0ZVNjcmlwdEF0dHJzID0geyBzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUgfTtcbi8qKlxuKiBSZW5kZXIgYm9keSBzY3JpcHQgdGFncyBjb2xsZWN0ZWQgZnJvbSByb3V0ZSBtYXRjaGVzIGFuZCBTU1IgbWFuaWZlc3RzLlxuKiBEdXJpbmcgc3RyZWFtaW5nIFNTUiwgYDxTY3JpcHRzPmAgbWFya3Mgd2hlcmUgbGF0ZSBoeWRyYXRpb24gc2NyaXB0cyBtYXlcbiogYmVnaW4gdG8gYmUgaW5zZXJ0ZWQuXG4qL1xudmFyIFNjcmlwdHMgPSAoKSA9PiB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBub25jZSA9IHJvdXRlci5vcHRpb25zLnNzcj8ubm9uY2U7XG5cdGNvbnN0IGdldFBhcnRzID0gKG1hdGNoZXMpID0+IHtcblx0XHRjb25zdCBwYXJ0cyA9IGdldFNzckJvZHlTY3JpcHRQYXJ0cyhtYXRjaGVzLCByb3V0ZXIuc3NyPy5tYW5pZmVzdCwgbm9uY2UsIHJvdXRlU2NyaXB0QXR0cnMpO1xuXHRcdGZvciAoY29uc3Qgc2NyaXB0IG9mIHBhcnRzWzFdKSBpZiAodHlwZW9mIHNjcmlwdC5hdHRycz8uc3JjID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRjb25zdCBzY3JpcHRXaXRoSG9pc3QgPSBzY3JpcHQ7XG5cdFx0XHRzY3JpcHRXaXRoSG9pc3QucHJldmVudFNjcmlwdEhvaXN0ID0gdHJ1ZTtcblx0XHR9XG5cdFx0cmV0dXJuIHBhcnRzO1xuXHR9O1xuXHRjb25zdCBnZXRTY3JpcHRzID0gKG1hdGNoZXMpID0+IHtcblx0XHRyZXR1cm4gY29tcG9zZVNzckJvZHlTY3JpcHRzKGdldFBhcnRzKG1hdGNoZXMpKTtcblx0fTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgcmV0dXJuIHJlbmRlclNjcmlwdHMoY29tcG9zZVNzckJvZHlTY3JpcHRzKGdldFBhcnRzKHJvdXRlci5zdG9yZXMubWF0Y2hlcy5nZXQoKSksIHJvdXRlci5zZXJ2ZXJTc3I/LnRha2VJbml0aWFsSHlkcmF0aW9uU2NyaXB0VGFncygpKSk7XG5cdHJldHVybiByZW5kZXJTY3JpcHRzKHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubWF0Y2hlcywgZ2V0U2NyaXB0cywgeyBjb21wYXJlOiBkZWVwRXF1YWwgfSkpO1xufTtcbmZ1bmN0aW9uIHJlbmRlclNjcmlwdHMoc2NyaXB0cykge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChGcmFnbWVudCwgeyBjaGlsZHJlbjogc2NyaXB0cy5tYXAoKGFzc2V0LCBpKSA9PiAvKiBAX19QVVJFX18gKi8gY3JlYXRlRWxlbWVudChBc3NldCwge1xuXHRcdC4uLmFzc2V0LFxuXHRcdGtleTogYHRzci1zY3JpcHRzLSR7YXNzZXQudGFnfS0ke2l9YFxuXHR9KSkgfSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFNjcmlwdHMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9U2NyaXB0cy5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUh5ZHJhdGVkIH0gZnJvbSBcIi4vQ2xpZW50T25seS5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBBc3NldCB9IGZyb20gXCIuL0Fzc2V0LmpzXCI7XG5pbXBvcnQgeyB1c2VUYWdzIH0gZnJvbSBcIi4vaGVhZENvbnRlbnRVdGlscy5qc1wiO1xuaW1wb3J0IHsgREVWX1NUWUxFU19BVFRSIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGNyZWF0ZUVsZW1lbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEZyYWdtZW50LCBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvSGVhZENvbnRlbnQuZGV2LnRzeFxuLyoqXG4qIFJlbmRlciByb3V0ZS1tYW5hZ2VkIGhlYWQgdGFncyAodGl0bGUsIG1ldGEsIGxpbmtzLCBzdHlsZXMsIGhlYWQgc2NyaXB0cykuXG4qIFBsYWNlIGluc2lkZSB0aGUgZG9jdW1lbnQgaGVhZCBvZiB5b3VyIGFwcCBzaGVsbC5cbipcbiogRGV2ZWxvcG1lbnQgdmVyc2lvbjogZmlsdGVycyBvdXQgZGV2IHN0eWxlcyBsaW5rIGFmdGVyIGh5ZHJhdGlvbiBhbmRcbiogaW5jbHVkZXMgYSBmYWxsYmFjayBjbGVhbnVwIGVmZmVjdCBmb3IgaHlkcmF0aW9uIG1pc21hdGNoIGNhc2VzLlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL2RvY3VtZW50LWhlYWQtbWFuYWdlbWVudFxuKi9cbmZ1bmN0aW9uIEhlYWRDb250ZW50KHByb3BzKSB7XG5cdGNvbnN0IHRhZ3MgPSB1c2VUYWdzKHByb3BzLmFzc2V0Q3Jvc3NPcmlnaW4pO1xuXHRjb25zdCBub25jZSA9IHVzZVJvdXRlcigpLm9wdGlvbnMuc3NyPy5ub25jZTtcblx0Y29uc3QgaHlkcmF0ZWQgPSB1c2VIeWRyYXRlZCgpO1xuXHRSZWFjdCQxLnVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKGh5ZHJhdGVkKSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKGBsaW5rWyR7REVWX1NUWUxFU19BVFRSfV1gKS5mb3JFYWNoKChlbCkgPT4gZWwucmVtb3ZlKCkpO1xuXHR9LCBbaHlkcmF0ZWRdKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goRnJhZ21lbnQsIHsgY2hpbGRyZW46IChoeWRyYXRlZCA/IHRhZ3MuZmlsdGVyKCh0YWcpID0+IHRhZy50YWcgIT09IFwibGlua1wiIHx8IHRhZy5hdHRycz8uW0RFVl9TVFlMRVNfQVRUUl0gIT09IHRydWUpIDogdGFncykubWFwKCh0YWcpID0+IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVFbGVtZW50KEFzc2V0LCB7XG5cdFx0Li4udGFnLFxuXHRcdGtleTogYHRzci1tZXRhLSR7SlNPTi5zdHJpbmdpZnkodGFnKX1gLFxuXHRcdG5vbmNlXG5cdH0pKSB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgSGVhZENvbnRlbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9SGVhZENvbnRlbnQuZGV2LmpzLm1hcCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsU0FBUyxVQUFVLENBQUMsR0FBRztDQUMvQixRQUFRLGFBQWE7Q0FDckIsSUFBSSxRQUFRLE9BQU8sTUFBTTtDQUN6QixPQUFPO0FBQ1I7O0FBRUEsU0FBUyxXQUFXLEtBQUs7Q0FDeEIsT0FBTyxLQUFLLGVBQWU7QUFDNUI7Ozs7QUNsQkEsSUFBTSxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2dCcEIsU0FBUyxTQUFTLE1BQU07Q0FDdkIsS0FBSyxhQUFhLEtBQUssY0FBYyxLQUFLLFFBQVE7Q0FDbEQsTUFBTSxVQUFVLElBQUksUUFBUSxLQUFLLE9BQU87Q0FDeEMsSUFBSSxLQUFLLFFBQVEsUUFBUSxJQUFJLFVBQVUsTUFBTSxNQUFNLFFBQVEsSUFBSSxZQUFZLEtBQUssSUFBSTtDQUNwRixNQUFNLFdBQVcsSUFBSSxTQUFTLE1BQU07RUFDbkMsUUFBUSxLQUFLO0VBQ2I7Q0FDRCxDQUFDO0NBQ0QsU0FBUyxVQUFVO0NBQ25CLElBQUksS0FBSyxPQUFPLE1BQU07Q0FDdEIsT0FBTztBQUNSOztBQUVBLFNBQVMsV0FBVyxLQUFLO0NBQ3hCLE9BQU8sZUFBZSxZQUFZLENBQUMsQ0FBQyxJQUFJO0FBQ3pDOzs7Ozs7O0FDM0JBLFNBQVMsS0FBSyxLQUFLO0NBQ2xCLE9BQU8sSUFBSSxJQUFJLFNBQVM7QUFDekI7Ozs7O0FBS0EsU0FBUyxpQkFBaUIsU0FBUyxVQUFVO0NBQzVDLElBQUksT0FBTyxZQUFZLFlBQVksT0FBTyxRQUFRLFFBQVE7Q0FDMUQsT0FBTztBQUNSO0FBQ0EsSUFBTSxTQUFTLE9BQU8sVUFBVTtBQUNoQyxTQUFTLFFBQVEsS0FBSztDQUNyQixLQUFLLE1BQU0sT0FBTyxLQUFLLElBQUksT0FBTyxLQUFLLEtBQUssR0FBRyxHQUFHLE9BQU87Q0FDekQsT0FBTztBQUNSO0FBQ0EsSUFBTSxtQkFBbUIsT0FBTyxPQUFPLElBQUk7QUFDM0MsSUFBTSx3QkFBd0IsTUFBTSxTQUFTLGlCQUFpQixNQUFNLE1BQU0sSUFBSTtBQUM5RSxTQUFTLGlCQUFpQixNQUFNLE1BQU0sWUFBWSxTQUFTLEdBQUc7Q0FFN0QsSUFBSSxTQUFTLE1BQU0sT0FBTztDQUMxQixJQUFJLFdBQVcsS0FBSyxPQUFPO0NBQzNCLE1BQU0sUUFBUSxNQUFNLFFBQVEsSUFBSSxLQUFLLE1BQU0sUUFBUSxJQUFJO0NBQ3ZELElBQUksQ0FBQyxTQUFTLEVBQUUsY0FBYyxJQUFJLEtBQUssY0FBYyxJQUFJLElBQUksT0FBTztDQUNwRSxNQUFNLFdBQVcsT0FBTyxLQUFLLElBQUk7Q0FDakMsTUFBTSxnQkFBZ0IsU0FBUztDQUMvQixNQUFNLFdBQVcsT0FBTyxLQUFLLElBQUk7Q0FDakMsTUFBTSxTQUFTLFNBQVM7Q0FDeEIsSUFBSSxRQUFRLGtCQUFrQixLQUFLLFVBQVUsV0FBVyxLQUFLLFVBQVUsaUJBQWlCLEtBQUssUUFBUSxNQUFNLEdBQUcsZ0JBQWdCLE9BQU8sVUFBVSxLQUFLLFFBQVEsTUFBTSxHQUFHLFNBQVMsTUFBTSxrQkFBa0IsT0FBTyxvQkFBb0IsSUFBSSxDQUFDLENBQUMsVUFBVSxXQUFXLE9BQU8sb0JBQW9CLElBQUksQ0FBQyxDQUFDLFVBQVUsT0FBTyxzQkFBc0IsSUFBSSxDQUFDLENBQUMsUUFBUSxPQUFPO0NBQ3pWLElBQUksSUFBSTtDQUNSLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUksT0FBTztFQUNWLE9BQU8sSUFBSSxRQUFRLEtBQUs7R0FDdkIsTUFBTTtHQUNOLFdBQVcsS0FBSztHQUNoQixRQUFRLEtBQUs7R0FDYixRQUFRLGFBQWEsUUFBUSxXQUFXLE9BQU8sYUFBYSxXQUFXLGlCQUFpQixVQUFVLE9BQU8sWUFBWSxNQUFNLElBQUk7R0FDL0gsSUFBSSxVQUFVLFVBQVU7RUFDekI7RUFDQSxJQUFJLE1BQU0sVUFBVSxrQkFBa0IsUUFBUSxPQUFPO0NBQ3RELE9BQU87RUFDTixJQUFJLFFBQVEsa0JBQWtCO0VBQzlCLElBQUksWUFBWTtFQUNoQixPQUFPLElBQUksUUFBUSxLQUFLO0dBQ3ZCLE1BQU0sU0FBUztHQUNmLFdBQVcsS0FBSztHQUNoQixNQUFNLFdBQVcsS0FBSztHQUN0QixRQUFRLGFBQWEsV0FBVyxXQUFXLE9BQU8sYUFBYSxXQUFXLGlCQUFpQixVQUFVLFVBQVUsWUFBWSxNQUFNLElBQUk7R0FDckksVUFBVSxVQUFVLGFBQWEsU0FBUyxPQUFPLE9BQU8sT0FBTyxLQUFLLE1BQU0sR0FBRztHQUM3RSxjQUFjLE9BQU8sR0FBRyxPQUFPLFFBQVE7R0FDdkMsU0FBUyxLQUFLO0VBQ2Y7RUFDQSxJQUFJLE9BQU8sT0FBTyxPQUFPLHNCQUFzQixJQUFJLENBQUMsQ0FBQyxTQUFTLE9BQU87RUFDckUsSUFBSSxXQUFXLE9BQU87Q0FDdkI7Q0FDQSxNQUFNLE9BQU8sUUFBUSxTQUFTLEtBQUssQ0FBQyxJQUFJLGFBQWEsV0FBVyxJQUFJLENBQUM7Q0FDckUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVEsS0FBSztFQUNoQyxNQUFNLFFBQVEsSUFBSSxTQUFTO0VBQzNCLElBQUksT0FBTztHQUNWLFdBQVcsS0FBSztHQUNoQixJQUFJLElBQUksR0FBRztJQUNWLFFBQVEsS0FBSztJQUNiLFFBQVEsYUFBYSxRQUFRLFdBQVcsT0FBTyxhQUFhLFdBQVcsaUJBQWlCLFVBQVUsT0FBTyxZQUFZLE1BQU0sSUFBSTtHQUNoSTtHQUNBLEtBQUssT0FBTyxJQUFJLElBQUksV0FBVztFQUNoQyxPQUFPLEtBQUssT0FBTyxTQUFTO0NBQzdCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxjQUFjLEdBQUc7Q0FDekIsSUFBSSxDQUFDLEtBQUssT0FBTyxNQUFNLFVBQVUsT0FBTztDQUN4QyxRQUFRLE9BQU8sZUFBZSxDQUFDLENBQUMsRUFBRSxlQUFlLFlBQVk7QUFDOUQ7Ozs7Ozs7Ozs7QUFVQSxTQUFTLFVBQVUsR0FBRyxHQUFHLFNBQVMsbUJBQW1CO0NBQ3BELElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxNQUFNLFFBQVEsQ0FBQyxLQUFLLE1BQU0sUUFBUSxDQUFDLEdBQUc7RUFDekMsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLE9BQU87RUFDbEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxJQUFJLEdBQUcsS0FBSztHQUN6QyxNQUFNLEtBQUssRUFBRTtHQUNiLE1BQU0sS0FBSyxFQUFFO0dBQ2IsSUFBSSxPQUFPLE1BQU0sQ0FBQyxVQUFVLElBQUksSUFBSSxTQUFTLGlCQUFpQixHQUFHLE9BQU87RUFDekU7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxJQUFJLGNBQWMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxHQUFHO0VBQ3pDLElBQUksU0FBUztHQUNaLEtBQUssTUFBTSxLQUFLLEdBQUcsSUFBSSxxQkFBcUIsRUFBRSxPQUFPLEtBQUssR0FDckQ7UUFBQSxDQUFDLFVBQVUsRUFBRSxJQUFJLEVBQUUsSUFBSSxTQUFTLGlCQUFpQixHQUFHLE9BQU87R0FBQTtHQUVoRSxPQUFPO0VBQ1I7RUFDQSxJQUFJLFNBQVM7RUFDYixJQUFJLG1CQUFtQixTQUFTLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQztPQUMxQyxLQUFLLE1BQU0sS0FBSyxHQUFHLElBQUksRUFBRSxPQUFPLEtBQUssR0FBRztFQUM3QyxLQUFLLE1BQU0sS0FBSyxHQUFHLElBQUkscUJBQXFCLEVBQUUsT0FBTyxLQUFLLEdBQ3JEO09BQUEsYUFBYSxLQUFLLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxJQUFJLFNBQVMsaUJBQWlCLEdBQUcsT0FBTztFQUFBO0VBRWxGLE9BQU8sV0FBVztDQUNuQjtDQUNBLE9BQU87QUFDUjs7Ozs7QUFLQSxTQUFTLHdCQUF3QixXQUFXO0NBQzNDLElBQUk7Q0FDSixJQUFJO0NBQ0osTUFBTSxvQkFBb0IsSUFBSSxTQUFTLFNBQVMsV0FBVztFQUMxRCxxQkFBcUI7RUFDckIsb0JBQW9CO0NBQ3JCLENBQUM7Q0FDRCxrQkFBa0IsU0FBUztDQUMzQixrQkFBa0IsV0FBVyxVQUFVO0VBQ3RDLGtCQUFrQixTQUFTO0VBQzNCLGtCQUFrQixRQUFRO0VBQzFCLG1CQUFtQixLQUFLO0VBQ3hCLFlBQVksS0FBSztDQUNsQjtDQUNBLGtCQUFrQixVQUFVLE1BQU07RUFDakMsa0JBQWtCLFNBQVM7RUFDM0Isa0JBQWtCLENBQUM7Q0FDcEI7Q0FDQSxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxzQkFBc0IsT0FBTztDQUNyQyxJQUFJLE9BQU8sT0FBTyxZQUFZLFVBQVUsT0FBTztDQUMvQyxPQUFPLE1BQU0sUUFBUSxXQUFXLDZDQUE2QyxLQUFLLE1BQU0sUUFBUSxXQUFXLDJDQUEyQyxLQUFLLE1BQU0sUUFBUSxXQUFXLGtDQUFrQztBQUN2TjtBQUlBLFNBQVMsU0FBUyxPQUFPLFdBQVc7Q0FDbkMsS0FBSyxJQUFJLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDM0MsTUFBTSxPQUFPLE1BQU07RUFDbkIsSUFBSSxVQUFVLElBQUksR0FBRyxPQUFPO0NBQzdCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7O0FBY0EsSUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxvQkFBb0IsU0FBUztDQUNyQyxPQUFPLFFBQVEsUUFBUSxpQkFBaUIsT0FBTyxNQUFNLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUM7QUFDbEg7QUFDQSxTQUFTLGNBQWMsU0FBUztDQUMvQixJQUFJO0NBQ0osSUFBSTtFQUNILFVBQVUsVUFBVSxPQUFPO0NBQzVCLFFBQVE7RUFDUCxVQUFVLFFBQVEsV0FBVyxtQkFBbUIsVUFBVTtHQUN6RCxJQUFJO0lBQ0gsT0FBTyxVQUFVLEtBQUs7R0FDdkIsUUFBUTtJQUNQLE9BQU87R0FDUjtFQUNELENBQUM7Q0FDRjtDQUNBLE9BQU8sb0JBQW9CLE9BQU87QUFDbkM7Ozs7O0FBS0EsSUFBTSw2QkFBNkI7Q0FDbEM7Q0FDQTtDQUNBO0NBQ0E7QUFDRDs7Ozs7Ozs7QUFRQSxTQUFTLGFBQWEsS0FBSztDQUMxQixJQUFJLElBQUksT0FBTyxLQUFLO0NBQ3BCLElBQUksQ0FBQyxJQUFJLFNBQVMsR0FBRyxHQUFHO0NBQ3hCLE9BQU8sMENBQTBDLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRSxFQUFFLFFBQVEsYUFBYSxFQUFFLENBQUMsQ0FBQyxZQUFZO0FBQ3ZHO0FBQ0EsSUFBTSw4QkFBOEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFtQnBDLFNBQVMsb0JBQW9CLEtBQUssV0FBVztDQUM1QyxJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLElBQUksNEJBQTRCLEtBQUssR0FBRyxHQUFHLE9BQU87Q0FDbEQsTUFBTSxTQUFTLGFBQWEsR0FBRztDQUMvQixPQUFPLFNBQVMsQ0FBQyxVQUFVLElBQUksTUFBTSxJQUFJO0FBQzFDO0FBQ0EsSUFBTSxxQkFBcUI7Q0FDMUIsS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsVUFBVTtDQUNWLFVBQVU7QUFDWDtBQUNBLElBQU0sb0JBQW9COzs7Ozs7OztBQVExQixTQUFTLFdBQVcsS0FBSztDQUN4QixPQUFPLElBQUksUUFBUSxvQkFBb0IsVUFBVSxtQkFBbUIsTUFBTTtBQUMzRTtBQUNBLFNBQVMsV0FBVyxNQUFNO0NBQ3pCLElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsSUFBSSxTQUFTO0NBQ2IsSUFBSSxxQkFBcUIsS0FBSyxJQUFJLEdBQUc7RUFDcEMsTUFBTSxLQUFLO0VBQ1gsSUFBSSxTQUFTO0VBQ2IsSUFBSTtFQUNKLFNBQVM7RUFDVCxPQUFPLFVBQVUsUUFBUSxHQUFHLEtBQUssSUFBSSxJQUFJO0dBQ3hDLFVBQVUsY0FBYyxLQUFLLE1BQU0sUUFBUSxNQUFNLEtBQUssQ0FBQyxJQUFJLE1BQU07R0FDakUsU0FBUyxHQUFHO0VBQ2I7RUFDQSxVQUFVLGNBQWMsU0FBUyxLQUFLLE1BQU0sTUFBTSxJQUFJLElBQUk7Q0FDM0Q7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBb0JBLFNBQVMsa0JBQWtCLE1BQU07Q0FDaEMsSUFBSSxDQUFDLG9CQUFvQixLQUFLLElBQUksR0FBRyxPQUFPO0NBQzVDLE9BQU8sS0FBSyxRQUFRLHlCQUF5QixrQkFBa0I7QUFDaEU7QUFjQSxTQUFTLFlBQVksR0FBRyxHQUFHO0NBQzFCLElBQUksTUFBTSxHQUFHLE9BQU87Q0FDcEIsSUFBSSxFQUFFLFdBQVcsRUFBRSxRQUFRLE9BQU87Q0FDbEMsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksRUFBRSxPQUFPLEVBQUUsSUFBSSxPQUFPO0NBQzdELE9BQU87QUFDUjs7OztBQ3RUQSxTQUFTLFVBQVUsT0FBTztDQUN6QixPQUFPLFVBQVUsTUFBTSxRQUFRLFFBQVE7RUFDdEMsT0FBTyxRQUFRLEtBQUs7Q0FDckIsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUM7QUFDYjs7QUFFQSxTQUFTLFVBQVUsTUFBTTtDQUN4QixPQUFPLEtBQUssUUFBUSxXQUFXLEdBQUc7QUFDbkM7O0FBRUEsU0FBUyxhQUFhLE1BQU07Q0FDM0IsT0FBTyxTQUFTLE1BQU0sT0FBTyxLQUFLLFFBQVEsUUFBUSxFQUFFO0FBQ3JEOztBQUVBLFNBQVMsY0FBYyxNQUFNO0NBQzVCLE1BQU0sTUFBTSxLQUFLO0NBQ2pCLE9BQU8sTUFBTSxLQUFLLEtBQUssTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRLFFBQVEsRUFBRSxJQUFJO0FBQ3RFOztBQUVBLFNBQVMsU0FBUyxNQUFNO0NBQ3ZCLE9BQU8sY0FBYyxhQUFhLElBQUksQ0FBQztBQUN4Qzs7QUFFQSxTQUFTLG9CQUFvQixPQUFPLFVBQVU7Q0FDN0MsSUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLFVBQVUsT0FBTyxVQUFVLEdBQUcsU0FBUyxJQUFJLE9BQU8sTUFBTSxNQUFNLEdBQUcsRUFBRTtDQUMvRixPQUFPO0FBQ1I7Ozs7Ozs7O0FBZUEsU0FBUyxZQUFZLE1BQU0sSUFBSSxnQkFBZ0IsU0FBUyxPQUFPO0NBQzlELElBQUksR0FBRyxTQUFTLElBQUksR0FBRyxLQUFLLFVBQVUsRUFBRTtDQUN4QyxJQUFJLEdBQUcsV0FBVyxHQUFHLEdBQUc7RUFDdkIsSUFBSSxHQUFHLFdBQVcsS0FBSyxrQkFBa0IsWUFBWSxPQUFPO0VBQzVELElBQUksa0JBQWtCLFVBQVUsT0FBTyxHQUFHLFNBQVMsR0FBRyxJQUFJLEtBQUssR0FBRyxHQUFHO0VBQ3JFLE9BQU8sR0FBRyxTQUFTLEdBQUcsSUFBSSxHQUFHLE1BQU0sR0FBRyxFQUFFLElBQUk7Q0FDN0M7Q0FDQSxNQUFNLFNBQVMsT0FBTztDQUN0QixJQUFJO0NBQ0osSUFBSSxPQUFPO0VBQ1YsTUFBTSxTQUFTLE9BQU8sT0FBTyxPQUFPO0VBQ3BDLE1BQU0sU0FBUyxNQUFNLElBQUksR0FBRztFQUM1QixJQUFJLFFBQVEsT0FBTztDQUNwQjtDQUNBLElBQUk7Q0FDSixJQUFJLFFBQVEsZUFBZSxLQUFLLE1BQU0sR0FBRztNQUNwQztFQUNKLElBQUksS0FBSyxTQUFTLElBQUksR0FBRyxPQUFPLFVBQVUsSUFBSTtFQUM5QyxlQUFlLEtBQUssTUFBTSxHQUFHO0VBQzdCLE9BQU8sYUFBYSxTQUFTLEtBQUssS0FBSyxZQUFZLE1BQU0sSUFBSSxhQUFhLElBQUk7RUFDOUUsTUFBTSxhQUFhLEdBQUcsTUFBTSxHQUFHO0VBQy9CLEtBQUssSUFBSSxRQUFRLEdBQUcsU0FBUyxXQUFXLFFBQVEsUUFBUSxRQUFRLFNBQVM7R0FDeEUsTUFBTSxRQUFRLFdBQVc7R0FDekIsSUFBSSxVQUFVLElBQUk7SUFDakIsSUFBSSxDQUFDLE9BQU8sZUFBZSxDQUFDLEtBQUs7U0FDNUIsSUFBSSxVQUFVLFNBQVMsR0FBRyxhQUFhLEtBQUssS0FBSztHQUN2RCxPQUFPLElBQUksVUFBVSxNQUFNLElBQUksYUFBYSxTQUFTLEdBQUcsYUFBYSxJQUFJO1FBQ3BFLGVBQWUsQ0FBQyxFQUFFO1FBQ2xCLElBQUksVUFBVSxLQUFLLENBQUMsT0FBTyxhQUFhLEtBQUssS0FBSztFQUN4RDtDQUNEO0NBQ0EsSUFBSSxhQUFhLFNBQVMsR0FBRztFQUM1QixJQUFJLEtBQUssWUFBWSxNQUFNLElBQ3RCO09BQUEsa0JBQWtCLFNBQVMsYUFBYSxJQUFJO0VBQUEsT0FDMUMsSUFBSSxrQkFBa0IsVUFBVSxhQUFhLEtBQUssRUFBRTtDQUM1RDtDQUNBLE1BQU0sU0FBUyxhQUFhLEtBQUssR0FBRztDQUNwQyxNQUFNLFVBQVUsU0FBUyxVQUFVLE1BQU0sSUFBSSxXQUFXO0NBQ3hELElBQUksT0FBTyxPQUFPLE1BQU0sSUFBSSxLQUFLLE1BQU07Q0FDdkMsT0FBTztBQUNSOzs7OztBQUtBLFNBQVMscUJBQXFCLDZCQUE2QjtDQUMxRCxNQUFNLFVBQVUsSUFBSSxJQUFJLDRCQUE0QixLQUFLLFNBQVMsQ0FBQyxtQkFBbUIsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO0NBQ25HLE1BQU0sUUFBUSxJQUFJLE9BQU8sQ0FBQyxHQUFHLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLFFBQVEsV0FBVyxNQUFNLEdBQUcsR0FBRztDQUN0RixRQUFRLFlBQVksUUFBUSxRQUFRLFFBQVEsVUFBVSxRQUFRLElBQUksS0FBSyxLQUFLLEtBQUs7QUFDbEY7O0FBS0EsU0FBUyxlQUFlLE9BQU87Q0FDOUIsT0FBTyxTQUFTLFFBQVEsVUFBVTtBQUNuQztBQVNBLFNBQVMsWUFBWSxLQUFLLE9BQU8sU0FBUztDQUN6QyxJQUFJLE9BQU8sVUFBVSxVQUFVLE9BQU8sTUFBTSxTQUFTLEtBQUs7Q0FDMUQsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsSUFBSSxVQUFVLENBQUMsU0FBUyx3QkFBd0IsS0FBSyxLQUFLLElBQUksT0FBTztDQUNyRSxJQUFJLFVBQVUsbUJBQW1CLEtBQUs7Q0FDdEMsSUFBSSxPQUFPLFVBQVUsUUFBUSxXQUFXLE9BQU8sR0FBRztDQUNsRCxPQUFPLFVBQVUsUUFBUSxPQUFPLElBQUk7QUFDckM7O0FBRUEsU0FBUyxnQkFBZ0IsTUFBTSxVQUFVLFFBQVEsU0FBUyxZQUFZO0NBQ3JFLE1BQU0sZ0JBQWdCLEtBQUssU0FBUyxHQUFHLElBQUksTUFBTTtDQUNqRCxJQUFJLFNBQVM7Q0FDYixLQUFLLE1BQU0sUUFBUSxVQUFVO0VBQzVCLElBQUksT0FBTyxTQUFTLFVBQVU7R0FDN0IsVUFBVTtHQUNWO0VBQ0Q7RUFDQSxNQUFNLENBQUMsTUFBTSxLQUFLLFFBQVEsYUFBYTtFQUN2QyxNQUFNLFFBQVEsU0FBUztFQUN2QixNQUFNLFNBQVMsU0FBUyxjQUFjLEtBQUssSUFBSSxZQUFZLGdCQUFnQjtFQUMzRSxJQUFJLGFBQWEsT0FBTztFQUN4QixJQUFJLFNBQVMsS0FBSyxjQUFjLE1BQU07RUFDdEMsSUFBSSxZQUFZO0dBQ2YsV0FBVyxPQUFPO0dBQ2xCLElBQUksT0FBTyxXQUFXLE9BQU87RUFDOUI7RUFDQSxJQUFJLFNBQVMsZUFBZSxVQUFVLEdBQUc7R0FDeEMsSUFBSSxXQUFXLE9BQU8sQ0FBQyxRQUFRO0dBQy9CLGFBQWE7RUFDZDtFQUNBLFVBQVUsU0FBUyxZQUFZLEtBQUssWUFBWSxPQUFPLEtBQUssVUFBVTtDQUN2RTtDQUNBLE9BQU8sU0FBUyxpQkFBaUI7QUFDbEM7Ozs7Ozs7Ozs7Ozs7OztBQ2pJQSxTQUFTLGlCQUFpQixLQUFLO0NBQzlCLE1BQU0sd0JBQXdCLElBQUksSUFBSTtDQUN0QyxJQUFJO0NBQ0osSUFBSTtDQUNKLE9BQU87RUFDTixJQUFJLEtBQUs7R0FDUixNQUFNLFFBQVEsTUFBTSxJQUFJLEdBQUc7R0FDM0IsSUFBSSxDQUFDLE9BQU87R0FDWixNQUFNLFVBQVU7R0FDaEIsT0FBTyxNQUFNO0VBQ2Q7RUFDQSxJQUFJLEtBQUssT0FBTztHQUNmLE1BQU0sV0FBVyxNQUFNLElBQUksR0FBRztHQUM5QixJQUFJLFVBQVU7SUFDYixTQUFTLFFBQVE7SUFDakI7R0FDRDtHQUNBLElBQUksTUFBTSxRQUFRLEtBQUs7SUFDdEIsSUFBSSxPQUFPLE1BQU0sS0FBSyxDQUFDLENBQUM7SUFDeEIsT0FBTyxDQUFDLFFBQVEsS0FBSyxTQUFTO0tBQzdCLElBQUksTUFBTSxLQUFLLFVBQVU7VUFDcEIsT0FBTyxNQUFNLE9BQU87S0FDekIsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0lBQ3BCO0lBQ0EsSUFBSSxTQUFTLFFBQVEsT0FBTyxLQUFLO0lBQ2pDLE1BQU0sT0FBTyxLQUFLLEdBQUc7R0FDdEI7R0FDQSxNQUFNLFFBQVE7SUFDYjtJQUNBO0lBQ0EsU0FBUztHQUNWO0dBQ0EsU0FBUztHQUNULE1BQU0sSUFBSSxLQUFLLEtBQUs7RUFDckI7RUFDQSxRQUFRO0dBQ1AsTUFBTSxNQUFNO0dBQ1osT0FBTyxLQUFLO0dBQ1osU0FBUyxLQUFLO0VBQ2Y7Q0FDRDtBQUNEOzs7QUNsREEsSUFBTSxxQkFBcUI7QUFDM0IsSUFBTSx3QkFBd0I7QUFDOUIsU0FBUyxjQUFjLE1BQU07Q0FDNUIsTUFBTSxTQUFTLEtBQUs7Q0FDcEIsSUFBSSxRQUFRLE9BQU87Q0FDbkIsTUFBTSxPQUFPLENBQUM7Q0FDZCxLQUFLLE1BQU0sV0FBVyxNQUFNLElBQUksT0FBTyxZQUFZLFVBQVUsS0FBSyxLQUFLLFFBQVEsRUFBRTtDQUNqRixPQUFPLEtBQUssUUFBUTtBQUNyQjs7QUFFQSxTQUFTLGFBQWEsTUFBTSxPQUFPLEtBQUs7Q0FDdkMsTUFBTSxPQUFPLEtBQUssVUFBVSxPQUFPLEdBQUc7Q0FDdEMsSUFBSSxLQUFLLFdBQVcsQ0FBQyxNQUFNLElBQUksT0FBTyxLQUFLLFdBQVcsSUFBSTtFQUN6RDtFQUNBO0VBQ0E7RUFDQSxLQUFLO0NBQ04sSUFBSTtFQUNIO0VBQ0EsS0FBSyxVQUFVLENBQUM7RUFDaEI7RUFDQTtDQUNEO0NBQ0EsTUFBTSxPQUFPLEtBQUssUUFBUSxHQUFHO0NBQzdCLElBQUksUUFBUSxHQUFHO0VBQ2QsTUFBTSxRQUFRLEtBQUssUUFBUSxLQUFLLElBQUk7RUFDcEMsTUFBTSxXQUFXLEtBQUssV0FBVyxPQUFPLENBQUMsTUFBTTtFQUMvQyxNQUFNLFlBQVksUUFBUSxXQUFXLElBQUk7RUFDekMsSUFBSSxTQUFTLEtBQUssS0FBSyxXQUFXLFlBQVksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxZQUFZLFlBQVksUUFBUTtHQUM1RixNQUFNLE1BQU0sS0FBSyxVQUFVLFdBQVcsS0FBSztHQUMzQyxPQUFPO0lBQ04sV0FBVyxJQUFJLE1BQU0sSUFBSTtJQUN6QixPQUFPO0lBQ1AsS0FBSyxVQUFVLEdBQUcsSUFBSTtJQUN0QixLQUFLLFVBQVUsUUFBUSxRQUFRLEdBQUcsTUFBTSxNQUFNLEtBQUssTUFBTTtHQUMxRDtFQUNEO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGNBQWMsc0JBQXNCLE9BQU8sT0FBTyxNQUFNLG9CQUFvQixxQkFBcUI7Q0FDekcsSUFBSSxTQUFTO0NBQ2IsTUFBTSxPQUFPLE1BQU0sWUFBWSxNQUFNO0NBQ3JDLE1BQU0sVUFBVSxNQUFNO0NBQ3RCLE1BQU0sU0FBUyxLQUFLO0NBQ3BCLE1BQU0sYUFBYSxLQUFLLFNBQVMsR0FBRyxJQUFJLFNBQVMsSUFBSTtDQUNyRCxNQUFNLGdCQUFnQixTQUFTLGlCQUFpQjtDQUNoRCxNQUFNLGNBQWMsU0FBUyxRQUFRLFNBQVMsU0FBUztDQUN2RCxJQUFJO0NBQ0osSUFBSSxlQUFlLHNCQUFzQixRQUFRLElBQUk7Q0FDckQsSUFBSSxDQUFDLFFBQVEsS0FBSyxTQUFTLEdBQUcsR0FBRztFQUNoQyxnQkFBZ0IscUJBQXFCLE1BQU0sS0FBSyxDQUFDO0VBQ2pELE1BQU0sT0FBTyxLQUFLLGFBQWE7RUFDL0IsSUFBSSxRQUFRLE9BQU8sU0FBUyxZQUFZLEtBQUssT0FBTyxHQUFHO0dBQ3RELGNBQWMsY0FBYyxTQUFTLEtBQUs7SUFDekMsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSyxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssVUFBVSxTQUFTLEtBQUssUUFBUSxPQUFPLE1BQU0sSUFBSSxJQUFJLFVBQVU7R0FDN0c7R0FDQSxlQUFlO0VBQ2hCO0NBQ0Q7Q0FDQSxPQUFPLFNBQVMsUUFBUTtFQUN2QixNQUFNLFFBQVE7RUFDZCxNQUFNLE9BQU8sS0FBSyxRQUFRLEtBQUssS0FBSztFQUNwQyxJQUFJLE1BQU0sU0FBUyxLQUFLLFNBQVM7RUFDakMsTUFBTSxVQUFVLGFBQWEsTUFBTSxPQUFPLEdBQUc7RUFDN0MsU0FBUyxNQUFNO0VBQ2YsSUFBSTtFQUNKLElBQUksT0FBTyxZQUFZLFVBQVU7R0FDaEMsSUFBSSxDQUFDLE1BQU07R0FDWCxJQUFJLE9BQU87R0FDWCxJQUFJO0dBQ0osSUFBSSxlQUFlLGlCQUFpQixLQUFLLDJCQUEyQixJQUFJLElBQUk7UUFDdkU7SUFDSixPQUFPLFFBQVEsWUFBWTtJQUMzQixpQkFBaUIsS0FBSyxzQ0FBc0MsSUFBSSxJQUFJO0dBQ3JFO0dBQ0EsTUFBTSxlQUFlLGVBQWUsSUFBSSxJQUFJO0dBQzVDLElBQUksY0FBYyxXQUFXO1FBQ3hCO0lBQ0osTUFBTSxPQUFPLGtCQUFrQixJQUFJO0lBQ25DLFdBQVc7SUFDWCxlQUFlLElBQUksTUFBTSxJQUFJO0dBQzlCO0VBQ0QsT0FBTztHQUNOLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLElBQUksU0FBUyxRQUFRO0dBQ3JCLElBQUksU0FBUyxRQUFRLE1BQU07R0FDM0IsSUFBSSxTQUFTLEdBQUc7SUFDZixNQUFNO0lBQ04sU0FBUyxNQUFNO0dBQ2hCO0dBQ0EsSUFBSSxpQkFBaUIsZUFBZSxLQUFLO0lBQ3hDLElBQUksZUFBZSxRQUFRLEdBQUcsY0FBYyxLQUFLLEtBQUssVUFBVSxjQUFjLFFBQVEsQ0FBQyxDQUFDO0lBQ3hGLFFBQVEsS0FBSyxNQUFNO0lBQ25CLElBQUksU0FBUyxLQUFLLFFBQVEsT0FBTyxLQUFLLEtBQUssYUFBYSxRQUFRLFFBQVEsS0FBSyxPQUFPLE1BQU0sR0FBRyxFQUFFO0lBQy9GLGNBQWMsS0FBSyxPQUFPO0lBQzFCLGVBQWU7R0FDaEI7R0FDQSxJQUFJLENBQUMsTUFBTTtHQUNYLE1BQU0sd0JBQXdCLGlCQUFpQixDQUFDLEVBQUUsVUFBVTtHQUM1RCxJQUFJLENBQUMsZUFBZTtJQUNuQixTQUFTLE9BQU8sWUFBWTtJQUM1QixTQUFTLE9BQU8sWUFBWTtHQUM3QjtHQUNBLE1BQU0sV0FBVyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUMsSUFBSSxTQUFTLElBQUksS0FBSyxhQUFhLENBQUMsSUFBSSxLQUFLLGFBQWEsQ0FBQztHQUMzRyxNQUFNLGVBQWUsU0FBUyxLQUFLLENBQUMsZUFBZSxTQUFTLE1BQU0sTUFBTSxDQUFDLEVBQUUsU0FBUyxFQUFFLGtCQUFrQix5QkFBeUIsRUFBRSxXQUFXLFVBQVUsRUFBRSxXQUFXLE1BQU07R0FDM0ssSUFBSSxjQUFjLFdBQVc7UUFDeEI7SUFDSixNQUFNLE9BQU8sa0JBQWtCLE1BQU0sTUFBTSx1QkFBdUIsUUFBUSxNQUFNO0lBQ2hGLFdBQVc7SUFDWCxTQUFTLEtBQUssSUFBSTtJQUNsQixJQUFJLFNBQVMsV0FBVyxHQUFHLG9CQUFvQixLQUFLLFFBQVE7R0FDN0Q7RUFDRDtFQUNBLE9BQU87Q0FDUjtDQUNBLElBQUksaUJBQWlCLGVBQWUsWUFBWSxjQUFjLEtBQUssS0FBSyxVQUFVLGNBQWMsVUFBVSxDQUFDO0NBQzNHLE1BQU0sY0FBYyxlQUFlLE1BQU07Q0FDekMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixJQUFJLGVBQWUsTUFBTSxZQUFZLENBQUMsTUFBTSxVQUFVLE1BQU0sTUFBTSxNQUFNLEdBQUcsV0FBVyxNQUFNLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLElBQUk7RUFDNUgsTUFBTSxlQUFlLGtCQUFrQixNQUFNLHFCQUFxQjtFQUNsRSxDQUFDLEtBQUssYUFBYSxDQUFDLEVBQUEsQ0FBRyxLQUFLLFlBQVk7RUFDeEMsT0FBTztDQUNSO0NBQ0EsTUFBTSxVQUFVLE1BQU0sUUFBUSxDQUFDLE1BQU0sYUFBYSxDQUFDLE1BQU07Q0FDekQsSUFBSSxVQUFVLGFBQWEsUUFBUTtFQUNsQyxNQUFNLFlBQVksa0JBQWtCLE1BQU0sa0JBQWtCO0VBQzVELEtBQUssUUFBUTtFQUNiLE9BQU87Q0FDUjtDQUNBLEtBQUssUUFBUSxlQUFlO0NBQzVCLEtBQUssV0FBVyxTQUFTLFFBQVEsWUFBWTtDQUM3QyxJQUFJLENBQUMsS0FBSyxPQUFPO0VBQ2hCLEtBQUssT0FBTztFQUNaLElBQUksUUFBUSxLQUFLLFFBQVE7Q0FDMUI7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7Q0FDMUIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxFQUFFLE9BQU8sT0FBTztDQUNoQyxJQUFJLENBQUMsRUFBRSxTQUFTLEVBQUUsT0FBTyxPQUFPO0NBQ2hDLElBQUksRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxXQUFXLE9BQU8sRUFBRSxXQUFXLEVBQUU7Q0FDNUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLFFBQVE7RUFDbEQsSUFBSSxFQUFFLE9BQU8sV0FBVyxFQUFFLE1BQU0sR0FBRyxPQUFPO0VBQzFDLElBQUksRUFBRSxPQUFPLFdBQVcsRUFBRSxNQUFNLEdBQUcsT0FBTztDQUMzQztDQUNBLElBQUksRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxRQUFRO0VBQ2xELElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxNQUFNLEdBQUcsT0FBTztFQUN4QyxJQUFJLEVBQUUsT0FBTyxTQUFTLEVBQUUsTUFBTSxHQUFHLE9BQU87Q0FDekM7Q0FDQSxJQUFJLEVBQUUsVUFBVSxDQUFDLEVBQUUsUUFBUSxPQUFPO0NBQ2xDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxRQUFRLE9BQU87Q0FDbEMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLFFBQVEsT0FBTztDQUNsQyxJQUFJLENBQUMsRUFBRSxVQUFVLEVBQUUsUUFBUSxPQUFPO0NBQ2xDLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxFQUFFLGVBQWUsT0FBTztDQUNoRCxJQUFJLENBQUMsRUFBRSxpQkFBaUIsRUFBRSxlQUFlLE9BQU87Q0FDaEQsT0FBTztBQUNSO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUSxPQUFPLEdBQUcsZUFBZSxRQUFRLFFBQVE7Q0FDM0UsT0FBTztFQUNOO0VBQ0EsT0FBTyxTQUFTLE9BQU8sUUFBUSxJQUFJO0VBQ25DLFVBQVU7RUFDVixPQUFPO0VBQ1AsUUFBUTtFQUNSLG1CQUFtQjtFQUNuQixTQUFTO0VBQ1QsVUFBVTtFQUNWLFVBQVU7RUFDVixPQUFPO0VBQ1AsTUFBTSxLQUFLO0VBQ1g7RUFDQSxPQUFPO0VBQ1AsVUFBVTtFQUNWO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7QUFDQSxTQUFTLGtCQUFrQixXQUFXLGVBQWU7Q0FDcEQsTUFBTSxjQUFjLGtCQUFrQjtDQUN0QyxNQUFNLHFCQUFxQixDQUFDO0NBQzVCLFNBQVMsTUFBTSxPQUFPLE9BQU8sWUFBWSxxQkFBcUI7RUFDN0QsTUFBTSxDQUFDLE1BQU0sUUFBUSxZQUFZLGNBQWMsT0FBTyxPQUFPLE9BQU8sWUFBWSxvQkFBb0IsbUJBQW1CO0VBQ3ZILElBQUksTUFBTSxVQUFVLEtBQUssTUFBTSxTQUFTLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxNQUFNLFFBQVE7Q0FDNUY7Q0FDQSxLQUFLLE1BQU0sU0FBUyxXQUFXLE1BQU0sT0FBTyxHQUFHLFdBQVc7Q0FDMUQsS0FBSyxNQUFNLFNBQVMsb0JBQW9CLE1BQU0sS0FBSyxXQUFXO0NBQzlELGNBQWMsWUFBWTtDQUMxQixjQUFjLFlBQVksaUJBQWlCLEdBQUc7QUFDL0M7Ozs7QUFJQSxTQUFTLGNBQWMsTUFBTSxlQUFlO0NBQzNDLFNBQVM7Q0FDVCxNQUFNLFNBQVMsY0FBYyxVQUFVLElBQUksSUFBSTtDQUMvQyxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU87Q0FDOUIsTUFBTSxTQUFTLFVBQVUsTUFBTSxjQUFjLFNBQVM7Q0FDdEQsY0FBYyxVQUFVLElBQUksTUFBTSxNQUFNO0NBQ3hDLE9BQU87QUFDUjs7OztBQUlBLFNBQVMsZ0JBQWdCLE1BQU0sZUFBZSxPQUFPLE1BQU0sZUFBZTtDQUN6RSxTQUFTO0NBQ1QsU0FBUztDQUNULE1BQU0sTUFBTSxnQkFBZ0IsU0FBUyxTQUFTO0NBQzlDLElBQUksT0FBTyxjQUFjLFlBQVksSUFBSSxHQUFHO0NBQzVDLElBQUksQ0FBQyxNQUFNO0VBQ1YsT0FBTyxrQkFBa0I7RUFDekIsY0FBYyxlQUFlLEVBQUUsS0FBSyxHQUFHLEdBQUcsSUFBSTtFQUM5QyxjQUFjLFlBQVksSUFBSSxLQUFLLElBQUk7Q0FDeEM7Q0FDQSxPQUFPLFVBQVUsTUFBTSxNQUFNLEtBQUs7QUFDbkM7QUFDQSxTQUFTLGVBQWUsTUFBTSxlQUFlLFFBQVEsT0FBTztDQUMzRCxNQUFNLE1BQU0sUUFBUSxPQUFPLFdBQVc7Q0FDdEMsTUFBTSxTQUFTLGNBQWMsV0FBVyxJQUFJLEdBQUc7Q0FDL0MsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPO0NBQzlCLFNBQVM7Q0FDVCxJQUFJO0NBQ0osSUFBSTtFQUNILFNBQVMsVUFBVSxNQUFNLGNBQWMsYUFBYSxLQUFLO0NBQzFELFNBQVMsS0FBSztFQUNiLElBQUksZUFBZSxVQUFVLFNBQVM7T0FDakMsTUFBTTtDQUNaO0NBQ0EsSUFBSSxRQUFRLE9BQU8sU0FBUyxpQkFBaUIsT0FBTyxLQUFLO0NBQ3pELGNBQWMsV0FBVyxJQUFJLEtBQUssTUFBTTtDQUN4QyxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxpQkFBaUIsV0FBVyxnQkFBZ0IsT0FBTztDQUMzRCxNQUFNLGNBQWMsa0JBQWtCO0NBQ3RDLE1BQU0scUJBQXFCLENBQUM7Q0FDNUIsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxlQUFlLENBQUM7Q0FDdEIsSUFBSSxRQUFRO0NBQ1osU0FBUyxNQUFNLE9BQU8sT0FBTyxZQUFZLHFCQUFxQjtFQUM3RCxNQUFNLEtBQUssS0FBSztFQUNoQixJQUFJLE1BQU0sTUFBTSxZQUM0QixNQUFNLElBQUksTUFBTSxxREFBcUQsT0FBTyxNQUFNLEVBQUUsR0FBRztFQUduSSxXQUFXLE1BQU0sTUFBTTtFQUN2QixJQUFJLFVBQVUsS0FBSyxNQUFNLE1BQU07R0FDOUIsTUFBTSxrQkFBa0IsY0FBYyxNQUFNLFFBQVE7R0FDcEQsSUFBSSxDQUFDLGFBQWEsb0JBQW9CLE1BQU0sU0FBUyxTQUFTLEdBQUcsR0FBRyxhQUFhLG1CQUFtQjtFQUNyRztFQUNBO0VBQ0EsTUFBTSxDQUFDLE1BQU0sUUFBUSxZQUFZLGNBQWMsZUFBZSxPQUFPLE9BQU8sWUFBWSxvQkFBb0IsbUJBQW1CO0VBQy9ILE1BQU0saUJBQWlCO0VBQ3ZCLElBQUksTUFBTSxVQUFVLEtBQUssTUFBTSxTQUFTLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxNQUFNLFFBQVE7Q0FDNUY7Q0FDQSxNQUFNLFdBQVcsR0FBRyxXQUFXO0NBQy9CLEtBQUssTUFBTSxTQUFTLG9CQUFvQixNQUFNLEtBQUssV0FBVztDQUM5RCxPQUFPO0VBQ04sZUFBZTtHQUNkO0dBQ0EsYUFBYSxpQkFBaUIsR0FBRztHQUNqQyxZQUFZLGlCQUFpQixHQUFHO0dBQ2hDLFdBQVc7R0FDWCxXQUFXO0VBQ1o7RUFDQTtFQUNBO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsVUFBVSxNQUFNLGFBQWEsUUFBUSxPQUFPO0NBQ3BELE1BQU0sUUFBUSxLQUFLLE1BQU0sR0FBRztDQUM1QixNQUFNLE9BQU8sYUFBYSxNQUFNLE9BQU8sYUFBYSxLQUFLO0NBQ3pELElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsTUFBTSxDQUFDLGFBQWEsY0FBYyxNQUFNLE9BQU8sSUFBSTtDQUNuRCxPQUFPO0VBQ04sT0FBTyxLQUFLLEtBQUs7RUFDakI7Q0FDRDtBQUNEOzs7Ozs7OztBQVFBLFNBQVMsY0FBYyxNQUFNLE9BQU8sTUFBTTtDQUN6QyxNQUFNLE9BQU8sWUFBWSxLQUFLLElBQUk7Q0FDbEMsTUFBTSxRQUFRLEtBQUssS0FBSyxRQUFRLGNBQWMsS0FBSyxLQUFLLElBQUk7Q0FDNUQsTUFBTSxZQUFZLE9BQU8sT0FBTyxJQUFJOztDQUVwQyxJQUFJLFlBQVksS0FBSyxTQUFTLFFBQVE7O0NBRXRDLElBQUksWUFBWSxLQUFLLFNBQVMsUUFBUTs7Q0FFdEMsSUFBSSxZQUFZLEtBQUssU0FBUyxRQUFROztDQUV0QyxJQUFJLGFBQWEsS0FBSyxTQUFTLFNBQVM7Q0FDeEMsT0FBTyxZQUFZLEtBQUssUUFBUSxhQUFhLGFBQWEsYUFBYTtFQUN0RSxNQUFNLE9BQU8sS0FBSztFQUNsQixJQUFJLEtBQUssU0FBUyxvQkFBb0I7RUFDdEMsSUFBSSxLQUFLLFNBQVMsdUJBQXVCO0dBQ3hDO0dBQ0E7R0FDQTtFQUNEO0VBQ0EsTUFBTSxPQUFPLE1BQU07RUFDbkIsTUFBTSxtQkFBbUI7RUFDekIsSUFBSSxNQUFNLGFBQWEsS0FBSztFQUM1QixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0dBQ3ZDLE1BQU0sT0FBTyxNQUFNO0dBQ25CLElBQUksS0FBSyxTQUFTLEtBQUssS0FBSyxVQUFVLEtBQUssV0FBVztJQUNyRDtJQUNBLFlBQVksbUJBQW1CO0lBQy9CO0dBQ0Q7R0FDQSxNQUFNLFFBQVEsS0FBSyxVQUFVLEtBQUssU0FBUyxLQUFLLFVBQVUsS0FBSyxPQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLElBQUk7R0FDbEgsSUFBSSxTQUFTLEtBQUssU0FBUyxHQUFHLFVBQVUsUUFBUSxtQkFBbUIsS0FBSztFQUN6RSxPQUFPLElBQUksS0FBSyxTQUFTLEdBQUc7R0FDM0IsTUFBTSxJQUFJO0dBQ1YsTUFBTSxRQUFRLEtBQUssVUFBVSxtQkFBbUIsRUFBRSxPQUFPLFFBQVEsS0FBSyxTQUFTLEVBQUUsT0FBTyxNQUFNO0dBQzlGLE1BQU0sUUFBUSxtQkFBbUIsS0FBSztHQUN0QyxVQUFVLE9BQU87R0FDakIsVUFBVSxTQUFTO0dBQ25CO0VBQ0Q7Q0FDRDtDQUNBLElBQUksS0FBSyxXQUFXLE9BQU8sT0FBTyxXQUFXLEtBQUssU0FBUztDQUMzRCxPQUFPLENBQUMsV0FBVztFQUNsQixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixPQUFPO0NBQ1IsQ0FBQztBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztDQUNoQyxNQUFNLE9BQU8sQ0FBQyxLQUFLO0NBQ25CLE9BQU8sTUFBTSxhQUFhO0VBQ3pCLFFBQVEsTUFBTTtFQUNkLEtBQUssS0FBSyxLQUFLO0NBQ2hCO0NBQ0EsS0FBSyxRQUFRO0NBQ2IsT0FBTztBQUNSO0FBQ0EsU0FBUyxZQUFZLE1BQU07Q0FDMUIsTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRLENBQUM7Q0FDakMsR0FBRztFQUNGLEtBQUssS0FBSyxTQUFTO0VBQ25CLE9BQU8sS0FBSztDQUNiLFNBQVM7Q0FDVCxPQUFPO0FBQ1I7QUFDQSxTQUFTLGFBQWEsTUFBTSxPQUFPLGFBQWEsT0FBTztDQUN0RCxJQUFJLFNBQVMsT0FBTyxZQUFZLE9BQU8sT0FBTztFQUM3QyxNQUFNLFlBQVk7RUFDbEIsU0FBUztDQUNWO0NBQ0EsTUFBTSxnQkFBZ0IsQ0FBQyxLQUFLLEtBQUs7Q0FDakMsTUFBTSxjQUFjLGlCQUFpQixTQUFTO0NBQzlDLE1BQU0sY0FBYyxNQUFNLFVBQVUsZ0JBQWdCLElBQUk7Q0FDeEQsTUFBTSxRQUFRLENBQUM7RUFDZCxNQUFNO0VBQ04sT0FBTztFQUNQLFNBQVM7RUFDVCxTQUFTO0VBQ1QsVUFBVTtFQUNWLFdBQVc7Q0FDWixDQUFDO0NBQ0QsSUFBSSxZQUFZO0NBQ2hCLElBQUksWUFBWTtDQUNoQixPQUFPLE1BQU0sUUFBUTtFQUNwQixNQUFNLFFBQVEsTUFBTSxJQUFJO0VBQ3hCLE1BQU0sRUFBRSxNQUFNLE9BQU8sU0FBUyxTQUFTLFVBQVUsY0FBYztFQUMvRCxJQUFJLEVBQUUsU0FBUyxjQUFjO0VBQzdCLElBQUksS0FBSyxTQUFTLEtBQUssS0FBSyxTQUFTLENBQUMsb0JBQW9CLFdBQVcsS0FBSyxHQUFHO0VBQzdFLElBQUksS0FBSyxPQUFPO0dBQ2YsSUFBSSxDQUFDLG9CQUFvQixNQUFNLE9BQU8sS0FBSyxHQUFHO0dBQzlDLFlBQVksTUFBTTtHQUNsQixVQUFVLE1BQU07RUFDakI7RUFDQSxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUyxzQkFBc0Isb0JBQW9CLFdBQVcsS0FBSyxHQUFHLFlBQVk7RUFDbEgsTUFBTSxlQUFlLFVBQVU7RUFDL0IsSUFBSSxjQUFjO0dBQ2pCLElBQUksS0FBSyxVQUFVLENBQUMsZUFBZSxLQUFLLFNBQVMsc0JBQXNCLEtBQUssU0FBUyxNQUFNLG9CQUFvQixXQUFXLEtBQUssR0FBRyxZQUFZO0dBQzlJLElBQUksQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLFNBQVMsQ0FBQyxLQUFLLFVBQVU7RUFDeEU7RUFDQSxNQUFNLE9BQU8sZUFBZSxLQUFLLElBQUksTUFBTTtFQUMzQyxJQUFJO0VBQ0osSUFBSSxnQkFBZ0IsS0FBSyxPQUFPO0dBQy9CLE1BQU0sYUFBYTtJQUNsQixNQUFNLEtBQUs7SUFDWDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNEO0dBQ0EsSUFBSSxhQUFhO0dBQ2pCLElBQUksS0FBSyxNQUFNLE9BQ1Y7UUFBQSxDQUFDLG9CQUFvQixNQUFNLE9BQU8sVUFBVSxHQUFHLGFBQWE7R0FBQTtHQUVqRSxJQUFJLFlBQVk7SUFDZixJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxXQUFXLHFCQUFxQixTQUFTLFdBQVcsR0FBRyxPQUFPO0lBQzlGLElBQUksb0JBQW9CLFdBQVcsVUFBVSxHQUFHLFlBQVk7R0FDN0Q7RUFDRDtFQUNBLElBQUksS0FBSyxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssU0FBUyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDdEUsTUFBTSxVQUFVLEtBQUssU0FBUztHQUM5QixNQUFNLEVBQUUsUUFBUSxXQUFXO0dBQzNCLElBQUksUUFBUTtJQUNYLElBQUksY0FBYztJQUNsQixJQUFJLEVBQUUsUUFBUSxnQkFBZ0IsT0FBTyxjQUFjLEtBQUssWUFBWSxFQUFBLENBQUcsV0FBVyxNQUFNLEdBQUc7R0FDNUY7R0FDQSxJQUFJLFFBQVE7SUFDWCxJQUFJLGNBQWM7SUFDbEIsTUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUc7SUFDdkMsTUFBTSxhQUFhLElBQUksTUFBTSxDQUFDLE9BQU8sTUFBTTtJQUMzQyxLQUFLLFFBQVEsZ0JBQWdCLGFBQWEsV0FBVyxZQUFZLE9BQU8sVUFBVSxJQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sUUFBUTtHQUMvSDtHQUNBLE1BQU0sS0FBSztJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1A7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBSSxLQUFLLFVBQVU7R0FDbEIsTUFBTSxjQUFjLFVBQVUsS0FBSyxLQUFLLFFBQVE7R0FDaEQsS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUNuRCxNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQzlCLE1BQU0sS0FBSztLQUNWLE1BQU07S0FDTjtLQUNBLFNBQVM7S0FDVDtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsSUFBSSxDQUFDLGNBQWMsS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUN0RSxNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQzlCLE1BQU0sRUFBRSxRQUFRLFdBQVc7SUFDM0IsSUFBSSxVQUFVLFFBQVE7S0FDckIsTUFBTSxXQUFXLFFBQVEsZ0JBQWdCLE9BQU8sY0FBYyxLQUFLLFlBQVk7S0FDL0UsSUFBSSxVQUFVLENBQUMsU0FBUyxXQUFXLE1BQU0sR0FBRztLQUM1QyxJQUFJLFVBQVUsU0FBUyxRQUFRLFFBQVEsU0FBUyxTQUFTLE9BQU8sTUFBTSxJQUFJLE9BQU8sUUFBUTtJQUMxRjtJQUNBLE1BQU0sS0FBSztLQUNWLE1BQU07S0FDTixPQUFPLFFBQVE7S0FDZjtLQUNBO0tBQ0E7S0FDQSxXQUFXLFlBQVksYUFBYSxhQUFhLEtBQUs7S0FDdEQ7S0FDQTtJQUNELENBQUM7R0FDRjtFQUNEO0VBQ0EsSUFBSSxDQUFDLGdCQUFnQixLQUFLLFdBQVcsTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQzdGLE1BQU0sVUFBVSxLQUFLLFFBQVE7R0FDN0IsTUFBTSxFQUFFLFFBQVEsV0FBVztHQUMzQixJQUFJLFVBQVUsUUFBUTtJQUNyQixNQUFNLFdBQVcsUUFBUSxnQkFBZ0IsT0FBTyxjQUFjLEtBQUssWUFBWTtJQUMvRSxJQUFJLFVBQVUsQ0FBQyxTQUFTLFdBQVcsTUFBTSxHQUFHO0lBQzVDLElBQUksVUFBVSxTQUFTLFFBQVEsUUFBUSxTQUFTLFNBQVMsT0FBTyxNQUFNLElBQUksT0FBTyxRQUFRO0dBQzFGO0dBQ0EsTUFBTSxLQUFLO0lBQ1YsTUFBTTtJQUNOLE9BQU8sUUFBUTtJQUNmO0lBQ0E7SUFDQSxVQUFVLFdBQVcsYUFBYSxhQUFhLEtBQUs7SUFDcEQ7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBSSxDQUFDLGdCQUFnQixLQUFLLG1CQUFtQjtHQUM1QyxNQUFNLFFBQVEsS0FBSyxrQkFBa0IsSUFBSSxjQUFjLEtBQUssWUFBWSxDQUFDO0dBQ3pFLElBQUksT0FBTyxNQUFNLEtBQUs7SUFDckIsTUFBTTtJQUNOLE9BQU8sUUFBUTtJQUNmO0lBQ0EsU0FBUyxVQUFVLGFBQWEsYUFBYSxLQUFLO0lBQ2xEO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBSSxDQUFDLGdCQUFnQixLQUFLLFFBQVE7R0FDakMsTUFBTSxRQUFRLEtBQUssT0FBTyxJQUFJLElBQUk7R0FDbEMsSUFBSSxPQUFPLE1BQU0sS0FBSztJQUNyQixNQUFNO0lBQ04sT0FBTyxRQUFRO0lBQ2Y7SUFDQSxTQUFTLFVBQVUsYUFBYSxhQUFhLEtBQUs7SUFDbEQ7SUFDQTtJQUNBO0lBQ0E7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxJQUFJLEtBQUssVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3RFLE1BQU0sVUFBVSxLQUFLLFNBQVM7R0FDOUIsTUFBTSxLQUFLO0lBQ1YsTUFBTTtJQUNOO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Q0FDQSxJQUFJLFdBQVcsT0FBTztDQUN0QixJQUFJLFNBQVMsV0FBVztFQUN2QixJQUFJLGFBQWEsVUFBVTtFQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxPQUFPLEtBQUssY0FBYyxNQUFNLEVBQUUsQ0FBQztFQUNqRSxNQUFNLFFBQVEsZUFBZSxLQUFLLFNBQVMsTUFBTSxLQUFLLE1BQU0sVUFBVTtFQUN0RSxVQUFVLGNBQWMsT0FBTyxPQUFPLElBQUk7RUFDMUMsVUFBVSxVQUFVLFFBQVEsbUJBQW1CLEtBQUs7RUFDcEQsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxhQUFhLGFBQWEsT0FBTztDQUN6QyxPQUFPLE1BQU0sY0FBYyxRQUFRO0FBQ3BDO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUyxhQUFhO0NBQ25ELE9BQU8sWUFBWSxNQUFNLGNBQWMsS0FBSztBQUM3QztBQUNBLFNBQVMsb0JBQW9CLE1BQU0sT0FBTyxPQUFPO0NBQ2hELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtFQUNILENBQUMsV0FBVyxTQUFTLGNBQWMsTUFBTSxPQUFPLEtBQUs7Q0FDdEQsUUFBUTtFQUNQLE9BQU87Q0FDUjtDQUNBLE1BQU0sWUFBWTtDQUNsQixNQUFNLFVBQVU7Q0FDaEIsSUFBSSxDQUFDLE1BQU0sS0FBSyxPQUFPLE9BQU87Q0FDOUIsSUFBSTtFQUNILElBQUksTUFBTSxLQUFLLE1BQU0sU0FBUyxNQUFNLE9BQU8sT0FBTztDQUNuRCxRQUFRLENBQUM7Q0FDVCxPQUFPO0FBQ1I7QUFDQSxTQUFTLG9CQUFvQixNQUFNLE1BQU07Q0FDeEMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixPQUFPLEtBQUssVUFBVSxLQUFLLFdBQVcsS0FBSyxZQUFZLEtBQUssWUFBWSxLQUFLLFdBQVcsS0FBSyxZQUFZLEtBQUssYUFBYSxLQUFLLGFBQWEsS0FBSyxZQUFZLEtBQUssYUFBYSxLQUFLLGNBQWMsS0FBSyxlQUFlLEtBQUssS0FBSyxTQUFTLHVCQUF1QixLQUFLLEtBQUssU0FBUyx1QkFBdUIsS0FBSyxLQUFLLFNBQVMsd0JBQXdCLEtBQUssS0FBSyxTQUFTLHVCQUF1QixLQUFLLEtBQUssUUFBUSxLQUFLLEtBQUs7QUFDN1o7OztBQy9qQkEsU0FBUyx3QkFBd0I7Q0FDaEMsSUFBSTtFQUNILE9BQU87Q0FDUixRQUFRO0VBQ1A7Q0FDRDtBQUNEO0FBQ0EsSUFBTSxhQUFhO0FBQ25CLElBQU0scUJBQXFCLHNCQUFzQjtBQUNqRCxTQUFTLCtCQUErQjtDQUN2QyxJQUFJO0VBQ0gsT0FBTyxLQUFLLE1BQU0sb0JBQW9CLFFBQVEsNkJBQTZCLEtBQUssSUFBSTtDQUNyRixRQUFRO0VBQ1AsT0FBTyxDQUFDO0NBQ1Q7QUFDRDtBQUNBLElBQU0seUJBQXlDLDZDQUE2QjtBQUM1RSxJQUFNLCtCQUErQjs7Ozs7OztBQU9yQyxJQUFNLGtDQUFrQyxhQUFhO0NBQ3BELE9BQU8sU0FBUyxNQUFNLGFBQWEsU0FBUztBQUM3QztBQUNBLFNBQVMsNkJBQTZCLFNBQVM7Q0FDOUMsTUFBTSxTQUFTLFFBQVEsYUFBYSw0QkFBNEI7Q0FDaEUsSUFBSSxRQUFRLE9BQU8sSUFBSSw2QkFBNkIsSUFBSSxPQUFPO0NBQy9ELElBQUksV0FBVztDQUNmLElBQUksS0FBSztDQUNULElBQUk7Q0FDSixPQUFPLFNBQVMsR0FBRyxZQUFZO0VBQzlCLElBQUksUUFBUTtFQUNaLElBQUksVUFBVTtFQUNkLE9BQU8sVUFBVSxRQUFRLHdCQUF3QjtFQUNqRCxNQUFNLE9BQU8sR0FBRyxHQUFHLFVBQVUsYUFBYSxNQUFNO0VBQ2hELFdBQVcsV0FBVyxHQUFHLEtBQUssS0FBSyxhQUFhO0VBQ2hELEtBQUs7Q0FDTjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsaUNBQWlDLFFBQVEsU0FBUztDQUMxRCxNQUFNLFVBQVUsd0JBQXdCLFFBQVEsVUFBVSwrQkFBQSxDQUFnQyxPQUFPLGNBQWM7Q0FDL0csSUFBSSxDQUFDLFNBQVM7Q0FDZCxJQUFJLFFBQVEsSUFBSSxPQUFPLFFBQVEsSUFBSSw2QkFBNkIsSUFBSSxRQUFRLEdBQUc7Q0FDL0UsTUFBTSxVQUFVLFFBQVEsYUFBYTtDQUNyQyxJQUFJLENBQUMsU0FBUztDQUNkLE9BQU8sUUFBUSxZQUFZLFNBQVMscUJBQXFCLDZCQUE2QixPQUFPO0FBQzlGO0FBQ0EsSUFBSSxlQUFlO0FBQ25CLElBQU0scUJBQXFCO0FBQzNCLFNBQVMsV0FBVyxVQUFVO0NBQzdCLElBQUk7RUFDSCxPQUFPLE9BQU8sYUFBYSxhQUFhLFNBQVMsSUFBSSxTQUFTLGNBQWMsUUFBUTtDQUNyRixRQUFRLENBQUM7QUFDVjtBQUNBLFNBQVMsdUJBQXVCLHNCQUFzQjtDQUNyRCxNQUFNLDJCQUEyQixJQUFJLElBQUk7Q0FDekMsS0FBSyxNQUFNLFlBQVksc0JBQXNCO0VBQzVDLElBQUksYUFBYSxvQkFBb0I7RUFDckMsTUFBTSxVQUFVLFdBQVcsUUFBUTtFQUNuQyxJQUFJLFNBQVMsU0FBUyxJQUFJLE9BQU87Q0FDbEM7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLHVCQUF1QixRQUFRLE9BQU87Q0FDOUMsTUFBTSwrQkFBK0IsU0FBUyxPQUFPLFFBQVE7Q0FDN0QsTUFBTSxTQUFTLE9BQU87Q0FDdEIsSUFBSSw4QkFBOEIsT0FBTyxJQUFJO0NBQzdDLElBQWdCLE9BQU8sVUFBVTtDQUNqQyxNQUFNLFNBQVMsT0FBTyxRQUFRLDJCQUEyQjtDQUN6RCxNQUFNLHVDQUF1QyxJQUFJLElBQUk7Q0FDckQsTUFBTSxnQ0FBZ0MsZUFBZTtFQUNwRCxNQUFNLFdBQVcsdUJBQXVCLGdCQUFnQixDQUFDO0VBQ3pELEtBQUssTUFBTSxVQUFVLHNCQUFzQixJQUFJLFdBQVcsVUFBVSxTQUFTLHNCQUFzQjtHQUNsRztHQUNBO0VBQ0Q7T0FDSyxJQUFJLE9BQU8sYUFBYSxTQUFTLDZCQUE2QixNQUFNLEtBQUs7R0FDN0UsU0FBUyxPQUFPO0dBQ2hCLFNBQVMsT0FBTztFQUNqQjtDQUNEO0NBQ0EsSUFBSSxnQ0FBZ0MsQ0FBQyxPQUFPLEdBQUc7RUFDOUMsT0FBTyxJQUFJO0VBQ1gsZUFBZTtFQUNmLFFBQVEsb0JBQW9CO0VBQzVCLFNBQVMsaUJBQWlCLFdBQVcsVUFBVTtHQUM5QyxJQUFJLGNBQWM7R0FDbEIscUJBQXFCLElBQUksTUFBTSxNQUFNO0VBQ3RDLEdBQUcsSUFBSTtFQUNQLE9BQU8sVUFBVSxpQkFBaUIsVUFBVTtHQUMzQyxJQUFJLE1BQU0sY0FBYyw2QkFBNkIsT0FBTyxNQUFNLFlBQVksQ0FBQztHQUMvRSxxQkFBcUIsTUFBTTtFQUM1QixDQUFDO0VBQ0QsaUJBQWlCLGtCQUFrQjtHQUNsQyxRQUFRLG9CQUFvQjtHQUM1Qiw2QkFBNkIsT0FBTyxPQUFPLE9BQU8saUJBQWlCLElBQUksS0FBSyxPQUFPLE9BQU8sU0FBUyxJQUFJLENBQUMsQ0FBQztHQUN6RyxJQUFJO0lBQ0gsb0JBQW9CLFFBQVEsWUFBWSxLQUFLLFVBQVUsc0JBQXNCLENBQUM7R0FDL0UsUUFBUTtJQUNvQyxRQUFRLEtBQUssMkVBQTJFO0dBQ3BJO0VBQ0QsQ0FBQztFQUNELGlCQUFpQixhQUFhLFVBQVU7R0FDdkMsSUFBSSxNQUFNLFdBQVcsUUFBUSxvQkFBb0I7RUFDbEQsQ0FBQztDQUNGO0NBQ0EsSUFBSSxPQUFPLEdBQUc7Q0FDZCxPQUFPLElBQUk7Q0FDWCxPQUFPLFVBQVUsZUFBZSxVQUFVO0VBQ3pDLE1BQU0sV0FBVyxPQUFPLFFBQVE7RUFDaEMsTUFBTSx1QkFBdUIsT0FBTyxRQUFRO0VBQzVDLE1BQU0sb0JBQW9CLE9BQU87RUFDakMsTUFBTSxpQkFBaUIsT0FBTztFQUM5QixJQUFJO0VBQ0oscUJBQXFCLE1BQU07RUFDM0IsT0FBTyxJQUFJO0VBQ1gsT0FBTyxJQUFJO0VBQ1gsSUFBSSxPQUFPLE9BQU8sUUFBUSxzQkFBc0IsY0FBYyxDQUFDLE9BQU8sUUFBUSxrQkFBa0IsRUFBRSxVQUFVLE9BQU8sZUFBZSxDQUFDLEdBQUc7RUFDdEksTUFBTSxXQUFXLE9BQU8sTUFBTSxVQUFVO0VBQ3hDLE1BQU0sZUFBZSxNQUFNLGdCQUFnQixPQUFPLE1BQU0sWUFBWTtFQUNwRSxJQUFJLE9BQU8sS0FBSyxnQkFBZ0IsaUJBQWlCLFVBQVU7R0FDMUQsTUFBTSxxQkFBcUIsdUJBQXVCO0dBQ2xELElBQUksb0JBQW9CO0lBQ3ZCLElBQUksbUJBQW1CLHVCQUF1QjtJQUM5QyxLQUFLLE1BQU0sbUJBQW1CLG9CQUFvQjtLQUNqRCxJQUFJLG9CQUFvQixvQkFDbkI7VUFBQSxtQkFBbUI7S0FBQSxPQUNqQjtNQUNOLE1BQU0sVUFBVSxXQUFXLGVBQWU7TUFDMUMsSUFBSSxDQUFDLFNBQVM7TUFDZCxJQUFJLHFCQUFxQixzQkFBc0I7T0FDOUMsd0JBQXdCLHVCQUF1QixvQkFBb0I7T0FDbkUsSUFBSSxvQkFBb0IsSUFBSSxPQUFPLEdBQUc7TUFDdkM7S0FDRDtLQUNBLElBQUksQ0FBQyxrQkFBa0IsbUJBQW1CLHVCQUF1QixZQUFZLENBQUM7S0FDOUUsaUJBQWlCLHFCQUFxQixtQkFBbUI7SUFDMUQ7R0FDRDtFQUNEO0VBQ0EsZUFBZTtFQUNmLElBQUk7R0FDSCxNQUFNLE9BQU8sTUFBTSxXQUFXO0dBQzlCLE1BQU0sNEJBQTRCLE1BQU0sV0FBVyxNQUFNLCtCQUErQjtHQUN4RixJQUFJLGlCQUFpQjtHQUNyQixJQUFJLG1CQUFtQjtJQUN0QixJQUFJLENBQUMsUUFBUSxzQkFBc0Isd0JBQXdCLHVCQUF1QixvQkFBb0I7SUFDdEcsTUFBTSxvQkFBb0IsUUFBUSw2QkFBNkI7SUFDL0QsTUFBTSxpQkFBaUIsT0FBTyxJQUFJLHVCQUF1QixZQUFZLEtBQUs7SUFDMUUsSUFBSSxnQkFBZ0IsS0FBSyxNQUFNLG1CQUFtQixnQkFBZ0I7S0FDakUsTUFBTSxFQUFFLFNBQVMsWUFBWSxlQUFlO0tBQzVDLElBQUksb0JBQW9CLG9CQUFvQjtNQUMzQyxJQUFJLG1CQUFtQjtNQUN2QixTQUFTO09BQ1IsS0FBSztPQUNMLE1BQU07T0FDTjtNQUNELENBQUM7TUFDRCxpQkFBaUI7S0FDbEIsT0FBTztNQUNOLE1BQU0sVUFBVSxXQUFXLGVBQWU7TUFDMUMsSUFBSSxTQUFTO09BQ1osUUFBUSxhQUFhO09BQ3JCLFFBQVEsWUFBWTtPQUNwQixxQkFBcUIsT0FBTyxPQUFPO01BQ3BDO0tBQ0Q7SUFDRDtJQUNBLElBQUksQ0FBQyxNQUFNO0tBQ1YsTUFBTSxnQkFBZ0I7TUFDckIsS0FBSztNQUNMLE1BQU07TUFDTjtLQUNEO0tBQ0EsSUFBSSxDQUFDLGdCQUFnQixTQUFTLGFBQWE7S0FDM0MsSUFBSSxxQkFBcUIsS0FBSyxNQUFNLFdBQVcscUJBQXFCLFFBQVEsU0FBUyxhQUFhO0lBQ25HO0dBQ0Q7R0FDQSxJQUFJLENBQUMsa0JBQWtCLFFBQVEsMkJBQTJCLFNBQVMsZUFBZSxJQUFJLENBQUMsRUFBRSxlQUFlLHlCQUF5QjtFQUNsSSxVQUFVO0dBQ1QsZUFBZTtFQUNoQjtDQUNELENBQUM7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyS0EsU0FBUyxPQUFPLEtBQUssWUFBWSxRQUFRO0NBQ3hDLElBQUk7Q0FDSixLQUFLLE1BQU0sT0FBTyxLQUFLO0VBQ3RCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLElBQUksUUFBUSxLQUFLLEdBQUcsQ0FBQyxXQUFXLElBQUksZ0JBQWdCLEVBQUEsQ0FBRyxJQUFJLEtBQUssVUFBVSxHQUFHLENBQUM7Q0FDL0U7Q0FDQSxPQUFPLFNBQVMsT0FBTyxTQUFTLElBQUk7QUFDckM7Ozs7Ozs7OztBQVNBLFNBQVMsUUFBUSxLQUFLO0NBQ3JCLElBQUksQ0FBQyxLQUFLLE9BQU87Q0FDakIsSUFBSSxRQUFRLFNBQVMsT0FBTztDQUM1QixJQUFJLFFBQVEsUUFBUSxPQUFPO0NBQzNCLE9BQU8sQ0FBQyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sT0FBTyxNQUFNLENBQUMsTUFBTTtBQUNyRDs7Ozs7Ozs7O0FBU0EsU0FBUyxPQUFPLEtBQUs7Q0FDcEIsTUFBTSxlQUFlLElBQUksZ0JBQWdCLEdBQUc7Q0FDNUMsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJO0NBQ2pDLEtBQUssTUFBTSxDQUFDLEtBQUssVUFBVSxhQUFhLFFBQVEsR0FBRztFQUNsRCxNQUFNLGdCQUFnQixPQUFPO0VBQzdCLElBQUksaUJBQWlCLE1BQU0sT0FBTyxPQUFPLFFBQVEsS0FBSztPQUNqRCxJQUFJLE1BQU0sUUFBUSxhQUFhLEdBQUcsY0FBYyxLQUFLLFFBQVEsS0FBSyxDQUFDO09BQ25FLE9BQU8sT0FBTyxDQUFDLGVBQWUsUUFBUSxLQUFLLENBQUM7Q0FDbEQ7Q0FDQSxPQUFPO0FBQ1I7OztBQzlEQSxJQUFNLFlBQVk7O0FBRWxCLElBQU0scUJBQXFCLGdCQUFnQixLQUFLLEtBQUs7O0FBRXJELElBQU0seUJBQXlCLG9CQUFvQixLQUFLLFdBQVcsS0FBSyxLQUFLOzs7Ozs7Ozs7OztBQVc3RSxTQUFTLGdCQUFnQixRQUFRO0NBQ2hDLE1BQU0sZUFBZSxXQUFXLEtBQUs7Q0FDckMsUUFBUSxjQUFjO0VBQ3JCLElBQUksVUFBVSxPQUFPLEtBQUssWUFBWSxVQUFVLFVBQVUsQ0FBQztFQUMzRCxNQUFNLFFBQVEsT0FBTyxTQUFTO0VBQzlCLEtBQUssTUFBTSxPQUFPLE9BQU87R0FDeEIsTUFBTSxRQUFRLE1BQU07R0FDcEIsSUFBSSxPQUFPLFVBQVUsVUFBVTtJQUM5QixJQUFJLGdCQUFnQixDQUFDLFVBQVUsS0FBSyxLQUFLLEdBQUc7SUFDNUMsSUFBSTtLQUNILE1BQU0sT0FBTyxPQUFPLEtBQUs7SUFDMUIsU0FBUyxNQUFNLENBQUM7R0FDakI7RUFDRDtFQUNBLE9BQU87Q0FDUjtBQUNEOzs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxvQkFBb0IsV0FBVyxRQUFRO0NBQy9DLE1BQU0sZUFBZSxXQUFXLEtBQUs7Q0FDckMsU0FBUyxlQUFlLEtBQUs7RUFDNUIsSUFBSSxPQUFPLE9BQU8sUUFBUSxVQUFVLElBQUk7R0FDdkMsT0FBTyxVQUFVLEdBQUc7RUFDckIsU0FBUyxNQUFNLENBQUM7T0FDWCxJQUFJLFVBQVUsT0FBTyxRQUFRLFVBQVU7R0FDM0MsSUFBSSxnQkFBZ0IsQ0FBQyxVQUFVLEtBQUssR0FBRyxHQUFHLE9BQU87R0FDakQsSUFBSTtJQUNILE9BQU8sR0FBRztJQUNWLE9BQU8sVUFBVSxHQUFHO0dBQ3JCLFNBQVMsTUFBTSxDQUFDO0VBQ2pCO0VBQ0EsT0FBTztDQUNSO0NBQ0EsUUFBUSxXQUFXO0VBQ2xCLE1BQU0sWUFBWSxPQUFPLFFBQVEsY0FBYztFQUMvQyxPQUFPLFlBQVksSUFBSSxjQUFjO0NBQ3RDO0FBQ0Q7Ozs7QUM5REEsU0FBUyxnQkFBZ0IsVUFBVTtDQUNsQyxPQUFPO0VBQ04sUUFBUSxFQUFFLFVBQVU7R0FDbkIsS0FBSyxNQUFNLFdBQVcsVUFBVSxNQUFNLG9CQUFvQixTQUFTLEdBQUc7R0FDdEUsT0FBTztFQUNSO0VBQ0EsU0FBUyxFQUFFLFVBQVU7R0FDcEIsS0FBSyxJQUFJLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUssTUFBTSxxQkFBcUIsU0FBUyxJQUFJLEdBQUc7R0FDMUYsT0FBTztFQUNSO0NBQ0Q7QUFDRDs7QUFFQSxTQUFTLGdCQUFnQixVQUFVLGVBQWUsU0FBUztDQUMxRCxNQUFNLGtCQUFrQixTQUFTLFFBQVE7Q0FDekMsTUFBTSxxQkFBcUIsSUFBSTtDQUMvQixNQUFNLGdCQUFnQixnQkFBZ0IscUJBQXFCLG1CQUFtQixZQUFZO0NBQzFGLE1BQU0seUJBQXlCLEdBQUcsY0FBYztDQUNoRCxNQUFNLGtCQUFrQjtFQUN2QixRQUFRLEVBQUUsVUFBVTtHQUNuQixNQUFNLFdBQVcsZ0JBQWdCLElBQUksV0FBVyxJQUFJLFNBQVMsWUFBWTtHQUN6RSxJQUFJLGFBQWEsZUFBZSxJQUFJLFdBQVc7UUFDMUMsSUFBSSxTQUFTLFdBQVcsc0JBQXNCLEdBQUcsSUFBSSxXQUFXLElBQUksU0FBUyxNQUFNLG1CQUFtQixNQUFNO0dBQ2pILE9BQU87RUFDUjtFQUNBLFNBQVMsRUFBRSxVQUFVO0dBQ3BCLElBQUksV0FBVyxVQUFVLElBQUksa0JBQWtCLElBQUksVUFBVTtHQUM3RCxPQUFPO0VBQ1I7Q0FDRDtDQUNBLE9BQU8sVUFBVTtFQUNoQixRQUFRLEVBQUUsVUFBVSxvQkFBb0IsU0FBUyxnQkFBZ0IsTUFBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0VBQy9FLFNBQVMsRUFBRSxVQUFVLGdCQUFnQixPQUFPLEVBQUUsS0FBSyxxQkFBcUIsU0FBUyxHQUFHLEVBQUUsQ0FBQztDQUN4RixJQUFJO0FBQ0w7O0FBRUEsU0FBUyxvQkFBb0IsU0FBUyxLQUFLO0NBQzFDLE1BQU0sTUFBTSxTQUFTLFFBQVEsRUFBRSxJQUFJLENBQUM7Q0FDcEMsSUFBSSxLQUFLO0VBQ1IsSUFBSSxPQUFPLFFBQVEsVUFBVSxPQUFPLElBQUksSUFBSSxHQUFHO09BQzFDLElBQUksZUFBZSxLQUFLLE9BQU87Q0FDckM7Q0FDQSxPQUFPO0FBQ1I7O0FBRUEsU0FBUyxxQkFBcUIsU0FBUyxLQUFLO0NBQzNDLE1BQU0sTUFBTSxTQUFTLFNBQVMsRUFBRSxJQUFJLENBQUM7Q0FDckMsSUFBSSxLQUFLO0VBQ1IsSUFBSSxPQUFPLFFBQVEsVUFBVSxPQUFPLElBQUksSUFBSSxHQUFHO09BQzFDLElBQUksZUFBZSxLQUFLLE9BQU87Q0FDckM7Q0FDQSxPQUFPO0FBQ1I7Ozs7QUNwREEsU0FBUyw4QkFBOEIsY0FBYztDQUNwRCxJQUFJLFFBQVE7Q0FDWixPQUFPO0VBQ04sTUFBTTtHQUNMLE9BQU87RUFDUjtFQUNBLElBQUksZUFBZTtHQUNsQixRQUFRLGlCQUFpQixlQUFlLEtBQUs7RUFDOUM7Q0FDRDtBQUNEOztBQUVBLFNBQVMsK0JBQStCLE1BQU07Q0FDN0MsT0FBTyxFQUFFLE1BQU07RUFDZCxPQUFPLEtBQUs7Q0FDYixFQUFFO0FBQ0g7QUFDQSxTQUFTLG1CQUFtQixpQkFBaUIsUUFBUTtDQUNwRCxNQUFNLEVBQUUsb0JBQW9CLHFCQUFxQixVQUFVO0NBQzNELE1BQU0sMEJBQTBCLElBQUksSUFBSTtDQUN4QyxNQUFNLFNBQVMsbUJBQW1CLE1BQU07Q0FDeEMsTUFBTSxXQUFXLG1CQUFtQixlQUFlO0NBQ25ELE1BQU0sbUJBQW1CLG1CQUFtQixLQUFLLENBQUM7Q0FDbEQsTUFBTSxNQUFNLG1CQUFtQixDQUFDLENBQUM7Q0FDakMsTUFBTSxVQUFVLDBCQUEwQixJQUFJLElBQUksQ0FBQyxDQUFDLEtBQUssT0FBTyxRQUFRLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FDdEYsTUFBTSxVQUFVLDJCQUEyQjtFQUMxQyxRQUFRLE9BQU8sSUFBSTtFQUNuQixXQUFXLE9BQU8sSUFBSSxNQUFNO0VBQzVCLFNBQVMsUUFBUSxJQUFJO0VBQ3JCLFVBQVUsU0FBUyxJQUFJO0VBQ3ZCLGtCQUFrQixpQkFBaUIsSUFBSTtDQUN4QyxFQUFFO0NBQ0YsU0FBUyxjQUFjLFNBQVM7RUFDL0IsSUFBSSxhQUFhLFFBQVEsSUFBSSxPQUFPO0VBQ3BDLElBQUksQ0FBQyxZQUFZO0dBQ2hCLGFBQWEsbUJBQW1CLEtBQUssQ0FBQztHQUN0QyxRQUFRLElBQUksU0FBUyxVQUFVO0VBQ2hDO0VBQ0EsT0FBTztDQUNSO0NBQ0EsTUFBTSxRQUFRO0VBQ2I7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7Q0FDQSxTQUFTLFdBQVcsYUFBYTtFQUNoQyxNQUFNLGNBQWMsSUFBSSxJQUFJO0VBQzVCLE1BQU0sVUFBVSxZQUFZLEtBQUssVUFBVSxNQUFNLE9BQU87RUFDeEQsWUFBWTtHQUNYLElBQUksQ0FBQyxZQUFZLGFBQWEsT0FBTyxHQUFHLElBQUksSUFBSSxPQUFPO0dBQ3ZELEtBQUssTUFBTSxNQUFNLGFBQWEsSUFBSSxDQUFDLFFBQVEsU0FBUyxFQUFFLEdBQUcsUUFBUSxJQUFJLEVBQUUsQ0FBQyxDQUFDLFVBQVUsS0FBSyxDQUFDO0dBQ3pGLEtBQUssTUFBTSxhQUFhLGFBQWE7SUFDcEMsTUFBTSxhQUFhLGNBQWMsVUFBVSxPQUFPO0lBQ2xELElBQUksV0FBVyxJQUFJLE1BQU0sV0FBVyxXQUFXLElBQUksU0FBUztHQUM3RDtFQUNELENBQUM7Q0FDRjtDQUNBLE9BQU87QUFDUjs7O0FDbEVBLElBQUksZ0JBQWdCO0FBQ3BCLElBQUksZ0JBQWdCO0FBQ3BCLElBQUksb0JBQW9COzs7Ozs7Ozs7O0FBVXhCLElBQUkseUJBQXlCO0FBQzdCLFNBQVMsMEJBQTBCLEtBQUs7Q0FDdkMsTUFBTSxRQUFRLHVCQUF1QixLQUFLLEdBQUc7Q0FDN0MsT0FBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLE1BQU0sRUFBRSxDQUFDLE1BQU0sSUFBSTtBQUNuRDtBQUNBLFNBQVMsY0FBYyxNQUFNO0NBQzVCLElBQUksa0JBQWtCLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBSyxRQUFRLHFCQUFxQixjQUFjLFFBQVEsU0FBUyxTQUFTLElBQUksS0FBSyxtQkFBbUIsU0FBUyxDQUFDO0NBQ3pKLE9BQU8sMEJBQTBCLElBQUk7QUFDdEM7QUFDQSxTQUFTLGNBQWMsTUFBTTtDQUM1QixJQUFJLFdBQVcsS0FBSyxZQUFZO0NBQ2hDLE1BQU0sOEJBQThCLElBQUksSUFBSTtDQUM1QyxNQUFNLFVBQVUsV0FBVztFQUMxQixXQUFXLEtBQUssWUFBWTtFQUM1QixZQUFZLFNBQVMsZUFBZSxXQUFXO0dBQzlDO0dBQ0E7RUFDRCxDQUFDLENBQUM7Q0FDSDtDQUNBLE1BQU0scUJBQXFCLFdBQVc7RUFDckMsSUFBSSxLQUFLLHVCQUF1QixNQUFNLE9BQU8sTUFBTTtPQUM5QyxXQUFXLEtBQUssWUFBWTtDQUNsQztDQUNBLE1BQU0sZ0JBQWdCLE9BQU8sRUFBRSxNQUFNLGNBQWMsR0FBRyxpQkFBaUI7RUFDdEUsSUFBSSxjQUFjLGlCQUFpQixPQUFPO0dBQ3pDLEtBQUs7R0FDTDtFQUNEO0VBQ0EsTUFBTSxXQUFXLEtBQUssY0FBYyxLQUFLLENBQUM7RUFDMUMsTUFBTSxrQkFBa0IsV0FBVyxTQUFTLFVBQVUsV0FBVyxTQUFTO0VBQzFFLElBQUksT0FBTyxhQUFhLGVBQWUsU0FBUyxVQUFVLGlCQUFpQixLQUFLLE1BQU0sV0FBVyxVQUFVO0dBQzFHLE1BQU0sZUFBZSxVQUFVLFdBQVcsTUFBTSxXQUFXLEtBQUs7R0FDaEUsSUFBSSxNQUFNLFFBQVEsVUFBVTtJQUMzQixpQkFBaUI7SUFDakI7SUFDQSxRQUFRLFdBQVc7R0FDcEIsQ0FBQyxHQUFHO0lBQ0gsS0FBSyxZQUFZO0lBQ2pCO0dBQ0Q7RUFDRDtFQUNBLEtBQUs7Q0FDTjtDQUNBLE9BQU87RUFDTixJQUFJLFdBQVc7R0FDZCxPQUFPO0VBQ1I7RUFDQSxJQUFJLFNBQVM7R0FDWixPQUFPLEtBQUssVUFBVTtFQUN2QjtFQUNBO0VBQ0EsWUFBWSxPQUFPO0dBQ2xCLFlBQVksSUFBSSxFQUFFO0dBQ2xCLGFBQWE7SUFDWixZQUFZLE9BQU8sRUFBRTtHQUN0QjtFQUNEO0VBQ0EsT0FBTyxNQUFNLE9BQU8saUJBQWlCO0dBQ3BDLE1BQU0sZUFBZSxTQUFTLE1BQU07R0FDcEMsUUFBUSxrQkFBa0IsZUFBZSxHQUFHLEtBQUs7R0FDakQsY0FBYztJQUNiLFlBQVk7S0FDWCxLQUFLLFVBQVUsTUFBTSxLQUFLO0tBQzFCLE9BQU8sRUFBRSxNQUFNLE9BQU8sQ0FBQztJQUN4QjtJQUNBO0lBQ0EsTUFBTTtJQUNOO0lBQ0E7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxVQUFVLE1BQU0sT0FBTyxpQkFBaUI7R0FDdkMsTUFBTSxlQUFlLFNBQVMsTUFBTTtHQUNwQyxRQUFRLGtCQUFrQixjQUFjLEtBQUs7R0FDN0MsY0FBYztJQUNiLFlBQVk7S0FDWCxLQUFLLGFBQWEsTUFBTSxLQUFLO0tBQzdCLE9BQU8sRUFBRSxNQUFNLFVBQVUsQ0FBQztJQUMzQjtJQUNBO0lBQ0EsTUFBTTtJQUNOO0lBQ0E7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxLQUFLLE9BQU8saUJBQWlCO0dBQzVCLGNBQWM7SUFDYixZQUFZO0tBQ1gsS0FBSyxHQUFHLE9BQU8sY0FBYyxpQkFBaUIsS0FBSztLQUNuRCxrQkFBa0I7TUFDakIsTUFBTTtNQUNOO0tBQ0QsQ0FBQztJQUNGO0lBQ0E7SUFDQSxNQUFNO0dBQ1AsQ0FBQztFQUNGO0VBQ0EsT0FBTyxpQkFBaUI7R0FDdkIsY0FBYztJQUNiLFlBQVk7S0FDWCxLQUFLLEtBQUssY0FBYyxpQkFBaUIsS0FBSztLQUM5QyxrQkFBa0IsRUFBRSxNQUFNLE9BQU8sQ0FBQztJQUNuQztJQUNBO0lBQ0EsTUFBTTtHQUNQLENBQUM7RUFDRjtFQUNBLFVBQVUsaUJBQWlCO0dBQzFCLGNBQWM7SUFDYixZQUFZO0tBQ1gsS0FBSyxRQUFRLGNBQWMsaUJBQWlCLEtBQUs7S0FDakQsa0JBQWtCLEVBQUUsTUFBTSxVQUFVLENBQUM7SUFDdEM7SUFDQTtJQUNBLE1BQU07R0FDUCxDQUFDO0VBQ0Y7RUFDQSxpQkFBaUIsU0FBUyxNQUFNLG1CQUFtQjtFQUNuRCxhQUFhLFFBQVEsS0FBSyxXQUFXLEdBQUc7RUFDeEMsUUFBUSxZQUFZO0dBQ25CLElBQUksQ0FBQyxLQUFLLGFBQWEsYUFBYSxDQUFDO0dBQ3JDLE1BQU0sV0FBVyxLQUFLLGNBQWMsS0FBSyxDQUFDO0dBQzFDLEtBQUssWUFBWSxDQUFDLEdBQUcsVUFBVSxPQUFPLENBQUM7R0FDdkMsYUFBYTtJQUNaLE1BQU0sV0FBVyxLQUFLLGNBQWMsS0FBSyxDQUFDO0lBQzFDLEtBQUssY0FBYyxTQUFTLFFBQVEsTUFBTSxNQUFNLE9BQU8sQ0FBQztHQUN6RDtFQUNEO0VBQ0EsYUFBYSxLQUFLLFFBQVE7RUFDMUIsZUFBZSxLQUFLLFVBQVU7RUFDOUI7RUFDQSxvQkFBb0IsS0FBSyxjQUFjLEtBQUssQ0FBQztDQUM5QztBQUNEO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxPQUFPO0NBQ3hDLE1BQU0sTUFBTSxnQkFBZ0I7Q0FDNUIsT0FBTztFQUNOLEdBQUc7RUFDSDtFQUNBLFdBQVc7R0FDVixnQkFBZ0I7Q0FDbEI7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBUyxxQkFBcUIsTUFBTTtDQUNuQyxNQUFNLE1BQU0sTUFBTSxXQUFXLE9BQU8sYUFBYSxjQUFjLFNBQVMsS0FBSztDQUM3RSxNQUFNLG9CQUFvQixJQUFJLFFBQVE7Q0FDdEMsTUFBTSx1QkFBdUIsSUFBSSxRQUFRO0NBQ3pDLElBQUksV0FBVyxDQUFDO0NBQ2hCLE1BQU0scUJBQXFCO0NBQzNCLE1BQU0sZ0JBQWdCLGdCQUFnQixXQUFXO0NBQ2pELE1BQU0sY0FBYyxTQUFTLGNBQWMsTUFBTSxhQUFhLEtBQUssV0FBVyxJQUFJLElBQUksSUFBSTtDQUMxRixNQUFNLGdCQUFnQixNQUFNLHdCQUF3QixVQUFVLEdBQUcsSUFBSSxTQUFTLFdBQVcsSUFBSSxTQUFTLFNBQVMsSUFBSSxTQUFTLFFBQVEsSUFBSSxRQUFRLEtBQUs7Q0FDckosSUFBSSxDQUFDLElBQUksUUFBUSxPQUFPLGFBQWEsQ0FBQyxJQUFJLFFBQVEsT0FBTyxLQUFLO0VBQzdELE1BQU0sV0FBVyxnQkFBZ0I7RUFDakMsSUFBSSxRQUFRLGFBQWE7SUFDdkIsZ0JBQWdCO0dBQ2pCLEtBQUs7R0FDTCxXQUFXO0VBQ1osR0FBRyxFQUFFO0NBQ047Q0FDQSxJQUFJLGtCQUFrQixjQUFjO0NBQ3BDLElBQUk7Q0FDSixJQUFJLGNBQWM7Q0FDbEIsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxxQkFBcUI7Q0FDekIsSUFBSSx5QkFBeUI7Q0FDN0IsTUFBTSxvQkFBb0I7Q0FDMUIsSUFBSTtDQUNKLE1BQU0sY0FBYztFQUNuQixJQUFJLENBQUMsTUFBTTtFQUNYLFFBQVEscUJBQXFCO0VBQzdCLENBQUMsS0FBSyxLQUFLLElBQUksUUFBUSxZQUFZLElBQUksUUFBUSxhQUFBLENBQWMsS0FBSyxJQUFJLElBQUksS0FBSyxFQUFFO0VBQ2pGLFFBQVEscUJBQXFCO0VBQzdCLE9BQU8sS0FBSztFQUNaLG1CQUFtQixLQUFLO0NBQ3pCO0NBQ0EsTUFBTSxzQkFBc0IsUUFBUSxVQUFVLFVBQVU7RUFDdkQsTUFBTSxPQUFPLE1BQU0sYUFBYSxXQUFXLFFBQVEsSUFBSSxLQUFLO0VBQzVELE1BQU0sbUJBQW1CLENBQUMsQ0FBQztFQUMzQixJQUFJLENBQUMsa0JBQWtCLG1CQUFtQjtFQUMxQyxrQkFBa0IsVUFBVSxVQUFVLEtBQUs7RUFDM0MsT0FBTztHQUNOLFFBQVEsZ0JBQWdCO0dBQ3hCO0dBQ0EsT0FBTyxNQUFNO0VBQ2Q7RUFDQSxJQUFJLENBQUMsa0JBQWtCLHFCQUFxQixNQUFNLENBQUM7Q0FDcEQ7Q0FDQSxNQUFNLGFBQWEsU0FBUztFQUMzQixrQkFBa0IsY0FBYztFQUNoQyxRQUFRLE9BQU8sRUFBRSxLQUFLLENBQUM7Q0FDeEI7Q0FDQSxNQUFNLGlCQUFpQixZQUFZO0VBQ2xDLHlCQUF5QjtFQUN6QixJQUFJLGVBQWU7R0FDbEIsZ0JBQWdCO0dBQ2hCO0VBQ0Q7RUFDQSxNQUFNLGVBQWUsY0FBYztFQUNuQyxNQUFNLFFBQVEsYUFBYSxNQUFNLGlCQUFpQixnQkFBZ0IsTUFBTTtFQUN4RSxNQUFNLFlBQVksVUFBVTtFQUM1QixNQUFNLFNBQVMsVUFBVTtFQUN6QixNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVTtFQUN0QyxjQUFjO0VBQ2QsTUFBTSxTQUFTLE9BQU8sT0FBTyxTQUFTLFNBQVM7RUFDL0MsTUFBTSxTQUFTLE9BQU87R0FDckIsTUFBTTtHQUNOLE9BQU87RUFDUixJQUFJLEVBQUUsTUFBTSxTQUFTLFNBQVMsVUFBVTtFQUN4QyxJQUFJLG9CQUFvQixxQkFBcUI7T0FDeEM7R0FDSixNQUFNLFdBQVcsYUFBYTtHQUM5QixJQUFJLE9BQU8sYUFBYSxlQUFlLFNBQVMsUUFDMUM7U0FBQSxNQUFNLFdBQVcsVUFBVSxJQUFJLE1BQU0sUUFBUSxVQUFVO0tBQzNEO0tBQ0E7S0FDQTtJQUNELENBQUMsR0FBRztLQUNILGdCQUFnQjtLQUNoQixJQUFJLFFBQVEsR0FBRyxDQUFDLEtBQUs7S0FDckIsUUFBUSxPQUFPLE1BQU07S0FDckI7SUFDRDs7RUFFRjtFQUNBLGtCQUFrQixjQUFjO0VBQ2hDLFFBQVEsT0FBTyxNQUFNO0NBQ3RCO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTTtFQUM3QixJQUFJLHdCQUF3QjtHQUMzQix5QkFBeUI7R0FDekI7RUFDRDtFQUNBLElBQUksY0FBYztFQUNsQixNQUFNLFdBQVcsYUFBYTtFQUM5QixJQUFJLE9BQU8sYUFBYSxlQUFlLFNBQVMsUUFBUSxLQUFLLE1BQU0sV0FBVyxVQUFVO0dBQ3ZGLE1BQU0seUJBQXlCLFFBQVEsc0JBQXNCO0dBQzdELElBQUksMkJBQTJCLE1BQU07SUFDcEMsY0FBYztJQUNkO0dBQ0Q7R0FDQSxJQUFJLE9BQU8sMkJBQTJCLGNBQWMsdUJBQXVCLE1BQU0sTUFBTTtJQUN0RixjQUFjO0lBQ2Q7R0FDRDtFQUNEO0VBQ0EsSUFBSSxhQUFhO0dBQ2hCLEVBQUUsZUFBZTtHQUNqQixPQUFPLEVBQUUsY0FBYztFQUN4QjtDQUNEO0NBQ0EsTUFBTSxVQUFVLGNBQWM7RUFDN0I7RUFDQSxpQkFBaUIsSUFBSSxRQUFRO0VBQzdCLFlBQVksTUFBTSxVQUFVLG1CQUFtQixNQUFNLE1BQU0sS0FBSztFQUNoRSxlQUFlLE1BQU0sVUFBVSxtQkFBbUIsT0FBTyxNQUFNLEtBQUs7RUFDcEUsT0FBTyxrQkFBa0I7R0FDeEIsSUFBSSxlQUFlO0lBQ2xCLHFCQUFxQjtJQUNyQix5QkFBeUI7R0FDMUI7R0FDQSxPQUFPLElBQUksUUFBUSxLQUFLO0VBQ3pCO0VBQ0EsVUFBVSxrQkFBa0I7R0FDM0IsSUFBSSxlQUFlO0lBQ2xCLHFCQUFxQjtJQUNyQix5QkFBeUI7R0FDMUI7R0FDQSxJQUFJLFFBQVEsUUFBUTtFQUNyQjtFQUNBLEtBQUssR0FBRyxrQkFBa0I7R0FDekIsY0FBYztHQUNkLElBQUksZUFBZTtJQUNsQixxQkFBcUI7SUFDckIseUJBQXlCO0dBQzFCO0dBQ0EsSUFBSSxRQUFRLEdBQUcsQ0FBQztFQUNqQjtFQUNBLGFBQWEsU0FBUyxXQUFXLElBQUk7RUFDckM7RUFDQSxlQUFlO0dBQ2QsSUFBSSxRQUFRLFlBQVk7R0FDeEIsSUFBSSxRQUFRLGVBQWU7R0FDM0IsSUFBSSxvQkFBb0IsbUJBQW1CLGdCQUFnQixFQUFFLFNBQVMsS0FBSyxDQUFDO0dBQzVFLElBQUksb0JBQW9CLGVBQWUsY0FBYztFQUN0RDtFQUNBLGlCQUFpQjtHQUNoQixJQUFJLG9CQUFvQixvQkFBb0Isa0JBQWtCLGtCQUFrQjtFQUNqRjtFQUNBLGFBQWE7RUFDYixhQUFhO0VBQ2IscUJBQXFCO0NBQ3RCLENBQUM7Q0FDRCxRQUFRLDJCQUEyQixTQUFTO0VBQzNDLHlCQUF5QjtFQUN6QixJQUFJO0dBQ0gsT0FBTyxJQUFJLElBQUksTUFBTSxJQUFJLFNBQVMsT0FBTyxDQUFDLENBQUM7R0FDM0MseUJBQXlCLFdBQVcsS0FBSyxJQUFJLE1BQU0sQ0FBQyxLQUFLLFNBQVMsR0FBRyxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxPQUFPLElBQUksU0FBUyxLQUFLLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDL0gsUUFBUSxDQUFDO0NBQ1Y7Q0FDQSxJQUFJLGlCQUFpQixtQkFBbUIsZ0JBQWdCLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDekUsSUFBSSxpQkFBaUIsZUFBZSxjQUFjO0NBQ2xELElBQUksUUFBUSxZQUFZLFNBQVMsR0FBRyxNQUFNO0VBQ3pDLE1BQU0sTUFBTSxrQkFBa0IsTUFBTSxJQUFJLFNBQVMsSUFBSTtFQUNyRCxJQUFJLENBQUMsUUFBUSxvQkFBb0IsVUFBVSxNQUFNO0VBQ2pELE9BQU87Q0FDUjtDQUNBLElBQUksUUFBUSxlQUFlLFNBQVMsR0FBRyxNQUFNO0VBQzVDLE1BQU0sTUFBTSxxQkFBcUIsTUFBTSxJQUFJLFNBQVMsSUFBSTtFQUN4RCxJQUFJLENBQUMsUUFBUSxvQkFBb0IsVUFBVSxTQUFTO0VBQ3BELE9BQU87Q0FDUjtDQUNBLE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxrQkFBa0IsTUFBTTtDQUNoQyxNQUFNLE1BQU0sTUFBTSxXQUFXLE9BQU8sYUFBYSxjQUFjLFNBQVMsS0FBSztDQUM3RSxPQUFPLHFCQUFxQjtFQUMzQixRQUFRO0VBQ1IscUJBQXFCO0dBQ3BCLE1BQU0sWUFBWSxJQUFJLFNBQVMsS0FBSyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQztHQUN0RCxNQUFNLFdBQVcsVUFBVSxNQUFNO0dBQ2pDLE1BQU0sYUFBYSxJQUFJLFNBQVM7R0FDaEMsTUFBTSxjQUFjLFVBQVUsTUFBTSxDQUFDO0dBQ3JDLE9BQU8sVUFBVSxHQUFHLFdBQVcsYUFBYSxZQUFZLFdBQVcsSUFBSSxLQUFLLElBQUksWUFBWSxLQUFLLEdBQUcsT0FBTyxJQUFJLFFBQVEsS0FBSztFQUM3SDtFQUNBLGFBQWEsU0FBUyxHQUFHLElBQUksU0FBUyxXQUFXLElBQUksU0FBUyxPQUFPLEdBQUc7Q0FDekUsQ0FBQztBQUNGOzs7Ozs7QUFNQSxTQUFTLG9CQUFvQixPQUFPLEVBQUUsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLEdBQUc7Q0FDOUQsTUFBTSxVQUFVLEtBQUs7Q0FDckIsSUFBSSxRQUFRLEtBQUssZUFBZSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssY0FBYyxDQUFDLEdBQUcsUUFBUSxTQUFTLENBQUMsSUFBSSxRQUFRLFNBQVM7Q0FDaEgsTUFBTSxTQUFTLFFBQVEsS0FBSyxRQUFRLFVBQVUsa0JBQWtCLE9BQU8sS0FBSyxDQUFDLENBQUM7Q0FDOUUsTUFBTSxvQkFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTyxNQUFNO0NBQ2pFLElBQUksV0FBVyxDQUFDO0NBQ2hCLE1BQU0scUJBQXFCO0NBQzNCLE1BQU0sZ0JBQWdCLGdCQUFnQixXQUFXO0NBQ2pELE9BQU8sY0FBYztFQUNwQjtFQUNBLGlCQUFpQixRQUFRO0VBQ3pCLFlBQVksTUFBTSxVQUFVO0dBQzNCLFFBQVEsUUFBUSxRQUFRLFNBQVMsSUFBSSxRQUFRLElBQUksUUFBUTtHQUN6RCxPQUFPLFNBQVM7R0FDaEIsUUFBUSxTQUFTO0dBQ2pCLElBQUksUUFBUSxRQUFRLFNBQVMsR0FBRztJQUMvQixRQUFRLFNBQVMsUUFBUTtJQUN6QixPQUFPLFNBQVMsUUFBUTtHQUN6QjtFQUNEO0VBQ0EsZUFBZSxNQUFNLFVBQVU7R0FDOUIsT0FBTyxTQUFTO0dBQ2hCLFFBQVEsU0FBUztFQUNsQjtFQUNBLFlBQVk7R0FDWCxRQUFRLEtBQUssSUFBSSxRQUFRLEdBQUcsQ0FBQztFQUM5QjtFQUNBLGVBQWU7R0FDZCxRQUFRLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxTQUFTLENBQUM7RUFDL0M7RUFDQSxLQUFLLE1BQU07R0FDVixRQUFRLEtBQUssSUFBSSxLQUFLLElBQUksUUFBUSxHQUFHLENBQUMsR0FBRyxRQUFRLFNBQVMsQ0FBQztFQUM1RDtFQUNBLFlBQVk7RUFDWixhQUFhO0VBQ2IsYUFBYTtDQUNkLENBQUM7QUFDRjtBQXdDQSxTQUFTLFVBQVUsTUFBTSxPQUFPO0NBQy9CLE1BQU0sZ0JBQWdCLGNBQWMsSUFBSTtDQUN4QyxNQUFNLFlBQVksY0FBYyxRQUFRLEdBQUc7Q0FDM0MsTUFBTSxjQUFjLGNBQWMsUUFBUSxHQUFHO0NBQzdDLElBQUksQ0FBQyxPQUFPO0VBQ1gsTUFBTSxNQUFNLGdCQUFnQjtFQUM1QixRQUFRO0lBQ04sZ0JBQWdCO0dBQ2pCO0dBQ0EsV0FBVztFQUNaO0NBQ0Q7Q0FDQSxPQUFPO0VBQ04sTUFBTTtFQUNOLFVBQVUsY0FBYyxVQUFVLEdBQUcsWUFBWSxJQUFJLGNBQWMsSUFBSSxLQUFLLElBQUksV0FBVyxXQUFXLElBQUksWUFBWSxjQUFjLElBQUksY0FBYyxjQUFjLE1BQU07RUFDMUssTUFBTSxZQUFZLEtBQUssY0FBYyxVQUFVLFNBQVMsSUFBSTtFQUM1RCxRQUFRLGNBQWMsS0FBSyxjQUFjLE1BQU0sYUFBYSxjQUFjLEtBQUssS0FBSyxJQUFJLFNBQVMsSUFBSTtFQUNyRztDQUNEO0FBQ0Q7QUFDQSxTQUFTLGtCQUFrQjtDQUMxQixRQUFRLEtBQUssT0FBTyxJQUFJLEVBQUEsQ0FBRyxTQUFTLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQztBQUNwRDs7O0FDcGNBLFNBQVMsY0FBYyxLQUFLLFFBQVE7Q0FDbkMsT0FBTyxJQUFJLGFBQWEsV0FBVyxJQUFJLGFBQWEsWUFBWSxJQUFJLFdBQVcsVUFBVSxDQUFDLENBQUMsSUFBSSxZQUFZLENBQUMsQ0FBQyxJQUFJO0FBQ2xIO0FBQ0EsU0FBUyxXQUFXLEtBQUs7Q0FDeEIsT0FBTyxJQUFJLFdBQVcsSUFBSSxTQUFTLElBQUk7QUFDeEM7QUFDQSxTQUFTLGVBQWUsT0FBTztDQUM5QixPQUFPLE1BQU0sUUFBUSxVQUFVLE1BQU0sUUFBUSxjQUFjLE1BQU0sVUFBVSxNQUFNLFFBQVEsV0FBVyxXQUFXLE1BQU0sUUFBUSxrQkFBa0I7QUFDaEo7Ozs7O0FBS0EsU0FBUyxzQkFBc0IsS0FBSztDQUNuQyxJQUFJLGVBQWUsT0FBTztFQUN6QixNQUFNLE1BQU07R0FDWCxNQUFNLElBQUk7R0FDVixTQUFTLElBQUk7RUFDZDtFQUM0QyxJQUFJLFFBQVEsSUFBSTtFQUM1RCxPQUFPO0NBQ1I7Q0FDQSxPQUFPLEVBQUUsTUFBTSxJQUFJO0FBQ3BCOzs7OztBQVdBLFNBQVMsc0JBQXNCLFVBQVUsa0JBQWtCO0NBQzFELE9BQU87RUFDTixjQUFjO0VBQ2QsWUFBWTtFQUNaLGFBQWEsa0JBQWtCLGFBQWEsU0FBUztFQUNyRCxhQUFhLGtCQUFrQixTQUFTLFNBQVM7RUFDakQsYUFBYSxrQkFBa0IsU0FBUyxTQUFTO0NBQ2xEO0FBQ0Q7Ozs7OztBQU1BLFNBQVMscUJBQXFCLEVBQUUsS0FBSyxNQUFNLFdBQVcsU0FBUyxhQUFhLFdBQVcsNkJBQTZCLGFBQWEsR0FBRyxTQUFTO0NBQzVJLE9BQU87QUFDUjtBQUNBLFNBQVMsYUFBYSxTQUFTO0NBQzlCLE9BQU8sUUFBUSxXQUFXLFVBQVUsTUFBTSxXQUFXLFdBQVcsTUFBTSxXQUFXLGNBQWMsTUFBTSxTQUFTLElBQUk7QUFDbkg7O0FBRUEsU0FBUyxrQkFBa0IsUUFBUSxVQUFVLFNBQVMsYUFBYSxTQUFTLE9BQU87Q0FDbEYsSUFBSSxhQUFhLFdBQVcsU0FBUyxNQUFNLEdBQUcsV0FBVztDQUN6RCxJQUFJLFNBQVMsVUFBVSxRQUFRLE1BQU0sR0FBRyxPQUFPO0NBQy9DLEtBQUssTUFBTSxTQUFTLFVBQVU7RUFDN0IsSUFBSSxTQUFTLE9BQU8sUUFBUSxPQUFPO0VBQ25DLElBQUksQ0FBQyxRQUFRLE1BQU0sY0FBYyxVQUFVLFlBQVksTUFBTSxPQUFPLEdBQUcsT0FBTyxXQUFXLE1BQU0sUUFBUSxDQUFDLFFBQVEsVUFBVSxLQUFLO0NBQ2hJO0NBQ0EsS0FBSyxNQUFNLFNBQVMsU0FBUztFQUM1QixJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU87RUFDbkMsT0FBTyxXQUFXLE1BQU0sUUFBUSxDQUFDLFFBQVEsU0FBUyxNQUFNLGNBQWMsVUFBVSxZQUFZLE1BQU0sT0FBTyxJQUFJLFdBQVcsVUFBVSxHQUFHLEtBQUs7Q0FDM0k7QUFDRDs7Ozs7Ozs7OztBQVVBLElBQUksYUFBYSxNQUFNOzs7O0NBSXRCLFlBQVksU0FBUyxnQkFBZ0I7RUFDcEMsS0FBSyxrQkFBa0IsR0FBRyxLQUFLLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRztFQUN4RCxLQUFLLFVBQVUsRUFBRSxHQUFHLEtBQUs7RUFDekIsS0FBSyw4QkFBOEIsSUFBSSxJQUFJO0VBQzNDLEtBQUsseUJBQXlCLElBQUksSUFBSTtFQUN0QyxLQUFLLGFBQWEsQ0FBQztFQUNuQixLQUFLLGtCQUFrQixPQUFPLE9BQU87R0FDcEMsR0FBRztHQUNILE9BQU87RUFDUjtFQUNBLEtBQUssVUFBVSxlQUFlO0dBRTVCLElBQUksV0FBVyxlQUFlLFFBQVEsS0FBSywrTUFBK007R0FFM1AsTUFBTSxjQUFjLEtBQUs7R0FDekIsS0FBSyxVQUFVO0lBQ2QsR0FBRztJQUNILEdBQUc7R0FDSjtHQUNBLEtBQUssV0FBVyxLQUFLLFFBQVEsWUFBQSxLQUFBLEtBQXdCLE9BQU8sYUFBYTtHQUN6RSxJQUFJLENBQWMsS0FBSyxVQUFXLEtBQUssa0NBQWtDLElBQUksUUFBUTtHQUNyRixLQUFLLG9CQUFvQixJQUFJLElBQUksS0FBSyxRQUFRLGlCQUFpQjtHQUMvRCxJQUFJLENBQUMsS0FBSyxXQUFXLEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUSxZQUFZLEtBQUssU0FBUyxJQUFJLENBQUMsS0FBSyxRQUFRLFNBQ2pHO1FBQUEsQ0FBYyxLQUFLLFVBQVcsS0FBSyxVQUFVLHFCQUFxQjtHQUFBLE9BQ2hFLEtBQUssVUFBVSxLQUFLLFFBQVE7R0FDbkMsS0FBSyxTQUFTLEtBQUssUUFBUTtHQUMzQixJQUFJLENBQUMsS0FBSyxRQUFRLElBQUksQ0FBYyxLQUFLLFlBQWEsUUFBUSxVQUFVLE9BQU8sV0FBVyxRQUFRLEtBQUssU0FBUyxPQUFPO1FBQ2xILEtBQUssU0FBUztHQUNuQixNQUFNLGVBQWUsS0FBSyxRQUFRLFlBQVk7R0FDOUMsTUFBTSxvQkFBb0IsS0FBSyxRQUFRO0dBQ3ZDLE1BQU0saUJBQWlCLEtBQUssYUFBYSxnQkFBZ0IsYUFBYSxZQUFZLHFCQUFxQixhQUFhLGtCQUFrQixLQUFLLFFBQVE7R0FDbkosSUFBSSxnQkFBZ0I7SUFDbkIsS0FBSyxXQUFXO0lBQ2hCLEtBQUssVUFBVSxpQkFBaUIsT0FBTyxTQUFTLFlBQVksSUFBSSxnQkFBZ0IsY0FBYyxLQUFLLFFBQVEsZUFBZSxpQkFBaUIsSUFBSTtHQUNoSjtHQUNBLElBQUksS0FBSyxTQUFTLEtBQUsscUJBQXFCO0dBQzVDLElBQUksS0FBSyxRQUFRLGNBQWMsS0FBSyxhQUEwQixLQUFLLFlBQWEsYUFBYSxrQkFBa0IsS0FBSyxRQUFRLGVBQWU7SUFDMUksS0FBSyxZQUFZLEtBQUssUUFBUTtJQUM5QixJQUFJO0lBR0gseUJBQXlCLEtBQUssZUFBZTtJQU85QyxLQUFLLFVBQVUsc0JBQXNCO0dBQ3RDO0dBQ0EsSUFBSSxDQUFDLEtBQUssUUFDTDtRQUFBLEtBQUssZ0JBQWdCO0tBQ3hCLE1BQU0sU0FBUyxLQUFLLGVBQWUsSUFBSTtLQUN2QyxLQUFLLFFBQVEsT0FBTztLQUNwQixLQUFLLFNBQVMsbUJBQW1CLEtBQUssZ0JBQWdCLE1BQU07S0FDNUQsSUFBSSxDQUFjLEtBQUssVUFBVyx1QkFBdUIsSUFBSTtJQUM5RDtVQUNNLElBQUksZ0JBQWdCLEtBQUssT0FBTyxTQUFTLElBQUksS0FBSyxjQUFjO0VBQ3hFO0VBQ0EsS0FBSyw2QkFBNkI7R0FDakMsS0FBSyxpQkFBaUIsS0FBSyxjQUFjLEtBQUssUUFBUSxVQUFVLEtBQUssY0FBYztFQUNwRjtFQUNBLEtBQUssdUJBQXVCO0dBQzNCLE1BQU0sU0FBUyxpQkFBaUIsS0FBSyxXQUFXLEtBQUssUUFBUSxhQUFhO0dBQzFFLElBQUksS0FBSyxRQUFRLFlBQVksa0JBQWtCLEtBQUssUUFBUSxZQUFZLE9BQU8sYUFBYTtHQUM1RixPQUFPO0lBQ04sR0FBRztJQUNILGtCQUFrQixpQkFBaUIsR0FBRztHQUN2QztFQUNEO0VBQ0EsS0FBSyxhQUFhLFdBQVcsT0FBTztHQUNuQyxNQUFNLFdBQVc7SUFDaEI7SUFDQTtHQUNEO0dBQ0EsS0FBSyxZQUFZLElBQUksUUFBUTtHQUM3QixhQUFhO0lBQ1osS0FBSyxZQUFZLE9BQU8sUUFBUTtHQUNqQztFQUNEO0VBQ0EsS0FBSyxRQUFRLGdCQUFnQjtHQUM1QixLQUFLLE1BQU0sWUFBWSxLQUFLLGFBQWEsSUFBSSxTQUFTLGNBQWMsWUFBWSxNQUFNLElBQUk7SUFDekYsU0FBUyxHQUFHLFdBQVc7R0FDeEIsU0FBUyxHQUFHO0lBQ1gsUUFBUSxNQUFNLENBQUM7R0FDaEI7RUFDRDtFQUNBLEtBQUssaUJBQWlCLGlCQUFpQixxQkFBcUI7R0FDM0QsTUFBTSxTQUFTLEVBQUUsVUFBVSxRQUFRLE1BQU0sUUFBUSxVQUFVO0lBQzFELElBQUksQ0FBQyxLQUFLLFdBQVcsQ0FBQyxnQ0FBZ0MsS0FBSyxRQUFRLEdBQUc7S0FDckUsTUFBTSxlQUFlLEtBQUssUUFBUSxZQUFZLE1BQU07S0FDcEQsTUFBTSxZQUFZLEtBQUssUUFBUSxnQkFBZ0IsWUFBWTtLQUMzRCxPQUFPO01BQ04sTUFBTSxXQUFXLFlBQVk7TUFDN0IsWUFBWSxXQUFXLFlBQVk7TUFDbkMsVUFBVSxXQUFXLFFBQVE7TUFDN0IsVUFBVTtNQUNWO01BQ0EsUUFBUSxxQkFBcUIsa0JBQWtCLFFBQVEsWUFBWTtNQUNuRSxNQUFNLFdBQVcsS0FBSyxNQUFNLENBQUMsQ0FBQztNQUM5QixPQUFPLGlCQUFpQixrQkFBa0IsT0FBTyxLQUFLO0tBQ3ZEO0lBQ0Q7SUFDQSxNQUFNLE1BQU0sb0JBQW9CLEtBQUssU0FBUyxJQUFJLElBQUksTUFBTSxLQUFLLE1BQU0sQ0FBQztJQUN4RSxNQUFNLGVBQWUsS0FBSyxRQUFRLFlBQVksSUFBSSxNQUFNO0lBQ3hELE1BQU0sWUFBWSxLQUFLLFFBQVEsZ0JBQWdCLFlBQVk7SUFDM0QsSUFBSSxTQUFTO0lBQ2IsT0FBTztLQUNOLE1BQU0sSUFBSSxLQUFLLFFBQVEsSUFBSSxRQUFRLEVBQUU7S0FDckMsWUFBWTtLQUNaLFVBQVUsV0FBVywwQkFBMEIsSUFBSSxRQUFRLENBQUM7S0FDNUQsVUFBVSxDQUFDLENBQUMsS0FBSyxXQUFXLGNBQWMsS0FBSyxLQUFLLE1BQU07S0FDMUQ7S0FDQSxRQUFRLHFCQUFxQixrQkFBa0IsUUFBUSxZQUFZO0tBQ25FLE1BQU0sV0FBVyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUM7S0FDbEMsT0FBTyxpQkFBaUIsa0JBQWtCLE9BQU8sS0FBSztJQUN2RDtHQUNEO0dBQ0EsTUFBTSxXQUFXLE1BQU0saUJBQWlCLGdCQUFnQixLQUFLO0dBQzdELE1BQU0sRUFBRSxnQkFBZ0IsY0FBYyxTQUFTO0dBQy9DLElBQUksbUJBQW1CLENBQUMsYUFBYSxjQUFjLEtBQUssa0JBQWtCO0lBQ3pFLE1BQU0scUJBQXFCLE1BQU0sZ0JBQWdCO0tBQ2hELEdBQUcsZUFBZTtLQUNsQixnQkFBZ0IsS0FBSztLQUNyQixLQUFLLFNBQVMsTUFBTTtLQUNwQixXQUFXLFNBQVMsTUFBTTtJQUMzQixDQUFDO0lBQ0QsbUJBQW1CLGlCQUFpQjtJQUNwQyxPQUFPO0dBQ1I7R0FDQSxPQUFPO0VBQ1I7RUFDQSxLQUFLLGVBQWUsZ0JBQWdCLHNCQUFzQixTQUFTO0dBQ2xFLElBQUksT0FBTyxtQkFBbUIsVUFBVSxPQUFPLEtBQUssb0JBQW9CO0lBQ3ZFLFVBQVU7SUFDVixRQUFRO0dBQ1QsR0FBRyxJQUFJO0dBQ1AsT0FBTyxLQUFLLG9CQUFvQixnQkFBZ0Isb0JBQW9CO0VBQ3JFO0VBQ0EsS0FBSyxvQkFBb0IsYUFBYTtHQUNyQyxNQUFNLFlBQVksT0FBTyxPQUFPLElBQUk7R0FDcEMsTUFBTSxRQUFRLGVBQWUsY0FBYyxRQUFRLEdBQUcsS0FBSyxlQUFlLElBQUk7R0FDOUUsSUFBSSxPQUFPLE9BQU8sT0FBTyxXQUFXLE1BQU0sU0FBUztHQUNuRCxPQUFPO0lBQ04sT0FBTyxVQUFVLENBQUMsS0FBSyxXQUFXLFdBQVc7SUFDN0M7SUFDQSxPQUFPO0dBQ1I7RUFDRDtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsSUFBSSxDQUFjLEtBQUssVUFBVztJQUNqQyxNQUFNLFNBQVMsS0FBSyxnQkFBZ0IsSUFBSSxJQUFJO0lBQzVDLElBQUksUUFBUSxPQUFPO0dBQ3BCO0dBQ0EsSUFBSSxjQUFjO0dBQ2xCLE1BQU0sU0FBUyxPQUFPLENBQUMsTUFBTTtJQUM1QixJQUFJLEtBQUssTUFBTTtLQUNkLE1BQU0sU0FBUyxVQUFVLEtBQUssTUFBTSxDQUFDLENBQUM7S0FDdEMsT0FBTztNQUNOLEdBQUc7TUFDSCxJQUFJLG9CQUFvQixLQUFLLFNBQVMsSUFBSSxJQUFJLE9BQU8sVUFBVSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFDN0UsUUFBUSxLQUFLLFFBQVEsWUFBWSxPQUFPLE1BQU07TUFDOUMsTUFBTSxPQUFPLEtBQUssTUFBTSxDQUFDO0tBQzFCO0lBQ0Q7SUFDQSxNQUFNLGtCQUFrQixLQUFLLGlCQUFpQixLQUFLLG9CQUFvQixLQUFLO0lBQzVFLElBQUk7SUFDSixNQUFNLGdCQUFnQjtLQUNyQixjQUFjO0tBQ2QsT0FBTztJQUNSO0lBQ0EsTUFBTSxxQkFBcUI7S0FDMUIsY0FBYztLQUNkLE9BQU8sZ0JBQWdCLEtBQUssdUJBQXVCLGVBQWU7SUFDbkU7SUFDQSxJQUE2QyxLQUFLLFFBQVEsS0FBSyxhQUFhO0tBQzNFLE1BQU0sQ0FBQyxrQkFBa0IsS0FBSyxpQkFBaUIsS0FBSyxJQUFJO0tBQ3hELE1BQU0sQ0FBQyxlQUFlLFlBQVksYUFBYTtLQUMvQyxNQUFNLGNBQWMsU0FBUyxnQkFBZ0IsTUFBTTtNQUNsRCxPQUFPLGFBQWEsRUFBRSxVQUFVLEtBQUssSUFBSTtLQUMxQyxDQUFDO0tBQ0QsTUFBTSxpQkFBaUIsU0FBUyxpQkFBaUIsTUFBTTtNQUN0RCxPQUFPLGFBQWEsRUFBRSxVQUFVLFFBQVE7S0FDekMsQ0FBQztLQUNELElBQUksQ0FBQyxlQUFlLENBQUMsZ0JBQWdCLFFBQVEsS0FBSyxrQ0FBa0MsS0FBSyxNQUFNO0lBQ2hHO0lBQ0EsTUFBTSxLQUFLLEtBQUssS0FBSyxHQUFHLEtBQUssT0FBTztJQUNwQyxNQUFNLFNBQVMsWUFBWSxHQUFHLE9BQU8sTUFBTSxLQUFLLEtBQUssbUJBQW1CLFNBQVMsUUFBUSxDQUFDLENBQUMsV0FBVyxLQUFLLFFBQVEsYUFBYSxDQUFDLENBQUMsSUFBSSxJQUFJLEtBQUssUUFBUSxlQUFlLEtBQUssZ0JBQWdCO0lBQzNMLE1BQU0sWUFBWSxLQUFLLGFBQWEsY0FBYyxNQUFNO0lBQ3hELE1BQU0sYUFBYSxPQUFPLFNBQVMsR0FBRztJQUN0QyxJQUFJO0lBQ0osSUFBSSxXQUFXLGFBQWEsVUFBVSxZQUFZLGlCQUFpQixTQUFTO1NBQ3ZFLElBQUksWUFBWSxhQUFhLENBQUM7U0FDOUI7S0FDSixNQUFNLENBQUMsZUFBZSxXQUFXLGNBQWMsS0FBSyxpQkFBaUIsTUFBTTtLQUMzRSxhQUFhO0tBQ2IsSUFBSSxLQUFLLFFBQVEsa0JBQWtCLENBQUMsY0FBYyxXQUFXLFNBQVMsT0FBTyxVQUFVLFFBQVEsYUFBYSxDQUFDLEdBQUcsWUFBWSxLQUFLLFFBQVEsYUFBYTtJQUN2SjtJQUNBLE1BQU0sZ0JBQWdCLGFBQWEsV0FBVyxrQkFBa0IsY0FBYyxPQUFPLEVBQUUsVUFBVSxPQUFPLEdBQUcsQ0FBQyxJQUFJLEtBQUs7SUFDckgsSUFBSTtJQUNKLEtBQUssTUFBTSxTQUFTLFlBQVk7S0FDL0IsTUFBTSxLQUFLLE1BQU0sUUFBUSxRQUFRLGFBQWEsTUFBTSxRQUFRO0tBQzVELElBQUksSUFBSTtNQUNQLE1BQU0sYUFBYSxhQUFhLENBQUMsQ0FBQztNQUNsQyxlQUFlLGtCQUFrQixLQUFLLFFBQVEsVUFBVTtNQUN4RCxJQUFJLENBQUMsUUFBUSxVQUFVLEdBQUc7TUFDMUIsSUFBSSxlQUFlLFlBQVksYUFBYSxPQUFPLE9BQU8sV0FBVyxHQUFHLFVBQVU7TUFDbEYsSUFBSTtPQUNILE9BQU8sT0FBTyxZQUFZLEdBQUcsVUFBVSxDQUFDO01BQ3pDLFFBQVEsQ0FBQztLQUNWO0lBQ0Q7SUFDQSxlQUFlLGtCQUFrQixLQUFLLFFBQVEscUJBQXFCLEtBQUssUUFBUSxhQUFhLElBQUksYUFBYSxDQUFDLENBQUMsS0FBSyxZQUFZO0lBQ2pJLE1BQU0sZUFBZSxLQUFLLGNBQWMsU0FBUywwQkFBMEIsV0FBVyxnQkFBZ0IsZ0JBQWdCLFFBQVEsZUFBZSxZQUFZLEtBQUssaUJBQWlCLElBQUksTUFBTSxDQUFDO0lBQzFMLElBQTZDLGFBQWEsQ0FBQyxLQUFLLGFBQWEsSUFBSTtLQUNoRixNQUFNLGFBQWEsS0FBSyxpQkFBaUIsWUFBWSxDQUFDLENBQUM7S0FDdkQsSUFBSSxZQUFZLE9BQU8sVUFBVSxJQUFJLFFBQVEsS0FBSyxtQkFBbUIsYUFBYSxlQUFlLFVBQVUsR0FBRyxtQkFBbUIsWUFBWSxHQUFHLG9NQUFvTTtJQUNyVixRQUFRLENBQUM7SUFDVCxNQUFNLGNBQWMscUJBQXFCLFlBQVksS0FBSyxzQkFBc0I7SUFDaEYsTUFBTSxtQkFBbUI7S0FDeEIsSUFBSSxTQUFTLGFBQWEsQ0FBQyxDQUFDO0tBQzVCLElBQUksS0FBSywwQkFBMEIsS0FBSyxRQUFRLFFBQVEsUUFBUTtNQUMvRCxNQUFNLGtCQUFrQixDQUFDO01BQ3pCLFdBQVcsU0FBUyxVQUFVO09BQzdCLElBQUksTUFBTSxRQUFRLGdCQUFnQixJQUFJO1FBQ3JDLE9BQU8sT0FBTyxpQkFBaUIsZUFBZSxNQUFNLFFBQVEsZ0JBQWdCO1NBQzNFLEdBQUc7U0FDSCxHQUFHO1FBQ0osQ0FBQyxDQUFDO09BQ0gsUUFBUSxDQUFDO01BQ1YsQ0FBQztNQUNELFNBQVM7S0FDVjtLQUNBLE9BQU87SUFDUjtJQUNBLE1BQU0sYUFBYSxZQUFZLFNBQVMsc0JBQXNCLGFBQWEsV0FBVyxHQUFHLElBQUksSUFBSSxLQUFLLFdBQVcsT0FBTyxXQUFXLElBQUksT0FBTyxLQUFLLFdBQVcsYUFBYSxLQUFLLE9BQU8sV0FBVyxDQUFDLElBQUksS0FBSyxVQUFVO0lBQ3ROLE1BQU0sWUFBWSxLQUFLLFFBQVEsZ0JBQWdCLFVBQVU7SUFDekQsTUFBTSxPQUFPLEtBQUssU0FBUyxPQUFPLFFBQVEsQ0FBQyxDQUFDLE9BQU8sT0FBTyxLQUFLLFNBQVMsYUFBYSxLQUFLLEtBQUssUUFBUSxDQUFDLENBQUMsSUFBSSxJQUFJLEtBQUssUUFBUSxLQUFLO0lBQ25JLE1BQU0sVUFBVSxPQUFPLElBQUksU0FBUztJQUNwQyxNQUFNLFlBQVksQ0FBQyxLQUFLLFFBQVEsZUFBZSxLQUFLLFVBQVUsT0FBTyxRQUFRLENBQUMsQ0FBQyxRQUFRLE9BQU8sS0FBSyxVQUFVLGFBQWEsS0FBSyxNQUFNLFFBQVEsQ0FBQyxDQUFDLEtBQUssSUFBSSxLQUFLO0lBQzdKLE1BQU0sV0FBVyxHQUFHLGVBQWUsWUFBWTtJQUMvQyxJQUFJO0lBQ0osSUFBSTtJQUNKLElBQUksV0FBVztJQUNmLElBQUksS0FBSyxTQUFTO0tBQ2pCLE1BQU0sTUFBTSxJQUFJLElBQUksVUFBVSxLQUFLLE1BQU07S0FDekMsTUFBTSxTQUFTLElBQUk7S0FDbkIsTUFBTSxlQUFlLHFCQUFxQixLQUFLLFNBQVMsR0FBRztLQUMzRCxPQUFPLFdBQVcsR0FBRztLQUNyQixJQUFJLGNBQWMsY0FBYyxNQUFNLEdBQUc7TUFDeEMsYUFBYSxhQUFhO01BQzFCLFdBQVc7S0FDWixPQUFPLGFBQWEsMEJBQTBCLFdBQVcsWUFBWSxDQUFDO0lBQ3ZFLE9BQU87S0FDTixPQUFPLGtCQUFrQixRQUFRO0tBQ2pDLGFBQWE7SUFDZDtJQUNBLE9BQU87S0FDTjtLQUNBO0tBQ0EsVUFBVTtLQUNWLFFBQVE7S0FDUjtLQUNBLE9BQU87S0FDUCxNQUFNLFFBQVE7S0FDZDtLQUNBLGdCQUFnQixLQUFLO0lBQ3RCO0dBQ0Q7R0FDQSxNQUFNLE9BQU8sTUFBTSxJQUFJO0dBQ3ZCLElBQUksS0FBSyxNQUFNLEtBQUssaUJBQWlCLE1BQU07SUFDMUMsTUFBTSxLQUFLO0lBQ1gsR0FBRyxLQUFLO0dBQ1QsQ0FBQztRQUNJLElBQUksS0FBSyxRQUFRLFlBQVk7SUFDakMsTUFBTSxRQUFRLGNBQWMsS0FBSyxVQUFVLEtBQUssYUFBYTtJQUM3RCxJQUFJLE9BQU87S0FDVixNQUFNLFNBQVMsT0FBTyxPQUFPLFdBQVcsR0FBRyxNQUFNLFNBQVM7S0FDMUQsTUFBTSxFQUFFLE1BQU0sT0FBTyxRQUFRLFlBQVksR0FBRyxjQUFjLE1BQU07S0FDaEUsTUFBTSxhQUFhLGtCQUFrQixZQUFZLE1BQU07S0FDdkQsS0FBSyxpQkFBaUIsTUFBTTtNQUMzQixNQUFNLEtBQUs7TUFDWCxHQUFHO01BQ0gsUUFBUTtLQUNULENBQUM7SUFDRjtHQUNEO0dBQ0EsSUFBSSxDQUFjLEtBQUssWUFBYSxDQUFDLGVBQWUsS0FBSyxpQkFBaUIsQ0FBQyxLQUFLLGdCQUFnQixLQUFLLGdCQUFnQixJQUFJLE1BQU0sSUFBSTtHQUNuSSxPQUFPO0VBQ1I7RUFDQSxLQUFLLGlCQUFpQixPQUFPLEVBQUUsZ0JBQWdCLGVBQWUsR0FBRyxXQUFXO0dBQzNFLElBQWdCLEtBQUssVUFBVTtHQUMvQixNQUFNLGVBQWUsS0FBSyxrQkFBa0I7R0FDNUMsSUFBSSxhQUFhLFlBQVksQ0FBYyxLQUFLLFVBQVcsT0FBTyxtQkFBbUIsTUFBTSxhQUFhLFlBQVk7SUFDbkgsU0FBUyxLQUFLO0lBQ2Q7R0FDRCxDQUFDO0dBQ0QsSUFBSTtHQUNKLE1BQU0saUJBQWlCLGNBQWMsS0FBSyxlQUFlLElBQUksTUFBTSxjQUFjLEtBQUssSUFBSSxLQUFLLFVBQVUscUJBQXFCLEtBQUssS0FBSyxHQUFHLHFCQUFxQixLQUFLLGVBQWUsS0FBSyxDQUFDO0dBQzFMLE1BQU0sd0JBQXdCLEtBQUs7R0FDbkMsSUFBSTtHQUNKLE1BQU0sZ0JBQWdCLElBQUksU0FBUyxTQUFTO0lBQzNDLFVBQVU7R0FDWCxDQUFDO0dBQ0QsY0FBYyxnQkFBZ0I7SUFDN0IsUUFBUTtJQUNSLHVCQUF1QixRQUFRO0dBQ2hDO0dBQ0EsS0FBSyxpQkFBaUI7R0FDdEIsSUFBSSxnQkFBZ0IsS0FBSyxLQUFLO1FBQ3pCO0lBQ0osSUFBSSxFQUFFLGdCQUFnQixvQkFBb0IsR0FBRyxnQkFBZ0I7SUFDN0QsSUFBSSxnQkFBZ0I7S0FDbkIsY0FBYztNQUNiLEdBQUc7TUFDSCxPQUFPO09BQ04sR0FBRyxlQUFlO09BQ2xCLFdBQVcsS0FBSztPQUNoQixnQkFBZ0I7UUFDZixHQUFHO1FBQ0gsUUFBUSxZQUFZO1FBQ3BCLE9BQU87U0FDTixHQUFHLFlBQVk7U0FDZixXQUFXLEtBQUs7U0FDaEIsZ0JBQWdCLEtBQUs7U0FDckIsV0FBVyxLQUFLO1NBQ2hCLEtBQUssS0FBSztRQUNYO09BQ0Q7TUFDRDtLQUNEO0tBQ0EsSUFBSSxZQUFZLGtCQUFrQixLQUFLLFFBQVEsa0JBQWtCLE9BQU8sWUFBWSxNQUFNLFlBQVksS0FBSztJQUM1RztJQUNBLFlBQVksUUFBUTtLQUNuQixHQUFHLFlBQVk7S0FDZiw2QkFBNkIsc0JBQXNCLEtBQUssUUFBUSw2QkFBNkI7SUFDOUY7SUFDQSxLQUFLLHVCQUF1QjtJQUM1QixnQkFBZ0IsS0FBSyxVQUFVLFlBQVk7SUFDM0MsS0FBSyxRQUFRLGtCQUFrQixZQUFZLFlBQVksT0FBTyxDQUFDLFlBQVksWUFBWSxZQUFZLE9BQU8sRUFBRSxjQUFjLENBQUM7SUFDM0gsSUFBSSxDQUFDLEtBQUssUUFBUSxZQUFZLE1BQU0sS0FBSyxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sY0FBYyxFQUFFLENBQUM7R0FDbEY7R0FDQSxLQUFLLFFBQVEsSUFBSSxLQUFLLGVBQWU7R0FDckMsT0FBTyxLQUFLO0VBQ2I7RUFDQSxLQUFLLDBCQUEwQixFQUFFLFNBQVMsYUFBYSxvQkFBb0IsZ0JBQWdCLGVBQWUsR0FBRyxTQUFTLENBQUMsTUFBTTtHQUM1SCxJQUFnQixLQUFLLFVBQVUsT0FBTyxRQUFRLFFBQVE7R0FDdEQsTUFBTSxXQUFXLEtBQUssY0FBYztJQUNuQyxHQUFHO0lBQ0gsd0JBQXdCO0dBQ3pCLENBQUM7R0FDRCxLQUFLLG1CQUFtQjtHQUN4QixNQUFNLGdCQUFnQixLQUFLLGVBQWU7SUFDekMsR0FBRztJQUNIO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7R0FDRCxDQUFDO0dBQ0QscUJBQXFCO0lBQ3BCLElBQUksS0FBSyxxQkFBcUIsVUFBVSxLQUFLLG1CQUFtQixLQUFLO0dBQ3RFLENBQUM7R0FDRCxPQUFPO0VBQ1I7RUFDQSxLQUFLLFdBQVcsT0FBTyxFQUFFLElBQUksZ0JBQWdCLE1BQU0sWUFBWSxHQUFHLFdBQVc7R0FDNUUsSUFBZ0IsS0FBSyxVQUFVO0dBQy9CLE1BQU0sYUFBYSxPQUFPLGFBQWEsSUFBSSxJQUFJLEtBQUs7R0FDcEQsSUFBSSxjQUFjLGdCQUFnQjtJQUNqQyxJQUFJLE9BQU8sS0FBSyxLQUFLLENBQUMsTUFBTTtLQUMzQixNQUFNLFdBQVcsS0FBSyxjQUFjO01BQ25DO01BQ0EsR0FBRztLQUNKLENBQUM7S0FDRCxNQUFNLGlCQUFpQixTQUFTLGtCQUFrQjtLQUNsRCxTQUFTLGVBQWU7S0FDeEIsZUFBZSxlQUFlO0lBQy9CO0lBQ0EsTUFBTSxhQUFhLENBQUMsY0FBYyxhQUFhLGFBQWE7SUFDNUQsT0FBTyxtQkFBbUIsTUFBTSxZQUFZLElBQUk7R0FDakQ7R0FDQSxPQUFPLEtBQUssdUJBQXVCO0lBQ2xDLEdBQUc7SUFDSDtJQUNBO0lBQ0EsYUFBYTtHQUNkLENBQUM7RUFDRjtFQUNBLEtBQUssT0FBTyxPQUFPLFNBQVM7R0FDM0IsSUFBZ0IsS0FBSyxVQUFVLE9BQU8sZ0JBQWdCLE1BQU0sSUFBSTtHQUNoRSxLQUFLLHFCQUFxQjtHQUMxQixJQUFJLE1BQU0sUUFBUSxLQUFLLFFBQVEsSUFBSSxLQUFLLE9BQU8sU0FBUyxVQUFVLEtBQUssT0FBTyxTQUFTO0dBQ3ZGLE1BQU0sZ0JBQWdCLE1BQU0sSUFBSTtFQUNqQztFQUNBLEtBQUssdUJBQXVCLE9BQU87R0FDbEMsTUFBTSx1QkFBdUIsS0FBSyx3QkFBd0IsS0FBSyxRQUFRO0dBQ3ZFLEtBQUssdUJBQXVCLEtBQUs7R0FDakMsSUFBSSx3QkFBd0IsRUFBYyxPQUFPLGFBQWEsZ0JBQWdCLE9BQU8sU0FBUyx3QkFBd0IsWUFBWTtJQUNqSSxJQUFJO0lBQ0osSUFBSSxPQUFPLHlCQUF5QixZQUFZLE9BQU8sS0FBSyxXQUFXLDJDQUEyQyxHQUFHO0tBQ3BILE1BQU0sT0FBTyxLQUFLO0tBQ2xCLE1BQU0sZUFBZSxLQUFLLE9BQU8saUJBQWlCLElBQUk7S0FDdEQsTUFBTSw4QkFBOEIsT0FBTyxxQkFBcUIsVUFBVSxhQUFhLHFCQUFxQixNQUFNLHNCQUFzQixNQUFNLFlBQVksQ0FBQyxJQUFJLHFCQUFxQjtLQUNwTCxJQUFJLGdDQUFnQyxPQUFPLE9BQU8sR0FBRztLQUNyRCw0QkFBNEI7TUFDM0IsUUFBUTtNQUNSLE9BQU87S0FDUjtJQUNELE9BQU8sNEJBQTRCO0lBQ25DLE9BQU8sU0FBUyxvQkFBb0IseUJBQXlCLENBQUMsQ0FBQztHQUNoRTtHQUNBLE9BQU8sR0FBRztFQUNYO0VBQ0EsS0FBSyxjQUFjLFNBQVM7R0FDM0IsTUFBTSxtQkFBbUIsS0FBSztHQUM5QixNQUFNLFNBQVMsTUFBTTtHQUNyQixNQUFNLFdBQVcsS0FBSztHQUN0QixNQUFNLDZCQUE2QixJQUFJLElBQUk7R0FDM0MsTUFBTSxZQUFZLFVBQVU7SUFDM0IsSUFBSSxDQUFDLFVBQVUsT0FBTyxLQUFLLEdBQUcsV0FBVyxJQUFJLE1BQU0sRUFBRTtHQUN0RDtHQUNBLGlCQUFpQixRQUFRLFFBQVE7R0FDakMsS0FBSyxPQUFPLFFBQVEsUUFBUTtHQUM1QixVQUFVLFNBQVMsWUFBWSxRQUFRLFFBQVEsUUFBUSxDQUFDO0dBQ3hELEtBQUssTUFBTSxFQUFFLENBQUMsUUFBUSxRQUFRO0dBQzlCLE1BQU0sUUFBUSxDQUFDO0dBQ2YsS0FBSyxNQUFNLENBQUMsWUFBWSxZQUFZLFlBQVksQ0FBQyxHQUFHLElBQUksUUFBUSxNQUFNLFVBQVUsV0FBVyxJQUFJLE1BQU0sRUFBRSxDQUFDLEdBQUc7SUFDMUcsU0FBUyxPQUFPLFVBQVU7SUFDMUIsTUFBTSxLQUFLLFVBQVU7R0FDdEI7R0FDQSxNQUFNLGNBQWMsTUFBTTtJQUN6QixJQUFJLFdBQVcsSUFBSSxFQUFFLEVBQUUsR0FBRztLQUN6QixNQUFNLFFBQVEsS0FBSyxXQUFXLEVBQUU7S0FDaEMsTUFBTSxPQUFPO01BQ1osR0FBRztNQUNILFNBQVM7TUFDVCxJQUFJLE1BQU0sZ0JBQWdCLEVBQUUsV0FBVyxXQUFXLEVBQUUsV0FBVyxlQUFlLGVBQWUsS0FBSyxJQUFJO09BQ3JHLFFBQVE7T0FDUixPQUFPLEtBQUs7TUFDYixJQUFJLEtBQUs7S0FDVjtLQUNBLEVBQUUsVUFBVSxLQUFLO0tBQ2pCLE9BQU87SUFDUjtJQUNBLE9BQU87R0FDUjtHQUNBLEtBQUssYUFBYSxpQkFBaUIsSUFBSSxVQUFVO0dBQ2pELEtBQUssTUFBTSxDQUFDLElBQUksVUFBVSxLQUFLLFFBQVEsSUFBSSxXQUFXLElBQUksRUFBRSxHQUFHO0lBQzlELE1BQU0sVUFBVTtJQUNoQixJQUFJLE1BQU0sY0FBYyxNQUFNLFNBQVM7R0FDeEM7R0FDQSxLQUFLLE1BQU0sTUFBTSxZQUFZO0lBQzVCLE1BQU0sU0FBUyxLQUFLLFVBQVUsSUFBSSxFQUFFO0lBQ3BDLEtBQUssVUFBVSxPQUFPLEVBQUU7SUFDeEIsSUFBSSxVQUFVLENBQUMsT0FBTyxJQUFJLE1BQU0sS0FBSyxPQUFPLEVBQUU7R0FDL0M7R0FDQSxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsTUFBTTtHQUNqRCxLQUFLLHVCQUF1QjtHQUM1QixPQUFPLEtBQUssS0FBSyxFQUFFLE1BQU0sTUFBTSxLQUFLLENBQUM7RUFDdEM7RUFDQSxLQUFLLG1CQUFtQixhQUFhO0dBQ3BDLE1BQU0sVUFBVSxTQUFTO0dBQ3pCLElBQUksT0FBTyxTQUFTLFFBQVEsSUFBSSxVQUFVLEtBQUssUUFBUTtHQUN2RCxJQUFJLENBQUMsTUFBTTtJQUNWLE1BQU0sV0FBVyxLQUFLLGNBQWMsT0FBTztJQUMzQyxRQUFRLFNBQVMsa0JBQWtCLFNBQUEsQ0FBVSxjQUFjO0dBQzVEO0dBQ0EsSUFBSTtHQUNKLElBQUksNEJBQTRCLEtBQUssSUFBSSxNQUFNLFNBQVMsYUFBYSxJQUFJLE1BQU0sQ0FBQyxLQUFLLGtCQUFrQixJQUFJLE1BQU0sR0FBRyxNQUFNLElBQUksTUFBOEMsOENBQThDLEtBQUssd0JBQXdCLE1BQU0sS0FBSyxLQUFLLGlCQUFpQixDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUUsRUFBd0M7R0FDN1UsSUFBSSxXQUFXLFdBQVcsV0FBVyxVQUFVO0lBQzlDLE1BQU0sTUFBTSxJQUFJLElBQUksSUFBSTtJQUN4QixJQUFJLElBQUksU0FBUyxXQUFXLElBQUksR0FBRyxPQUFPLElBQUk7U0FDekMsSUFBSSxDQUFDLGNBQWMsS0FBSyxLQUFLLE1BQU0sR0FBRztLQUMxQyxPQUFPLFdBQVcsR0FBRztLQUNyQixTQUFTLEtBQUs7SUFDZjtHQUNEO0dBQ0EsSUFBSSxRQUFRLFFBQVEsaUJBQWlCO0dBQ3JDLFFBQVEsT0FBTztHQUNmLFNBQVMsUUFBUSxJQUFJLFlBQVksSUFBSTtHQUNyQyxPQUFPO0VBQ1I7RUFDQSxLQUFLLGNBQWMsU0FBUztHQUMzQixNQUFNLFNBQVMsS0FBSztHQUNwQixNQUFNLFdBQVcsS0FBSztHQUN0QixNQUFNLFNBQVMsTUFBTTtHQUNyQixNQUFNLFlBQVksQ0FBQztHQUNuQixNQUFNLGVBQWUsQ0FBQztHQUN0QixLQUFLLE1BQU0sQ0FBQyxJQUFJLFVBQVUsUUFBUSxJQUFJLENBQUMsVUFBVSxPQUFPLEtBQUssR0FBRztJQUMvRCxhQUFhLEtBQUssRUFBRTtJQUNwQixVQUFVLEtBQUssS0FBSztHQUNyQjtHQUNBLE1BQU0sUUFBUSxDQUFDO0dBQ2YsS0FBSyxNQUFNLENBQUMsWUFBWSxZQUFZLFlBQVksQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLFFBQVEsS0FBSyxNQUFNLEdBQUc7SUFDeEYsTUFBTSxLQUFLLFVBQVU7SUFDckIsVUFBVSxLQUFLLEdBQUcsT0FBTztHQUMxQjtHQUNBLEtBQUssTUFBTSxNQUFNLGNBQWMsT0FBTyxPQUFPLEVBQUU7R0FDL0MsS0FBSyxNQUFNLGNBQWMsT0FBTyxTQUFTLE9BQU8sVUFBVTtHQUMxRCxLQUFLLE1BQU0sU0FBUyxXQUFXO0lBQzlCLE1BQU0sU0FBUyxNQUFNO0lBQ3JCLE1BQU0sVUFBVSxLQUFLO0lBQ3JCLElBQUksVUFBVSxDQUFDLEVBQUUsT0FBTyxJQUFJO0tBQzNCLElBQUksS0FBSyxVQUFVLElBQUksTUFBTSxFQUFFLE1BQU0sUUFBUSxLQUFLLFNBQVMsT0FBTyxNQUFNLEVBQUU7S0FDMUUsTUFBTSxLQUFLLE9BQU8sRUFBRTtJQUNyQjtHQUNEO0dBQ0EsS0FBSyxNQUFNLGNBQWMsT0FBTyxXQUFXLE1BQU07RUFDbEQ7RUFDQSxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLGdCQUFnQixTQUFTLG1CQUFtQixNQUFNLElBQUk7RUFDM0QsS0FBSyxjQUFjLFVBQVUsU0FBUztHQUNyQyxNQUFNLGdCQUFnQjtJQUNyQixHQUFHO0lBQ0gsSUFBSSxTQUFTLEtBQUssWUFBWSxTQUFTLFFBQVEsSUFBSSxTQUFTLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSSxLQUFLO0lBQzFILFFBQVEsU0FBUyxVQUFVLENBQUM7SUFDNUIsYUFBYTtHQUNkO0dBQ0EsTUFBTSxPQUFPLEtBQUssY0FBYyxhQUFhO0dBQzdDLE1BQU0sWUFBWSxLQUFLLE9BQU8sT0FBTyxJQUFJLE1BQU07R0FDL0MsSUFBSSxNQUFNLFdBQVcsQ0FBQyxXQUFXLE9BQU87R0FDeEMsTUFBTSxlQUFlLE1BQU0sV0FBVyxDQUFDLFlBQVksS0FBSyxpQkFBaUIsS0FBSyxPQUFPLGlCQUFpQixJQUFJLEtBQUssS0FBSyxPQUFPLFNBQVMsSUFBSTtHQUN4SSxNQUFNLFFBQVEsZ0JBQWdCLEtBQUssVUFBVSxNQUFNLGlCQUFpQixPQUFPLE1BQU0sU0FBUyxPQUFPLGFBQWEsVUFBVSxLQUFLLGFBQWE7R0FDMUksSUFBSSxDQUFDLE9BQU8sT0FBTztHQUNuQixJQUFJLFNBQVMsUUFDUjtRQUFBLENBQUMsVUFBVSxNQUFNLFdBQVcsU0FBUyxRQUFRLElBQUksR0FBRyxPQUFPO0dBQUE7R0FFaEUsSUFBSSxNQUFNLGlCQUFpQixNQUFNLE9BQU8sVUFBVSxhQUFhLFFBQVEsS0FBSyxRQUFRLElBQUksSUFBSSxNQUFNLFlBQVk7R0FDOUcsT0FBTyxNQUFNO0VBQ2Q7RUFDQSxLQUFLLGlCQUFpQjtFQUN0QixJQUFJLFFBQVEsNkJBQTZCLFFBQVEsS0FBSyxvQkFBb0IscUJBQXFCLFFBQVEsMkJBQTJCO0VBQ2xJLEtBQUssT0FBTztHQUNYLHFCQUFxQjtHQUNyQixrQkFBa0I7R0FDbEIscUJBQXFCO0dBQ3JCLFNBQVMsS0FBSztHQUNkLEdBQUc7R0FDSCxlQUFlLFFBQVEsaUJBQWlCO0dBQ3hDLGNBQWMsUUFBUSxnQkFBZ0I7R0FDdEMsaUJBQWlCLFFBQVEsbUJBQW1CO0dBQzVDLGFBQWEsUUFBUSxlQUFlO0dBQ3BDLG1CQUFtQixRQUFRLHFCQUFxQjtFQUNqRCxDQUFDO0VBQ0QsSUFBSSxFQUFjLE9BQU8sYUFBYSxjQUFjLEtBQUssaUJBQWlCO0NBQzNFO0NBQ0EsVUFBVTtFQUNULE9BQU8sQ0FBQyxDQUFDLEtBQUssUUFBUTtDQUN2QjtDQUNBLElBQUksUUFBUTtFQUNYLE9BQU8sS0FBSyxPQUFPLFFBQVEsSUFBSTtDQUNoQztDQUNBLFVBQVUsUUFBUTtFQUNqQixPQUFPLE9BQU8sTUFBTSxNQUFNO0VBQzFCLEtBQUssbUNBQW1DLElBQUksUUFBUTtFQUNwRCxJQUFJLENBQWMsS0FBSyxVQUFXLEtBQUssa0NBQWtDLElBQUksUUFBUTtFQUNyRixNQUFNLGdCQUFnQixLQUFLLFFBQVE7RUFDbkMsSUFBSSxlQUFlO0dBQ2xCLGNBQWMsS0FBSyxXQUFXO0dBQzlCLElBQUksS0FBSyxXQUFXLGNBQWMsUUFBUSxlQUFlLGNBQWMsaUJBQWlCLGNBQWMsT0FBTyxlQUFlLENBQUM7R0FDN0gsS0FBSyxXQUFXLGNBQWMsTUFBTTtFQUNyQztDQUNEO0NBQ0Esb0JBQW9CLE1BQU0sTUFBTTtFQUMvQixNQUFNLENBQUMsc0JBQXNCLFdBQVcsY0FBYyxLQUFLLGlCQUFpQixLQUFLLFFBQVE7RUFDekYsSUFBSSxnQkFBZ0I7RUFDcEIsSUFBSSxtQkFBbUI7RUFDdkIsSUFBSSxhQUFhLFdBQVcsU0FBUyxPQUFPLFVBQVUsUUFBUSxjQUFjLEtBQUssUUFBUSxHQUFHLElBQUksS0FBSyxRQUFRLGVBQWUsZ0JBQWdCLENBQUMsR0FBRyxlQUFlLEtBQUssUUFBUSxhQUFhO09BQ3BMLG1CQUFtQjtFQUN4QixNQUFNLG1CQUFtQixtQkFBbUIsMEJBQTBCLEtBQUssUUFBUSxjQUFjLGFBQWEsSUFBSSxLQUFLO0VBQ3ZILE1BQU0sVUFBVSxJQUFJLE1BQU0sY0FBYyxNQUFNO0VBQzlDLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sY0FBYyxPQUFPLFVBQVU7R0FDcEMsTUFBTSxRQUFRLFVBQVU7R0FDeEIsT0FBTyxPQUFPLFlBQVksTUFBTSxLQUFLLFFBQVEsVUFBVSxLQUFLLFFBQVEsZ0JBQWdCLFVBQVUsTUFBTSxjQUFjLFVBQVUsWUFBWSxNQUFNLEVBQUUsSUFBSSxLQUFLO0VBQzFKO0VBQ0EsSUFBSTtFQUNKLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxjQUFjLFFBQVEsU0FBUztHQUMxRCxNQUFNLFFBQVEsY0FBYztHQUM1QixNQUFNLGNBQWMsUUFBUSxRQUFRO0dBQ3BDLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKO0lBQ0MsTUFBTSxlQUFlLGFBQWEsVUFBVSxLQUFLO0lBQ2pELE1BQU0scUJBQXFCLGFBQWEsaUJBQWlCLEtBQUs7SUFDOUQsSUFBSTtLQUNILE1BQU0sZUFBZSxlQUFlLE1BQU0sUUFBUSxnQkFBZ0IsRUFBRSxHQUFHLGFBQWEsQ0FBQyxLQUFLLEtBQUs7S0FDL0YsaUJBQWlCO01BQ2hCLEdBQUc7TUFDSCxHQUFHO0tBQ0o7S0FDQSxvQkFBb0I7TUFDbkIsR0FBRztNQUNILEdBQUc7S0FDSjtJQUNELFNBQVMsS0FBSztLQUNiLElBQUksbUJBQW1CO0tBQ3ZCLElBQUksRUFBRSxlQUFlLG1CQUFtQixtQkFBbUIsSUFBSSxpQkFBaUIsSUFBSSxTQUFTLEVBQUUsT0FBTyxJQUFJLENBQUM7S0FDM0csSUFBSSxNQUFNLGNBQWMsTUFBTTtLQUM5QixpQkFBaUI7S0FDakIsb0JBQW9CLENBQUM7S0FDckIsY0FBYztJQUNmO0dBQ0Q7R0FDQSxJQUFJLGFBQWE7R0FDakIsSUFBSSxpQkFBaUI7R0FDckIsSUFBSTtJQUNILGFBQWEsTUFBTSxRQUFRLGFBQWEsRUFBRSxRQUFRLGVBQWUsQ0FBQyxLQUFLO0lBQ3ZFLGlCQUFpQixhQUFhLEtBQUssVUFBVSxVQUFVLEtBQUssS0FBSztHQUNsRSxTQUFTLE9BQU87SUFDZixJQUFJLE1BQU0sY0FBYyxNQUFNO0lBQzlCLGdCQUFnQjtHQUNqQjtHQUNBLE1BQU0sYUFBYSxXQUFXO0dBQzlCLE1BQU0sbUJBQW1CLE1BQU0saUJBQWlCLGdCQUFnQixNQUFNLFVBQVUsTUFBTSxnQkFBZ0IsV0FBVyxLQUFLLG1CQUFtQixVQUFVLElBQUksTUFBTTtHQUM3SixNQUFNLFVBQVUsTUFBTSxLQUFLLG1CQUFtQjtHQUM5QyxNQUFNLGdCQUFnQixXQUFXLE9BQU8sS0FBSztHQUM3QyxNQUFNLGdCQUF5RCxNQUFNLGlCQUFpQixLQUFLLElBQUksS0FBSyxPQUFPLElBQUksT0FBTyxNQUFNLGVBQWUsT0FBTyxVQUFVLGdCQUFnQixLQUFLO0dBQ2pMLGVBQWUsZUFBZSxpQkFBaUIsT0FBTyxPQUFPLFlBQVksWUFBWTtHQUNyRixJQUFJO0dBQ0osSUFBSSxDQUFDLGVBQWUsSUFBSTtJQUN2QixvQkFBb0IsT0FBTyxZQUFZO0dBQ3hDLFNBQVMsS0FBSztJQUNiLElBQUksV0FBVyxHQUFHLEtBQUssV0FBVyxHQUFHLEdBQUcsY0FBYztTQUNqRCxjQUFjLElBQUksZUFBZSxJQUFJLFNBQVMsRUFBRSxPQUFPLElBQUksQ0FBQztJQUNqRSxJQUFJLE1BQU0sY0FBYyxNQUFNO0dBQy9CO0dBQ0EsTUFBTSxRQUFRLGdCQUFnQixTQUFTO0dBQ3ZDLElBQUk7R0FDSixJQUFJLGVBQWUsUUFBUTtJQUMxQixHQUFHO0lBQ0g7SUFDQSxRQUFRLGdCQUFnQixxQkFBcUIsY0FBYyxRQUFRLGNBQWMsSUFBSSxxQkFBcUIsY0FBYyxRQUFRLGNBQWM7SUFDOUksZUFBZTtJQUNmO0dBQ0Q7UUFDSztJQUNKLE1BQU0sU0FBUyxlQUFlLEtBQUssSUFBSSxZQUFZO0lBQ25ELFFBQVE7S0FDUCxJQUFJO0tBQ0osS0FBaUIsS0FBSyxXQUFXLEtBQUssSUFBSSxNQUFNLFFBQVE7S0FDeEQ7S0FDQSxTQUFTLE1BQU07S0FDZixRQUFRLGVBQWUsVUFBVTtLQUNqQyxlQUFlO0tBQ2YsVUFBVTtLQUNWLFdBQVcsS0FBSyxJQUFJO0tBQ3BCLFFBQVEsZ0JBQWdCLHFCQUFxQixjQUFjLFFBQVEsY0FBYyxJQUFJO0tBQ3JGLGVBQWU7S0FDZjtLQUNBO0tBQ0EsWUFBWTtLQUNaLE9BQU8sS0FBSztLQUNaO0tBQ0EsU0FBUyxDQUFDO0tBQ1YsaUJBQWlCLE1BQU0sZUFBZSxJQUFJLGdCQUFnQjtLQUMxRDtLQUNBLFlBQVksZ0JBQWdCLGlCQUFpQixjQUFjLFlBQVksVUFBVSxJQUFJO0tBQ3JGLFNBQVM7S0FDVCxTQUFTO0tBQ1QsWUFBWSxNQUFNLFFBQVEsY0FBYyxDQUFDO0tBQ3pDLFVBQVUsTUFBTTtJQUNqQjtHQUNEO0dBQ0EsTUFBTSxZQUFZLHFCQUFxQixNQUFNO0dBQzdDLElBQUksTUFBTSxhQUFhLENBQUMsV0FBVyxNQUFNLFFBQVEsS0FBSztHQUN0RCxNQUFNLFlBQVk7R0FDbEIsUUFBUSxTQUFTO0VBQ2xCO0VBQ0EsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0dBQ3BELE1BQU0sUUFBUSxRQUFRO0dBQ3RCLE1BQU0sU0FBUyxNQUFNLFVBQVUsU0FBUyxxQkFBcUIsTUFBTSxRQUFRLFlBQVksSUFBSTtHQUMzRixJQUFJLE1BQU0sYUFBYSxNQUFNLFVBQVUsQ0FBQztFQUN6QztFQUNBLE9BQU87Q0FDUjs7Ozs7O0NBTUEsdUJBQXVCLFVBQVU7RUFDaEMsTUFBTSxjQUFjLEtBQUssS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDO0VBQzlDLE1BQU0saUJBQWlCLGNBQWMsS0FBSyxPQUFPLFFBQVEsSUFBSSxXQUFXLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSztFQUN2RixNQUFNLG1CQUFtQixnQkFBZ0I7RUFDekMsTUFBTSxTQUFTLEtBQUssaUJBQWlCLElBQUksUUFBUTtFQUNqRCxJQUFJLFVBQVUsT0FBTyxPQUFPLGtCQUFrQixPQUFPLE9BQU87RUFDNUQsTUFBTSxDQUFDLGVBQWUsYUFBYSxLQUFLLGlCQUFpQixTQUFTLFFBQVE7RUFDMUUsTUFBTSxZQUFZLEtBQUssYUFBYTtFQUNwQyxNQUFNLG9CQUFvQixFQUFFLEdBQUcsU0FBUyxPQUFPO0VBQy9DLEtBQUssTUFBTSxTQUFTLGVBQWUsSUFBSTtHQUN0QyxPQUFPLE9BQU8sbUJBQW1CLGVBQWUsTUFBTSxRQUFRLGdCQUFnQixpQkFBaUIsQ0FBQztFQUNqRyxRQUFRLENBQUM7RUFDVCxNQUFNLGlCQUFpQixrQkFBa0IsZUFBZSxZQUFZLFVBQVUsTUFBTSxlQUFlLGFBQWEsU0FBUztFQUN6SCxJQUFJO0VBQ0osSUFBSSxnQkFBZ0IsU0FBUyxlQUFlO09BQ3ZDO0dBQ0osTUFBTSxlQUFlO0dBQ3JCLEtBQUssTUFBTSxTQUFTLGVBQWUsSUFBSTtJQUN0QyxvQkFBb0IsT0FBTyxZQUFZO0dBQ3hDLFFBQVEsQ0FBQztHQUNULFNBQVM7RUFDVjtFQUNBLE1BQU0sU0FBUztHQUNkO0dBQ0EsVUFBVTtHQUNWO0dBQ0E7RUFDRDtFQUNBLEtBQUssaUJBQWlCLElBQUksVUFBVSxDQUFDLGtCQUFrQixNQUFNLENBQUM7RUFDOUQsT0FBTztDQUNSO0FBQ0Q7QUFDQSxlQUFlLG1CQUFtQixRQUFRLE1BQU0sRUFBRSxTQUFTLGlCQUFpQjtDQUMzRSxJQUFJLG9CQUFvQixNQUFNLE9BQU8saUJBQWlCLEdBQUc7RUFDYixRQUFRLEtBQUssNkNBQTZDLE1BQU07RUFDM0c7Q0FDRDtDQUNBLElBQUksQ0FBQyxlQUFlO0VBQ25CLE1BQU0sV0FBVyxPQUFPLFFBQVEsYUFBYTtFQUM3QyxLQUFLLE1BQU0sV0FBVyxVQUFVLElBQUksU0FBUyxXQUN4QztPQUFBLE1BQU0sUUFBUSxVQUFVO0lBQzNCLGlCQUFpQixPQUFPLFFBQVE7SUFDaEMsY0FBYyxPQUFPLFFBQVE7SUFDN0IsUUFBUSxVQUFVLFlBQVk7R0FDL0IsQ0FBQyxHQUFHO0VBQUE7Q0FFTjtDQUNBLE9BQU8sUUFBUSwwQkFBMEIsSUFBSTtDQUM3QyxJQUFJLFNBQVMsT0FBTyxTQUFTLFFBQVEsSUFBSTtNQUNwQyxPQUFPLFNBQVMsT0FBTztBQUM3QjtBQU9DLFdBQVcsVUFBVSxxQkFBcUI7QUFDMUMsV0FBVyxVQUFVLGdCQUFnQixpQkFBaUI7Q0FDckQsS0FBSyxnQkFBZ0IsS0FBSztDQUMxQixLQUFLLHFCQUFxQjtDQUMxQixNQUFNLG1CQUFtQixJQUFJO0FBQzlCOztBQUdELElBQUksbUJBQW1CLGNBQWMsTUFBTSxDQUFDOztBQUU1QyxJQUFJLGlCQUFpQixjQUFjLE1BQU0sQ0FBQztBQUMxQyxJQUFNQSxlQUFhLFFBQVEsSUFBSSxTQUFTLEdBQUcsS0FBSyxJQUFJLFNBQVMsSUFBSSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUk7QUFDcEYsU0FBUyxhQUFhLEdBQUcsR0FBRztDQUMzQixPQUFPQSxZQUFVLENBQUMsTUFBTUEsWUFBVSxDQUFDO0FBQ3BDOzs7OztBQUtBLFNBQVMsT0FBTyxJQUFJLEtBQUs7Q0FDeEIsT0FBTyxPQUFPLEdBQUcsU0FBUztFQUN6QixRQUFRLE1BQU0sR0FBRyxFQUFBLENBQUcsT0FBTyxVQUFVLENBQUMsR0FBRyxJQUFJO0NBQzlDO0FBQ0Q7QUFXQSxTQUFTLGVBQWUsZ0JBQWdCLE9BQU87Q0FDOUMsSUFBSSxrQkFBa0IsTUFBTSxPQUFPLENBQUM7Q0FDcEMsSUFBSSxlQUFlLGdCQUFnQjtFQUNsQyxNQUFNLFNBQVMsZUFBZSxZQUFZLENBQUMsU0FBUyxLQUFLO0VBQ3pELElBQUksa0JBQWtCLFNBQVMsTUFBTSxJQUFJLGlCQUFpQixnQ0FBZ0M7RUFDMUYsSUFBSSxPQUFPLFFBQVEsTUFBTSxJQUFJLGlCQUFpQixLQUFLLFVBQVUsT0FBTyxRQUFRLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRSxPQUFPLE9BQU8sQ0FBQztFQUN6RyxPQUFPLE9BQU87Q0FDZjtDQUNBLElBQUksV0FBVyxnQkFBZ0IsT0FBTyxlQUFlLE1BQU0sS0FBSztDQUNoRSxJQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxlQUFlLEtBQUs7Q0FDckUsT0FBTyxDQUFDO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixNQUFNLE1BQU07Q0FDdEMsSUFBSSxTQUFTLEtBQUssS0FBSyxTQUFTLE1BQU0sT0FBTztDQUM3QyxNQUFNLE9BQU8sT0FBTyxPQUFPLElBQUk7Q0FDL0IsSUFBSSxTQUFTLFNBQVMsU0FBUyxNQUFNLE9BQU87Q0FDNUMsSUFBSSxPQUFPLFNBQVMsWUFBWTtFQUMvQixPQUFPLE9BQU8sTUFBTSxJQUFJO0VBQ3hCLE9BQU8sT0FBTyxPQUFPLE1BQU0sS0FBSyxJQUFJLENBQUM7Q0FDdEM7Q0FDQSxPQUFPLE9BQU8sT0FBTyxNQUFNLE1BQU0sSUFBSTtBQUN0QztBQUNBLFNBQVMscUJBQXFCLE1BQU0sZUFBZTtDQUNsRCxJQUFJLE9BQU8sU0FBUyxZQUFZLE9BQU87Q0FDdkMsSUFBSSxDQUFDLGlCQUFpQixTQUFTLFNBQVMsU0FBUyxNQUFNLE9BQU87Q0FDOUQsT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLFFBQVEsY0FBYyxNQUFNLFNBQVMsT0FBTyxTQUFTLFlBQVksQ0FBQyxPQUFPLEtBQUssTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUNoSTtBQUNBLElBQU0sZUFBZSxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQ3JDLFNBQVMscUJBQXFCLFlBQVksdUJBQXVCO0NBQ2hFLE1BQU0sY0FBYyxDQUFDO0NBQ3JCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztFQUMzQyxNQUFNLGVBQWUsV0FBVyxFQUFFLENBQUM7RUFDbkMsSUFBSSxZQUFZLGNBQ1g7T0FBQSxhQUFhLFFBQVEsYUFBYSxZQUFZLEtBQUssR0FBRyxhQUFhLE9BQU8sV0FBVztFQUFBLE9BQ25GLElBQUksYUFBYSxvQkFBb0IsYUFBYSxtQkFBbUI7R0FDM0UsTUFBTSxvQkFBb0IsRUFBRSxRQUFRLFdBQVc7SUFDOUMsTUFBTSxTQUFTLEtBQUssYUFBYSxtQkFBbUIsYUFBYSxpQkFBaUIsUUFBUSxNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsTUFBTSxJQUFJLE1BQU07SUFDckksT0FBTyxhQUFhLG9CQUFvQixhQUFhLGtCQUFrQixRQUFRLE1BQU0sU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLElBQUk7R0FDckg7R0FDQSxZQUFZLEtBQUssZ0JBQWdCO0VBQ2xDO0VBQ0EsTUFBTSxzQkFBc0IsYUFBYTtFQUN6QyxJQUFJLHlCQUF5QixxQkFBcUI7R0FDakQsTUFBTSxZQUFZLEVBQUUsUUFBUSxNQUFNLFdBQVc7SUFDNUMsTUFBTSxTQUFTLEtBQUssTUFBTTtJQUMxQixJQUFJO0tBQ0gsTUFBTSxZQUFZLGVBQWUscUJBQXFCLE1BQU07S0FDNUQsSUFBSSxRQUFRLFdBQ047V0FBQSxNQUFNLE9BQU8sV0FBVyxJQUFJLEVBQUUsT0FBTyxTQUFTLENBQUMsS0FBSyw4QkFBOEIsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLEtBQUssVUFBVSxJQUFJO0tBQUE7S0FFMUgsT0FBTztNQUNOLEdBQUc7TUFDSCxHQUFHO0tBQ0o7SUFDRCxRQUFRLENBQUM7SUFDVCxPQUFPO0dBQ1I7R0FDQSxZQUFZLEtBQUssUUFBUTtFQUMxQjtDQUNEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxzQkFBc0IsYUFBYSxRQUFRLE1BQU07Q0FDekQsTUFBTSxhQUFhLE9BQU8sZUFBZSxTQUFTO0VBQ2pELElBQUksU0FBUyxZQUFZLFFBQVE7R0FDaEMsSUFBSSxDQUFDLEtBQUssUUFBUSxPQUFPLENBQUM7R0FDMUIsSUFBSSxLQUFLLFdBQVcsTUFBTSxPQUFPO0dBQ2pDLE1BQU0sU0FBUyxpQkFBaUIsS0FBSyxRQUFRLGFBQWE7R0FDMUQsSUFBSSxNQUFNLEtBQUssV0FBVztHQUMxQixPQUFPO0VBQ1I7RUFDQSxNQUFNLFFBQVEsV0FBVyxnQkFBZ0I7R0FDeEMsSUFBSSxhQUFhO0lBQ2hCLE1BQU0sV0FBVyxRQUFRLENBQUM7SUFDMUIsT0FBTztLQUNOLFFBQVEsVUFBVSxRQUFRLEdBQUcsV0FBVyxRQUFRO0tBQ2hELE1BQU07SUFDUDtHQUNEO0dBQ0EsT0FBTyxVQUFVLFFBQVEsR0FBRyxXQUFXLElBQUk7RUFDNUM7RUFDQSxPQUFPLFlBQVksTUFBTSxDQUFDO0dBQ3pCLFFBQVE7R0FDUjtHQUNBO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsT0FBTyxVQUFVLEdBQUcsTUFBTTtBQUMzQjtBQUNBLFNBQVMsMEJBQTBCLGNBQWMsUUFBUTtDQUN4RCxJQUFJLGlCQUFpQixRQUFRO0VBQzVCLElBQUk7RUFDSixLQUFLLElBQUksSUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUM1QyxNQUFNLFFBQVEsT0FBTztHQUNyQixJQUFJLE1BQU0sUUFBUSxtQkFBbUIsT0FBTyxNQUFNO0dBQ2xELGFBQWEsTUFBTSxZQUFZLE1BQU07RUFDdEM7RUFDQSxJQUFJLFVBQVUsT0FBTztDQUN0QjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsb0JBQW9CLE9BQU8sbUJBQW1CO0NBQ3RELE1BQU0sY0FBYyxNQUFNLFFBQVEsUUFBUSxTQUFTLE1BQU0sUUFBUTtDQUNqRSxJQUFJLGFBQWEsT0FBTyxPQUFPLG1CQUFtQixZQUFZLGlCQUFpQixDQUFDO0FBQ2pGOzs7QUN2OEJBLFNBQVMsa0JBQWtCLE9BQU8sUUFBUTtDQUN6QyxNQUFNLFNBQVMsVUFBVSxNQUFNO0NBQy9CLE1BQU0sUUFBUSxLQUFLO0FBQ3BCO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTyxNQUFNO0NBQ3RDLE9BQU8sTUFBTSxRQUFRLEtBQUssRUFBRSxVQUFVO0FBQ3ZDO0FBQ0EsU0FBUyxlQUFlLE9BQU8sZ0JBQWdCO0NBQzlDLE1BQU0sWUFBWSxpQkFBaUIsT0FBTyxXQUFXO0NBQ3JELElBQUksVUFBVSxpQkFBaUIsT0FBTyxrQkFBa0I7Q0FDeEQsSUFBSSxnQkFBZ0IsSUFBSSxTQUFTLFVBQVUsUUFBUSxLQUFLLGNBQWM7TUFDakUsZUFBZTtDQUNwQixJQUFJLGFBQWEsU0FBUyxPQUFPLFFBQVEsSUFBSSxDQUFDLFdBQVcsT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQztDQUNoRixPQUFPLGFBQWE7QUFDckI7QUFDQSxTQUFTLGVBQWUsT0FBTyxlQUFlLGdCQUFnQjtDQUM3RCxNQUFNLGtCQUFrQixrQkFBa0IsUUFBUSxLQUFLLElBQUksZ0JBQWdCLGlCQUFpQixPQUFPLGFBQWEsSUFBSSxlQUFlLE9BQU8sY0FBYztDQUN4SixNQUFNLFVBQVUsTUFBTTtDQUN0QixJQUFJLFNBQVMsT0FBTyxZQUFZLE9BQU8sVUFBVSxJQUFJLFFBQVEsS0FBSyxTQUFTO0NBQzNFLElBQUksQ0FBQyxNQUFNLFFBQVEsT0FBTyxVQUFVO0NBQ3BDLE1BQU0sVUFBVSxNQUFNLE9BQU8sQ0FBQyxDQUFDLE1BQU0sY0FBYztFQUNsRCxJQUE2QyxNQUFNLFVBQVUsU0FBUztHQUNyRSxNQUFNLEVBQUUsSUFBSSxLQUFLLEdBQUcsWUFBWSxVQUFVO0dBQzFDLE9BQU8sT0FBTyxNQUFNLFNBQVMsT0FBTztHQUNwQyxNQUFNLFFBQVE7RUFDZjtDQUNELElBQUksVUFBVTtFQUNiLElBQTZDLE1BQU0sVUFBVSxTQUFTLE1BQU0sUUFBUSxLQUFLO0VBQ3pGLE1BQU07Q0FDUCxDQUFDO0NBQ0QsTUFBTSxRQUFRO0NBQ2QsT0FBTyxRQUFRLEtBQUssU0FBUztBQUM5Qjs7QUFFQSxTQUFTLG9CQUFvQixTQUFTO0NBQ3JDLE1BQU0sTUFBTSxRQUFRLFdBQVcsVUFBVSxNQUFNLFdBQVcsYUFBYSxNQUFNLFNBQVMsSUFBSTtDQUMxRixPQUFPLE9BQU8sTUFBTSxRQUFRLFNBQVMsUUFBUSxNQUFNLEdBQUcsR0FBRyxJQUFJO0FBQzlEOztBQUVBLFNBQVMsaUJBQWlCLFNBQVM7Q0FDbEMsSUFBSSxNQUFNLFFBQVE7Q0FDbEIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssU0FBUztFQUN6QyxNQUFNLFFBQVEsUUFBUTtFQUN0QixJQUFJLE1BQU0sY0FBYyxLQUFLLEdBQUc7R0FDL0IsTUFBTSxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksUUFBUSxHQUFHLE1BQU0sU0FBUyxDQUFDO0dBQ3hEO0VBQ0Q7RUFDQSxJQUFJLE1BQU0sV0FBVyxhQUFhLE1BQU0sV0FBVztHQUNsRCxNQUFNLFFBQVE7R0FDZDtFQUNEO0NBQ0Q7Q0FDQSxPQUFPLE1BQU0sUUFBUSxTQUFTLFFBQVEsTUFBTSxHQUFHLEdBQUcsSUFBSTtBQUN2RDtBQUNBLElBQU1DLFlBQVU7QUFDaEIsSUFBTUMsVUFBUTtBQUNkLElBQU1DLGNBQVk7QUFDbEIsSUFBTUMsZUFBYTtBQUNuQixJQUFNLG1CQUFtQixDQUFDLENBQUM7QUFDM0IsU0FBUyxVQUFVLFFBQVE7Q0FDMUIsT0FBTyxPQUFPLE9BQU8sT0FBTztBQUM3QjtBQUNBLFNBQVNDLFVBQVEsT0FBTyxRQUFRO0NBQy9CLElBQUksT0FBTyxTQUFTLE9BQU8sUUFBUSxLQUFLLENBQUMsUUFBUSxPQUFPLE1BQU0sR0FBRyxLQUFLLENBQUM7Q0FDdkUsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3ZDLE1BQU0sY0FBYyxPQUFPLE1BQU07RUFDakMsT0FBTyxpQkFBaUIsU0FBUyxPQUFPLEVBQUUsTUFBTSxLQUFLLENBQUM7RUFDdEQsUUFBUSxRQUFRLEtBQUssQ0FBQyxDQUFDLEtBQUssU0FBUyxNQUFNLENBQUMsQ0FBQyxXQUFXLE9BQU8sb0JBQW9CLFNBQVMsS0FBSyxDQUFDO0NBQ25HLENBQUM7QUFDRjtBQUNBLFNBQVNDLFdBQVMsUUFBUSxPQUFPO0NBQ2hDLE9BQU8sT0FBTyxXQUFXLE1BQU07QUFDaEM7QUFDQSxTQUFTQyxZQUFVLE9BQU8sVUFBVSxTQUFTO0NBQzVDLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxDQUFDSCxjQUFZLEtBQUs7Q0FDaEQsSUFBSSxXQUFXLEtBQUssR0FBRztFQUN0QixNQUFNLFlBQVk7RUFDbEIsT0FBTyxDQUFDRCxhQUFXLEtBQUs7Q0FDekI7Q0FDQSxJQUFJLENBQUMsVUFBVSxPQUFPLENBQUNGLFdBQVMsS0FBSztDQUNyQyxJQUFJLE9BQU8sT0FBTyxTQUFTLFlBQVksUUFBUSxJQUFJLE1BQU0sd0JBQXdCLEVBQUUsT0FBTyxNQUFNLENBQUM7Q0FDakcsT0FBTyxDQUFDQyxTQUFPLEtBQUs7QUFDckI7QUFDQSxTQUFTTSxpQkFBZSxPQUFPLE9BQU87Q0FDckMsSUFBSSxVQUFVRCxZQUFVLE9BQU8sTUFBTSxNQUFNLEVBQUU7Q0FDN0MsSUFBSSxRQUFRLE9BQU9MLFNBQU8sT0FBTztDQUNqQyxJQUFJO0VBQ0gsTUFBTSxRQUFRLFVBQVUsUUFBUSxFQUFFO0NBQ25DLFNBQVMsY0FBYztFQUN0QixVQUFVSyxZQUFVLGNBQWMsTUFBTSxNQUFNLEVBQUU7Q0FDakQ7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLG1CQUFtQixRQUFRLE1BQU0sT0FBTyxPQUFPLFNBQVM7Q0FDaEUsSUFBSSxRQUFRLEVBQUUsQ0FBQyxPQUFPLFNBQVMsT0FBTztDQUN0QyxPQUFPRSxzQkFBb0IsUUFBUSxNQUFNLE9BQU9ELGlCQUFlLE9BQU8sS0FBSyxHQUFHLE9BQU87QUFDdEY7QUFDQSxlQUFlRSxnQkFBYyxRQUFRLE1BQU0sU0FBUyxLQUFLLG9CQUFvQixhQUFhO0NBQ3pGLE1BQU0sQ0FBQyxVQUFVLFdBQVc7Q0FDNUIsTUFBTSxTQUFTLFFBQVEsRUFBRSxDQUFDO0NBQzFCLE1BQU0sVUFBVSxDQUFDLENBQUMsUUFBUTtDQUMxQixLQUFLLElBQUksUUFBUSxRQUFRLE1BQU0sR0FBRyxRQUFRLEtBQUssU0FBUztFQUN2RCxNQUFNLFFBQVEsUUFBUTtFQUN0QixNQUFNLFFBQVFKLFdBQVMsUUFBUSxLQUFLO0VBQ3BDLE1BQU0sa0JBQWtCLFFBQVE7RUFDaEMsTUFBTSxnQkFBZ0IsUUFBUSxRQUFRLEVBQUUsRUFBRSxXQUFXLE9BQU8sUUFBUSxXQUFXLENBQUM7RUFDaEYsTUFBTSxTQUFTO0dBQ2QsUUFBUSxNQUFNO0dBQ2Q7R0FDQSxXQUFXLFNBQVMsT0FBTyxTQUFTO0lBQ25DLEdBQUc7SUFDSCxlQUFlO0dBQ2hCLENBQUM7R0FDRCxlQUFlLE9BQU87R0FDdEIsT0FBTyxVQUFVLFlBQVksTUFBTTtHQUNuQyxpQkFBaUIsUUFBUTtHQUN6QjtHQUNBO0dBQ0EsU0FBUyxNQUFNO0VBQ2hCO0VBQ0EsSUFBSTtHQUNILE1BQU0sZUFBZSxNQUFNLFNBQVMsTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLFFBQVE7SUFDakYsR0FBRztJQUNILE1BQU0sTUFBTTtJQUNaLFNBQVM7R0FDVixDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUs7R0FDaEIsTUFBTSxVQUFVO0lBQ2YsR0FBRztJQUNILEdBQUc7R0FDSjtFQUNELFNBQVMsT0FBTztHQUNmLGNBQWMsUUFBUSxLQUFLO0dBQzNCLE9BQU8sQ0FBQyxPQUFPLG1CQUFtQixRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sQ0FBQztFQUN2RTtFQUNBLElBQUksT0FBTyxTQUFTLE9BQU8sQ0FBQyxPQUFPLGdCQUFnQjtFQUNuRCxNQUFNLGtCQUFrQixNQUFNLGVBQWUsTUFBTTtFQUNuRCxJQUFJLG9CQUFvQixLQUFLLEdBQUc7R0FDL0IsY0FBYyxRQUFRLEtBQUs7R0FDM0IsT0FBTyxDQUFDLE9BQU8sbUJBQW1CLFFBQVEsTUFBTSxPQUFPLGlCQUFpQixPQUFPLENBQUM7RUFDakY7RUFDQSxNQUFNLGFBQWEsTUFBTSxRQUFRO0VBQ2pDLElBQUksQ0FBQyxZQUFZO0VBQ2pCLE1BQU0saUJBQWlCLE1BQU07RUFDN0IsSUFBSSxTQUFTLGFBQWE7R0FDekIsTUFBTSxTQUFTO0dBQ2YsUUFBUSxFQUFFLEdBQUc7RUFDZDtFQUNBLElBQUk7R0FDSCxZQUFZLFFBQVEsT0FBTyxjQUFjLFFBQVEsRUFBRTtHQUNuRCxNQUFNLFFBQVEsV0FBVztJQUN4QixHQUFHO0lBQ0gsUUFBUSxNQUFNO0lBQ2QsU0FBUyxNQUFNO0lBQ2YsR0FBRyxPQUFPLFFBQVE7R0FDbkIsQ0FBQztHQUNELE1BQU0sU0FBUyxPQUFPLE9BQU8sT0FBTyxTQUFTLGFBQWFELFVBQVEsT0FBTyxNQUFNLElBQUk7R0FDbkYsSUFBSSxPQUFPLFNBQVMsT0FBTyxDQUFDLE9BQU8sZ0JBQWdCO0dBQ25ELE1BQU0sVUFBVUksc0JBQW9CLFFBQVEsTUFBTSxPQUFPRixZQUFVLFFBQVEsT0FBTyxNQUFNLEVBQUUsR0FBRyxPQUFPO0dBQ3BHLElBQUksUUFBUSxPQUFPTixXQUFTO0lBQzNCLGNBQWMsUUFBUSxLQUFLO0lBQzNCLE9BQU8sQ0FBQyxPQUFPLE9BQU87R0FDdkI7R0FDQSxNQUFNLFVBQVU7SUFDZixHQUFHLE1BQU07SUFDVCxHQUFHO0dBQ0o7RUFDRCxTQUFTLE9BQU87R0FDZixjQUFjLFFBQVEsS0FBSztHQUMzQixPQUFPLENBQUMsT0FBTyxtQkFBbUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUM7RUFDdkUsVUFBVTtHQUNULE1BQU0sU0FBUztHQUNmLFlBQVksUUFBUSxPQUFPLE9BQU8sUUFBUSxFQUFFO0VBQzdDO0NBQ0Q7Q0FDQSxtQkFBbUI7QUFDcEI7QUFDQSxTQUFTLG1CQUFtQixRQUFRLE9BQU8sUUFBUTtDQUNsRCxJQUFJLENBQUMsVUFBVSxFQUFFLE9BQU8sSUFBSTtDQUM1QixJQUFJLE9BQU8sVUFBVSxJQUFJLE1BQU0sRUFBRSxNQUFNLFFBQVE7RUFDOUMsTUFBTSxVQUFVLE9BQU87RUFDdkIsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxXQUFXLENBQUMsUUFBUSxFQUFFLENBQUMsU0FBUyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUMsTUFBTSxjQUFjLFVBQVUsT0FBTyxNQUFNLEVBQUUsS0FBSyxRQUFRLEVBQUUsQ0FBQyxNQUFNLGNBQWMsVUFBVSxlQUFlLFlBQVksR0FBRztFQUNoTixPQUFPLFNBQVMsT0FBTyxNQUFNLEVBQUU7Q0FDaEM7Q0FDQSxPQUFPLE9BQU87QUFDZjtBQUNBLFNBQVMsY0FBYyxRQUFRLE9BQU87Q0FDckMsTUFBTSxTQUFTLE1BQU07Q0FDckIsTUFBTSxVQUFVLEtBQUs7Q0FDckIsbUJBQW1CLFFBQVEsT0FBTyxNQUFNLENBQUMsRUFBRSxNQUFNO0FBQ2xEOzs7OztBQUtBLFNBQVMsdUJBQXVCLFFBQVEsVUFBVSxNQUFNLG1CQUFtQjtDQUMxRSxNQUFNLFFBQVEsQ0FBQztDQUNmLEtBQUssTUFBTSxTQUFTLFVBQVUsSUFBSSxDQUFDLE1BQU0sU0FBUyxLQUFLLEdBQUc7RUFDekQsTUFBTSxTQUFTLE1BQU07RUFDckIsTUFBTSxVQUFVLEtBQUs7RUFDckIsSUFBSSxxQkFBcUIsU0FBUyxPQUFPLEtBQUssT0FBTyxVQUFVLElBQUksTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLE1BQU0sY0FBYyxVQUFVLE9BQU8sTUFBTSxFQUFFLEdBQUcsT0FBTyxLQUFLO09BQ3hKO0dBQ0osTUFBTSxhQUFhLG1CQUFtQixRQUFRLE9BQU8sTUFBTTtHQUMzRCxJQUFJLFlBQVksTUFBTSxLQUFLLFVBQVU7RUFDdEM7Q0FDRDtDQUNBLEtBQUssTUFBTSxjQUFjLE9BQU8sV0FBVyxNQUFNO0FBQ2xEO0FBQ0EsU0FBUyxzQkFBc0IsU0FBUztDQUN2QyxLQUFLLE1BQU0sU0FBUyxTQUFTO0VBQzVCLE1BQU0sU0FBUyxNQUFNO0VBQ3JCLElBQUksUUFBUSxPQUFPLEVBQUU7Q0FDdEI7QUFDRDtBQUNBLFNBQVMsWUFBWSxRQUFRLE9BQU8sT0FBTyxPQUFPO0NBQ2pELE1BQU0sYUFBYTtDQUNuQixJQUFJLFNBQVMsT0FBTyxNQUFNLE9BQU8sT0FBTztDQUN4QyxNQUFNLFFBQVEsT0FBTyxPQUFPLFFBQVEsSUFBSSxNQUFNLE9BQU87Q0FDckQsTUFBTSxZQUFZLE9BQU8sSUFBSTtDQUM3QixJQUFJLFdBQVcsT0FBTyxNQUFNLElBQUksTUFBTSxJQUFJO0VBQ3pDLEdBQUc7RUFDSCxZQUFZO0NBQ2IsQ0FBQztBQUNGO0FBQ0EsU0FBU1UsbUJBQWlCLFFBQVEsTUFBTSxPQUFPLE9BQU8sWUFBWSxvQkFBb0IsU0FBUztDQUM5RixNQUFNLFdBQVcsS0FBSztDQUN0QixPQUFPO0VBQ04sUUFBUSxNQUFNO0VBQ2Q7RUFDQSxXQUFXLFNBQVMsT0FBTyxTQUFTO0dBQ25DLEdBQUc7R0FDSCxlQUFlO0VBQ2hCLENBQUM7RUFDRCxPQUFPLFVBQVUsWUFBWSxNQUFNO0VBQ25DLGlCQUFpQjtFQUNqQjtFQUNBLE1BQU0sTUFBTTtFQUNaO0VBQ0EsU0FBUyxNQUFNO0VBQ2Y7RUFDQSxHQUFHLE9BQU8sUUFBUTtDQUNuQjtBQUNEO0FBQ0EsZUFBZSxhQUFhLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxvQkFBb0IsU0FBUztDQUM1RixNQUFNLFFBQVEsUUFBUTtDQUN0QixNQUFNLFNBQVMsTUFBTTtDQUNyQixJQUFJLE9BQU8sU0FBUyxPQUFPO0NBQzNCLElBQUksQ0FBQyxRQUFRLE9BQU8sQ0FBQ1YsV0FBUyxLQUFLLENBQUM7Q0FDcEMsSUFBSSxTQUFTLE1BQU07Q0FDbkIsWUFBWSxRQUFRLE9BQU8sVUFBVSxLQUFLO0NBQzFDLElBQUk7RUFDSCxJQUFJLENBQUMsUUFBUTtHQUNaLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtHQUN2QyxTQUFTO0lBQ1IsUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXLE9BQU9VLG1CQUFpQixRQUFRLE1BQU0sT0FBTyxPQUFPLFlBQVksb0JBQW9CLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLFVBQVVKLFlBQVUsT0FBTyxPQUFPLE1BQU0sRUFBRSxJQUFJLFVBQVVBLFlBQVUsT0FBTyxNQUFNLE1BQU0sRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVc7S0FDalAsSUFBSSxPQUFPLE9BQU9OLGFBQVcsT0FBTyxVQUFVLElBQUksTUFBTSxFQUFFLE1BQU0sUUFBUTtNQUN2RSxPQUFPLFNBQVMsT0FBTyxNQUFNLEVBQUU7TUFDL0IsSUFBSSxDQUFDLE9BQU8sSUFBSSxXQUFXLE1BQU07S0FDbEM7S0FDQSxPQUFPLE9BQU8sT0FBT0MsV0FBUyxPQUFPLEtBQUtNLGlCQUFlLE9BQU8sT0FBTyxFQUFFLElBQUk7SUFDOUUsQ0FBQztJQUNEO0lBQ0E7R0FDRDtHQUNBLENBQUMsT0FBTyw2QkFBNkIsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLE1BQU0sSUFBSSxNQUFNO0VBQ3JFO0VBQ0EsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sa0JBQWtCLE9BQU87RUFDL0IsT0FBT0Msc0JBQW9CLFFBQVEsTUFBTSxPQUFPLE1BQU1KLFVBQVEsT0FBTyxJQUFJLE1BQU0sR0FBRyxPQUFPO0NBQzFGLFNBQVMsT0FBTztFQUNmLElBQUksVUFBVSxVQUFVLENBQUMsT0FBTyxTQUFTLE1BQU07RUFDL0MsY0FBYyxRQUFRLEtBQUs7RUFDM0IsT0FBTztDQUNSLFVBQVU7RUFDVCxZQUFZLFFBQVEsT0FBTyxPQUFPLEtBQUs7Q0FDeEM7QUFDRDtBQUNBLFNBQVMsV0FBVyxPQUFPLFFBQVEsU0FBUztDQUMzQyxJQUFJLE9BQU8sT0FBT0QsY0FBWTtDQUM5QixNQUFNLFNBQVM7Q0FDZixNQUFNLFFBQVEsS0FBSztDQUNuQixJQUFJLE9BQU8sT0FBT0gsV0FBUztFQUMxQixNQUFNLGFBQWEsT0FBTztFQUMxQixNQUFNLFVBQVU7RUFDaEIsTUFBTSxZQUFZLEtBQUssSUFBSTtFQUMzQixNQUFNLFVBQVU7Q0FDakIsT0FBTyxNQUFNLFVBQVU7QUFDeEI7QUFDQSxTQUFTLGlCQUFpQixRQUFRLE9BQU8sU0FBUztDQUNqRCxNQUFNLFVBQVUsT0FBTyxPQUFPLElBQUksTUFBTSxFQUFFO0NBQzFDLElBQUksWUFBWSxXQUFXLE9BQU8sV0FBVyxNQUFNLGNBQWMsVUFBVSxPQUFPLE1BQU0sTUFBTSxVQUFVLFlBQVksTUFBTSxPQUFPLEdBQUc7Q0FDcEksTUFBTSxTQUFTO0VBQ2QsR0FBRztFQUNILFdBQVcsS0FBSztFQUNoQixTQUFTLENBQUM7Q0FDWDtDQUNBLElBQUksT0FBTyxTQUFTLE9BQU8sUUFBUSxFQUFFO0NBQ3JDLE9BQU8sT0FBTyxJQUFJLE1BQU0sSUFBSSxNQUFNO0NBQ2xDLElBQUksU0FBUyxjQUFjLFFBQVEsT0FBTztBQUMzQztBQUNBLFNBQVMsa0JBQWtCLE9BQU8sU0FBUztDQUMxQyxJQUFJLFFBQVEsT0FBT0MsV0FBUyxRQUFRLE9BQU9DLGFBQVcsT0FBTztFQUM1RCxHQUFHO0VBQ0gsUUFBUSxRQUFRLE9BQU9ELFVBQVEsVUFBVTtFQUN6QyxPQUFPLFFBQVE7RUFDZixTQUFTLEtBQUs7Q0FDZjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVNVLG1CQUFpQixRQUFRLE1BQU0sT0FBTyxPQUFPLGdCQUFnQixTQUFTLGFBQWE7Q0FDM0YsTUFBTSxRQUFRLEtBQUssRUFBRSxDQUFDO0NBQ3RCLE1BQU0sUUFBUU4sV0FBUyxRQUFRLEtBQUs7Q0FDcEMsTUFBTSxVQUFVLENBQUMsQ0FBQyxRQUFRO0NBQzFCLE1BQU0sb0JBQW9CLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRTtDQUNwRCxJQUFJO0NBQ0osSUFBSSxTQUFTO0NBQ2IsSUFBSTtDQUNKLElBQUk7RUFDSCxJQUFJLE1BQU0sV0FBVyxXQUFXO0dBQy9CLGFBQWEsTUFBTSxRQUFRO0dBQzNCLElBQUksT0FBTyxlQUFlLFlBQVksYUFBYSxXQUFXSyxtQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxRQUFRLElBQUksZ0JBQWdCLE9BQU8sQ0FBQztHQUMvSSxJQUFJLFFBQVEsRUFBRSxDQUFDLE9BQU8sU0FBUyxnQkFBZ0I7RUFDaEQ7RUFDQSxJQUFJLENBQUMsZUFBZSxJQUFJLE1BQU0sV0FBVyxXQUFXLFNBQVM7T0FDeEQ7R0FDSixNQUFNLFdBQVcsV0FBVyxNQUFNLFVBQVUsTUFBTSxRQUFRLG9CQUFvQixPQUFPLFFBQVEsMkJBQTJCLE1BQU0sTUFBTSxRQUFRLGFBQWEsT0FBTyxRQUFRLG9CQUFvQjtHQUM1TCxTQUFTLENBQUMsRUFBRSxNQUFNLFdBQVcsY0FBYyxlQUFlLEtBQUssS0FBSyxLQUFLLElBQUksSUFBSSxNQUFNLGFBQWEsYUFBYSxRQUFRLE1BQU0sTUFBTSxVQUFVLFdBQVcsUUFBUSxFQUFFLENBQUMsTUFBTSxjQUFjLFVBQVUsWUFBWSxNQUFNLFdBQVcsVUFBVSxPQUFPLE1BQU0sRUFBRTtFQUMxUDtDQUNELFNBQVMsT0FBTztFQUNmLE1BQU0sVUFBVTtFQUNoQixjQUFjLFFBQVEsS0FBSztFQUMzQixnQkFBZ0IsbUJBQW1CLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTztDQUN2RTtDQUNBLE1BQU0sY0FBYyxNQUFNLFFBQVE7Q0FDbEMsTUFBTSxhQUFhLE9BQU8sZ0JBQWdCO0NBQzFDLE1BQU0sU0FBUyxhQUFhLGNBQWMsYUFBYTtDQUN2RCxNQUFNLGNBQWMsQ0FBQyxXQUFXLE1BQU0sUUFBUSxZQUFZO0NBQzFELElBQUksUUFBUSxlQUFlLGVBQWUsQ0FBMkMsT0FBTyxNQUFNLEtBQU0sT0FBTyxVQUFVLElBQUksTUFBTSxFQUFFLElBQUksS0FBSztDQUM5SSxJQUFJLFVBQVUsTUFBTSxXQUFXLGVBQWUsUUFBUSxLQUFLO01BQ3RELElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxXQUFXLGVBQWUsS0FBSyxHQUFHLFNBQVM7TUFDcEUsSUFBSSxDQUFDLFFBQVEsUUFBUSxLQUFLO0NBQy9CLE1BQU0sYUFBYSxDQUFDLEVBQUUsZUFBZSxVQUFVLE1BQU0sV0FBVyxhQUFhLENBQUMsV0FBVyxDQUFDLFFBQVEsUUFBUSxhQUFhLEtBQUssSUFBSSxZQUFZLG9CQUFvQixPQUFPLFFBQVEsNEJBQTRCO0NBQzNNLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sV0FBVyxVQUFVLENBQUMsZUFBZSxNQUFNLFdBQVcsYUFBYSxDQUFDLENBQUM7Q0FDM0UsTUFBTSxVQUFVLFNBQVMsY0FBYyxRQUFRLEtBQUssS0FBSztDQUN6RCxNQUFNLGNBQWMsTUFBTSxVQUFVLE1BQU0sVUFBVSxPQUFPLFVBQVUsS0FBSztDQUMxRSxJQUFJLFVBQVUsQ0FBQyxhQUFhO0VBQzNCLE1BQU0sVUFBVTtFQUNoQixNQUFNLFlBQVksS0FBSyxJQUFJO0NBQzVCO0NBQ0EsSUFBSSxPQUFPLE1BQU0sRUFBRTtDQUNuQixJQUFJLFVBQVU7RUFDYixNQUFNLGlCQUFpQixNQUFNO0VBQzdCLE1BQU0sVUFBVTtFQUNoQixtQkFBbUIsUUFBUSxPQUFPLGNBQWMsQ0FBQyxFQUFFLE1BQU07RUFDekQsSUFBSSxTQUFTLGFBQWEsTUFBTSxTQUFTO0VBQ3pDLFVBQVU7Q0FDWDtDQUNBLElBQUksQ0FBQyxRQUFRLE1BQU0sYUFBYTtDQUNoQyxNQUFNLFVBQVUsQ0FBQyxpQkFBaUIsV0FBVyxhQUFhLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsTUFBTSxXQUFXO0VBQ3ZJLFdBQVcsT0FBTyxRQUFRLE9BQU87RUFDakMsSUFBSSxPQUFPLE9BQU9WLFdBQVM7R0FDMUIsSUFBSSxlQUFlLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxTQUFTLGlCQUFpQixRQUFRLE9BQU8saUJBQWlCO0dBQ2hHLElBQUksU0FBUyxhQUFhLE1BQU0sU0FBUztFQUMxQztFQUNBLE9BQU87Q0FDUixDQUFDLElBQUksUUFBUSxRQUFRLGlCQUFpQixDQUFDQSxXQUFTLE1BQU0sVUFBVSxDQUFDO0NBQ2pFLE1BQU0sZ0JBQWdCLFlBQVk7RUFDakMsSUFBSTtHQUNILE1BQU0sUUFBUSxlQUFlLE9BQU8sS0FBSyxHQUFHLFdBQVc7R0FDdkQsSUFBSSxPQUFPLE1BQU1JLFVBQVEsT0FBTyxRQUFRLEVBQUUsQ0FBQyxNQUFNO0VBQ2xELFNBQVMsT0FBTztHQUNmLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLFdBQVcsbUJBQW1CLGtCQUFrQixVQUFVLFVBQVUsV0FBVyxXQUFXLFVBQVUsV0FBVyxjQUFjLFVBQVUsVUFBVSxHQUFHLE9BQU8sQ0FBQyxPQUFPLG1CQUFtQixRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sQ0FBQztFQUM5TztFQUNBLE1BQU0sU0FBUyxNQUFNO0VBQ3JCLElBQUksWUFBWSxPQUFPLE9BQU9KLGFBQVcsTUFBTSxXQUFXLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLFNBQVM7R0FDbEcsTUFBTSxTQUFTO0dBQ2YsVUFBVTtFQUNYO0NBQ0QsRUFBQSxDQUFHO0NBQ0gsTUFBTSxLQUFLO0VBQ1Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxNQUFNLFdBQVcsa0JBQWtCLE9BQU8sTUFBTSxDQUFDO0NBQ2pGLE1BQU0sWUFBWTtFQUNqQixHQUFHO0VBQ0gsUUFBUTtFQUNSLFNBQVM7RUFDVCxTQUFTO0NBQ1Y7Q0FDQSxNQUFNLFVBQVU7Q0FDaEIsTUFBTSxhQUFhO0NBQ25CLE1BQU0sb0JBQW9CLGFBQWEsUUFBUSxNQUFNLFdBQVcsT0FBTyxRQUFRLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxNQUFNLFdBQVc7RUFDeEgsTUFBTSxhQUFhO0VBQ25CLFdBQVcsV0FBVyxRQUFRLEtBQUs7RUFDbkMsT0FBTztDQUNSLENBQUM7Q0FDRCxDQUFDLEtBQUssT0FBTyxDQUFDLEVBQUEsQ0FBRyxLQUFLO0VBQ3JCO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE9BQU8sa0JBQWtCLE1BQU0sV0FBVyxrQkFBa0IsV0FBVyxNQUFNLENBQUM7QUFDL0U7QUFDQSxlQUFlWSxzQkFBb0IsUUFBUSxTQUFTLFNBQVMsUUFBUSxXQUFXLEdBQUc7Q0FDbEYsTUFBTSxRQUFRLFVBQVUsRUFBRSxDQUFDO0NBQzNCLElBQUksUUFBUSxPQUFPLFVBQVUsUUFBUSxXQUFXLFVBQVUsTUFBTSxZQUFZLE1BQU0sT0FBTyxJQUFJLFVBQVUsTUFBTSxRQUFRLFNBQVM7Q0FDOUgsSUFBSSxRQUFRLEdBQUcsUUFBUTtDQUN2QixLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLO0VBQ2hDLE1BQU0sUUFBUVAsV0FBUyxRQUFRLFFBQVEsRUFBRTtFQUN6QyxJQUFJO0dBQ0gsTUFBTSxVQUFVLGVBQWUsT0FBTyxLQUFLO0dBQzNDLElBQUksU0FBUyxNQUFNRCxVQUFRLFNBQVMsTUFBTTtFQUMzQyxTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQVMsTUFBTTtFQUMvQztFQUNBLElBQUksTUFBTSxRQUFRLG1CQUFtQixPQUFPO0NBQzdDO0NBQ0EsT0FBTyxPQUFPLFVBQVUsUUFBUTtBQUNqQztBQUNBLFNBQVMsa0JBQWtCLFFBQVEsTUFBTTtDQUN4QyxJQUFJLEtBQUssSUFBSTtFQUNaLHVCQUF1QixRQUFRLEtBQUssRUFBRSxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQztFQUM3RCxLQUFLLEtBQUssS0FBSztDQUNoQjtBQUNEO0FBQ0EsZUFBZSxZQUFZLE9BQU8sZUFBZSxlQUFlLE1BQU07Q0FDckUsSUFBSTtDQUNKLElBQUk7RUFDSCxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQyxLQUFLLE9BQU8sWUFBWTtHQUNyRSxNQUFNLFlBQVksS0FBSztHQUN2QixJQUFJLFFBQVEsYUFBYSxNQUFNLE1BQU07R0FDckMsSUFBSSxRQUFRLE1BQU1ELGNBQVksTUFBTSxDQUFDLFdBQVcsT0FBTztHQUN2RCxJQUFJLENBQUMsaUJBQWlCLFFBQVEsT0FBT0gsV0FBUztJQUM3QyxnQkFBZ0IsQ0FBQyxXQUFXLE9BQU87SUFDbkMsTUFBTSxRQUFRLEtBQUssaUJBQWlCLENBQUMsRUFBQSxDQUFHLEtBQUssYUFBYTtLQUN6RCxJQUFJLFNBQVMsTUFBTSxXQUFXO0tBQzlCLE9BQU8sU0FBUyxFQUFFLENBQUMsTUFBTSxnQkFBZ0I7TUFDeEMsSUFBSSxZQUFZLE9BQU9HLGNBQVksTUFBTSxDQUFDLFNBQVMsSUFBSSxXQUFXO0tBQ25FLENBQUM7SUFDRixDQUFDLENBQUM7R0FDSDtFQUNELENBQUMsQ0FBQyxDQUFDO0NBQ0osU0FBUyxPQUFPO0VBQ2YsT0FBTztDQUNSO0NBQ0EsT0FBTyxpQkFBaUI7QUFDekI7QUFDQSxTQUFTSyxzQkFBb0IsUUFBUSxNQUFNLE9BQU8sU0FBUyxTQUFTLFFBQVE7Q0FDM0UsT0FBTyxRQUFRLE9BQU9MLGNBQVk7RUFDakMsTUFBTSxXQUFXLFFBQVE7RUFDekIsTUFBTSxrQkFBa0IsU0FBUztFQUNqQyxJQUFJO0dBQ0gsSUFBSSxnQkFBZ0IsUUFBUSxTQUFTLFFBQVEsSUFBSSxVQUFVLEdBQUc7SUFDN0QsT0FBTyxnQkFBZ0IsUUFBUTtJQUMvQixJQUFJLGdCQUFnQixnQkFBZ0IsT0FBTztHQUM1QztHQUNBLElBQUksZ0JBQWdCLGlCQUFpQixRQUFRLEtBQUssUUFBUSxNQUFNLElBQUksT0FBTztHQUMzRSxNQUFNLFdBQVcsT0FBTyxjQUFjO0lBQ3JDLEdBQUc7SUFDSCxlQUFlLEtBQUs7SUFDcEIsd0JBQXdCO0dBQ3pCLENBQUM7R0FDRCxNQUFNLGlCQUFpQixTQUFTLGtCQUFrQjtHQUNsRCxJQUFJLGVBQWUsVUFBVTtJQUM1QixNQUFNLFdBQVcsU0FBUyxNQUFNO0lBQ2hDLFNBQVMsVUFBVSxFQUFFLEdBQUcsZ0JBQWdCO0lBQ3hDLFNBQVMsUUFBUSxJQUFJLFlBQVksZUFBZSxVQUFVO0lBQzFELE9BQU8sZ0JBQWdCLFFBQVE7SUFDL0IsT0FBTyxRQUFRLEtBQUssQ0FBQ0EsY0FBWSxRQUFRLElBQUk7S0FDNUNBO0tBQ0E7S0FDQTtJQUNEO0dBQ0Q7R0FDQSxPQUFPO0lBQ05BO0lBQ0E7SUFDQTtHQUNEO0VBQ0QsU0FBUyxPQUFPO0dBQ2YsVUFBVSxTQUFTLENBQUNGLFNBQU8sS0FBSyxJQUFJTSxpQkFBZSxPQUFPLEtBQUs7R0FDL0QsU0FBUztFQUNWO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxlQUFlLFdBQVcsUUFBUSxNQUFNLE9BQU8sWUFBWSxZQUFZLFNBQVM7Q0FDL0UsTUFBTSxVQUFVLEtBQUs7Q0FDckIsSUFBSSxVQUFVLE1BQU07Q0FDcEIsSUFBSSx3QkFBd0I7Q0FDNUIsTUFBTSxrQkFBa0IsUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTO0NBQ3BFLE1BQU0sY0FBYyxVQUFVLE1BQU0sRUFBRSxDQUFDLE9BQU9MLGNBQVlVLHNCQUFvQixRQUFRLFNBQVMsT0FBTyxXQUFXLE1BQU0sSUFBSSxNQUFNO0NBQ2pJLElBQUksZUFBZSxrQkFBa0IsSUFBSSxRQUFRLFNBQVM7Q0FDMUQsS0FBSyxVQUFVLEVBQUUsQ0FBQyxNQUFNLE1BQU1ULGNBQVksZUFBZTtNQUNwRCxJQUFJLFNBQVM7RUFDakIsZUFBZSxRQUFRLE9BQU8sTUFBTSxXQUFXLE9BQU87RUFDdEQsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN6QixJQUFJLEtBQUssTUFBTSxjQUFjO0dBQzdCLE1BQU0sVUFBVSxNQUFNLEtBQUs7R0FDM0IsSUFBSSxRQUFRLE9BQU9ILGFBQVcsUUFBUSxLQUFLRyxnQkFBYyxFQUFFLGdCQUFnQixRQUFRLEtBQUssTUFBTTtJQUM3RixVQUFVLENBQUMsS0FBSyxJQUFJLE9BQU87SUFDM0IsZUFBZSxRQUFRLEtBQUssTUFBTSxXQUFXLE9BQU87SUFDcEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sUUFBUSxPQUFPO0VBQ3pCLElBQUksS0FBSyxNQUFNLGNBQWM7RUFDN0IsTUFBTSxlQUFlLE1BQU0sS0FBSztFQUNoQyxJQUFJLENBQUMsY0FBYztFQUNuQixVQUFVO0VBQ1Y7Q0FDRDtDQUNBLEtBQUssVUFBVSxFQUFFLENBQUMsTUFBTSxNQUFNQSxjQUFZO0VBQ3pDLE1BQU0sVUFBVSxRQUFRO0VBQ3hCLElBQUksUUFBUSxPQUFPQSxnQkFBYyxRQUFRLEVBQUUsQ0FBQyxRQUFRLGtCQUFrQixRQUFRLElBQUk7R0FDakYsa0JBQWtCLFFBQVEsSUFBSTtHQUM5QixPQUFPO0VBQ1I7RUFDQSx3QkFBd0I7RUFDeEIsVUFBVSxDQUFDLEdBQUcsQ0FBQ0YseUJBQXVCLElBQUksTUFBTSxvQkFBb0IsQ0FBQyxDQUFDO0NBQ3ZFO0NBQ0EsTUFBTSxXQUFXLFVBQVUsUUFBUSxNQUFNLE1BQU0sV0FBVyxPQUFPLElBQUk7Q0FDckUsSUFBSSxZQUFZLEdBQUc7RUFDbEIsTUFBTSxVQUFVLFVBQVU7RUFDMUIsTUFBTSxPQUFPLFVBQVU7RUFDdkIsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxRQUFRLFVBQVU7RUFDeEIsTUFBTSxnQkFBZ0I7R0FDckIsSUFBSSxTQUFTO0lBQ1osTUFBTSxZQUFZLEtBQUs7SUFDdkIsSUFBSSxTQUFTQSxTQUFPLE1BQU0sU0FBUztTQUM5QjtLQUNKLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLElBQUksTUFBTSxZQUFZLE9BQU8sVUFBVSxJQUFJO01BQzFDLE1BQU0sU0FBUztNQUNmLE1BQU0sWUFBWTtLQUNuQixPQUFPLE1BQU0sU0FBUztJQUN2QjtJQUNBLE1BQU0sUUFBUTtJQUNkLE1BQU0sYUFBYTtHQUNwQjtFQUNEO0VBQ0EsUUFBUTtFQUNSLElBQUksQ0FBQyxTQUFTLFVBQVU7RUFDeEIsTUFBTSxRQUFRSSxXQUFTLFFBQVEsS0FBSztFQUNwQyxJQUFJO0dBQ0gsTUFBTUQsVUFBUSxVQUFVLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxlQUFlLE9BQU8sU0FBU0gsVUFBUSxtQkFBbUIsbUJBQW1CLENBQUMsSUFBSSxRQUFRLElBQUksQ0FBQyxlQUFlLEtBQUssR0FBRyxlQUFlLE9BQU8sbUJBQW1CLENBQUMsQ0FBQyxHQUFHLFdBQVcsTUFBTTtFQUMzTyxTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsV0FBVyxVQUFVLFdBQVcsT0FBTyxTQUFTO0lBQzdELGtCQUFrQixRQUFRLElBQUk7SUFDOUIsT0FBTztHQUNSO0VBQ0Q7RUFDQSxJQUFJLENBQUMsU0FBUyxNQUFNLFNBQVM7T0FDeEIsSUFBSSx1QkFBdUI7R0FDL0IsV0FBVyxNQUFNO0dBQ2pCLE1BQU0sUUFBUSxJQUFJO0lBQ2pCLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxFQUFFO0lBQzlCLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxFQUFFO0lBQzlCLElBQUksS0FBSyxNQUFNLENBQUMsRUFBQSxDQUFHLEtBQUssU0FBUyxLQUFLLEVBQUU7R0FDekMsQ0FBQztHQUNELGtCQUFrQixRQUFRLElBQUk7R0FDOUIsdUJBQXVCLFFBQVEsT0FBTztHQUN0QyxRQUFRO0VBQ1Q7Q0FDRDtDQUNBLE9BQU87QUFDUjtBQUNBLGVBQWVZLGNBQVksUUFBUSxNQUFNLFFBQVEsUUFBUSxHQUFHLE1BQU0sS0FBSyxFQUFFLENBQUMsUUFBUTtDQUNqRixNQUFNLFVBQVUsS0FBSztDQUNyQixLQUFLLElBQUksUUFBUSxPQUFPLFFBQVEsS0FBSyxTQUFTO0VBQzdDLE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sZUFBZVIsV0FBUyxRQUFRLEtBQUssQ0FBQyxDQUFDO0VBQzdDLElBQUksYUFBYSxRQUFRLGFBQWEsU0FBUyxJQUFJO0dBQ2xELE1BQU0sVUFBVTtJQUNmLEtBQUssT0FBTyxRQUFRO0lBQ3BCO0lBQ0E7SUFDQSxRQUFRLE1BQU07SUFDZCxZQUFZLE1BQU07R0FDbkI7R0FDQSxNQUFNLENBQUMsTUFBTSxXQUFXLE1BQU1ELFVBQVEsUUFBUSxJQUFJLENBQUMsYUFBYSxPQUFPLE9BQU8sR0FBRyxhQUFhLFVBQVUsT0FBTyxDQUFDLENBQUMsR0FBRyxNQUFNO0dBQzFILE1BQU0sT0FBTyxNQUFNO0dBQ25CLE1BQU0sUUFBUSxNQUFNO0dBQ3BCLE1BQU0sY0FBYyxNQUFNO0dBQzFCLE1BQU0sU0FBUyxNQUFNO0dBQ3JCLE1BQU0sVUFBVTtFQUNqQixTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQVM7R0FDeEMsUUFBUSxNQUFNLEtBQUs7RUFDcEI7RUFDQSxJQUFJLE1BQU0sV0FBVyxhQUFhLE1BQU0sV0FBVztDQUNwRDtDQUNBLE9BQU87QUFDUjtBQUNBLGVBQWUsa0JBQWtCLFFBQVEsVUFBVSxTQUFTLFNBQVM7Q0FDcEUsTUFBTSxVQUFVLENBQUMsVUFBVSxPQUFPO0NBQ2xDLE1BQU0sU0FBUyxRQUFRLEVBQUUsQ0FBQztDQUMxQixJQUFJO0NBQ0osSUFBSTtFQUNILE1BQU0sWUFBWSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQzVDLElBQUksa0JBQWtCLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUztFQUNsRSxJQUFJLE9BQU8sUUFBUSxpQkFBaUIsVUFBVSxtQkFBbUIsR0FBRztHQUNuRSxNQUFNLFdBQVcsTUFBTVEsc0JBQW9CLFFBQVEsU0FBUyxLQUFLLEdBQUcsUUFBUSxlQUFlO0dBQzNGLFFBQVEsZ0JBQWdCLENBQUMsWUFBWSxLQUFLO0dBQzFDLFFBQVEsU0FBUyxDQUFDLFlBQVk7R0FDOUIsa0JBQWtCO0VBQ25CO0VBQ0EsSUFBSSxNQUFNLGtCQUFrQixJQUFJLFFBQVEsU0FBUyxrQkFBa0I7RUFDbkUsSUFBSSxjQUFjO0VBQ2xCLE9BQU8sY0FBYyxPQUFPLGdCQUFnQixpQkFBaUI7R0FDNUQsTUFBTSxRQUFRLFFBQVE7R0FDdEIsTUFBTSxZQUFZLFFBQVEsRUFBRSxDQUFDO0dBQzdCLE1BQU0sVUFBVSxVQUFVO0dBQzFCLElBQUksV0FBVyxPQUFPLE1BQU0sTUFBTSxVQUFVLFdBQVcsYUFBYSxNQUFNLFdBQVcsU0FBUyxPQUFPLE1BQU0sTUFBTSxRQUFRLFdBQVcsV0FBVztHQUMvSTtHQUNBLElBQUksVUFBVSxhQUFhLFFBQVEsV0FBVztFQUMvQztFQUNBLE1BQU0sUUFBUSxDQUFDO0VBQ2YsTUFBTSxRQUFRLFFBQVEsTUFBTTtFQUM1QixJQUFJLGlCQUFpQixRQUFRLFFBQVEsUUFBUSxRQUFRLFFBQVEsRUFBRSxJQUFJLEtBQUs7RUFDeEUsTUFBTSwyQkFBMkI7R0FDaEMsS0FBSyxJQUFJLFFBQVEsT0FBTyxRQUFRLEtBQUssU0FBUztJQUM3QyxJQUFJLE9BQU8sU0FBUztJQUNwQixpQkFBaUJELG1CQUFpQixRQUFRLFNBQVMsT0FBTyxPQUFPLGdCQUFnQixTQUFTLFdBQVc7R0FDdEc7RUFDRDtFQUNBLE1BQU0sVUFBVSxNQUFNRixnQkFBYyxRQUFRLFNBQVMsU0FBUyxLQUFLLG9CQUFvQixXQUFXO0VBQ2xHLElBQUksU0FBUztHQUNaLFFBQVEsS0FBSztHQUNiLE1BQU0sUUFBUTtHQUNkLElBQUksUUFBUSxFQUFFLENBQUMsT0FBT1AsYUFBVztJQUNoQyxNQUFNLFdBQVcsTUFBTVUsc0JBQW9CLFFBQVEsU0FBUyxTQUFTLE1BQU07SUFDM0UsUUFBUSxLQUFLO0lBQ2IsTUFBTSxLQUFLLElBQUksS0FBSyxXQUFXLENBQUM7R0FDakMsT0FBTyxJQUFJLFFBQVEsRUFBRSxDQUFDLE1BQU1ULGNBQVksTUFBTTtHQUM5QyxtQkFBbUI7RUFDcEI7RUFDQSxJQUFJLENBQUMsT0FBTyxXQUFXLENBQUMsUUFBUSxJQUFJO0dBQ25DLE1BQU0sUUFBUSxDQUFDO0dBQ2YsS0FBSyxNQUFNLENBQUMsSUFBSSxXQUFXLE9BQU8sWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSTtJQUNqRSxPQUFPLFNBQVMsT0FBTyxFQUFFO0lBQ3pCLE1BQU0sS0FBSyxPQUFPLEVBQUU7R0FDckI7R0FDQSxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsTUFBTTtFQUNsRDtFQUNBLE1BQU0sWUFBWSxXQUFXLFFBQVEsU0FBUyxPQUFPLFFBQVEsSUFBSSxZQUFZLE9BQU8sU0FBUyxRQUFRLEVBQUUsR0FBRyxRQUFRLEVBQUU7RUFDcEgsSUFBSSxRQUFRLEVBQUUsRUFBRSxRQUFRLFFBQVEsS0FBSyxZQUFZLFFBQVEsSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLFVBQVUsTUFBTSxlQUFlLFVBQVUsVUFBVSxJQUFJLElBQUksb0JBQW9CLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0VBQ3JMLFVBQVUsTUFBTTtDQUNqQixTQUFTLE9BQU87RUFDZixrQkFBa0IsUUFBUSxPQUFPO0VBQ2pDLElBQUksVUFBVSxVQUFVLE9BQU8sU0FBUyxPQUFPO0VBQy9DLE1BQU07Q0FDUDtDQUNBLElBQUksVUFBVSxPQUFPLEdBQUcsT0FBTztDQUMvQixPQUFPVSxjQUFZLFFBQVEsU0FBUyxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVMsUUFBUSxLQUFLLENBQUM7QUFDM0Y7Ozs7Ozs7QUFPQSxTQUFTLGFBQWEsUUFBUSxJQUFJO0NBQ2pDLElBQUksT0FBTyxRQUFRLElBQUk7Q0FDdkIsTUFBTSxVQUFVLEdBQUc7Q0FDbkIsTUFBTSxZQUFZLE9BQU8sT0FBTyxRQUFRLElBQUk7Q0FDNUMsSUFBSSxVQUFVLE9BQU87Q0FDckIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0VBQ3BELE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sVUFBVSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU07RUFDckQsTUFBTSxtQkFBbUIsVUFBVSxNQUFNLEVBQUUsT0FBTyxNQUFNLE1BQU0sVUFBVSxNQUFNLEVBQUUsV0FBVztFQUMzRixJQUFJLFdBQVcsQ0FBQyxrQkFBa0I7RUFDbEMsTUFBTSxRQUFRUixXQUFTLFFBQVEsS0FBSztFQUNwQyxNQUFNLFFBQVEsV0FBVyxNQUFNLFVBQVUsSUFBSSxNQUFNLFFBQVEsYUFBYSxPQUFPLFFBQVE7RUFDdkYsTUFBTSxZQUFZLE1BQU0sUUFBUSxvQkFBb0IsT0FBTyxRQUFRO0VBQ25FLElBQUksQ0FBQyxhQUFhLE9BQU8sVUFBVSxZQUFZLFVBQVUsVUFBVTtHQUNsRSxJQUFJLFNBQVM7SUFDWixRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7R0FDZDtHQUNBO0VBQ0Q7RUFDQSxNQUFNLE1BQU0sTUFBTSxRQUFRLGdCQUFnQixPQUFPLFFBQVEsdUJBQXVCO0VBQ2hGLElBQUksV0FBVztFQUNmLElBQUksVUFBVSxPQUFPLE1BQU0sSUFBSTtHQUM5QixXQUFXLFFBQVEsT0FBTztHQUMxQixRQUFRLEtBQUs7RUFDZCxPQUFPO0dBQ04sYUFBYSxVQUFVLEVBQUU7R0FDekIsT0FBTyxXQUFXLFVBQVUsS0FBSztFQUNsQztFQUNBLElBQUksQ0FBQyxTQUFTLE9BQU8sV0FBVyxVQUFVO0dBQ3pDO0dBQ0EsTUFBTTtHQUNOLG1CQUFtQixLQUFLLElBQUksSUFBSSxNQUFNLEdBQUcsS0FBSztHQUM5QyxLQUFLO0dBQ0wsb0JBQW9CLEtBQUs7R0FDekI7RUFDRDtFQUNBLElBQUksUUFBUSxNQUFNLENBQUMsWUFBWSxRQUFRLE9BQU8sV0FBVztFQUN6RCxRQUFRLEtBQUs7RUFDYixJQUFJLENBQUMsUUFBUSxJQUFJO0dBQ2hCLGFBQWEsUUFBUSxFQUFFO0dBQ3ZCLE1BQU0sWUFBWSxRQUFRLEtBQUssS0FBSyxJQUFJO0dBQ3hDLElBQUksWUFBWSxHQUFHO0lBQ2xCLFFBQVEsS0FBSyxpQkFBaUIsYUFBYSxRQUFRLEVBQUUsR0FBRyxTQUFTO0lBQ2pFO0dBQ0Q7R0FDQSxRQUFRLEtBQUs7RUFDZDtFQUNBLE1BQU0sVUFBVSxRQUFRLEtBQUssV0FBVztHQUN2QyxHQUFHO0dBQ0gsU0FBUyxLQUFLO0VBQ2YsRUFBRTtFQUNGLFFBQVEsTUFBTSxDQUFDLFNBQVM7RUFDeEIsTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLHNCQUFzQixPQUFPLE9BQU8sV0FBVyxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsTUFBTSxhQUFhO0dBQ3BILElBQUksWUFBWSxPQUFPLGFBQWEsV0FBVyxRQUFRLE9BQU8sT0FBTyxDQUFDLFFBQVEsSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLElBQUk7R0FDNUcsT0FBTztFQUNSLENBQUM7RUFDRDtDQUNEO0FBQ0Q7Ozs7O0FBS0EsU0FBUyxjQUFjLFFBQVEsSUFBSTtDQUNsQyxNQUFNLFVBQVUsT0FBTztDQUN2QixJQUFJLE9BQU8sUUFBUSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxNQUFNLFVBQVUsTUFBTSxPQUFPLFVBQVUsRUFBRSxHQUFHO0VBQ3JGLGFBQWEsVUFBVSxFQUFFO0VBQ3pCLE9BQU8sV0FBVyxLQUFLO0NBQ3hCO0FBQ0Q7QUFDQSxlQUFlLG9CQUFvQixRQUFRLElBQUk7Q0FDOUMsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxDQUFDLFNBQVM7Q0FDZCxhQUFhLFFBQVEsRUFBRTtDQUN2QixNQUFNLFlBQVksUUFBUSxLQUFLLEtBQUssSUFBSTtDQUN4QyxJQUFJLENBQUMsUUFBUSxNQUFNLGFBQWEsS0FBSyxDQUFDLG9CQUFvQixHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxFQUFFLEdBQUc7Q0FDM0csSUFBSTtDQUNKLElBQUk7RUFDSCxNQUFNRCxVQUFRLElBQUksU0FBUyxZQUFZO0dBQ3RDLFFBQVEsV0FBVyxTQUFTLFNBQVM7RUFDdEMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLE1BQU07Q0FDakIsUUFBUSxDQUFDO0NBQ1QsYUFBYSxLQUFLO0FBQ25CO0FBQ0EsU0FBUyxlQUFlLFFBQVEsU0FBUztDQUN4QyxPQUFPLGFBQWE7Q0FDcEIsT0FBTyxPQUFPLFdBQVcsT0FBTztBQUNqQztBQUNBLFNBQVMsY0FBYyxRQUFRLElBQUksU0FBUyxnQkFBZ0I7Q0FDM0QsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxjQUFjLE9BQU87Q0FDM0IsTUFBTSxpQkFBaUIsT0FBTztDQUM5QixLQUFLLE1BQU0sU0FBUyxTQUFTO0VBQzVCLE1BQU0sVUFBVTtFQUNoQixJQUFJLGdCQUFnQixNQUFNLFlBQVksS0FBSztDQUM1QztDQUNBLE1BQU0sTUFBTSxvQkFBb0IsT0FBTyxDQUFDLENBQUM7Q0FDekMsTUFBTSx5QkFBeUIsSUFBSSxJQUFJO0NBQ3ZDLElBQTZDLENBQUMsR0FBRyxJQUFJO0VBQ3BELE1BQU0sTUFBTSxLQUFLLElBQUk7RUFDckIsTUFBTSw2QkFBNkIsSUFBSSxJQUFJO0VBQzNDLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxRQUFRLFFBQVEsU0FBUztHQUNwRCxNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFFBQVEsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksTUFBTSxFQUFFO0VBQ3ZFO0VBQ0EsS0FBSyxNQUFNLFNBQVMsQ0FBQyxHQUFHLFVBQVUsR0FBRyxlQUFlLE9BQU8sQ0FBQyxHQUFHO0dBQzlELElBQUksTUFBTSxXQUFXLGFBQWEsV0FBVyxJQUFJLE1BQU0sRUFBRSxHQUFHO0dBQzVELE1BQU0sUUFBUUMsV0FBUyxRQUFRLEtBQUs7R0FDcEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxVQUFVLE1BQU0sTUFBTSxjQUFjLE1BQU0sVUFBVSxNQUFNLFFBQVEsaUJBQWlCLE9BQU8sUUFBUSx3QkFBd0IsTUFBTSxNQUFNLFFBQVEsVUFBVSxPQUFPLFFBQVEsaUJBQWlCLE1BQU07R0FDak4sT0FBTyxJQUFJLE1BQU0sSUFBSSxlQUFlLElBQUksTUFBTSxFQUFFLE1BQU0sUUFBUSxRQUFRO0lBQ3JFLEdBQUc7SUFDSCxTQUFTLEtBQUs7SUFDZCxZQUFZO0lBQ1osU0FBUyxDQUFDO0dBQ1gsQ0FBQztFQUNGO0NBQ0Q7Q0FDQSxHQUFHLEtBQUssQ0FBQztDQUNULE9BQU8sU0FBUztDQUNoQixNQUFNLFVBQVUsT0FBTyxnQkFBZ0IsYUFBYSxPQUFPO0NBQzNELGVBQWUsUUFBUSxPQUFPO0NBQzlCLHVCQUF1QixRQUFRLENBQUMsR0FBRyxlQUFlLE9BQU8sR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDLFFBQVEsVUFBVSxNQUFNLFdBQVcsT0FBTyxJQUFJLE1BQU0sRUFBRSxNQUFNLEtBQUssR0FBRyxPQUFPO0NBQ3pHO0VBQzFDLE1BQU0sVUFBVSxHQUFHLEVBQUUsR0FBRztFQUN4QixJQUFJLFdBQVcsT0FBTyxhQUFhLFNBQVMsUUFBUSxFQUFFLENBQUM7Q0FDeEQ7Q0FDQSxrQkFBa0IsUUFBUSxVQUFVLFNBQVMsYUFBYSxTQUFTLEVBQUU7QUFDdEU7Ozs7OztBQU1BLGVBQWUsYUFBYSxRQUFRLE9BQU87Q0FDMUMsSUFBSSxVQUFVLE9BQU87Q0FDckIsT0FBTyxXQUFXLFlBQVksT0FBTztFQUNwQyxRQUFRO0VBQ1IsTUFBTSxRQUFRO0VBQ2QsVUFBVSxPQUFPO0NBQ2xCO0FBQ0Q7QUFDQSxTQUFTLGVBQWUsUUFBUSxJQUFJLFNBQVM7Q0FDNUMsTUFBTSxVQUFVLFFBQVEsRUFBRSxDQUFDO0NBQzNCLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLElBQUksQ0FBQyxVQUFVLE9BQU8sT0FBTyxTQUFTO0VBQ3JDLEdBQUc7RUFDSCxTQUFTO0VBQ1QsZUFBZTtDQUNoQixDQUFDO0NBQ0QsSUFBSSxRQUFRLGdCQUFnQixPQUFPLE9BQU8sU0FBUztFQUNsRCxPQUFPLFNBQVMsa0JBQWtCLFNBQUEsQ0FBVTtFQUM1QyxnQkFBZ0I7RUFDaEIsU0FBUztFQUNULGVBQWU7Q0FDaEIsQ0FBQztDQUNELFNBQVMsYUFBYSxHQUFHLEtBQUs7Q0FDOUIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxZQUFZLE9BQU8sZUFBZTtFQUN2QyxHQUFHO0VBQ0gsZ0JBQWdCLFFBQVE7RUFDeEIsU0FBUztFQUNULGFBQWEsUUFBUTtFQUNyQixvQkFBb0IsUUFBUTtFQUM1QixlQUFlO0NBQ2hCLENBQUM7Q0FDRCxxQkFBcUI7RUFDcEIsSUFBSSxPQUFPLHFCQUFxQixVQUFVLE9BQU8sbUJBQW1CLEtBQUs7Q0FDMUUsQ0FBQztDQUNELE9BQU87QUFDUjtBQUNBLGVBQWUsY0FBYyxRQUFRLElBQUksTUFBTSxPQUFPLFlBQVk7Q0FDakUsTUFBTSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUUsR0FBRyxNQUFNLEVBQUU7Q0FDL0Msc0JBQXNCLElBQUk7Q0FDMUIsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN6QixjQUFjLFFBQVEsS0FBSyxLQUFLLEdBQUc7RUFDbkMsS0FBSyxLQUFLLE1BQU0sS0FBSztDQUN0QjtDQUNBLE1BQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJO0NBQ3pCLElBQUk7Q0FDSixJQUFJO0VBQ0gsVUFBVSxNQUFNLFdBQVcsUUFBUSxNQUFNLE9BQU8sR0FBRyxJQUFJLFVBQVU7Q0FDbEUsU0FBUyxPQUFPO0VBQ2YsdUJBQXVCLFFBQVEsSUFBSTtFQUNuQyxNQUFNO0NBQ1A7Q0FDQSxJQUFJLFVBQVUsT0FBTyxHQUFHO0VBQ3ZCLHVCQUF1QixRQUFRLElBQUk7RUFDbkMsSUFBSSxRQUFRLE9BQU9GLGdCQUFjLE9BQU8sUUFBUSxNQUFNLE9BQU8sZUFBZSxNQUFNLE1BQU0sZUFBZSxRQUFRLElBQUksT0FBTztFQUMxSDtDQUNEO0NBQ0EsTUFBTVUsY0FBWSxRQUFRLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTTtDQUMvQyxJQUFJLE9BQU8sUUFBUSxNQUFNLE9BQU8sZUFBZSxNQUFNO0VBQ3BELHVCQUF1QixRQUFRLElBQUk7RUFDbkM7Q0FDRDtDQUNBLEtBQUssTUFBTSxTQUFTLE1BQU07RUFDekIsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRTtFQUN6QyxJQUFJLFFBQVEsV0FBVyxPQUFPLFlBQVksTUFBTSxTQUFTO0dBQ3hELE9BQU8sT0FBTyxPQUFPLE1BQU0sRUFBRTtHQUM3QixjQUFjLFFBQVEsTUFBTTtFQUM3QjtDQUNEO0NBQ0EsZUFBZSxRQUFRLElBQUk7Q0FDM0IsdUJBQXVCLFFBQVEsTUFBTSxJQUFJO0FBQzFDO0FBQ0EsZUFBZSxxQkFBcUIsUUFBUSxJQUFJLGtCQUFrQixTQUFTLE1BQU0sZ0JBQWdCO0NBQ2hHLE1BQU0sU0FBUyxNQUFNLGtCQUFrQixRQUFRLEdBQUcsSUFBSSxHQUFHLElBQUk7RUFDNUQsR0FBRztFQUNILEdBQUc7RUFDSCxPQUFPO0VBQ1AsS0FBSztFQUNMO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksVUFBVSxNQUFNLEdBQUc7RUFDdEIsTUFBTSxTQUFTLE9BQU8sT0FBT1YsZ0JBQWMsT0FBTyxRQUFRO0VBQzFELElBQUksQ0FBQyxVQUFVLE9BQU8sRUFBRSxDQUFDLFFBQVEsZ0JBQWdCLGNBQWMsUUFBUSxFQUFFO0VBQ3pFLHVCQUF1QixRQUFRLEdBQUcsRUFBRTtFQUNwQyxHQUFHLEtBQUssQ0FBQztFQUNULElBQUksQ0FBQyxRQUFRO0VBQ2IsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixjQUFjLFFBQVEsRUFBRTtHQUN4QjtFQUNEO0VBQ0EsSUFBNkMsR0FBRyxJQUFJLE9BQU8sbUJBQW1CO0VBQzlFLE1BQU0sZUFBZSxRQUFRLElBQUksTUFBTTtFQUN2QztDQUNEO0NBQ0EsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxPQUFPLFFBQVEsSUFBSSxNQUFNLG9CQUFvQixRQUFRLEVBQUU7Q0FDM0QsSUFBSSxPQUFPLFFBQVEsSUFBSTtFQUN0QixjQUFjLFFBQVEsRUFBRTtFQUN4Qix1QkFBdUIsUUFBUSxPQUFPO0VBQ3RDLGtCQUFrQixRQUFRLE1BQU07RUFDaEM7Q0FDRDtDQUNBLE1BQU0sYUFBYSxHQUFHO0NBQ3RCLE1BQU0sYUFBYSxzQkFBc0IsWUFBWSxPQUFPLE9BQU8saUJBQWlCLElBQUksQ0FBQztDQUN6RixNQUFNLGFBQWEsT0FBTztDQUMxQixNQUFNLE9BQU8sb0JBQW9CLFlBQVk7RUFDNUMsSUFBSSxPQUFPLFFBQVEsSUFBSSxNQUFNLG9CQUFvQixRQUFRLEVBQUU7RUFDM0QsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixjQUFjLFFBQVEsRUFBRTtHQUN4Qix1QkFBdUIsUUFBUSxPQUFPO0dBQ3RDLGtCQUFrQixRQUFRLE1BQU07R0FDaEM7RUFDRDtFQUNBLE1BQU0sZUFBZTtHQUNwQixjQUFjLFFBQVEsRUFBRTtHQUN4QixjQUFjLFFBQVEsSUFBSSxTQUFTLGNBQWM7R0FDakQsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN2QixPQUFPLEtBQUs7SUFDWCxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7R0FDRCxJQUFJLE9BQU8sUUFBUSxJQUFJLE9BQU8sS0FBSztJQUNsQyxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7RUFDRjtFQUNBLE1BQU0sV0FBVyxNQUFNLE9BQU8sZ0JBQWdCLFFBQVEsT0FBTztFQUM3RCxJQUE2QyxHQUFHLElBQUksR0FBRyxLQUFLLEtBQUs7RUFDakUsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixrQkFBa0IsUUFBUSxNQUFNO0dBQ2hDO0VBQ0Q7RUFDQSxJQUFJLFlBQVksUUFBUSxjQUFjLFFBQVEsSUFBSSxTQUFTLFlBQVksT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLFFBQVEsS0FBSztFQUNyRyxPQUFPLFlBQVk7R0FDbEIsT0FBTyxPQUFPLGlCQUFpQixJQUFJLFVBQVU7R0FDN0MsT0FBTyxPQUFPLE9BQU8sSUFBSSxNQUFNO0dBQy9CLElBQUksT0FBTyxRQUFRLElBQUksT0FBTyxLQUFLO0lBQ2xDLE1BQU07SUFDTixHQUFHO0dBQ0osQ0FBQztHQUNELElBQUksWUFBWSxPQUFPLFFBQVEsSUFBSSxPQUFPLEtBQUs7SUFDOUMsTUFBTTtJQUNOLEdBQUc7R0FDSixDQUFDO0VBQ0YsQ0FBQztFQUNELElBQUksT0FBTyxRQUFRLElBQUk7RUFDdkIsT0FBTyxnQkFBZ0IsUUFBUTtFQUMvQixPQUFPLGlCQUFpQixLQUFLO0NBQzlCLENBQUM7QUFDRjtBQUNBLGVBQWUsZ0JBQWdCLFFBQVEsTUFBTTtDQUM1QyxJQUFJLGdCQUFnQjtDQUN1QixnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLENBQUMsQ0FBQyxPQUFPLE1BQU07Q0FDdkcsTUFBTSxnQkFBZ0IsT0FBTztDQUM3QixNQUFNLG1CQUFtQixPQUFPLE9BQU8saUJBQWlCLElBQUk7Q0FDNUQsTUFBTSxtQkFBbUIsb0JBQW9CLE9BQU8sT0FBTyxTQUFTLElBQUk7Q0FDeEUsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxrQkFBa0IsT0FBTztDQUMvQixNQUFNLFlBQVksaUJBQWlCLFNBQVMsU0FBUyxPQUFPLGdCQUFnQixjQUFjLElBQUk7Q0FDOUYsTUFBTSxVQUFVLE9BQU87Q0FDdkIsTUFBTSxzQkFBc0IsZ0JBQWdCLEtBQUssSUFBSSxVQUFVLEVBQUUsQ0FBQztDQUNsRSxNQUFNLFlBQVksSUFBSSxnQkFBZ0I7Q0FDdEMsTUFBTSxvQkFBb0IsT0FBTztDQUNqQyxPQUFPLGFBQWE7Q0FDcEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixVQUFVLEVBQUUsQ0FBQztDQUN6RCxtQkFBbUIsTUFBTTtDQUN6QixJQUFJLENBQUMsVUFBVSxPQUFPLFNBQVM7RUFDOUIsTUFBTSxhQUFhLHNCQUFzQixVQUFVLGdCQUFnQjtFQUNuRSxPQUFPLEtBQUs7R0FDWCxNQUFNO0dBQ04sR0FBRztFQUNKLENBQUM7RUFDRCxJQUFJLENBQUMsVUFBVSxPQUFPLFNBQVMsT0FBTyxLQUFLO0dBQzFDLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQztDQUNGO0NBQ0EsSUFBSSxVQUFVLE9BQU8sU0FBUztFQUM3QixNQUFNLGFBQWEsUUFBUSxhQUFhO0VBQ3hDO0NBQ0Q7Q0FDQSxNQUFNLFdBQVcsaUJBQWlCLFNBQVMsU0FBUztDQUNwRCxJQUFJLGFBQWE7Q0FDakIsTUFBTSxVQUFtRCxnQkFBZ0IsT0FBTyxZQUFZLFVBQVU7RUFDckcsYUFBYTtFQUNiLGdCQUFnQjtDQUNqQixDQUFDLElBQUksT0FBTyxZQUFZLFVBQVUsRUFBRSxhQUFhLFVBQVUsQ0FBQztDQUM1RCxzQkFBc0IsT0FBTztDQUM3QixNQUFNLGlCQUFpQixzQkFBc0IsUUFBUSxFQUFFLENBQUMsT0FBTyxJQUFJLEtBQUs7Q0FDeEUsSUFBSSxnQkFBZ0IsYUFBYTtNQUM1QixxQkFBcUIsTUFBTTtDQUNoQyxJQUFJLFVBQVUsT0FBTyxTQUFTO0VBQzdCLHVCQUF1QixRQUFRLE9BQU87RUFDdEMsTUFBTSxhQUFhLFFBQVEsYUFBYTtFQUN4QztDQUNEO0NBQ0EsT0FBTyxhQUFhLEtBQUs7Q0FDekIsSUFBSTtDQUNKLE1BQU0sWUFBWSxxQkFBcUIsUUFBUSxJQUFJLGdCQUFnQixhQUFhLFFBQVEsRUFBRSxHQUFHLE1BQU0sTUFBTSxjQUFjO0NBQ3ZILE1BQU0sT0FBTyxNQUFNLE9BQU8sSUFBSSxTQUFTLFlBQVksU0FBUyxPQUFPLElBQUksUUFBUSxRQUFRLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDakcsTUFBTSxLQUFLO0VBQ1Y7RUFDQTtFQUNBO0VBQ0E7RUFDQSxLQUFLLElBQUk7RUFDVCxLQUFLLFdBQVcsYUFBYSxRQUFRLEVBQUUsQ0FBQztDQUN6QztDQUNBLElBQTZDLGVBQWU7RUFDM0QsR0FBRyxLQUFLLENBQUMsT0FBTztFQUNoQixPQUFPLG1CQUFtQixLQUFLO0NBQ2hDO0NBQ0EsT0FBTyxNQUFNO0NBQ2IsSUFBSSxlQUFlO0VBQ2xCLEtBQUssTUFBTSxTQUFTLE9BQU8sT0FBTyxRQUFRLElBQUksR0FBRztHQUNoRCxJQUFJLE9BQU8sUUFBUSxJQUFJO0dBQ3ZCLElBQUksTUFBTSxZQUFZLFlBQVksUUFBUSxPQUFPLEtBQUs7RUFDdkQ7RUFDQSxjQUFjLEVBQUUsQ0FBQyxNQUFNO0VBQ3ZCLHVCQUF1QixRQUFRLGNBQWMsSUFBSSxHQUFHLElBQUksSUFBSTtDQUM3RDtDQUNBLElBQUksT0FBTyxRQUFRLElBQUk7RUFDdEIsdUJBQXVCLFFBQVEsR0FBRyxFQUFFO0VBQ3BDLEdBQUcsS0FBSyxDQUFDO0VBQ1QsU0FBUztFQUNULE1BQU0sYUFBYSxRQUFRLEVBQUU7RUFDN0I7Q0FDRDtDQUNBLE9BQU8sWUFBWTtFQUNsQixPQUFPLE9BQU8sT0FBTyxJQUFJLFNBQVM7RUFDbEMsT0FBTyxPQUFPLFNBQVMsSUFBSSxRQUFRO0NBQ3BDLENBQUM7Q0FDRCxJQUFJLGtCQUFrQixDQUFDLE9BQU8sV0FBVyxVQUFVLFFBQVEsRUFBRSxFQUFFLFdBQVcsYUFBYSxDQUFDLFFBQVEsTUFBTSxVQUFVLE1BQU0sU0FBUyxHQUFHLGFBQWEsUUFBUSxFQUFFO0NBQ3pKLFNBQVMsSUFBSSxDQUFDO0NBQ2QsTUFBTSxHQUFHO0FBQ1Y7QUFDQSxlQUFlLG1CQUFtQixRQUFRO0NBQ3pDLE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLElBQUksV0FBVyxDQUFDLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU0sV0FBVztFQUN2RSxNQUFNLFFBQVE7RUFDZCxJQUFJLE9BQU8sUUFBUSxTQUFTLE1BQU0sYUFBYSxRQUFRLE9BQU87Q0FDL0Q7Q0FDQSxPQUFPLFVBQVUsTUFBTTtDQUN2QixPQUFPLFdBQVc7Q0FDbEIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxnQkFBZ0IsUUFBUSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzdDO0FBQ0EsZUFBZSxtQkFBbUIsUUFBUSxNQUFNO0NBQy9DLElBQThDLE9BQU8sb0JBQW9CLE9BQU8sTUFBTSxJQUFLO0NBQzNGLElBQUksV0FBVyxPQUFPLGNBQWMsSUFBSTtDQUN4QyxLQUFLLElBQUksWUFBWSxJQUFJLGFBQWE7RUFDckMsTUFBTSxPQUFPLE9BQU87RUFDcEIsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBQ3ZDLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7R0FDSCxJQUFJO0lBQ0gsVUFBVSxPQUFPLFlBQVksVUFBVSxFQUFFLGFBQWEsV0FBVyxDQUFDO0lBQ2xFLHNCQUFzQixPQUFPO0lBQzdCLFVBQVUsT0FBTyw4QkFBOEIsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLFlBQVksT0FBTztJQUNqRixTQUFTLE1BQU0sa0JBQWtCLFFBQVEsVUFBVSxTQUFTO0tBQzNEO0tBQ0E7S0FDQTtLQUNBO0lBQ0QsQ0FBQztHQUNGLFVBQVU7SUFDVCxJQUFJLFFBQVE7S0FDWCxTQUFTLE9BQU8sT0FBTyxVQUFVO0tBQ2pDLHVCQUF1QixRQUFRLE9BQU87SUFDdkM7SUFDQSxXQUFXLE1BQU07R0FDbEI7R0FDQSxJQUFJLENBQUMsVUFBVSxNQUFNLEdBQUcsT0FBTyxPQUFPO0dBQ3RDLElBQUksQ0FBQyxVQUFVLE9BQU8sU0FBUyxLQUErQyxPQUFPLG9CQUFvQixPQUFPLE1BQU0sSUFBSztHQUMzSCxXQUFXLE9BQU87RUFDbkIsU0FBUyxPQUFPO0dBQ2YsSUFBSSxDQUFDLFdBQVcsS0FBSyxHQUFHLFFBQVEsTUFBTSxLQUFLO0dBQzNDO0VBQ0Q7Q0FDRDtBQUNEOzs7QUNua0NBLFNBQVMsWUFBWSxVQUFVLE9BQU87Q0FDckMsSUFBSSxDQUFDLFVBQVU7Q0FDZixJQUFJO0VBQ0gsTUFBTSxTQUFTLFNBQVMsS0FBSztFQUM3QixJQUFJLFdBQVcsS0FBSyxHQUFHLFFBQVEsUUFBUSxNQUFNLENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQztDQUM5RCxRQUFRLENBQUM7QUFDVjs7Ozs7Ozs7QUFRQSxTQUFTLGNBQWMsT0FBTyxRQUFRLFFBQVEsYUFBYTtDQUMxRCxNQUFNLFVBQVUsUUFBUSxRQUFRLEtBQUs7Q0FDckMsSUFBSSxPQUFPLFNBQVM7RUFDbkIsUUFBUSxNQUFNLFdBQVcsWUFBWSxRQUFRLE1BQU0sSUFBSSxVQUFVLFlBQVksYUFBYSxLQUFLLENBQUM7RUFDaEcsT0FBTyxRQUFRLE9BQU8sT0FBTyxNQUFNO0NBQ3BDO0NBQ0EsT0FBTyxJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQ3ZDLE1BQU0sY0FBYyxPQUFPLE9BQU8sTUFBTTtFQUN4QyxPQUFPLGlCQUFpQixTQUFTLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQztFQUN0RCxRQUFRLE1BQU0sV0FBVztHQUN4QixPQUFPLG9CQUFvQixTQUFTLEtBQUs7R0FDekMsSUFBSSxPQUFPLFNBQVMsWUFBWSxRQUFRLE1BQU07UUFDekMsUUFBUSxNQUFNO0VBQ3BCLElBQUksVUFBVTtHQUNiLE9BQU8sb0JBQW9CLFNBQVMsS0FBSztHQUN6QyxJQUFJLE9BQU8sU0FBUyxZQUFZLGFBQWEsS0FBSztRQUM3QyxPQUFPLEtBQUs7RUFDbEIsQ0FBQztDQUNGLENBQUM7QUFDRjs7O0FDM0JBLElBQU0sVUFBVTtBQUNoQixJQUFNLFFBQVE7QUFDZCxJQUFNLFlBQVk7QUFDbEIsSUFBTSxhQUFhO0FBQ25CLElBQU0sVUFBVTtBQUNoQixJQUFNLDZCQUE2QixPQUFPLE9BQU87Q0FDaEQsTUFBTTtDQUNOLFNBQVM7QUFDVixDQUFDO0FBQ0QsSUFBTSx3QkFBd0IsT0FBTyxPQUFPO0NBQzNDLE1BQU07Q0FDTixTQUFTO0FBQ1YsQ0FBQztBQUNELFNBQVMsU0FBUyxRQUFRLE9BQU87Q0FDaEMsT0FBTyxPQUFPLFdBQVcsTUFBTTtBQUNoQztBQUNBLFNBQVMsVUFBVSxPQUFPLFVBQVU7Q0FDbkMsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPLENBQUMsWUFBWSxLQUFLO0NBQ2hELElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxDQUFDLFdBQVcsS0FBSztDQUMvQyxJQUFJLFlBQVksT0FBTyxPQUFPLFNBQVMsWUFBWSxRQUFRLElBQUksTUFBTSx3QkFBd0IsRUFBRSxPQUFPLE1BQU0sQ0FBQztDQUM3RyxPQUFPLFdBQVcsQ0FBQyxPQUFPLEtBQUssSUFBSSxDQUFDLFNBQVMsS0FBSztBQUNuRDtBQUNBLFNBQVMsZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLFFBQVEsU0FBUyxNQUFNO0NBQzFFLFFBQVEsZUFBZTtDQUN2QixJQUFJLFVBQVUsVUFBVSxPQUFPLElBQUk7Q0FDbkMsSUFBSSxRQUFRLE9BQU8sT0FBTyxPQUFPLG9CQUFvQixRQUFRLE1BQU0sT0FBTyxTQUFTLFFBQVEsTUFBTTtDQUNqRyxJQUFJO0VBQ0gsTUFBTSxRQUFRLFVBQVUsUUFBUSxFQUFFO0NBQ25DLFNBQVMsY0FBYztFQUN0QixVQUFVLFVBQVUsY0FBYyxJQUFJO0NBQ3ZDO0NBQ0EsUUFBUSxlQUFlO0NBQ3ZCLE9BQU8sb0JBQW9CLFFBQVEsTUFBTSxPQUFPLFNBQVMsUUFBUSxNQUFNO0FBQ3hFO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUSxNQUFNLE9BQU8sU0FBUyxRQUFRLFNBQVMsTUFBTTtDQUNqRixJQUFJLFFBQVEsT0FBTyxZQUFZLE9BQU87Q0FDdEMsUUFBUSxlQUFlO0NBQ3ZCLElBQUk7RUFDSCxRQUFRLEVBQUUsQ0FBQyxRQUFRLGdCQUFnQixLQUFLO0VBQ3hDLE9BQU8sZ0JBQWdCLFFBQVEsRUFBRTtFQUNqQyxRQUFRLGVBQWU7RUFDdkIsT0FBTztDQUNSLFNBQVMsT0FBTztFQUNmLFFBQVEsZUFBZTtFQUN2QixPQUFPLFNBQVMsZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLFFBQVEsS0FBSyxJQUFJLENBQUMsT0FBTyxLQUFLO0NBQzFGO0FBQ0Q7QUFDQSxTQUFTLE1BQU0sT0FBTyxPQUFPO0NBQzVCLElBQUksVUFBVSxLQUFLLEdBQUcsT0FBTztFQUM1QixRQUFRO0VBQ1IsT0FBTztDQUNSO0NBQ0EsT0FBTztFQUNOLFFBQVE7RUFDUjtDQUNEO0FBQ0Q7QUFDQSxTQUFTLGFBQWEsUUFBUSxVQUFVO0NBQ3ZDLFFBQVEsWUFBWSxPQUFPLFNBQVM7RUFDbkMsR0FBRztFQUNILGVBQWU7Q0FDaEIsQ0FBQztBQUNGO0FBQ0EsU0FBUyxRQUFRLE9BQU8sUUFBUTtDQUMvQixPQUFPLFNBQVMsY0FBYyxPQUFPLE1BQU0sSUFBSTtBQUNoRDtBQUNBLFNBQVMsV0FBVyxRQUFRLE1BQU0sT0FBTztDQUN4QyxNQUFNLFFBQVEsS0FBSyxRQUFRO0NBQzNCLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztDQUNwQyxNQUFNLFlBQVksS0FBSyxRQUFRLFFBQVEsRUFBRSxFQUFFO0NBQzNDLElBQUksT0FBTyxRQUFRLEdBQUcsT0FBTyxNQUFNLE9BQU87Q0FDMUMsSUFBSSxjQUFjLE9BQU8sT0FBTztDQUNoQyxNQUFNLFdBQVcsVUFBVTtFQUMxQixPQUFPLFVBQVUsUUFBUSxjQUFjLGNBQWMsY0FBYztDQUNwRTtDQUNBLE1BQU0sYUFBYSxPQUFPLFFBQVEsY0FBYztDQUNoRCxNQUFNLG1CQUFtQixRQUFRLFVBQVU7Q0FDM0MsTUFBTSxNQUFNO0NBQ1osTUFBTSxTQUFTLE1BQU0sUUFBUTtDQUM3QixJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU87Q0FDOUIsSUFBSSxPQUFPLFdBQVcsWUFBWSxPQUFPLFFBQVEsTUFBTTtDQUN2RCxNQUFNLFVBQVU7RUFDZixRQUFRLE1BQU0sTUFBTSxRQUFRLE1BQU0sV0FBVztFQUM3QyxRQUFRLE1BQU0sTUFBTSxRQUFRLE1BQU0sV0FBVztFQUM3QyxVQUFVLEtBQUs7RUFDZixTQUFTLEtBQUssUUFBUSxLQUFLLGVBQWU7R0FDekMsT0FBTyxVQUFVO0dBQ2pCLFVBQVUsVUFBVTtHQUNwQixVQUFVLFVBQVU7R0FDcEIsWUFBWSxVQUFVO0dBQ3RCLElBQUksVUFBVTtHQUNkLFNBQVMsVUFBVTtHQUNuQixRQUFRLE1BQU0sVUFBVSxRQUFRLFVBQVUsV0FBVztHQUNyRCxRQUFRLE1BQU0sVUFBVSxRQUFRLFVBQVUsV0FBVztHQUNyRCxLQUFLLFVBQVU7RUFDaEIsRUFBRTtDQUNIO0NBQ0EsSUFBSTtFQUNILE9BQU8sUUFBUSxRQUFRLE9BQU8sT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLFVBQVUsUUFBUSxTQUFTLFVBQVUsQ0FBQztDQUNyRixTQUFTLE9BQU87RUFDZixPQUFPLFFBQVEsT0FBTyxLQUFLO0NBQzVCO0FBQ0Q7QUFDQSxTQUFTLGNBQWMsT0FBTyxTQUFTO0NBQ3RDLElBQUksUUFBUSxPQUFPLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxTQUFTLFFBQVEsRUFBRSxDQUFDLFVBQVUsTUFBTTtDQUNoRixPQUFPO0FBQ1I7QUFDQSxlQUFlLGNBQWMsUUFBUSxNQUFNLFFBQVE7Q0FDbEQsTUFBTSxpQkFBaUIsS0FBSyxRQUFRLFdBQVcsVUFBVSxNQUFNLFNBQVM7Q0FDeEUsSUFBSSxNQUFNLGlCQUFpQixJQUFJLEtBQUssUUFBUSxTQUFTLGlCQUFpQjtDQUN0RSxJQUFJO0NBQ0osSUFBSSxnQkFBZ0IsRUFBRSxHQUFHLE9BQU8sUUFBUSxXQUFXLENBQUMsRUFBRTtDQUN0RCxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsS0FBSyxTQUFTO0VBQ3pDLE1BQU0sUUFBUSxLQUFLLFFBQVE7RUFDM0IsTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLO0VBQ3BDLElBQUk7R0FDSCxNQUFNLE1BQU0sV0FBVyxRQUFRLE1BQU0sS0FBSztHQUMxQyxNQUFNLE1BQU0sZUFBZSxVQUFVLE1BQU0sTUFBTTtFQUNsRCxTQUFTLE9BQU87R0FDZixRQUFRLGVBQWU7R0FDdkIsVUFBVSxDQUFDLE9BQU8sY0FBYyxPQUFPLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQztHQUMxRixNQUFNO0VBQ1A7RUFDQSxRQUFRLGVBQWU7RUFDdkIsSUFBSSxVQUFVLEVBQUUsQ0FBQyxPQUFPLFlBQVk7RUFDcEMsTUFBTSxzQkFBc0IsS0FBSztFQUNqQyxJQUFJLFVBQVU7RUFDZCxJQUFJO0dBQ0gsSUFBSTtHQUNKLElBQUksTUFBTSxRQUFRLFNBQVM7SUFDMUIsTUFBTSxzQkFBc0I7S0FDM0IsTUFBTSxNQUFNO0tBQ1osUUFBUSxNQUFNO0tBQ2QsU0FBUztLQUNULFVBQVUsS0FBSztLQUNmLFVBQVUsYUFBYSxRQUFRLEtBQUssUUFBUTtLQUM1QyxlQUFlLE9BQU87S0FDdEIsT0FBTyxNQUFNO0tBQ2IsaUJBQWlCLE1BQU07S0FDdkIsU0FBUztLQUNULFNBQVMsS0FBSztLQUNkLFNBQVMsTUFBTTtJQUNoQjtJQUNBLGVBQWUsTUFBTSxRQUFRLFFBQVEsbUJBQW1CLEtBQUssS0FBSztHQUNuRTtHQUNBLFVBQVU7SUFDVCxHQUFHO0lBQ0gsR0FBRztHQUNKO0dBQ0EsTUFBTSxVQUFVO0VBQ2pCLFNBQVMsT0FBTztHQUNmLFFBQVEsZUFBZTtHQUN2QixJQUFJLENBQUMsU0FBUyxVQUFVLENBQUMsT0FBTyxjQUFjLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0dBQ3hHLE1BQU07R0FDTjtFQUNEO0VBQ0EsUUFBUSxlQUFlO0VBQ3ZCLElBQUksU0FBUztFQUNiLE1BQU0sa0JBQWtCLE1BQU0sZUFBZSxNQUFNO0VBQ25ELElBQUksb0JBQW9CLEtBQUssR0FBRztHQUMvQixVQUFVLENBQUMsT0FBTyxjQUFjLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxpQkFBaUIsTUFBTSxDQUFDLENBQUM7R0FDcEcsTUFBTTtHQUNOO0VBQ0Q7RUFDQSxRQUFRLGVBQWU7RUFDdkIsSUFBSSxNQUFNLFFBQVEsU0FBUyxDQUFDLE1BQU0sUUFBUSxZQUFZO0dBQ3JELGdCQUFnQjtHQUNoQjtFQUNEO0VBQ0EsTUFBTSxrQkFBa0IsTUFBTTtFQUM5QixNQUFNLFVBQVU7R0FDZixRQUFRLE1BQU07R0FDZDtHQUNBLFFBQVEsTUFBTTtHQUNkLFNBQVM7R0FDVDtHQUNBLFVBQVUsS0FBSztHQUNmLFVBQVUsYUFBYSxRQUFRLEtBQUssUUFBUTtHQUM1QyxlQUFlLE9BQU87R0FDdEIsT0FBTyxNQUFNO0dBQ2IsU0FBUyxLQUFLO0dBQ2QsU0FBUyxNQUFNO0dBQ2YsR0FBRyxPQUFPLFFBQVE7RUFDbkI7RUFDQSxJQUFJO0dBQ0gsTUFBTSxvQkFBb0IsTUFBTSxNQUFNLFFBQVEsV0FBVyxPQUFPO0dBQ2hFLFFBQVEsZUFBZTtHQUN2QixNQUFNLFVBQVUsY0FBYyxPQUFPLG9CQUFvQixRQUFRLE1BQU0sT0FBTyxVQUFVLG1CQUFtQixLQUFLLEdBQUcsTUFBTSxDQUFDO0dBQzFILElBQUksUUFBUSxPQUFPLFNBQVM7SUFDM0IsVUFBVSxDQUFDLE9BQU8sT0FBTztJQUN6QixNQUFNO0lBQ047R0FDRDtHQUNBLE1BQU0sc0JBQXNCO0dBQzVCLE1BQU0sVUFBVTtJQUNmLEdBQUc7SUFDSCxHQUFHO0dBQ0o7R0FDQSxnQkFBZ0IsTUFBTTtFQUN2QixTQUFTLE9BQU87R0FDZixRQUFRLGVBQWU7R0FDdkIsVUFBVSxDQUFDLE9BQU8sY0FBYyxPQUFPLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQztHQUMxRixNQUFNO0dBQ047RUFDRDtDQUNEO0NBQ0EsT0FBTztFQUNOLFVBQVUsS0FBSztFQUNmLFNBQVMsS0FBSztFQUNkO0VBQ0E7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPLE9BQU87Q0FDbkUsT0FBTztFQUNOLFFBQVEsTUFBTTtFQUNkLE1BQU0sTUFBTTtFQUNaLFNBQVM7RUFDVCxvQkFBb0IsTUFBTSxRQUFRLEVBQUUsRUFBRTtFQUN0QyxpQkFBaUIsTUFBTTtFQUN2QixTQUFTLE1BQU07RUFDZixVQUFVLEtBQUs7RUFDZixVQUFVLGFBQWEsUUFBUSxLQUFLLFFBQVE7RUFDNUMsT0FBTyxNQUFNO0VBQ2I7RUFDQSxHQUFHLE9BQU8sUUFBUTtDQUNuQjtBQUNEO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxRQUFRO0NBQzdELE1BQU0sUUFBUSxLQUFLLFFBQVE7Q0FDM0IsTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLO0NBQ3BDLElBQUk7Q0FDSixJQUFJLE1BQU0sUUFBUSxPQUFPLFVBQVUsUUFBUSxRQUFRLENBQUMsT0FBTyxDQUFDO01BQ3ZEO0VBQ0osTUFBTSxjQUFjLE1BQU0sUUFBUTtFQUNsQyxNQUFNLFNBQVMsT0FBTyxnQkFBZ0IsYUFBYSxjQUFjLGFBQWE7RUFDOUUsSUFBSSxDQUFDLFFBQVEsVUFBVSxRQUFRLFFBQVEsQ0FBQyxTQUFTLEtBQUssQ0FBQyxDQUFDO09BQ25ELFVBQVUsUUFBUSxRQUFRLENBQUMsQ0FBQyxXQUFXLE9BQU8saUJBQWlCLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXLFVBQVUsUUFBUSxLQUFLLElBQUksVUFBVSxVQUFVLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVc7R0FDOU0sSUFBSSxRQUFRLFdBQVcsTUFBTSxnQkFBZ0IsT0FBTyxXQUFXLHVCQUF1QixPQUFPLENBQUMsT0FBTztHQUNyRyxJQUFJLE9BQU8sT0FBTyxPQUFPLFNBQVMsZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLElBQUksTUFBTTtRQUNsRixTQUFTLG9CQUFvQixRQUFRLE1BQU0sT0FBTyxRQUFRLE1BQU07R0FDckUsT0FBTyxjQUFjLE9BQU8sTUFBTTtFQUNuQyxDQUFDO0NBQ0Y7Q0FDQSxNQUFNLGNBQWMsUUFBUSxNQUFNLFdBQVc7RUFDNUMsTUFBTSxXQUFXLEVBQUUsR0FBRyxNQUFNO0VBQzVCLElBQUksT0FBTyxPQUFPLFNBQVM7R0FDMUIsU0FBUyxhQUFhLE9BQU87R0FDN0IsU0FBUyxTQUFTO0dBQ2xCLFNBQVMsUUFBUSxLQUFLO0dBQ3RCLFNBQVMsVUFBVTtHQUNuQixTQUFTLGFBQWE7RUFDdkIsT0FBTyxJQUFJLE9BQU8sT0FBTyxPQUFPO0dBQy9CLFNBQVMsU0FBUztHQUNsQixTQUFTLFFBQVEsT0FBTztFQUN6QixPQUFPLElBQUksT0FBTyxPQUFPLFdBQVc7R0FDbkMsU0FBUyxTQUFTO0dBQ2xCLFNBQVMsUUFBUSxPQUFPO0VBQ3pCO0VBQ0EsT0FBTztDQUNSLENBQUM7Q0FDRCxPQUFPO0VBQ047RUFDQTtFQUNBLE9BQU87Q0FDUjtBQUNEO0FBQ0EsZUFBZSxvQkFBb0IsUUFBUSxTQUFTLFNBQVMsUUFBUSxXQUFXLEdBQUc7Q0FDbEYsTUFBTSxRQUFRLFVBQVUsRUFBRSxDQUFDO0NBQzNCLElBQUksUUFBUSxPQUFPLFVBQVUsUUFBUSxXQUFXLFVBQVUsTUFBTSxZQUFZLE1BQU0sT0FBTyxJQUFJLFVBQVUsTUFBTSxRQUFRLFNBQVM7Q0FDOUgsSUFBSSxRQUFRLEdBQUcsUUFBUTtDQUN2QixLQUFLLElBQUksWUFBWSxPQUFPLGFBQWEsR0FBRyxhQUFhO0VBQ3hELE1BQU0sUUFBUSxTQUFTLFFBQVEsUUFBUSxVQUFVO0VBQ2pELElBQUk7R0FDSCxNQUFNLFVBQVUsZUFBZSxPQUFPLEtBQUs7R0FDM0MsSUFBSSxTQUFTLE1BQU07RUFDcEIsUUFBUTtHQUNQLFFBQVEsZUFBZTtFQUN4QjtFQUNBLFFBQVEsZUFBZTtFQUN2QixJQUFJLE1BQU0sUUFBUSxtQkFBbUIsT0FBTztDQUM3QztDQUNBLE9BQU8sT0FBTyxVQUFVLFFBQVE7QUFDakM7QUFDQSxTQUFTLGFBQWEsU0FBUyxRQUFRLEdBQUcsU0FBUyw0QkFBNEI7Q0FDOUUsS0FBSyxJQUFJLFFBQVEsT0FBTyxRQUFRLFFBQVEsUUFBUSxTQUFTLFFBQVEsTUFBTSxDQUFDLGdCQUFnQixNQUFNLE1BQU07QUFDckc7QUFDQSxlQUFlLGFBQWEsUUFBUSxNQUFNLFNBQVMsUUFBUTtDQUMxRCxJQUFJLENBQUMsU0FBUztFQUNiLE1BQU0sV0FBVyxLQUFLLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUztFQUNsRSxJQUFJLFlBQVksR0FBRztHQUNsQixhQUFhLEtBQUssU0FBUyxXQUFXLENBQUM7R0FDdkMsT0FBTztJQUNOLFFBQVE7SUFDUjtJQUNBLE1BQU07R0FDUDtFQUNEO0VBQ0EsT0FBTyxFQUFFLFFBQVEsSUFBSTtDQUN0QjtDQUNBLE1BQU0sQ0FBQyxPQUFPLFdBQVc7Q0FDekIsSUFBSSxRQUFRLE9BQU8sT0FBTztFQUN6QixNQUFNLFFBQVEsS0FBSyxRQUFRO0VBQzNCLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sU0FBUztFQUNmLE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sYUFBYTtFQUNuQixhQUFhLEtBQUssU0FBUyxRQUFRLENBQUM7RUFDcEMsT0FBTztHQUNOLFFBQVE7R0FDUixVQUFVO0dBQ1YsTUFBTTtFQUNQO0NBQ0Q7Q0FDQSxNQUFNLFdBQVcsUUFBUSxNQUFNLE1BQU0sb0JBQW9CLFFBQVEsS0FBSyxTQUFTLFNBQVMsTUFBTTtDQUM5RixNQUFNLFFBQVEsS0FBSyxRQUFRO0NBQzNCLE1BQU0sUUFBUSxRQUFRO0NBQ3RCLE1BQU0sVUFBVSxNQUFNO0NBQ3RCLE1BQU0sWUFBWSxLQUFLO0NBQ3ZCLElBQUksTUFBTSxZQUFZLE9BQU8sVUFBVSxJQUFJO0VBQzFDLE1BQU0sU0FBUztFQUNmLE1BQU0sWUFBWTtFQUNsQixNQUFNLFFBQVE7Q0FDZixPQUFPO0VBQ04sTUFBTSxTQUFTO0VBQ2YsTUFBTSxRQUFRO0NBQ2Y7Q0FDQSxNQUFNLGFBQWE7Q0FDbkIsYUFBYSxLQUFLLFNBQVMsV0FBVyxDQUFDO0NBQ3ZDLE9BQU87RUFDTixRQUFRO0VBQ1I7RUFDQSxNQUFNO0NBQ1A7QUFDRDtBQUNBLGVBQWUsaUJBQWlCLFFBQVEsTUFBTSxLQUFLLFFBQVE7Q0FDMUQsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssUUFBUSxRQUFRLFNBQVM7RUFDekQsTUFBTSxRQUFRLEtBQUssUUFBUTtFQUMzQixJQUFJLFNBQVMsT0FBTyxNQUFNLFFBQVEsUUFBUSxNQUFNLFdBQVcsV0FBVztFQUN0RSxNQUFNLFFBQVEsU0FBUyxRQUFRLEtBQUs7RUFDcEMsSUFBSTtHQUNILE1BQU0sVUFBVSxlQUFlLEtBQUs7R0FDcEMsSUFBSSxTQUFTO0lBQ1osTUFBTSxRQUFRLFFBQVEsV0FBVztLQUNoQyxRQUFRLGVBQWU7SUFDeEIsSUFBSSxVQUFVO0tBQ2IsUUFBUSxlQUFlO0tBQ3ZCLE9BQU8sQ0FBQyxPQUFPLGNBQWMsT0FBTyxlQUFlLFFBQVEsTUFBTSxPQUFPLE9BQU8sTUFBTSxDQUFDLENBQUM7SUFDeEYsQ0FBQztJQUNELE1BQU0sWUFBWSxDQUFDLENBQUM7SUFDcEIsT0FBTyxLQUFLLEtBQUs7R0FDbEI7RUFDRCxTQUFTLE9BQU87R0FDZixRQUFRLGVBQWU7R0FDdkIsT0FBTyxLQUFLLENBQUMsT0FBTyxjQUFjLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDOUY7Q0FDRDtDQUNBLEtBQUssTUFBTSxTQUFTLFFBQVE7RUFDM0IsTUFBTSxVQUFVLE1BQU0sUUFBUSxLQUFLLElBQUksUUFBUSxNQUFNO0VBQ3JELElBQUksU0FBUyxPQUFPO0NBQ3JCO0FBQ0Q7QUFDQSxlQUFlLFlBQVksUUFBUSxNQUFNLFFBQVE7Q0FDaEQsS0FBSyxNQUFNLFNBQVMsS0FBSyxTQUFTO0VBQ2pDLE1BQU0sZUFBZSxTQUFTLFFBQVEsS0FBSyxDQUFDLENBQUM7RUFDN0MsSUFBSSxhQUFhLFFBQVEsYUFBYSxXQUFXLGFBQWEsU0FBUztHQUN0RSxNQUFNLFVBQVU7SUFDZixLQUFLLE9BQU8sUUFBUTtJQUNwQixTQUFTLEtBQUs7SUFDZDtJQUNBLFFBQVEsTUFBTTtJQUNkLFlBQVksTUFBTTtHQUNuQjtHQUNBLElBQUk7SUFDSCxNQUFNLENBQUMsTUFBTSxTQUFTLFdBQVcsTUFBTSxRQUFRLElBQUk7S0FDbEQsYUFBYSxPQUFPLE9BQU87S0FDM0IsYUFBYSxVQUFVLE9BQU87S0FDOUIsYUFBYSxVQUFVLE9BQU87SUFDL0IsQ0FBQztJQUNELFFBQVEsZUFBZTtJQUN2QixNQUFNLE9BQU8sTUFBTTtJQUNuQixNQUFNLFFBQVEsTUFBTTtJQUNwQixNQUFNLGNBQWMsTUFBTTtJQUMxQixNQUFNLFNBQVMsTUFBTTtJQUNyQixNQUFNLFVBQVU7SUFDaEIsTUFBTSxVQUFVO0dBQ2pCLFNBQVMsT0FBTztJQUNmLFFBQVEsZUFBZTtJQUN2QixRQUFRLE1BQU0sS0FBSztHQUNwQjtFQUNEO0VBQ0EsSUFBSSxNQUFNLFFBQVEsU0FBUyxNQUFNLFdBQVcsYUFBYSxNQUFNLFdBQVc7Q0FDM0U7QUFDRDtBQUNBLGVBQWUsa0JBQWtCLFFBQVEsVUFBVSxnQkFBZ0IsUUFBUTtDQUMxRSxNQUFNLFVBQVU7RUFDZjtFQUNBLFNBQVMsZUFBZSxLQUFLLFdBQVc7R0FDdkMsR0FBRztHQUNILHFCQUFxQixLQUFLO0dBQzFCLFNBQVMsQ0FBQztHQUNWLFlBQVk7R0FDWixpQkFBaUIsSUFBSSxnQkFBZ0I7RUFDdEMsRUFBRTtDQUNIO0NBQ0EsTUFBTSxrQkFBa0IsYUFBYSxRQUFRLFNBQVMsR0FBRyxRQUFRLFVBQVUsMEJBQTBCO0NBQ3JHLElBQUksUUFBUSxTQUFTO0VBQ3BCLFVBQVU7RUFDVixPQUFPLGVBQWU7Q0FDdkI7Q0FDQSxRQUFRLGlCQUFpQixTQUFTLFdBQVcsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUMzRCxJQUFJO0VBQ0gsTUFBTSx3QkFBd0IsUUFBUSxRQUFRLFdBQVcsVUFBVSxNQUFNLFNBQVM7RUFDbEYsSUFBSSxPQUFPLFFBQVEsaUJBQWlCLFVBQVUseUJBQXlCLEdBQUc7R0FDekUsTUFBTSxXQUFXLE1BQU0sb0JBQW9CLFFBQVEsUUFBUSxTQUFTLEtBQUssR0FBRyxRQUFRLHFCQUFxQjtHQUN6RyxJQUFJLGFBQWEsdUJBQXVCO0lBQ3ZDLFFBQVEsUUFBUSxzQkFBc0IsQ0FBQyxZQUFZLEtBQUs7SUFDeEQsUUFBUSxRQUFRLFNBQVMsQ0FBQyxZQUFZO0dBQ3ZDO0VBQ0Q7RUFDQSxNQUFNLE9BQU8sTUFBTSxjQUFjLFFBQVEsU0FBUyxNQUFNO0VBQ3hELFFBQVEsZUFBZTtFQUN2QixJQUFJLFlBQVksS0FBSztFQUNyQixJQUFJLEtBQUssVUFBVSxFQUFFLENBQUMsT0FBTyxZQUFZLFlBQVk7T0FDaEQsSUFBSSxLQUFLLFVBQVUsRUFBRSxDQUFDLE9BQU8sV0FBVztHQUM1QyxLQUFLLFFBQVEsS0FBSyxNQUFNLG9CQUFvQixRQUFRLEtBQUssU0FBUyxLQUFLLFNBQVMsTUFBTTtHQUN0RixZQUFZLEtBQUssSUFBSSxXQUFXLEtBQUssUUFBUSxLQUFLLENBQUM7RUFDcEQ7RUFDQSxNQUFNLFFBQVEsQ0FBQztFQUNmLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxXQUFXLFNBQVM7R0FDL0MsTUFBTSxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxPQUFPLE1BQU07R0FDaEUsTUFBTSxLQUFLLElBQUk7RUFDaEI7RUFDQSxJQUFJO0VBQ0osSUFBSSxVQUFVLEtBQUssVUFBVSxFQUFFLENBQUMsT0FBTyxhQUFhLEtBQUssVUFBVSxLQUFLO0VBQ3hFLElBQUk7R0FDSCxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLFFBQVEsTUFBTSxrQkFBa0I7SUFDMUUsTUFBTSxRQUFRLEtBQUssUUFBUSxLQUFLO0lBQ2hDLE1BQU0sVUFBVTtJQUNoQixJQUFJLFFBQVEsT0FBTyxTQUFTO0tBQzNCLE1BQU0sYUFBYSxRQUFRO0tBQzNCLE1BQU0sU0FBUztLQUNmLE1BQU0sUUFBUSxLQUFLO0tBQ25CLE1BQU0sVUFBVTtLQUNoQixNQUFNLGFBQWE7S0FDbkIsTUFBTSxZQUFZLEtBQUssSUFBSTtJQUM1QixPQUFPLElBQUksUUFBUSxPQUFPLFlBQVk7S0FDckMsVUFBVSxDQUFDLEtBQUssT0FBTyxPQUFPO0tBQzlCLE1BQU07SUFDUCxPQUFPO0tBQ04sSUFBSSxNQUFNLFFBQVEsT0FBTztNQUN4QixNQUFNLFNBQVM7TUFDZixNQUFNLFFBQVEsS0FBSztNQUNuQixNQUFNLFVBQVU7TUFDaEIsTUFBTSxhQUFhO0tBQ3BCO0tBQ0EsSUFBSSxDQUFDLGlCQUFpQixRQUFRLE9BQU8sU0FBUyxnQkFBZ0IsQ0FBQyxLQUFLLE9BQU8sT0FBTztJQUNuRjtHQUNELENBQUMsQ0FBQyxDQUFDO0VBQ0osU0FBUyxPQUFPO0dBQ2YsSUFBSSxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUcsTUFBTTtHQUNqQyxVQUFVO0VBQ1g7RUFDQSxRQUFRLGVBQWU7RUFDdkIsSUFBSSxVQUFVLEVBQUUsQ0FBQyxPQUFPLFlBQVk7R0FDbkMsYUFBYSxLQUFLLFNBQVMsR0FBRyxxQkFBcUI7R0FDbkQsT0FBTztJQUNOLE1BQU07SUFDTixVQUFVLFFBQVEsRUFBRSxDQUFDO0dBQ3RCO0VBQ0Q7RUFDQSxJQUFJLFVBQVUsS0FBSyxXQUFXO0VBQzlCLE1BQU0sa0JBQWtCLEtBQUssUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTO0VBQ3pFLElBQUk7RUFDSixJQUFJLFNBQVM7R0FDWixNQUFNLGFBQWEsUUFBUSxPQUFPLFFBQVEsRUFBRSxDQUFDLE9BQU8sWUFBWSxNQUFNLG9CQUFvQixRQUFRLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFBSSxRQUFRO0dBQzNJLEtBQUssTUFBTSxRQUFRLE9BQU87SUFDekIsSUFBSSxLQUFLLFNBQVMsWUFBWTtJQUM5QixNQUFNLFVBQVUsTUFBTSxLQUFLO0lBQzNCLElBQUksUUFBUSxPQUFPLFdBQVcsUUFBUSxLQUFLLGNBQWMsRUFBRSxnQkFBZ0IsS0FBSyxRQUFRLEtBQUssU0FBUztLQUNyRyxVQUFVLENBQUMsS0FBSyxPQUFPLE9BQU87S0FDOUIsUUFBUSxLQUFLLFFBQVEsT0FBTyxZQUFZLE1BQU0sb0JBQW9CLFFBQVEsS0FBSyxTQUFTLFNBQVMsTUFBTSxJQUFJLEtBQUs7S0FDaEg7SUFDRDtHQUNEO0dBQ0EsZUFBZSxRQUFRO0VBQ3hCLE9BQU8sZUFBZSxrQkFBa0IsSUFBSSxLQUFLLFFBQVEsU0FBUztFQUNsRSxNQUFNLGtCQUFrQixNQUFNLGlCQUFpQixRQUFRLE1BQU0sY0FBYyxNQUFNO0VBQ2pGLFFBQVEsZUFBZTtFQUN2QixJQUFJLGlCQUFpQjtHQUNwQixJQUFJLGdCQUFnQixFQUFFLENBQUMsT0FBTyxZQUFZO0lBQ3pDLGFBQWEsS0FBSyxTQUFTLEdBQUcscUJBQXFCO0lBQ25ELE9BQU87S0FDTixNQUFNO0tBQ04sVUFBVSxnQkFBZ0IsRUFBRSxDQUFDO0lBQzlCO0dBQ0Q7R0FDQSxVQUFVO0VBQ1g7RUFDQSxNQUFNLFdBQVcsTUFBTSxhQUFhLFFBQVEsTUFBTSxTQUFTLE1BQU07RUFDakUsSUFBSSxTQUFTLGFBQWEsS0FBSyxHQUFHO0dBQ2pDLE1BQU0sUUFBUSxLQUFLLFFBQVEsU0FBUztHQUNwQyxJQUFJLE1BQU0sUUFBUSxNQUFNO0lBQ3ZCLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztJQUNwQyxJQUFJO0tBQ0gsSUFBSSxTQUFTLFNBQVMsT0FBTyxNQUFNLGVBQWUsT0FBTyxnQkFBZ0I7VUFDcEUsSUFBSSxNQUFNLFdBQVcsTUFBTSxRQUFRLElBQUksQ0FBQyxlQUFlLEtBQUssR0FBRyxlQUFlLE9BQU8sbUJBQW1CLENBQUMsQ0FBQztVQUMxRyxNQUFNLGVBQWUsT0FBTyxtQkFBbUI7SUFDckQsUUFBUSxDQUFDO0lBQ1QsUUFBUSxlQUFlO0dBQ3hCO0VBQ0Q7RUFDQSxRQUFRLGVBQWU7RUFDdkIsTUFBTSxZQUFZLFFBQVE7R0FDekIsVUFBVSxLQUFLO0dBQ2YsU0FBUyxLQUFLO0VBQ2YsR0FBRyxNQUFNO0VBQ1QsUUFBUSxlQUFlO0VBQ3ZCLE9BQU8sV0FBVyxXQUFXLFlBQVk7R0FDeEMsSUFBSSxDQUFDLFNBQVMsVUFBVTtFQUN6QixDQUFDO0VBQ0QsT0FBTztHQUNOLE1BQU07R0FDTixRQUFRLFNBQVM7R0FDakIsU0FBUyxLQUFLO0VBQ2Y7Q0FDRCxVQUFVO0VBQ1QsUUFBUSxvQkFBb0IsU0FBUyxTQUFTO0NBQy9DO0FBQ0Q7QUFDQSxlQUFlLGdCQUFnQixRQUFRLE1BQU07Q0FDNUMsT0FBTyxxQkFBcUI7Q0FDNUIsTUFBTSxPQUFPLE9BQU87Q0FDcEIsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxjQUFjLE9BQU87Q0FDM0IsSUFBSTtDQUNKLElBQUk7RUFDSCxNQUFNLFlBQVksT0FBTyxjQUFjO0dBQ3RDLElBQUksS0FBSztHQUNULFFBQVE7R0FDUixRQUFRO0dBQ1IsTUFBTTtHQUNOLE9BQU87R0FDUCx3QkFBd0I7RUFDekIsQ0FBQztFQUNELElBQUksS0FBSyxlQUFlLFVBQVUsWUFBWSxNQUFNLFNBQVMsRUFBRSxNQUFNLFVBQVUsY0FBYyxJQUFJLENBQUM7RUFDbEcsTUFBTSxhQUFhLHNCQUFzQixNQUFNLE9BQU8sT0FBTyxpQkFBaUIsSUFBSSxDQUFDO0VBQ25GLE9BQU8sS0FBSztHQUNYLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQztFQUNELE9BQU8sS0FBSztHQUNYLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQztFQUNELE1BQU0sU0FBUyxlQUFlO0VBQzlCLFNBQVMsTUFBTSxRQUFRLGtCQUFrQixRQUFRLE1BQU0sT0FBTyxZQUFZLElBQUksR0FBRyxNQUFNLE9BQU8sR0FBRyxNQUFNLE9BQU87RUFDOUcsTUFBTSxTQUFTLGVBQWU7Q0FDL0IsU0FBUyxPQUFPO0VBQ2YsTUFBTSxTQUFTLGVBQWU7RUFDOUIsSUFBSSxDQUFDLFdBQVcsS0FBSyxHQUFHLE1BQU07RUFDOUIsTUFBTSxRQUFRLGdCQUFnQjtFQUM5QixTQUFTO0dBQ1IsTUFBTTtHQUNOLFVBQVUsT0FBTyxnQkFBZ0IsS0FBSztFQUN2QztDQUNEO0NBQ0EsT0FBTyxnQkFBZ0I7Q0FDdkIsSUFBSSxVQUFVO0NBQ2QsT0FBTyxZQUFZO0VBQ2xCLE9BQU8sT0FBTyxTQUFTLElBQUksSUFBSTtFQUMvQixPQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU07RUFDL0IsSUFBSSxPQUFPLFNBQVMsVUFBVTtHQUM3QixPQUFPLGFBQWEsT0FBTztHQUMzQixVQUFVLE9BQU8sZ0JBQWdCLGFBQWEsT0FBTyxPQUFPO0dBQzVELE9BQU8sT0FBTyxXQUFXLE9BQU8sT0FBTztHQUN2QyxPQUFPLE9BQU8saUJBQWlCLElBQUksSUFBSTtFQUN4QztDQUNELENBQUM7Q0FDRCxJQUFJLE9BQU8sU0FBUyxVQUFVLGtCQUFrQixRQUFRLFVBQVUsT0FBTyxTQUFTLGFBQWEsT0FBTztDQUN0RyxPQUFPLGdCQUFnQixRQUFRO0NBQy9CLE9BQU8saUJBQWlCLEtBQUs7QUFDOUI7Ozs7Ozs7O0FDdmtCQSxJQUFJLFdBQUEsYUFBbUJXO0FBQ3ZCLElBQUksa0JBQThCLE9BQU8sV0FBVyxjQUFBLGFBQXNCLFlBQUEsYUFBb0I7Ozs7Ozs7O0FDRDlGLElBQU0sdUJBQXVCLE9BQU8sSUFBSSxzQkFBc0I7Ozs7Ozs7Ozs7Ozs7QUFhOUQsU0FBUyxNQUFNLFVBQVUsU0FBUztDQUNqQyxNQUFNLFVBQVU7Q0FDaEIsSUFBSSxRQUFRLHVCQUF1QixPQUFPO0NBQzFDLFFBQVEsd0JBQXdCLEVBQUUsUUFBUSxVQUFVO0NBQ3BELFFBQVEsTUFBTSxTQUFTO0VBQ3RCLFFBQVEscUJBQXFCLENBQUMsU0FBUztFQUN2QyxRQUFRLHFCQUFxQixDQUFDLE9BQU87Q0FDdEMsQ0FBQyxDQUFDLENBQUMsT0FBTyxVQUFVO0VBQ25CLFFBQVEscUJBQXFCLENBQUMsU0FBUztFQUN2QyxRQUFRLHFCQUFxQixDQUFDLFFBQVE7R0FDckMsT0FBTyxTQUFTLGtCQUFrQixzQkFBQSxDQUF1QixLQUFLO0dBQzlELGlCQUFpQjtFQUNsQjtDQUNELENBQUM7Q0FDRCxPQUFPO0FBQ1I7OztBQ2xDQSxJQUFNLGlCQUFpQjs7O0FDQXZCLElBQU0sa0JBQWtCO0FBQ3hCLFNBQVMsb0JBQW9CLGtCQUFrQixNQUFNO0NBQ3BELElBQUksQ0FBQyxrQkFBa0I7Q0FDdkIsSUFBSSxPQUFPLHFCQUFxQixVQUFVLE9BQU87Q0FDakQsT0FBTyxpQkFBaUI7QUFDekI7QUFDQSxTQUFTLHdCQUF3QixVQUFVO0NBQzFDLE9BQU8sVUFBVSxnQkFBZ0I7QUFDbEM7QUFDQSxTQUFTLHNCQUFzQixVQUFVLE1BQU0sa0JBQWtCO0NBQ2hFLE1BQU0sY0FBYyx5QkFBeUIsSUFBSTtDQUNqRCxNQUFNLGNBQWMsb0JBQW9CLGtCQUFrQixRQUFRLEtBQUssWUFBWTtDQUNuRixPQUFPO0VBQ04sR0FBRyx3QkFBd0IsUUFBUSxNQUFNLFNBQVM7R0FDakQsS0FBSztHQUNMLElBQUk7RUFDTCxJQUFJLEVBQUUsS0FBSyxnQkFBZ0I7RUFDM0IsTUFBTSxZQUFZO0VBQ2xCLEdBQUcsY0FBYyxFQUFFLFlBQVksSUFBSSxDQUFDO0NBQ3JDO0FBQ0Q7QUFDQSxTQUFTLHlCQUF5QixNQUFNO0NBQ3ZDLElBQUksT0FBTyxTQUFTLFVBQVUsT0FBTztFQUNwQyxNQUFNO0VBQ04sYUFBYSxLQUFLO0NBQ25CO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxxQkFBcUIsUUFBUSxNQUFNO0NBQzNDLElBQUksS0FBSyxXQUFXLEdBQUc7Q0FDdkIsSUFBSSxLQUFLLFdBQVcsR0FBRztFQUN0QixPQUFPLEtBQUssS0FBSyxFQUFFO0VBQ25CO0NBQ0Q7Q0FDQSxNQUFNLHVCQUF1QixJQUFJLElBQUk7Q0FDckMsS0FBSyxNQUFNLE9BQU8sTUFBTTtFQUN2QixNQUFNLE1BQU0sS0FBSyxVQUFVLEdBQUc7RUFDOUIsSUFBSSxLQUFLLElBQUksR0FBRyxHQUFHO0VBQ25CLEtBQUssSUFBSSxHQUFHO0VBQ1osT0FBTyxLQUFLLEdBQUc7Q0FDaEI7QUFDRDtBQUlBLFNBQVMsdUJBQXVCLE1BQU07Q0FDckMsSUFBSSxPQUFPLFNBQVMsVUFBVSxPQUFPO0VBQ3BDLE1BQU07RUFDTixhQUFhLEtBQUs7Q0FDbkI7Q0FDQSxPQUFPO0FBQ1I7Ozs7Ozs7QUMvQ0EsSUFBTSxXQUFXLE9BQU8sU0FBUztDQUNoQyxNQUFNLFFBQVEsS0FBSyxNQUFNLEdBQUc7Q0FDNUIsSUFBSTtDQUNKLElBQUksSUFBSTtDQUNSLElBQUksUUFBUTtDQUNaLFFBQVEsT0FBTyxNQUFNLFNBQVMsUUFBUSxTQUFTLE1BQU0sUUFBUSxNQUFNO0NBQ25FLE9BQU8sU0FBUztBQUNqQjs7O0FDVkEsU0FBUyxzQkFBc0IsU0FBUyxVQUFVLE9BQU8sa0JBQWtCO0NBQzFFLE1BQU0sZUFBZSxpQkFBaUIsT0FBTztDQUM3QyxNQUFNLGVBQWUsQ0FBQztDQUN0QixNQUFNLGtCQUFrQixDQUFDO0NBQ3pCLEtBQUssTUFBTSxTQUFTLGNBQWMsS0FBSyxNQUFNLFVBQVUsTUFBTSxRQUFRLE1BQU0sT0FBTyxJQUFJLE1BQU0sVUFBVSxDQUFDLEdBQUc7RUFDekcsSUFBSSxDQUFDLFFBQVE7RUFDYixNQUFNLEVBQUUsVUFBVSxHQUFHLFVBQVU7RUFDL0IsYUFBYSxLQUFLO0dBQ2pCLEtBQUs7R0FDTCxPQUFPO0lBQ04sR0FBRztJQUNILEdBQUc7SUFDSDtHQUNEO0dBQ0E7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxJQUFJLFVBQVUsS0FBSyxNQUFNLFNBQVMsY0FBYyxLQUFLLE1BQU0sU0FBUyxTQUFTLE9BQU8sTUFBTSxRQUFRLEVBQUUsV0FBVyxDQUFDLEdBQUcsZ0JBQWdCLEtBQUs7RUFDdkksS0FBSztFQUNMLE9BQU87R0FDTixHQUFHLE1BQU07R0FDVDtFQUNEO0VBQ0EsVUFBVSxNQUFNO0NBQ2pCLENBQUM7Q0FDRCxPQUFPLENBQUMsY0FBYyxlQUFlO0FBQ3RDO0FBQ0EsU0FBUyxzQkFBc0IsQ0FBQyxjQUFjLGtCQUFrQix5QkFBeUI7Q0FDeEYsSUFBSSxDQUFDLHlCQUF5QixPQUFPLENBQUMsR0FBRyxjQUFjLEdBQUcsZUFBZTtDQUN6RSxPQUFPO0VBQ04sR0FBRyx3QkFBd0I7RUFDM0IsR0FBRztFQUNILEdBQUc7RUFDSCx3QkFBd0I7Q0FDekI7QUFDRDs7O0FDL0JBLElBQUksWUFBWSxNQUFNO0NBQ3JCLElBQUksS0FBSztFQUNSLE9BQU8sS0FBSztDQUNiO0NBQ0EsSUFBSSxLQUFLO0VBQ1IsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxJQUFJLE9BQU87RUFDVixPQUFPLEtBQUs7Q0FDYjtDQUNBLElBQUksV0FBVztFQUNkLE9BQU8sS0FBSztDQUNiO0NBQ0EsWUFBWSxTQUFTO0VBQ3BCLEtBQUssUUFBUSxrQkFBa0I7R0FDOUIsS0FBSyxnQkFBZ0I7R0FDckIsS0FBSyxVQUFVLEtBQUs7R0FDcEIsTUFBTSxVQUFVLEtBQUs7R0FDckIsTUFBTSxTQUFTLENBQUMsU0FBUyxRQUFRLENBQUMsU0FBUztHQUMzQyxLQUFLLGNBQWMsS0FBSyxRQUFRLGlCQUFpQjtHQUNqRCxJQUFJLFFBQVEsS0FBSyxRQUFRO1FBQ3BCLElBQUksQ0FBQyxLQUFLLGFBQzZCLE1BQU0sSUFBSSxNQUFNLCtIQUErSDtHQUczTCxJQUFJLE9BQU8sU0FBUyxjQUFjLFNBQVM7R0FDM0MsSUFBSSxRQUFRLFNBQVMsS0FBSyxPQUFPLGFBQWEsSUFBSTtHQUNsRCxNQUFNLFdBQVcsU0FBUyxNQUFNO0dBQ2hDLE1BQU0sS0FBSyxTQUFTLGNBQWMsV0FBVyxLQUFLLFlBQVksT0FBTyxhQUFhLEtBQUssS0FBSyxZQUFZLE1BQU0sT0FBTyxZQUFZLEdBQUc7R0FDcEksSUFBSSxTQUFTLFlBQVksT0FBTztHQUNoQyxNQUFNLFdBQVcsT0FBTyxhQUFhLE1BQU0sU0FBUyxLQUFLLElBQUksS0FBSyxZQUFZLFdBQVcsVUFBVSxLQUFLLFlBQVksV0FBVyxNQUFNLElBQUk7R0FDekksS0FBSyxRQUFRO0dBQ2IsS0FBSyxNQUFNO0dBQ1gsS0FBSyxZQUFZO0dBQ2pCLEtBQUssTUFBTSxjQUFjLFFBQVE7RUFDbEM7RUFDQSxLQUFLLGVBQWUsYUFBYTtHQUNoQyxPQUFPLEtBQUssaUJBQWlCLFFBQVE7RUFDdEM7RUFDQSxLQUFLLG9CQUFvQixhQUFhO0dBQ3JDLElBQUksTUFBTSxRQUFRLFFBQVEsR0FBRyxLQUFLLFdBQVc7R0FDN0MsSUFBSSxPQUFPLGFBQWEsWUFBWSxhQUFhLE1BQU0sS0FBSyxXQUFXLE9BQU8sT0FBTyxRQUFRO0dBQzdGLE9BQU87RUFDUjtFQUNBLEtBQUssc0JBQXNCO0dBQzFCLE9BQU87RUFDUjtFQUNBLEtBQUssZ0JBQWdCLFlBQVk7R0FDaEMsT0FBTyxPQUFPLEtBQUssU0FBUyxPQUFPO0dBQ25DLE9BQU87RUFDUjtFQUNBLEtBQUssVUFBVSxZQUFZO0dBQzFCLE9BQU8sT0FBTyxLQUFLLFNBQVMsT0FBTztHQUNuQyxPQUFPO0VBQ1I7RUFDQSxLQUFLLFFBQVEsV0FBVztHQUN2QixLQUFLLFNBQVM7R0FDZCxPQUFPO0VBQ1I7RUFDQSxLQUFLLFlBQVksU0FBUyxTQUFTO0dBQ2xDLE1BQU0sS0FBSztHQUNYLEdBQUc7RUFDSixDQUFDO0VBQ0QsS0FBSyxVQUFVLFdBQVcsQ0FBQztFQUMzQixLQUFLLFNBQVMsQ0FBQyxTQUFTO0VBQ3hCLElBQUksU0FBUyxNQUFNLFNBQVMsTUFBTSxNQUFNLElBQUksTUFBTSxxREFBcUQ7Q0FDeEc7QUFDRDtBQUNBLElBQUksZUFBZSxNQUFNO0NBQ3hCLFlBQVksRUFBRSxNQUFNO0VBQ25CLEtBQUssWUFBWSxTQUFTO0dBQ3pCLE9BQU8sU0FBUztJQUNmLFNBQVMsS0FBSztJQUNkLEdBQUc7R0FDSixDQUFDO0VBQ0Y7RUFDQSxLQUFLLFlBQVksU0FBUyxTQUFTO0dBQ2xDLE1BQU0sS0FBSztHQUNYLEdBQUc7RUFDSixDQUFDO0VBQ0QsS0FBSyxLQUFLO0NBQ1g7QUFDRDtBQUNBLElBQUksZ0JBQWdCLGNBQWMsVUFBVTtDQUMzQyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxPQUFPO0NBQ2Q7QUFDRDs7O0FDNUZBLElBQU0sc0JBQXNCLFlBQVk7Q0FDdkMsT0FBTztFQUNOLHVCQUF1QixRQUFRO0VBQy9CLFlBQVksUUFBUTtDQUNyQjtBQUNEOzs7Ozs7Ozs7Ozs7O0FDTUEsU0FBUyxtQkFBbUIsTUFBTTtDQUNqQyxRQUFRLEVBQUUsUUFBUSxXQUFXO0VBQzVCLE1BQU0sRUFBRSxRQUFRLGNBQWMsU0FBUyxLQUFLLFFBQVEsSUFBSTtFQUN4RCxJQUFJLFNBQVMsTUFBTTtHQUNsQixNQUFNLE9BQU87SUFDWixHQUFHO0lBQ0gsR0FBRztHQUNKO0dBQ0EsTUFBTSxVQUFVLEtBQUs7R0FDckIsTUFBTSxXQUFXLEtBQUs7R0FDdEIsS0FBSyxNQUFNLE9BQU8sU0FBUyxLQUFLLEtBQUssQ0FBQyxHQUFHLElBQUksWUFBWSxPQUFPLEtBQUssVUFBVSxHQUFHLEtBQUssVUFBVSxPQUFPLE1BQU0sUUFBUSxJQUFJLEdBQUcsQ0FBQyxHQUFHLE9BQU8sS0FBSztHQUM3SSxLQUFLLE1BQU0sT0FBTyxLQUFLLGNBQWMsQ0FBQyxHQUFHLE9BQU8sS0FBSztHQUNyRCxLQUFLLE1BQU0sT0FBTyxLQUFLLFdBQVcsS0FBSyxLQUFLLENBQUMsR0FBRyxJQUFJLE9BQU8sVUFBVSxDQUFDLEtBQUssWUFBWSxJQUFJLEdBQUcsS0FBSyxFQUFFLEtBQUssU0FBUyxJQUFJLEdBQUcsTUFBTSxZQUFZLE9BQU8sS0FBSyxVQUFVLEdBQUcsS0FBSyxVQUFVLE9BQU8sTUFBTSxLQUFLLFFBQVEsSUFBSSxHQUFHLENBQUMsS0FBSyxLQUFLLE9BQU8sT0FBTztHQUM5TyxPQUFPO0VBQ1I7RUFDQSxNQUFNLE9BQU8sRUFBRSxHQUFHLGFBQWE7RUFDL0IsTUFBTSxXQUFXLEtBQUs7RUFDdEIsS0FBSyxNQUFNLE9BQU8sTUFBTTtHQUN2QixNQUFNLFlBQVk7R0FDbEIsSUFBSSxFQUFFLEtBQUssWUFBWSxJQUFJLFNBQVMsS0FBSyxLQUFLLFNBQVMsSUFBSSxTQUFTLE1BQU0sWUFBWSxPQUFPLEtBQUssVUFBVSxTQUFTLEtBQUssVUFBVSxPQUFPLE1BQU0sS0FBSyxRQUFRLElBQUksU0FBUyxDQUFDLFFBQVEsRUFBRSxPQUFPLFNBQVMsT0FBTyxVQUFVLEtBQUssV0FBVyxJQUFJLFNBQVMsS0FBSyxVQUFVLEtBQUssTUFBTSxLQUFLLFVBQVUsSUFBSSxTQUFTLENBQUMsSUFBSSxLQUFLLE9BQU8sT0FBTztFQUNuVTtFQUNBLE9BQU87Q0FDUjtBQUNEOzs7Ozs7Ozs7OztBQVdBLFNBQVMsa0JBQWtCLE9BQU87Q0FDakMsU0FBUyxFQUFFLFFBQVEsTUFBTSxXQUFXO0VBQ25DLElBQUksVUFBVSxNQUFNO0dBQ25CLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxTQUFTLFFBQVE7SUFDcEMsSUFBSSxNQUFNLENBQUMsS0FBSywrQkFBK0IsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLEdBQUc7R0FDbEUsQ0FBQztHQUNELE9BQU8sQ0FBQztFQUNUO0VBQ0EsTUFBTSxTQUFTLEVBQUUsR0FBRyxLQUFLLE1BQU0sRUFBRTtFQUNqQyxJQUFJLE1BQU0sUUFBUSxLQUFLLEdBQUcsTUFBTSxTQUFTLFFBQVE7R0FDaEQsT0FBTyxPQUFPO0dBQ2QsSUFBSSxNQUFNLENBQUMsS0FBSywrQkFBK0IsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLEdBQUc7RUFDbEUsQ0FBQztPQUNJLE9BQU8sUUFBUSxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxXQUFXO0dBQ3BELElBQUksVUFBVSxPQUFPLE1BQU0sS0FBSyxHQUFHO0lBQ2xDLE9BQU8sT0FBTztJQUNkLElBQUksTUFBTSxDQUFDLEtBQUssNEJBQTRCLElBQUksSUFBSSxFQUFBLENBQUcsSUFBSSxLQUFLLEtBQUs7R0FDdEU7RUFDRCxDQUFDO0VBQ0QsT0FBTztDQUNSO0FBQ0Q7Ozs7Ozs7QUM5REEsU0FBUywyQkFBMkIsTUFBTTtDQUV4QyxJQUFJLENBQUMsS0FBSyxPQUFPLDhDQUE4QyxLQUFLLEtBQUssR0FBRyxHQUFHLE1BQU0sSUFBSSxNQUFNLG1DQUFtQyxLQUFLLFVBQVUsS0FBSyxHQUFHLEVBQUUsc0tBQXNLO0NBRWxVLE9BQU87QUFDUjs7Ozs7QUNKQSxTQUFTLFdBQVcsRUFBRSxTQUFTLFlBQVk7Q0FDMUMsSUFBSSxVQUFVLE9BQU8sU0FBUyxRQUFRO0NBQ3RDLE1BQU0sVUFBVSxNQUFNLFFBQVE7Q0FDOUIsSUFBSSxRQUFRLHFCQUFxQixDQUFDLFdBQVcsV0FBVyxNQUFNO0NBQzlELElBQUksUUFBUSxxQkFBcUIsQ0FBQyxXQUFXLFNBQVMsTUFBTSxRQUFRLHFCQUFxQixDQUFDO0NBQzFGLE9BQU8sUUFBUSxxQkFBcUIsQ0FBQztBQUN0Qzs7Ozs7QUFLQSxTQUFTLE1BQU0sT0FBTztDQUNyQixNQUFNLFFBQXdCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFlBQVksRUFBRSxHQUFHLE1BQU0sQ0FBQztDQUMxRCxJQUFJLE1BQU0sVUFBVSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBQSxhQUFZLFVBQVU7RUFDaEUsVUFBVSxNQUFNO0VBQ2hCLFVBQVU7Q0FDWCxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDMUIsTUFBTSxPQUFPLFdBQVcsS0FBSztDQUM3QixPQUFPLE1BQU0sU0FBUyxJQUFJO0FBQzNCOzs7QUN4QkEsSUFBSSwyQkFBQSxhQUEyRSxjQUFjLEtBQUssQ0FBQztBQUNuRyxTQUFTLCtCQUErQixTQUFTLFdBQVc7Q0FDM0QsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUkseUJBQXlCLFVBQVU7RUFDN0QsT0FBTztFQUNQLFVBQVU7Q0FDWCxDQUFDO0FBQ0Y7OztBQ0xBLElBQUksZ0JBQWdCLGNBQUEsYUFBc0IsVUFBVTtDQUNuRCxZQUFZLEdBQUcsT0FBTztFQUNyQixNQUFNLEdBQUcsS0FBSztFQUNkLEtBQUssUUFBUSxFQUFFLE9BQU8sRUFBRTtFQUN4QixLQUFLLGNBQWM7R0FDbEIsS0FBSyxTQUFTLEVBQUUsT0FBTyxFQUFFLENBQUM7RUFDM0I7Q0FDRDtDQUNBLE9BQU8seUJBQXlCLE9BQU8sT0FBTztFQUM3QyxNQUFNLFdBQVcsTUFBTSxZQUFZO0VBQ25DLElBQUksTUFBTSxTQUFTLE1BQU0sYUFBYSxVQUFVLE9BQU87R0FDdEQ7R0FDQSxPQUFPO0VBQ1I7RUFDQSxPQUFPLEVBQUUsU0FBUztDQUNuQjtDQUNBLE9BQU8seUJBQXlCLE9BQU87RUFDdEMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUU7Q0FDekI7Q0FDQSxrQkFBa0IsT0FBTyxXQUFXO0VBQ25DLEtBQUssTUFBTSxVQUFVLE9BQU8sU0FBUztDQUN0QztDQUNBLFNBQVM7RUFDUixNQUFNLFFBQVEsS0FBSyxNQUFNO0VBQ3pCLElBQUksT0FLSCxPQUErQywrQkFKekMsYUFBa0IsY0FBYyxLQUFLLE1BQU0sa0JBQWtCLGdCQUFnQjtHQUNsRixPQUFPLE1BQU07R0FDYixPQUFPLEtBQUs7RUFDYixDQUM4RSxHQUFTLGdCQUFnQjtFQUV4RyxPQUFPLEtBQUssTUFBTTtDQUNuQjtBQUNEO0FBQ0EsU0FBUyxlQUFlLEVBQUUsU0FBUztDQUNsQyxNQUFNLENBQUMsTUFBTSxXQUFBLGFBQW1CLFNBQVMsSUFBcUM7Q0FDOUUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUssT0FBTztFQUNsQyxPQUFPO0dBQ04sU0FBUztHQUNULFVBQVU7RUFDWDtFQUNBLFVBQVU7R0FDTyxpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBSyxPQUFPO0lBQzNCLE9BQU87S0FDTixTQUFTO0tBQ1QsWUFBWTtLQUNaLEtBQUs7SUFDTjtJQUNBLFVBQVUsQ0FBaUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtLQUN4QyxPQUFPLEVBQUUsVUFBVSxPQUFPO0tBQzFCLFVBQVU7SUFDWCxDQUFDLEdBQW1CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7S0FDakMsT0FBTztNQUNOLFlBQVk7TUFDWixVQUFVO01BQ1YsUUFBUTtNQUNSLFNBQVM7TUFDVCxZQUFZO01BQ1osY0FBYztLQUNmO0tBQ0EsZUFBZSxTQUFTLE1BQU0sQ0FBQyxDQUFDO0tBQ2hDLFVBQVUsT0FBTyxlQUFlO0lBQ2pDLENBQUMsQ0FBQztHQUNILENBQUM7R0FDZSxpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxPQUFPLEVBQUUsT0FBTyxFQUFFLFFBQVEsU0FBUyxFQUFFLENBQUM7R0FDMUQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksT0FBTyxFQUFFLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU87SUFDeEUsT0FBTztLQUNOLFVBQVU7S0FDVixRQUFRO0tBQ1IsY0FBYztLQUNkLFNBQVM7S0FDVCxPQUFPO0tBQ1AsVUFBVTtJQUNYO0lBQ0EsVUFBVSxPQUFPLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFFBQVEsRUFBRSxVQUFVLE1BQU0sUUFBUSxDQUFDLElBQUk7R0FDdkYsQ0FBQyxFQUFFLENBQUMsSUFBSTtFQUNUO0NBQ0QsQ0FBQztBQUNGOzs7QUMvRUEsSUFBSSxvQkFBb0I7QUFDeEIsSUFBSSwwQkFBMEI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCOUIsU0FBUyxXQUFXLEVBQUUsVUFBVSxXQUFXLFFBQVE7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUEsYUFBVSxVQUFVLEVBQUUsVUFBVSxZQUFZLElBQUksV0FBVyxTQUFTLENBQUM7QUFDN0Y7O0FBRUEsU0FBUyxZQUFZLFVBQVUsTUFBTTtDQUNwQyxPQUFBLGFBQWEscUJBQXFCLFdBQVcsYUFBYSxVQUFVLG9CQUFvQixXQUFXO0FBQ3BHO0FBQ0EsU0FBUyxZQUFZO0NBQ3BCLGFBQWEsQ0FBQztBQUNmOzs7QUM3QkEsSUFBSSxnQkFBQSxhQUF3QixjQUFjLElBQUk7Ozs7Ozs7Ozs7Ozs7QUNXOUMsU0FBUyxVQUFVLE1BQU07Q0FDeEIsTUFBTSxRQUFBLGFBQWdCLFdBQVcsYUFBYTtDQUM5QyxJQUFJLENBQUMsT0FBTyxrQkFBa0IsSUFBSTtDQUNsQyxPQUFPO0FBQ1I7QUFDQSxTQUFTLGtCQUFrQixNQUFNO0NBQ2hDLElBQThDLE1BQU0sUUFBUSxNQUFPLFFBQVEsS0FBSyxzRUFBc0U7QUFDdko7OztBQ2xCQSxJQUFJLGVBQUEsYUFBdUIsY0FBYyxLQUFLLENBQUM7QUFDL0MsSUFBSSxvQkFBQSxhQUE0QixjQUFjLEtBQUssQ0FBQzs7OztBQ0twRCxTQUFTLHFCQUFxQixFQUFFLFFBQVEsUUFBUSxhQUFhO0NBQzVELE9BQU87RUFDTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7Q0FDQSxTQUFTLEtBQUssS0FBSyxLQUFLLFNBQVM7RUFDaEMsTUFBTSxVQUFVLElBQUk7RUFDcEIsSUFBSSxZQUFZLEtBQUssS0FBSyxRQUFRLFFBQVEsS0FBSztFQUMvQyxNQUFNLFVBQVUsWUFBWSxLQUFLLElBQUksUUFBUSxVQUFVLElBQUk7RUFDM0QsSUFBSSxZQUFZLEtBQUssS0FBSyxRQUFRLFFBQVEsS0FBSztHQUM5QyxRQUFRLFVBQVU7R0FDbEIsSUFBSSxXQUFXO0dBQ2Y7RUFDRDtFQUNBLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLElBQUksWUFBWSxLQUFLLEtBQUssUUFBUSxZQUFZLFdBQVcsUUFBUSxRQUFRLEtBQUs7RUFDOUUsTUFBTSxVQUFVLElBQUksV0FBVyxJQUFJLFdBQVc7R0FDN0M7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsU0FBUyxLQUFLO0VBQ2Y7RUFDQSxJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtFQUMxQyxJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtPQUNyQyxJQUFJLE9BQU87RUFDaEIsSUFBSSxZQUFZLEtBQUssR0FBRyxRQUFRLFVBQVU7T0FDckMsSUFBSSxPQUFPO0NBQ2pCO0NBQ0EsU0FBUyxPQUFPLE1BQU0sTUFBTSxLQUFLLEtBQUs7RUFDckMsTUFBTSxNQUFNLEtBQUs7RUFDakIsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxVQUFVLEtBQUs7RUFDckIsSUFBSSxZQUFZLEtBQUssR0FBRyxRQUFRLFVBQVU7T0FDckMsSUFBSSxXQUFXO0VBQ3BCLElBQUksWUFBWSxLQUFLLEdBQUcsUUFBUSxVQUFVO09BQ3JDLElBQUksT0FBTztFQUNoQixJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtPQUNyQyxJQUFJLFdBQVc7RUFDcEIsSUFBSSxZQUFZLEtBQUssR0FBRyxRQUFRLFVBQVU7T0FDckMsS0FBSyxJQUFJLE9BQU8sYUFBYSxLQUFLLEdBQUcsVUFBVSxHQUFHO0VBQ3ZELE9BQU87Q0FDUjtDQUNBLFNBQVMsVUFBVSxNQUFNO0VBQ3hCLElBQUksT0FBTyxLQUFLO0VBQ2hCLElBQUk7RUFDSixLQUFLLEdBQUc7R0FDUCxNQUFNLE1BQU0sS0FBSztHQUNqQixJQUFJLFFBQVEsSUFBSTtHQUNoQixJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksUUFBUSxRQUFRO1FBQ2xDLElBQUksRUFBRSxRQUFTLEtBQVMsUUFBUTtRQUNoQyxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUksUUFBUSxRQUFRLEtBQUs7UUFDM0MsSUFBSSxFQUFFLFFBQVMsT0FBYSxZQUFZLE1BQU0sR0FBRyxHQUFHO0lBQ3hELElBQUksUUFBUSxRQUFTO0lBQ3JCLFNBQVM7R0FDVixPQUFPLFFBQVE7R0FDZixJQUFJLFFBQVEsR0FBRyxPQUFPLEdBQUc7R0FDekIsSUFBSSxRQUFRLEdBQUc7SUFDZCxNQUFNLFVBQVUsSUFBSTtJQUNwQixJQUFJLFlBQVksS0FBSyxHQUFHO0tBQ3ZCLE1BQU0sV0FBVyxPQUFPLFFBQUEsQ0FBUztLQUNqQyxJQUFJLFlBQVksS0FBSyxHQUFHO01BQ3ZCLFFBQVE7T0FDUCxPQUFPO09BQ1AsTUFBTTtNQUNQO01BQ0EsT0FBTztLQUNSO0tBQ0E7SUFDRDtHQUNEO0dBQ0EsS0FBSyxPQUFPLFVBQVUsS0FBSyxHQUFHO0lBQzdCLE9BQU8sS0FBSztJQUNaO0dBQ0Q7R0FDQSxPQUFPLFVBQVUsS0FBSyxHQUFHO0lBQ3hCLE9BQU8sTUFBTTtJQUNiLFFBQVEsTUFBTTtJQUNkLElBQUksU0FBUyxLQUFLLEdBQUc7S0FDcEIsT0FBTyxLQUFLO0tBQ1osU0FBUztJQUNWO0dBQ0Q7R0FDQTtFQUNELFNBQVM7Q0FDVjtDQUNBLFNBQVMsV0FBVyxNQUFNLEtBQUs7RUFDOUIsSUFBSTtFQUNKLElBQUksYUFBYTtFQUNqQixJQUFJLFFBQVE7RUFDWixLQUFLLEdBQUc7R0FDUCxNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLFFBQVEsSUFBSTtHQUNsQixJQUFJLElBQUksUUFBUSxJQUFJLFFBQVE7UUFDdkIsS0FBSyxRQUFTLFFBQWMsSUFDNUI7UUFBQSxPQUFPLEdBQUcsR0FBRztLQUNoQixNQUFNLE9BQU8sSUFBSTtLQUNqQixJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsaUJBQWlCLElBQUk7S0FDbEQsUUFBUTtJQUNUO1VBQ00sS0FBSyxRQUFTLFFBQWMsSUFBUztJQUMzQyxJQUFJLEtBQUssWUFBWSxLQUFLLEtBQUssS0FBSyxZQUFZLEtBQUssR0FBRyxRQUFRO0tBQy9ELE9BQU87S0FDUCxNQUFNO0lBQ1A7SUFDQSxPQUFPLElBQUk7SUFDWCxNQUFNO0lBQ04sRUFBRTtJQUNGO0dBQ0Q7R0FDQSxJQUFJLENBQUMsT0FBTztJQUNYLE1BQU0sVUFBVSxLQUFLO0lBQ3JCLElBQUksWUFBWSxLQUFLLEdBQUc7S0FDdkIsT0FBTztLQUNQO0lBQ0Q7R0FDRDtHQUNBLE9BQU8sY0FBYztJQUNwQixNQUFNLFdBQVcsSUFBSTtJQUNyQixNQUFNLGtCQUFrQixTQUFTLFlBQVksS0FBSztJQUNsRCxJQUFJLGlCQUFpQjtLQUNwQixPQUFPLE1BQU07S0FDYixRQUFRLE1BQU07SUFDZixPQUFPLE9BQU87SUFDZCxJQUFJLE9BQU87S0FDVixJQUFJLE9BQU8sR0FBRyxHQUFHO01BQ2hCLElBQUksaUJBQWlCLGlCQUFpQixRQUFRO01BQzlDLE1BQU0sS0FBSztNQUNYO0tBQ0Q7S0FDQSxRQUFRO0lBQ1QsT0FBTyxJQUFJLFNBQVM7SUFDcEIsTUFBTSxLQUFLO0lBQ1gsTUFBTSxVQUFVLEtBQUs7SUFDckIsSUFBSSxZQUFZLEtBQUssR0FBRztLQUN2QixPQUFPO0tBQ1AsU0FBUztJQUNWO0dBQ0Q7R0FDQSxPQUFPO0VBQ1IsU0FBUztDQUNWO0NBQ0EsU0FBUyxpQkFBaUIsTUFBTTtFQUMvQixHQUFHO0dBQ0YsTUFBTSxNQUFNLEtBQUs7R0FDakIsTUFBTSxRQUFRLElBQUk7R0FDbEIsS0FBSyxRQUFTLFFBQWMsSUFBSTtJQUMvQixJQUFJLFFBQVEsUUFBUTtJQUNwQixLQUFLLFFBQVMsT0FBWSxHQUFHLE9BQU8sR0FBRztHQUN4QztFQUNELFVBQVUsT0FBTyxLQUFLLGFBQWEsS0FBSztDQUN6QztDQUNBLFNBQVMsWUFBWSxXQUFXLEtBQUs7RUFDcEMsSUFBSSxPQUFPLElBQUk7RUFDZixPQUFPLFNBQVMsS0FBSyxHQUFHO0dBQ3ZCLElBQUksU0FBUyxXQUFXLE9BQU87R0FDL0IsT0FBTyxLQUFLO0VBQ2I7RUFDQSxPQUFPO0NBQ1I7QUFDRDs7O0FDN0tBLFNBQVMsV0FBVyxhQUFhLGNBQWMsbUJBQW1CO0NBQ2pFLE1BQU0sYUFBYSxPQUFPLGdCQUFnQjtDQUMxQyxNQUFNLE9BQU8sYUFBYSxjQUFjLEtBQUs7Q0FDN0MsT0FBTztFQUNOLE9BQU8sYUFBYSxZQUFZLE9BQU8sWUFBQSxFQUFjLEtBQUssSUFBSTtFQUM5RCxRQUFRLGFBQWEsWUFBWSxRQUFRLGFBQUEsRUFBZSxLQUFLLElBQUk7RUFDakUsV0FBVyxhQUFhLFlBQVksV0FBVyxrQkFBQSxFQUFvQixLQUFLLElBQUk7Q0FDN0U7QUFDRDtBQUNBLElBQU0sZ0JBQWdCLENBQUM7QUFDdkIsSUFBSSxRQUFRO0FBQ1osSUFBTSxFQUFFLE1BQU0sUUFBUSxXQUFXLFlBQVkscUJBQXFDLHFDQUFxQjtDQUN0RyxPQUFPLE1BQU07RUFDWixPQUFPLEtBQUssUUFBUTtDQUNyQjtDQUNBLE9BQU8sUUFBUTtFQUNkLGNBQWMseUJBQXlCO0VBQ3ZDLE9BQU8sU0FBUztDQUNqQjtDQUNBLFVBQVUsTUFBTTtFQUNmLElBQUksS0FBSyxhQUFhLEtBQUssR0FBRztHQUM3QixLQUFLLFdBQVcsS0FBSztHQUNyQixLQUFLLFFBQVE7R0FDYixVQUFVLElBQUk7RUFDZjtDQUNEO0FBQ0QsQ0FBQztBQUNELElBQUksY0FBYztBQUNsQixJQUFJLHNCQUFzQjtBQUMxQixJQUFJO0FBQ0osSUFBSSxhQUFhO0FBQ2pCLFNBQVMsTUFBTSxJQUFJO0NBQ2xCLElBQUk7RUFDSCxFQUFFO0VBQ0YsR0FBRztDQUNKLFVBQVU7RUFDVCxJQUFJLENBQUMsRUFBRSxZQUFZLE1BQU07Q0FDMUI7QUFDRDtBQUNBLFNBQVMsVUFBVSxLQUFLO0NBQ3ZCLE1BQU0sV0FBVyxJQUFJO0NBQ3JCLElBQUksTUFBTSxhQUFhLEtBQUssSUFBSSxTQUFTLFVBQVUsSUFBSTtDQUN2RCxPQUFPLFFBQVEsS0FBSyxHQUFHLE1BQU0sT0FBTyxLQUFLLEdBQUc7QUFDN0M7QUFDQSxTQUFTLFFBQVE7Q0FDaEIsSUFBSSxhQUFhLEdBQUc7Q0FDcEIsT0FBTyxjQUFjLHFCQUFxQjtFQUN6QyxNQUFNLFNBQVMsY0FBYztFQUM3QixjQUFjLGlCQUFpQixLQUFLO0VBQ3BDLE9BQU8sT0FBTztDQUNmO0NBQ0EsY0FBYztDQUNkLHNCQUFzQjtBQUN2QjtBQW9DQSxTQUFTLFdBQVcsV0FBVyxTQUFTO0NBQ3ZDLE1BQU0sYUFBYSxPQUFPLGNBQWM7Q0FDeEMsTUFBTSxTQUFTO0NBQ2YsTUFBTSxPQUFPO0VBQ1osV0FBVyxhQUFhLEtBQUssSUFBSTtFQUNqQyxNQUFNLEtBQUs7RUFDWCxVQUFVLEtBQUs7RUFDZixNQUFNLEtBQUs7RUFDWCxVQUFVLEtBQUs7RUFDZixPQUFPLGFBQWEsSUFBSTtFQUN4QixNQUFNO0dBQ0wsSUFBSSxjQUFjLEtBQUssR0FBRyxLQUFLLE1BQU0sV0FBVyxLQUFLO0dBQ3JELE9BQU8sS0FBSztFQUNiO0VBQ0EsVUFBVSxjQUFjO0dBQ3ZCLE1BQU0sTUFBTSxXQUFXLFlBQVk7R0FDbkMsTUFBTSxXQUFXLEVBQUUsU0FBUyxNQUFNO0dBQ2xDLE1BQU0sSUFBSSxhQUFhO0lBQ3RCLEtBQUssSUFBSTtJQUNULElBQUksQ0FBQyxTQUFTLFNBQVMsU0FBUyxVQUFVO1NBQ3JDO0tBQ0osWUFBWSxLQUFLO0tBQ2pCLElBQUksT0FBTyxLQUFLLFNBQVM7SUFDMUI7R0FDRCxDQUFDO0dBQ0QsT0FBTyxFQUFFLG1CQUFtQjtJQUMzQixFQUFFLEtBQUs7R0FDUixFQUFFO0VBQ0g7RUFDQSxRQUFRLFVBQVU7R0FDakIsTUFBTSxVQUFVO0dBQ2hCLE1BQU0sVUFBVSxTQUFTLFdBQVcsT0FBTztHQUMzQyxJQUFJLFlBQVk7SUFDZixZQUFZO0lBQ1osRUFBRTtJQUNGLEtBQUssV0FBVyxLQUFLO0dBQ3RCLE9BQU8sSUFBSSxhQUFhLEtBQUssR0FBRyxPQUFPO0dBQ3ZDLElBQUksWUFBWSxLQUFLLFFBQVE7R0FDN0IsSUFBSTtJQUNILE1BQU0sV0FBVyxLQUFLO0lBQ3RCLE1BQU0sV0FBVyxPQUFPLGFBQWEsYUFBYSxTQUFTLFFBQVEsSUFBSSxhQUFhLEtBQUssS0FBSyxhQUFhLE9BQU8sUUFBUSxJQUFJO0lBQzlILElBQUksYUFBYSxLQUFLLEtBQUssQ0FBQyxRQUFRLFVBQVUsUUFBUSxHQUFHO0tBQ3hELEtBQUssWUFBWTtLQUNqQixPQUFPO0lBQ1I7SUFDQSxPQUFPO0dBQ1IsVUFBVTtJQUNULFlBQVk7SUFDWixJQUFJLFlBQVksS0FBSyxTQUFTO0lBQzlCLFVBQVUsSUFBSTtHQUNmO0VBQ0Q7Q0FDRDtDQUNBLElBQUksWUFBWTtFQUNmLEtBQUssUUFBUTtFQUNiLEtBQUssTUFBTSxXQUFXO0dBQ3JCLE1BQU0sUUFBUSxLQUFLO0dBQ25CLElBQUksUUFBUSxNQUFNLFFBQVEsTUFBTSxXQUFXLEtBQUssTUFBTSxJQUFJLEdBQ3JEO1FBQUEsS0FBSyxRQUFRLEdBQUc7S0FDbkIsTUFBTSxPQUFPLEtBQUs7S0FDbEIsSUFBSSxTQUFTLEtBQUssR0FBRyxpQkFBaUIsSUFBSTtJQUMzQztVQUNNLElBQUksUUFBUSxJQUFJLEtBQUssUUFBUSxRQUFRO0dBQzVDLElBQUksY0FBYyxLQUFLLEdBQUcsS0FBSyxNQUFNLFdBQVcsS0FBSztHQUNyRCxPQUFPLEtBQUs7RUFDYjtDQUNELE9BQU8sS0FBSyxNQUFNLFNBQVMsV0FBVztFQUNyQyxJQUFJLEtBQUssUUFBUSxTQUFTLEdBQUc7R0FDNUIsTUFBTSxPQUFPLEtBQUs7R0FDbEIsSUFBSSxTQUFTLEtBQUssR0FBRztJQUNwQixVQUFVLElBQUk7SUFDZCxpQkFBaUIsSUFBSTtJQUNyQixNQUFNO0dBQ1A7RUFDRDtDQUNEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxPQUFPLElBQUk7Q0FDbkIsTUFBTSxZQUFZO0VBQ2pCLE1BQU0sVUFBVTtFQUNoQixZQUFZO0VBQ1osRUFBRTtFQUNGLFVBQVUsV0FBVyxLQUFLO0VBQzFCLFVBQVUsUUFBUTtFQUNsQixJQUFJO0dBQ0gsT0FBTyxHQUFHO0VBQ1gsVUFBVTtHQUNULFlBQVk7R0FDWixVQUFVLFNBQVM7R0FDbkIsVUFBVSxTQUFTO0VBQ3BCO0NBQ0Q7Q0FDQSxNQUFNLFlBQVk7RUFDakIsTUFBTSxLQUFLO0VBQ1gsVUFBVSxLQUFLO0VBQ2YsTUFBTSxLQUFLO0VBQ1gsVUFBVSxLQUFLO0VBQ2YsT0FBTztFQUNQLFNBQVM7R0FDUixNQUFNLFFBQVEsS0FBSztHQUNuQixJQUFJLFFBQVEsTUFBTSxRQUFRLE1BQU0sV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHLElBQUk7UUFDNUQsS0FBSyxRQUFRO0VBQ25CO0VBQ0EsT0FBTztHQUNOLEtBQUssUUFBUTtHQUNiLEtBQUssV0FBVyxLQUFLO0dBQ3JCLFVBQVUsSUFBSTtFQUNmO0NBQ0Q7Q0FDQSxJQUFJO0NBQ0osT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7O0NDak1BLENBQ0csV0FBWTtFQUNYLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsT0FBUSxNQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQVEsTUFBTSxLQUFLLE1BQU07RUFDeEU7RUFDQSxTQUFTLHVCQUF1QixXQUFXLGFBQWE7R0FDdEQscUJBQ0UsS0FBSyxNQUFNLE1BQU0sb0JBQ2Ysb0JBQW9CLENBQUMsR0FDdkIsUUFBUSxNQUNOLGdNQUNGO0dBQ0YsSUFBSSxRQUFRLFlBQVk7R0FDeEIsSUFBSSxDQUFDLDRCQUE0QjtJQUMvQixJQUFJLGNBQWMsWUFBWTtJQUM5QixTQUFTLE9BQU8sV0FBVyxNQUN4QixRQUFRLE1BQ1Asc0VBQ0YsR0FDQyw2QkFBNkIsQ0FBQztHQUNuQztHQUNBLGNBQWMsU0FBUyxFQUNyQixNQUFNO0lBQVM7SUFBb0I7R0FBWSxFQUNqRCxDQUFDO0dBQ0QsSUFBSSxPQUFPLFlBQVksRUFBRSxDQUFDLE1BQ3hCLGNBQWMsWUFBWTtHQUM1QixnQkFDRSxXQUFZO0lBQ1YsS0FBSyxRQUFRO0lBQ2IsS0FBSyxjQUFjO0lBQ25CLHVCQUF1QixJQUFJLEtBQUssWUFBWSxFQUFRLEtBQUssQ0FBQztHQUM1RCxHQUNBO0lBQUM7SUFBVztJQUFPO0dBQVcsQ0FDaEM7R0FDQSxVQUNFLFdBQVk7SUFDVix1QkFBdUIsSUFBSSxLQUFLLFlBQVksRUFBUSxLQUFLLENBQUM7SUFDMUQsT0FBTyxVQUFVLFdBQVk7S0FDM0IsdUJBQXVCLElBQUksS0FBSyxZQUFZLEVBQVEsS0FBSyxDQUFDO0lBQzVELENBQUM7R0FDSCxHQUNBLENBQUMsU0FBUyxDQUNaO0dBQ0EsY0FBYyxLQUFLO0dBQ25CLE9BQU87RUFDVDtFQUNBLFNBQVMsdUJBQXVCLE1BQU07R0FDcEMsSUFBSSxvQkFBb0IsS0FBSztHQUM3QixPQUFPLEtBQUs7R0FDWixJQUFJO0lBQ0YsSUFBSSxZQUFZLGtCQUFrQjtJQUNsQyxPQUFPLENBQUMsU0FBUyxNQUFNLFNBQVM7R0FDbEMsU0FBUyxPQUFPO0lBQ2QsT0FBTyxDQUFDO0dBQ1Y7RUFDRjtFQUNBLFNBQVMsdUJBQXVCLFdBQVcsYUFBYTtHQUN0RCxPQUFPLFlBQVk7RUFDckI7RUFDQSxnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiwrQkFDeEMsK0JBQStCLDRCQUE0QixNQUFNLENBQUM7RUFDcEUsSUFBSSxRQUFBLGNBQUEsR0FDRixXQUFXLGVBQWUsT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLElBQ3pELFdBQVcsTUFBTSxVQUNqQixZQUFZLE1BQU0sV0FDbEIsa0JBQWtCLE1BQU0saUJBQ3hCLGdCQUFnQixNQUFNLGVBQ3RCLG9CQUFvQixDQUFDLEdBQ3JCLDZCQUE2QixDQUFDLEdBQzlCLE9BQ0UsZ0JBQWdCLE9BQU8sVUFDdkIsZ0JBQWdCLE9BQU8sT0FBTyxZQUM5QixnQkFBZ0IsT0FBTyxPQUFPLFNBQVMsZ0JBQ25DLHlCQUNBO0VBQ1IsUUFBUSx1QkFDTixLQUFLLE1BQU0sTUFBTSx1QkFBdUIsTUFBTSx1QkFBdUI7RUFDdkUsZ0JBQWdCLE9BQU8sa0NBQ3JCLGVBQ0UsT0FBTywrQkFBK0IsOEJBQ3hDLCtCQUErQiwyQkFBMkIsTUFBTSxDQUFDO0NBQ3JFLEVBQUEsQ0FBRzs7Ozs7Q0N6RkgsT0FBTyxVQUFBLGlEQUFBOzs7Ozs7Ozs7Ozs7OztDQ01ULENBQ0csV0FBWTtFQUNYLFNBQVMsR0FBRyxHQUFHLEdBQUc7R0FDaEIsT0FBUSxNQUFNLE1BQU0sTUFBTSxLQUFLLElBQUksTUFBTSxJQUFJLE1BQVEsTUFBTSxLQUFLLE1BQU07RUFDeEU7RUFDQSxnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiwrQkFDeEMsK0JBQStCLDRCQUE0QixNQUFNLENBQUM7RUFDcEUsSUFBSSxRQUFBLGNBQUEsR0FDRixPQUFBLGFBQUEsR0FDQSxXQUFXLGVBQWUsT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLElBQ3pELHVCQUF1QixLQUFLLHNCQUM1QixTQUFTLE1BQU0sUUFDZixZQUFZLE1BQU0sV0FDbEIsVUFBVSxNQUFNLFNBQ2hCLGdCQUFnQixNQUFNO0VBQ3hCLFFBQVEsbUNBQW1DLFNBQ3pDLFdBQ0EsYUFDQSxtQkFDQSxVQUNBLFNBQ0E7R0FDQSxJQUFJLFVBQVUsT0FBTyxJQUFJO0dBQ3pCLElBQUksU0FBUyxRQUFRLFNBQVM7SUFDNUIsSUFBSSxPQUFPO0tBQUUsVUFBVSxDQUFDO0tBQUcsT0FBTztJQUFLO0lBQ3ZDLFFBQVEsVUFBVTtHQUNwQixPQUFPLE9BQU8sUUFBUTtHQUN0QixVQUFVLFFBQ1IsV0FBWTtJQUNWLFNBQVMsaUJBQWlCLGNBQWM7S0FDdEMsSUFBSSxDQUFDLFNBQVM7TUFDWixVQUFVLENBQUM7TUFDWCxtQkFBbUI7TUFDbkIsZUFBZSxTQUFTLFlBQVk7TUFDcEMsSUFBSSxLQUFLLE1BQU0sV0FBVyxLQUFLLFVBQVU7T0FDdkMsSUFBSSxtQkFBbUIsS0FBSztPQUM1QixJQUFJLFFBQVEsa0JBQWtCLFlBQVksR0FDeEMsT0FBUSxvQkFBb0I7TUFDaEM7TUFDQSxPQUFRLG9CQUFvQjtLQUM5QjtLQUNBLG1CQUFtQjtLQUNuQixJQUFJLFNBQVMsa0JBQWtCLFlBQVksR0FDekMsT0FBTztLQUNULElBQUksZ0JBQWdCLFNBQVMsWUFBWTtLQUN6QyxJQUFJLEtBQUssTUFBTSxXQUFXLFFBQVEsa0JBQWtCLGFBQWEsR0FDL0QsT0FBUSxtQkFBbUIsY0FBZTtLQUM1QyxtQkFBbUI7S0FDbkIsT0FBUSxvQkFBb0I7SUFDOUI7SUFDQSxJQUFJLFVBQVUsQ0FBQyxHQUNiLGtCQUNBLG1CQUNBLHlCQUNFLEtBQUssTUFBTSxvQkFBb0IsT0FBTztJQUMxQyxPQUFPLENBQ0wsV0FBWTtLQUNWLE9BQU8saUJBQWlCLFlBQVksQ0FBQztJQUN2QyxHQUNBLFNBQVMseUJBQ0wsS0FBSyxJQUNMLFdBQVk7S0FDVixPQUFPLGlCQUFpQix1QkFBdUIsQ0FBQztJQUNsRCxDQUNOO0dBQ0YsR0FDQTtJQUFDO0lBQWE7SUFBbUI7SUFBVTtHQUFPLENBQ3BEO0dBQ0EsSUFBSSxRQUFRLHFCQUFxQixXQUFXLFFBQVEsSUFBSSxRQUFRLEVBQUU7R0FDbEUsVUFDRSxXQUFZO0lBQ1YsS0FBSyxXQUFXLENBQUM7SUFDakIsS0FBSyxRQUFRO0dBQ2YsR0FDQSxDQUFDLEtBQUssQ0FDUjtHQUNBLGNBQWMsS0FBSztHQUNuQixPQUFPO0VBQ1Q7RUFDQSxnQkFBZ0IsT0FBTyxrQ0FDckIsZUFDRSxPQUFPLCtCQUErQiw4QkFDeEMsK0JBQStCLDJCQUEyQixNQUFNLENBQUM7Q0FDckUsRUFBQSxDQUFHOzs7OztDQzNGSCxPQUFPLFVBQUEsa0NBQUE7O0FDRFQsU0FBUyxlQUFlLEdBQUcsR0FBRztDQUM3QixPQUFPLE1BQU07QUFDZDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJBLFNBQVMsWUFBWSxRQUFRLFlBQVksTUFBTSxHQUFHLFNBQVM7Q0FDMUQsTUFBTSxVQUFVLFNBQVMsV0FBVztDQUNwQyxNQUFNLGFBQUEsR0FBWUMsYUFBQUEsWUFBQUEsRUFBYSxzQkFBc0I7RUFDcEQsTUFBTSxFQUFFLGdCQUFnQixPQUFPLFVBQVUsaUJBQWlCO0VBQzFELE9BQU87Q0FDUixHQUFHLENBQUMsTUFBTSxDQUFDO0NBQ1gsTUFBTSxlQUFBLEdBQWNBLGFBQUFBLFlBQUFBLE9BQWtCLE9BQU8sSUFBSSxHQUFHLENBQUMsTUFBTSxDQUFDO0NBQzVELFFBQUEsR0FBT0MscUJBQUFBLGlDQUFBQSxDQUFpQyxXQUFXLGFBQWEsYUFBYSxVQUFVLE9BQU87QUFDL0Y7OztBQzNCQSxJQUFJLGFBQWEsQ0FBQztBQUNsQixTQUFTLHFCQUFxQixNQUFNLFFBQVE7Q0FDM0MsTUFBTSxpQkFBQSxhQUF5QixPQUFPO0NBQ3RDLFFBQVEsVUFBVTtFQUNqQixNQUFNLFdBQVcsTUFBTSxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7RUFDckQsSUFBSSxNQUFNLHFCQUFxQixPQUFPLFFBQVEsMEJBQTBCLE9BQU8sZUFBZSxVQUFVLGlCQUFpQixlQUFlLFNBQVMsUUFBUTtFQUN6SixPQUFPO0NBQ1I7QUFDRDs7Ozs7QUFLQSxTQUFTLFNBQVMsTUFBTTtDQUN2QixNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLGlCQUFBLGFBQXlCLFdBQVcsS0FBSyxPQUFPLG9CQUFvQixZQUFZO0NBQ3RGLE1BQU0sVUFBVSxLQUFLLFFBQVE7Q0FDN0IsTUFBTSxhQUFhLE9BQU8sT0FBTyxjQUFjLE9BQU87Q0FDdEQsSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sUUFBUSxXQUFXLElBQUk7RUFDN0IsSUFBSSxDQUFDLE9BQU87R0FDWCxJQUFJLEtBQUssZUFBZSxNQUNvQixNQUFNLElBQUksTUFBTSxvQ0FBb0MsS0FBSyxPQUFPLHlCQUF5QixLQUFLLEtBQUssS0FBSyxvQkFBb0I7R0FHeEs7RUFDRDtFQUNBLE9BQU8sS0FBSyxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7Q0FDM0M7Q0FDQSxNQUFNLFdBQVcscUJBQXFCLE1BQU0sTUFBTTtDQUNsRCxNQUFNLGlCQUFpQixZQUFZLGFBQWEsVUFBVSxRQUFRLFNBQVMsS0FBSyxJQUFJLFVBQVU7Q0FDOUYsSUFBSSxtQkFBbUIsWUFBWSxPQUFPO0NBQzFDLElBQUksS0FBSyxlQUFlLE1BQ29CLE1BQU0sSUFBSSxNQUFNLG9DQUFvQyxLQUFLLE9BQU8seUJBQXlCLEtBQUssS0FBSyxLQUFLLG9CQUFvQjtBQUd6Szs7Ozs7Ozs7Ozs7Ozs7QUMvQkEsU0FBUyxjQUFjLE1BQU07Q0FDNUIsT0FBTyxTQUFTO0VBQ2YsTUFBTSxLQUFLO0VBQ1gsUUFBUSxLQUFLO0VBQ2IsbUJBQW1CLEtBQUs7RUFDeEIsU0FBUyxVQUFVO0dBQ2xCLE9BQU8sS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLFVBQVUsSUFBSSxNQUFNO0VBQzVEO0NBQ0QsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7OztBQ1RBLFNBQVMsY0FBYyxNQUFNO0NBQzVCLE1BQU0sRUFBRSxRQUFRLEdBQUcsU0FBUztDQUM1QixPQUFPLFNBQVM7RUFDZixHQUFHO0VBQ0gsU0FBUyxVQUFVO0dBQ2xCLE9BQU8sU0FBUyxPQUFPLE1BQU0sVUFBVSxJQUFJLE1BQU07RUFDbEQ7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7OztBQ1BBLFNBQVMsVUFBVSxNQUFNO0NBQ3hCLE9BQU8sU0FBUztFQUNmLE1BQU0sS0FBSztFQUNYLGFBQWEsS0FBSztFQUNsQixtQkFBbUIsS0FBSztFQUN4QixRQUFRLEtBQUs7RUFDYixTQUFTLFVBQVU7R0FDbEIsTUFBTSxTQUFTLEtBQUssV0FBVyxRQUFRLE1BQU0sU0FBUyxNQUFNO0dBQzVELE9BQU8sS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLElBQUk7RUFDNUM7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7OztBQ1hBLFNBQVMsVUFBVSxNQUFNO0NBQ3hCLE9BQU8sU0FBUztFQUNmLE1BQU0sS0FBSztFQUNYLFFBQVEsS0FBSztFQUNiLGFBQWEsS0FBSztFQUNsQixtQkFBbUIsS0FBSztFQUN4QixTQUFTLFVBQVU7R0FDbEIsT0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPLE1BQU0sTUFBTSxJQUFJLE1BQU07RUFDeEQ7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTEEsU0FBUyxZQUFZLGNBQWM7Q0FDbEMsTUFBTSxTQUFTLFVBQVU7Q0FDekIsT0FBQSxhQUFlLGFBQWEsWUFBWTtFQUN2QyxPQUFPLE9BQU8sU0FBUztHQUN0QixHQUFHO0dBQ0gsTUFBTSxRQUFRLFFBQVEsY0FBYztFQUNyQyxDQUFDO0NBQ0YsR0FBRyxDQUFDLGNBQWMsTUFBTSxNQUFNLENBQUM7QUFDaEM7Ozs7Ozs7Ozs7QUFVQSxTQUFTLFNBQVMsT0FBTztDQUN4QixNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLG1CQUFBLGFBQTJCLE9BQU8sSUFBSTtDQUM1QyxzQkFBc0I7RUFDckIsSUFBSSxpQkFBaUIsWUFBWSxPQUFPO0dBQ3ZDLFNBQVMsS0FBSztHQUNkLGlCQUFpQixVQUFVO0VBQzVCO0NBQ0QsR0FBRztFQUNGO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxPQUFPO0FBQ1I7OztBQ2xEQSxTQUFTLGdCQUFnQixNQUFNO0NBQzlCLE9BQU8sU0FBUztFQUNmLEdBQUc7RUFDSCxTQUFTLFVBQVUsS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLE9BQU8sSUFBSSxNQUFNO0NBQ3JFLENBQUM7QUFDRjs7O0FDRUEsU0FBUyxnQkFBZ0IsR0FBRyxRQUFRO0NBQ25DLE1BQU0sTUFBQSxhQUFjLE9BQU8sTUFBTTtDQUNqQyxNQUFNLFNBQVMsSUFBSTtDQUNuQixPQUFPLFNBQVMsT0FBTyxVQUFVO0VBQ2hDLElBQUksQ0FBQyxVQUFVLE9BQU8sUUFBUSxPQUFPLE9BQU8sSUFBSSxHQUFHLE9BQU8sU0FBUztDQUNwRSxDQUFDO0NBQ0QsT0FBTyxJQUFJO0FBQ1o7QUFDQSxTQUFTLFlBQVksUUFBUSxTQUFTO0NBQ3JDLE9BQU8sYUFBYSxPQUFPLENBQUMsQ0FBQyxPQUFPLFFBQVE7RUFDM0MsUUFBUSxLQUFLLEdBQUc7RUFDaEIsUUFBUSxLQUFLLGNBQWM7Q0FDNUIsQ0FBQztBQUNGO0FBQ0EsSUFBSSx3QkFBd0IsRUFBRSxVQUFVLEdBQUcsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUc7QUFDaEYsU0FBUyxvQkFBb0IsSUFBSSxtQkFBbUI7Q0FDbkQsTUFBTSxTQUFTLE9BQU8sT0FBTyxZQUFZLGFBQWEsRUFBRTtDQUN4RCxJQUFJLENBQUMsUUFBUTtDQUNiLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxNQUFNLEdBQUc7RUFDUSxRQUFRLEtBQUsseUNBQXlDLElBQUk7RUFDckcsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxnQkFBZ0IsVUFBVSxNQUFNLGVBQWUsVUFBVSxZQUFZO0NBQzdFLE1BQU0sY0FBYyxvQkFBb0IsU0FBUyxVQUFVLFFBQVE7Q0FDbkUsTUFBTSxXQUFXLG9CQUFvQixLQUFLLFVBQVUsUUFBUTtDQUM1RCxJQUFJLGVBQWUsUUFBUSxnQkFBZ0IsV0FBVyxFQUFFLFlBQVksV0FBVyxRQUFRLE1BQU0sWUFBWSxXQUFXLFNBQVMsVUFBVSxZQUFZLFNBQVMsWUFBWSxPQUFPLE9BQU87Q0FDdEwsSUFBSSxlQUFlLGlCQUFpQixNQUMvQjtNQUFBLENBQUMsVUFBVSxTQUFTLFFBQVEsS0FBSyxRQUFRLENBQUMsZUFBZSxPQUFPLGVBQWUsaUJBQWlCLEdBQUcsT0FBTztDQUFBO0NBRS9HLElBQUksZUFBZSxhQUFhLE9BQU8sY0FBYyxTQUFTLFNBQVMsS0FBSztDQUM1RSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGFBQWEsU0FBUyxjQUFjLE1BQU07Q0FDbEQsTUFBTSxTQUFTLFVBQVU7Q0FDekIsSUFBZ0IsT0FBTyxVQUFVLE9BQU8sbUJBQW1CLFFBQVEsU0FBUyxjQUFjLElBQUk7Q0FDOUYsTUFBTSxXQUFBLGFBQW1CLE9BQU8sSUFBSTtDQUNwQyxNQUFNLFlBQUEsYUFBb0IsYUFBYSxZQUFZO0VBQ2xELFNBQVMsVUFBVTtFQUNuQixJQUFJLE9BQU8saUJBQWlCLFlBQVksT0FBTyxhQUFhLE9BQU87RUFDbkUsSUFBSSxjQUFjLGFBQWEsVUFBVTtDQUMxQyxHQUFHLENBQUMsWUFBWSxDQUFDO0NBQ2pCLE1BQU0sRUFBRSxlQUFlLElBQUksU0FBUyxhQUFhLGNBQWMsa0JBQWtCLG9CQUFvQixTQUFTLGlCQUFpQixhQUFhLGdCQUFnQixlQUFlLFVBQVUsUUFBUSxTQUFTLFFBQVEsU0FBUyxjQUFjLGNBQWMsaUJBQWlCO0NBQ3BRLE1BQU0sYUFBYSxZQUFZLENBQUMsQ0FBQyxlQUFlLFdBQVc7Q0FDM0QsTUFBTSxDQUFDLGNBQWMsY0FBYyx1QkFBdUIsZ0JBQWdCLFFBQVEsUUFBUSxRQUFRLFFBQVEsYUFBYTtDQUN2SCxNQUFNLENBQUMsVUFBVSxRQUFBLGFBQWdCLGNBQWMsQ0FBQyxTQUFTLEVBQUUsR0FBRyxRQUFRLENBQUMsR0FBRztFQUN6RTtFQUNBLFFBQVE7RUFDUixRQUFRO0VBQ1IsUUFBUTtFQUNSLFFBQVE7RUFDUjtFQUNBO0VBQ0EsUUFBUTtFQUNSLFFBQVE7RUFDUixRQUFRO0NBQ1QsQ0FBQztDQUNELE1BQU0sa0JBQUEsYUFBMEIsY0FBYztFQUM3QyxNQUFNLHFCQUFxQixvQkFBb0IsSUFBSSxPQUFPLGlCQUFpQjtFQUMzRSxJQUFJLHVCQUF1QixLQUFLLEdBQUc7R0FDbEMsTUFBTSxRQUFRLENBQUMsc0JBQXNCLEtBQUssQ0FBQztHQUMzQyxhQUFhO0VBQ2Q7RUFDQSxJQUFJO0VBQ0osSUFBSTtFQUNKLFFBQVEsYUFBYTtHQUNwQixJQUFJLENBQUMsU0FBUyxlQUFlLEtBQUssZ0JBQWdCO0dBQ2xELE1BQU0sT0FBTyxPQUFPLGNBQWMsSUFBSTtHQUN0QyxNQUFNLE9BQU8sY0FBYyxNQUFNLFFBQVEsUUFBUTtHQUNqRCxJQUFJLENBQUMsWUFBWSxTQUFTLE9BQU8sTUFBTTtJQUN0QyxXQUFXLENBQUMsTUFBTSxFQUFFLFlBQVksUUFBUSxDQUFDLGFBQWEsSUFBSSxNQUFNLEtBQUssQ0FBQztJQUN0RSxTQUFTLENBQUMsTUFBTSxJQUFJO0dBQ3JCO0dBQ0EsT0FBTyxTQUFTLE9BQU8sS0FBSyxLQUFLLGdCQUFnQixVQUFVLE1BQU0scUJBQXFCLE9BQU8sVUFBVSxVQUFVLElBQUksU0FBUztFQUMvSDtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxNQUFNLENBQUMsTUFBTSxZQUFZLFlBQVksT0FBTyxPQUFPLFVBQVUsaUJBQWlCLHFCQUFxQjtDQUNuRyxNQUFNLGVBQWUsYUFBYSxLQUFLLEtBQUs7Q0FDNUMsTUFBTSxlQUFlLFlBQVksU0FBUyxLQUFLO0NBQy9DLE1BQU0sbUJBQUEsYUFBMkIsT0FBTyxLQUFLO0NBQzdDLE1BQU0sVUFBVSxRQUFRLGtCQUFrQixnQkFBZ0IsZUFBZSxRQUFRLGVBQWUsT0FBTyxRQUFRO0NBQy9HLE1BQU0sZUFBZSxvQkFBb0IsT0FBTyxRQUFRLHVCQUF1QjtDQUMvRSxNQUFNLGlCQUFBLGFBQXlCLGFBQWEsTUFBTTtFQUNqRCxNQUFNLGlCQUFpQixHQUFHO0VBQzFCLElBQUksRUFBRSxrQkFBa0IsWUFBWSxXQUFXO0dBQzlDLElBQUksbUJBQW1CLE9BQU8sY0FBYyxRQUFRO0dBQ3BEO0VBQ0Q7RUFDQSxJQUFJLENBQUMsY0FBYztHQUNsQixZQUFZLFFBQVEsUUFBUTtHQUM1QjtFQUNEO0VBQ0EsSUFBSSxXQUFXLElBQUksUUFBUSxHQUFHO0VBQzlCLFdBQVcsSUFBSSxVQUFVLGlCQUFpQjtHQUN6QyxXQUFXLE9BQU8sUUFBUTtHQUMxQixZQUFZLFFBQVEsUUFBUTtFQUM3QixHQUFHLFlBQVksQ0FBQztDQUNqQixHQUFHO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxhQUFRLGdCQUFnQjtFQUN2QixJQUFJLENBQUMsU0FBUztFQUNkLElBQUksWUFBWSxZQUFZLENBQUMsaUJBQWlCLFNBQVM7R0FDdEQsaUJBQWlCLFVBQVU7R0FDM0IsWUFBWSxRQUFRLFFBQVE7RUFDN0I7RUFDQSxJQUFJLFNBQVM7RUFDYixJQUFJO0VBQ0osSUFBSSxZQUFZLGNBQWMsU0FBUyxXQUFXLE9BQU8seUJBQXlCLFlBQVk7R0FDN0YsV0FBVyxJQUFJLHNCQUFzQixZQUFZO0lBQ2hELElBQUksUUFBUSxlQUFlLFFBQVEsSUFBSSxDQUFDO0dBQ3pDLEdBQUcsRUFBRSxZQUFZLFFBQVEsQ0FBQztHQUMxQixTQUFTLFFBQVEsU0FBUyxPQUFPO0VBQ2xDO0VBQ0EsYUFBYTtHQUNaLFNBQVM7R0FDVCxVQUFVLFdBQVc7R0FDckIsY0FBYyxRQUFRO0VBQ3ZCO0NBQ0QsR0FBRztFQUNGO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsTUFBTSxRQUFRLG9CQUFvQixTQUFTLElBQUk7Q0FDL0MsTUFBTSxNQUFNLGVBQWUsWUFBWTtDQUN2QyxJQUFJLGNBQWM7RUFDakIsTUFBTSxPQUFPO0VBQ2IsT0FBTztDQUNSO0NBQ0EsTUFBTSxlQUFlLE1BQU07RUFDMUIsTUFBTSxrQkFBa0IsVUFBVSxFQUFFLGNBQWMsYUFBYSxRQUFRO0VBQ3ZFLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLGFBQWEsQ0FBQyxFQUFFLHFCQUFxQixDQUFDLG1CQUFtQixvQkFBb0IsWUFBWSxFQUFFLFdBQVcsR0FBRztHQUN2SyxFQUFFLGVBQWU7R0FDakIsT0FBTyxTQUFTO0lBQ2YsR0FBRztJQUNIO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNELENBQUM7RUFDRjtDQUNEO0NBQ0EsTUFBTSx5QkFBeUI7RUFDOUIsSUFBSSxZQUFZLFVBQVUsWUFBWSxRQUFRLFFBQVE7Q0FDdkQ7Q0FDQSxNQUFNLG9CQUFvQjtFQUN6QixJQUFJLFlBQVksVUFBVSxjQUFjLFFBQVE7Q0FDakQ7Q0FDQSxNQUFNLFVBQVUsZ0JBQWdCLFNBQVMsV0FBVztDQUNwRCxNQUFNLFNBQVMsZ0JBQWdCLFFBQVEsV0FBVztDQUNsRCxNQUFNLFVBQVUsZ0JBQWdCLFNBQVMsY0FBYztDQUN2RCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsY0FBYztDQUNqRSxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsV0FBVztDQUM5RCxNQUFNLGVBQWUsZ0JBQWdCLGNBQWMsZ0JBQWdCO0NBQ25FLE9BQU8sZUFBZSxPQUFPLFNBQVMsVUFBVSxNQUFNLGNBQWMsSUFBSTtBQUN6RTtBQUNBLElBQUksc0JBQXNCLENBQUM7QUFDM0IsSUFBSSx1QkFBdUIsRUFBRSxXQUFXLFNBQVM7QUFDakQsSUFBSSxxQ0FBcUMsSUFBSSxJQUFJO0NBQ2hEO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7QUFDRCxDQUFDO0FBQ0QsU0FBUyxvQkFBb0IsU0FBUyxNQUFNO0NBQzNDLE1BQU0sUUFBUSxDQUFDO0NBQ2YsS0FBSyxNQUFNLE9BQU8sU0FBUztFQUMxQixJQUFJLG1CQUFtQixJQUFJLEdBQUcsS0FBSyxRQUFRLFVBQVUsU0FBUyxLQUFLLEtBQUssUUFBUSxjQUFjLFNBQVMsS0FBSztFQUM1RyxNQUFNLE9BQU8sUUFBUTtDQUN0QjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsZUFBZSxPQUFPLFNBQVMsVUFBVSxNQUFNLGNBQWMsTUFBTTtDQUMzRSxNQUFNLEVBQUUsYUFBYSxlQUFlLFdBQVcsT0FBTyxXQUFXO0NBQ2pFLE1BQU0sYUFBYSxpQkFBaUIsV0FBVyxjQUFjLGVBQWUsQ0FBQyxDQUFDLE1BQU0sV0FBVyx1QkFBdUI7Q0FDdEgsT0FBTyxPQUFPLE9BQU8sVUFBVTtDQUMvQixNQUFNLE9BQU87Q0FDYixJQUFJLFNBQVMsS0FBSyxNQUFNLFdBQVc7Q0FDbkMsTUFBTSxTQUFTO0NBQ2YsTUFBTSxhQUFhLFdBQVc7Q0FDOUIsSUFBSSxTQUFTLFlBQVksTUFBTSxRQUFRLFNBQVMsYUFBYTtFQUM1RCxHQUFHO0VBQ0gsR0FBRztDQUNKLElBQUksU0FBUztDQUNiLE1BQU0saUJBQWlCLFdBQVc7Q0FDbEMsSUFBSSxhQUFhLGdCQUFnQixNQUFNLFlBQVksWUFBWSxpQkFBaUIsR0FBRyxVQUFVLEdBQUcsbUJBQW1CLFlBQVk7Q0FDL0gsSUFBSSxjQUFjO0VBQ2pCLE1BQU0sT0FBTztFQUNiLE1BQU0sbUJBQW1CO0NBQzFCO0NBQ0EsSUFBSSxVQUFVO0VBQ2IsTUFBTSxpQkFBaUI7RUFDdkIsTUFBTSxrQkFBa0I7Q0FDekI7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLG1CQUFtQixRQUFRLFNBQVMsY0FBYyxNQUFNO0NBQ2hFLE1BQU0sRUFBRSxJQUFJLFVBQVUsa0JBQWtCO0NBQ3hDLE1BQU0scUJBQXFCLG9CQUFvQixJQUFJLE9BQU8saUJBQWlCO0NBQzNFLE1BQU0sT0FBTyx1QkFBdUIsS0FBSyxJQUFJLE9BQU8sY0FBYyxPQUFPLElBQUksS0FBSztDQUNsRixNQUFNLGFBQWEsT0FBTyxjQUFjLE1BQU0sUUFBUSxRQUFRLElBQUksc0JBQXNCLEtBQUs7Q0FDN0YsTUFBTSxlQUFlLFlBQVksQ0FBQztDQUNsQyxNQUFNLGVBQWUsdUJBQXVCLGNBQWMsYUFBYSxVQUFVLElBQUksYUFBYSxLQUFLO0NBQ3ZHLE1BQU0sUUFBUSxvQkFBb0IsU0FBUyxJQUFJO0NBQy9DLE1BQU0sTUFBTTtDQUNaLElBQUksY0FBYztFQUNqQixNQUFNLE9BQU87RUFDYixPQUFPO0NBQ1I7Q0FDQSxPQUFPLGVBQWUsT0FBTyxTQUFTLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxZQUFZLENBQUMsZUFBZSxnQkFBZ0IsT0FBTyxPQUFPLFNBQVMsSUFBSSxHQUFHLE1BQU0sZUFBZSxPQUFPLFVBQVUsS0FBSyxHQUFHLFlBQVksY0FBYyxJQUFJO0FBQzFNO0FBQ0EsSUFBSSw2QkFBNkIsSUFBSSxRQUFRO0FBQzdDLElBQUksaUJBQWlCLGdCQUFnQjtDQUNwQyxhQUFhLFdBQVcsSUFBSSxXQUFXLENBQUM7Q0FDeEMsV0FBVyxPQUFPLFdBQVc7QUFDOUI7QUFDQSxJQUFJLG1CQUFtQixPQUFPLFdBQVc7Q0FDeEMsSUFBSSxDQUFDLE9BQU8sT0FBTztDQUNuQixRQUFRLFVBQVUsTUFBTSxxQkFBcUIsTUFBTSxLQUFLLEdBQUcsTUFBTSxvQkFBb0IsT0FBTyxLQUFLO0FBQ2xHO0FBQ0EsU0FBUyxjQUFjLE1BQU0sUUFBUSxVQUFVO0NBQzlDLElBQUksVUFBVTtDQUNkLE1BQU0sV0FBVyxLQUFLLGtCQUFrQjtDQUN4QyxNQUFNLE9BQU8sU0FBUyxXQUFXLFNBQVMsYUFBYSxPQUFPLFFBQVEsV0FBVyxTQUFTLFVBQVUsS0FBSztDQUN6RyxLQUFLLFNBQVMsWUFBWSxTQUFTLFNBQVMsZUFBZSxvQkFBb0IsTUFBTSxPQUFPLGlCQUFpQixHQUFHO0VBQ3BFLFFBQVEsS0FBSyx5Q0FBeUMsTUFBTTtFQUN2RztDQUNEO0NBQ0EsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxXQUFXLE1BQU07Q0FDekIsT0FBQSxhQUFlLFdBQVcsU0FBUyxZQUFZLE9BQU8sS0FBSztFQUMxRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNO0dBQ2hDLEdBQUc7R0FDSCxVQUFVO0dBQ1Y7RUFDRCxDQUFDO0NBQ0YsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxJQUFJLE9BQUEsYUFBZSxLQUFBLGFBQWEsWUFBWSxPQUFPLFFBQVE7Q0FDMUQsTUFBTSxPQUFPLE1BQU0sWUFBWTtDQUMvQixNQUFNLFlBQVksYUFBYSxPQUFPLEtBQUssSUFBSTtDQUMvQyxNQUFNLFdBQVcsT0FBTyxNQUFNLGFBQWEsYUFBYSxNQUFNLFNBQVMsRUFBRSxVQUFVLFVBQVUsbUJBQW1CLFNBQVMsQ0FBQyxJQUFJLE1BQU07Q0FDcEksT0FBQSxhQUFlLGNBQWMsTUFBTSxXQUFXLFFBQVE7QUFDdkQsQ0FBQyxHQUFHLGlCQUFpQjtBQUNyQixTQUFTLGtCQUFrQixNQUFNLE1BQU07Q0FDdEMsSUFBSSxZQUFZO0NBQ2hCLEtBQUssTUFBTSxPQUFPLE1BQU07RUFDdkI7RUFDQSxJQUFJLEtBQUssU0FBUyxLQUFLLE1BQU07RUFDN0IsSUFBSSxDQUFDLG1CQUFtQixJQUFJLEdBQUcsS0FBSyxDQUFDLFVBQVUsS0FBSyxNQUFNLEtBQUssTUFBTSxPQUFPLElBQUksR0FBRyxPQUFPO0NBQzNGO0NBQ0EsS0FBSyxNQUFNLFFBQVEsTUFBTTtDQUN6QixPQUFPLGNBQWM7QUFDdEI7Ozs7Ozs7O0FBUUEsSUFBSSxlQUFlLFlBQVk7Q0FDOUIsT0FBTztBQUNSOzs7Ozs7Ozs7Ozs7QUM1VEEsU0FBUyxZQUFZLElBQUk7Q0FDeEIsT0FBTyxJQUFJLFNBQVMsRUFBRSxHQUFHLENBQUM7QUFDM0I7QUFDQSxJQUFJLFdBQVcsY0FBYyxhQUFhOzs7O0NBSXpDLFlBQVksRUFBRSxNQUFNO0VBQ25CLE1BQU0sRUFBRSxHQUFHLENBQUM7RUFDWixLQUFLLFlBQVksU0FBUztHQUN6QixPQUFPLFNBQVM7SUFDZixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxtQkFBbUIsU0FBUztHQUNoQyxPQUFPLGdCQUFnQjtJQUN0QixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsU0FBUztHQUMxQixPQUFPLFVBQVU7SUFDaEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsT0FBTyxjQUFjO0lBQ3BCLEdBQUc7SUFDSCxNQUFNLEtBQUs7SUFDWCxRQUFRO0dBQ1QsQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztJQUNYLFFBQVE7R0FDVCxDQUFDO0VBQ0Y7RUFDQSxLQUFLLG9CQUFvQjtHQUN4QixPQUFPLFlBQVksRUFBRSxNQUFNLFVBQVUsQ0FBQyxDQUFDLFdBQVcsS0FBSyxHQUFHLENBQUMsU0FBUyxDQUFDO0VBQ3RFO0VBQ0EsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsU0FBUyxLQUFLO0lBQ2QsR0FBRztHQUNKLENBQUM7RUFDRjtFQUNBLEtBQUssT0FBQSxhQUFhLFlBQVksT0FBTyxRQUFRO0dBQzVDLE1BQU0sV0FBVyxVQUFVLENBQUMsQ0FBQyxXQUFXLEtBQUssR0FBRyxDQUFDO0dBQ2pELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE1BQU07SUFDaEM7SUFDQSxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDtBQUNBLElBQUksUUFBUSxjQUFjLFVBQVU7Ozs7Q0FJbkMsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sT0FBTztFQUNiLEtBQUssWUFBWSxTQUFTO0dBQ3pCLE9BQU8sU0FBUztJQUNmLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLG1CQUFtQixTQUFTO0dBQ2hDLE9BQU8sZ0JBQWdCO0lBQ3RCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsU0FBUztHQUMxQixPQUFPLFVBQVU7SUFDaEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsT0FBTyxjQUFjO0lBQ3BCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLG9CQUFvQjtHQUN4QixPQUFPLFlBQVksRUFBRSxNQUFNLEtBQUssU0FBUyxDQUFDO0VBQzNDO0VBQ0EsS0FBSyxPQUFBLGFBQWEsWUFBWSxPQUFPLFFBQVE7R0FDNUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksTUFBTTtJQUNoQztJQUNBLE1BQU0sS0FBSztJQUNYLEdBQUc7R0FDSixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsWUFBWSxTQUFTO0NBQzdCLE9BQU8sSUFBSSxNQUFNLE9BQU87QUFDekI7Ozs7Ozs7Ozs7QUFVQSxTQUFTLDZCQUE2QjtDQUNyQyxRQUFRLFlBQVk7RUFDbkIsT0FBTyxnQkFBZ0IsT0FBTztDQUMvQjtBQUNEOzs7O0FBSUEsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxZQUFZLGNBQWMsY0FBYzs7OztDQUkzQyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxPQUFPO0VBQ2IsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssbUJBQW1CLFNBQVM7R0FDaEMsT0FBTyxnQkFBZ0I7SUFDdEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGlCQUFpQixTQUFTO0dBQzlCLE9BQU8sY0FBYztJQUNwQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssb0JBQW9CO0dBQ3hCLE9BQU8sWUFBWSxFQUFFLE1BQU0sS0FBSyxTQUFTLENBQUM7RUFDM0M7RUFDQSxLQUFLLE9BQUEsYUFBYSxZQUFZLE9BQU8sUUFBUTtHQUM1QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNO0lBQ2hDO0lBQ0EsTUFBTSxLQUFLO0lBQ1gsR0FBRztHQUNKLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDs7Ozs7Ozs7Ozs7QUFXQSxTQUFTLGdCQUFnQixTQUFTO0NBQ2pDLE9BQU8sSUFBSSxVQUFVLE9BQU87QUFDN0I7QUFDQSxTQUFTLGdCQUFnQixNQUFNO0NBQzlCLE9BQU87QUFDUjtBQUNBLElBQUksZ0JBQWdCLGNBQWMsTUFBTTtDQUN2QyxZQUFZLFNBQVM7RUFDcEIsTUFBTTtHQUNMLEdBQUc7R0FDSCxJQUFJO0VBQ0wsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7O0FDdE9BLFNBQVMsZ0JBQWdCLE1BQU07Q0FDOUIsUUFBUSxZQUFZO0VBQ25CLE1BQU0sUUFBUSxZQUFZLE9BQU87RUFDakMsTUFBTSxTQUFTO0VBQ2YsT0FBTztDQUNSO0FBQ0Q7Ozs7O0FBS0EsSUFBSSxZQUFZLE1BQU07Q0FDckIsWUFBWSxNQUFNLE9BQU87RUFDeEIsS0FBSyxPQUFPO0VBQ1osS0FBSyxlQUFlLFlBQVk7R0FFOUIsSUFBSSxDQUFDLEtBQUssUUFBUSxRQUFRLEtBQUssMElBQTBJO0dBRTFLLE1BQU0sUUFBUSxZQUFZLE9BQU87R0FDakMsTUFBTSxTQUFTO0dBQ2YsT0FBTztFQUNSO0VBQ0EsS0FBSyxTQUFTLE9BQU87Q0FDdEI7QUFDRDs7Ozs7QUFLQSxTQUFTLGdCQUFnQixPQUFPO0NBQ1ksUUFBUSxLQUFLLGlOQUFpTjtDQUN6USxRQUFRLGFBQWE7QUFDdEI7QUFDQSxJQUFJLFlBQVksTUFBTTtDQUNyQixZQUFZLE1BQU07RUFDakIsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsR0FBRztJQUNILE1BQU0sS0FBSyxRQUFRO0dBQ3BCLENBQUM7RUFDRjtFQUNBLEtBQUssbUJBQW1CLFNBQVM7R0FDaEMsT0FBTyxnQkFBZ0I7SUFDdEIsR0FBRztJQUNILE1BQU0sS0FBSyxRQUFRO0dBQ3BCLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLLFFBQVE7R0FDcEIsQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUssUUFBUTtHQUNwQixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGlCQUFpQixTQUFTO0dBQzlCLE9BQU8sY0FBYztJQUNwQixHQUFHO0lBQ0gsTUFBTSxLQUFLLFFBQVE7R0FDcEIsQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSyxRQUFRO0dBQ3BCLENBQUM7RUFDRjtFQUNBLEtBQUssb0JBQW9CO0dBQ3hCLE9BQU8sWUFBWSxFQUFFLE1BQU0sVUFBVSxDQUFDLENBQUMsV0FBVyxLQUFLLFFBQVEsR0FBRyxDQUFDLFNBQVMsQ0FBQztFQUM5RTtFQUNBLEtBQUssVUFBVTtDQUNoQjtBQUNEOzs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxnQkFBZ0IsSUFBSTtDQUM1QixRQUFRLFNBQVM7RUFDaEIsT0FBTyxJQUFJLFVBQVU7R0FDcEI7R0FDQSxHQUFHO0VBQ0osQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsb0JBQW9CLElBQUk7Q0FDaEMsSUFBSSxPQUFPLE9BQU8sVUFBVSxPQUFPLElBQUksVUFBVSxFQUFFO0NBQ25ELFFBQVEsU0FBUyxJQUFJLFVBQVU7RUFDOUI7RUFDQSxHQUFHO0NBQ0osQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7QUN6SEEsU0FBUyxtQkFBbUIsVUFBVSxZQUFZO0NBQ2pELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtDQUNKLE1BQU0sYUFBYTtFQUNsQixJQUFJLENBQUMsYUFBYTtHQUNqQixRQUFRLEtBQUs7R0FDYixjQUFjLFNBQVMsQ0FBQyxDQUFDLE1BQU0sUUFBUTtJQUN0QyxJQUFJLEVBQWMsT0FBTyxXQUFXLGNBQWM7S0FDakQsY0FBYyxLQUFLO0tBQ25CLFNBQVMsVUFBVSxLQUFLO0lBQ3pCO0lBQ0EsT0FBTyxJQUFJLGNBQWM7R0FDMUIsQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRO0lBQ2pCLGNBQWMsS0FBSztJQUNuQixRQUFRO0dBQ1QsQ0FBQztFQUNGO0VBQ0EsT0FBTztDQUNSO0NBQ0EsTUFBTSxXQUFXLFNBQVMsS0FBSyxPQUFPO0VBQ3JDLElBQUksT0FBTztHQUNWLElBQUksc0JBQXNCLEtBQUssS0FBSyxFQUFjLE9BQU8sV0FBVyxnQkFBZ0IsT0FBTyxtQkFBbUIsYUFBYTtJQUMxSCxNQUFNLGFBQWEsMEJBQTBCLE1BQU07SUFDbkQsSUFBSSxDQUFDLGVBQWUsUUFBUSxVQUFVLEdBQUc7S0FDeEMsZUFBZSxRQUFRLFlBQVksR0FBRztLQUN0QyxPQUFPLFNBQVMsT0FBTztLQUN2QixNQUFNLElBQUksY0FBYyxDQUFDLENBQUM7SUFDM0I7R0FDRDtHQUNBLE1BQU07RUFDUDtFQUNBLElBQUksQ0FBQyxNQUFNLElBQUksVUFBVSxTQUFTLEtBQUssQ0FBQztPQUNuQyxNQUFNLEtBQUs7RUFDaEIsT0FBQSxhQUFlLGNBQWMsTUFBTSxLQUFLO0NBQ3pDO0NBQ0EsU0FBUyxVQUFVO0NBQ25CLE9BQU87QUFDUjs7O0FDNUNBLFNBQVMsY0FBYyxPQUFPO0NBQzdCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQWdCLE9BQU8sVUFBVTtFQUNoQyxNQUFNLFdBQVcsYUFBYSxPQUFPLE9BQU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxTQUFTLEdBQUcsT0FBTyxPQUFPLE9BQU8sSUFBSTtFQUNoRyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxlQUFlO0dBQ3pDLG1CQUFtQjtHQUNuQixVQUFVLE9BQU8sY0FBYztJQUM5QixJQUFJLFdBQVcsS0FBSyxHQUFHLE1BQU0sVUFBVSxPQUFPLFNBQVM7U0FDbEQsTUFBTTtHQUNaO0dBQ0EsaUJBQWlCLEVBQUUsWUFBWTtJQUM5QixJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU8sTUFBTSxXQUFXLEtBQUs7U0FDL0MsTUFBTTtHQUNaO0dBQ0EsVUFBVSxNQUFNO0VBQ2pCLENBQUM7Q0FDRjtDQUNBLE1BQU0sV0FBVyxhQUFhLFlBQVksT0FBTyxPQUFPLFdBQVcsYUFBYSxTQUFTLFFBQVEsRUFBRSxHQUFHLFlBQVksT0FBTyxPQUFPLE1BQU07Q0FDdEksT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZUFBZTtFQUN6QyxtQkFBbUI7RUFDbkIsVUFBVSxPQUFPLGNBQWM7R0FDOUIsSUFBSSxXQUFXLEtBQUssR0FBRyxNQUFNLFVBQVUsT0FBTyxTQUFTO1FBQ2xELE1BQU07RUFDWjtFQUNBLGlCQUFpQixFQUFFLFlBQVk7R0FDOUIsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPLE1BQU0sV0FBVyxLQUFLO1FBQy9DLE1BQU07RUFDWjtFQUNBLFVBQVUsTUFBTTtDQUNqQixDQUFDO0FBQ0Y7QUFDQSxTQUFTLHdCQUF3QjtDQUNoQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxLQUFLLEVBQUUsVUFBVSxZQUFZLENBQUM7QUFDMUQ7Ozs7OztBQ2xDQSxTQUFTLFdBQVcsRUFBRSxZQUFZO0NBQ2pDLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQUksQ0FBYyxPQUFPLFVBQVcsT0FBTztDQUMzQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0VBQ3BDLE9BQU8sT0FBTyxRQUFRLEtBQUs7RUFDM0IseUJBQXlCLEVBQUUsUUFBUSxXQUFXLG1DQUFtQztDQUNsRixDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7O0FDREEsU0FBUyxvQkFBb0IsUUFBUSxPQUFPLE1BQU07Q0FDakQsSUFBSSxDQUFDLE1BQU0sUUFBUSxtQkFBbUI7RUFDckMsSUFBSSxPQUFPLFFBQVEsMEJBRWxCLE9BQStDLCtCQUErQixpQkFEdEMsR0FBQSxtQkFBQSxJQUFBLENBQUksT0FBTyxRQUFRLDBCQUEwQixFQUFFLEdBQUcsS0FBSyxDQUNqQixHQUFpQixtQkFBbUI7RUFHbEgsSUFBSSxDQUFDLE1BQU0sUUFBUSxtQkFBbUIsUUFBUSxLQUFLLGtFQUFrRSxNQUFNLEdBQUcsbVBBQW1QO0VBRWxYLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLHVCQUF1QixDQUFDLENBQUM7Q0FDckQ7Q0FFQSxPQUErQywrQkFBK0IsaUJBRHRDLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE1BQU0sUUFBUSxtQkFBbUIsRUFBRSxHQUFHLEtBQUssQ0FDVCxHQUFpQixtQkFBbUI7QUFDbkg7OztBQ3pCQSxTQUFTLG9DQUFvQyxTQUFTO0NBQ3JELE9BQU87QUFDUjs7O0FDRUEsU0FBU0Msc0JBQW9CO0NBQzVCLE1BQU0sU0FBUyxvQ0FBb0MsVUFBVSxDQUFDO0NBQzlELElBQUksQ0FBQyxRQUFRLE9BQU87Q0FDcEIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksWUFBWSxFQUFFLFVBQVUsT0FBTyxDQUFDO0FBQzVEOzs7QUNNQSxTQUFTLGNBQWMsUUFBUSxPQUFPO0NBQ3JDLE1BQU0sbUJBQW1CLE9BQU8sUUFBUSxvQkFBb0IsT0FBTyxRQUFRO0NBQzNFLElBQUksQ0FBQyxrQkFBa0IsT0FBTztDQUU5QixPQUErQywrQkFBK0IsaUJBQUEsR0FEdkNDLG1CQUFBQSxJQUFBQSxDQUFJLGtCQUFrQixDQUFDLENBQzZCLEdBQUcsa0JBQWtCO0FBQ2pIO0FBQ0EsSUFBSSw2QkFBNkIsR0FBRyxNQUFNLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUU7QUFDdEUsSUFBSSxxQkFBcUIsUUFBUSxPQUFPLFFBQVEsQ0FBQyxNQUFNLFVBQVUsTUFBTSxRQUFRLGtCQUFrQixNQUFNLFFBQVEsa0JBQWtCLFFBQVEsU0FBUyxRQUFRLGVBQWUsRUFBZSxPQUFPLFlBQWEsT0FBTztBQUNuTixJQUFJLFFBQUEsYUFBZ0IsS0FBSyxTQUFTLFVBQVUsRUFBRSxXQUFXO0NBQ3hELE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQWdCLE9BQU8sVUFBVSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxXQUFXO0VBQ3RFO0VBQ0EsT0FBTyxPQUFPLE9BQU8sUUFBUSxJQUFJLE9BQU8sQ0FBQyxDQUFDLElBQUk7Q0FDL0MsQ0FBQztDQUNELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFdBQVc7RUFDckM7RUFDQSxPQUFPLFlBQVksT0FBTyxPQUFPLGNBQWMsT0FBTyxDQUFDO0NBQ3hELENBQUM7QUFDRixDQUFDO0FBQ0QsU0FBUyxVQUFVLEVBQUUsUUFBUSxTQUFTO0NBQ3JDLE1BQU0sUUFBUSxPQUFPLFdBQVcsTUFBTTtDQUN0QyxNQUFNLGlCQUFpQixjQUFjLFFBQVEsS0FBSztDQUNsRCxNQUFNLHNCQUFzQixNQUFNLFFBQVEsa0JBQWtCLE9BQU8sUUFBUTtDQUMzRSxNQUFNLGVBQWUsTUFBTSxRQUFRLFdBQVcsT0FBTyxRQUFRO0NBQzdELE1BQU0seUJBQXlCLE1BQU0sU0FBUyxNQUFNLFFBQVEscUJBQXFCLE9BQU8sUUFBUSxlQUFlLFFBQVEsWUFBWSxNQUFNLFFBQVE7Q0FDakosTUFBTSxnQkFBZ0IsTUFBTSxRQUFRLFNBQVMsTUFBTSxRQUFRO0NBQzNELE1BQU0saUJBQWlCLGtCQUFrQixRQUFRLE9BQU8sTUFBTSxHQUFHLE1BQU0sTUFBTSxRQUFRLGtCQUFrQixtQkFBbUIsTUFBTSxRQUFRLGdCQUFnQixXQUFXO0NBQ25LLElBQUksVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksWUFBWSxFQUFFLE1BQU0sQ0FBQztDQUN2RCxJQUFJLGVBQWUsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksWUFBWTtFQUM1RCxVQUFVO0VBQ1YsVUFBVTtDQUNYLENBQUM7Q0FDRCxJQUFJLHdCQUF3QixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxlQUFlO0VBQ3hFLFdBQVcsVUFBVTtHQUNwQixNQUFNLFlBQVksTUFBTTtHQUN4QixJQUFJLE1BQU0sWUFBWSxNQUFNLFNBQVMsTUFBTTtHQUUzQyxPQUErQywrQkFEekMsYUFBMEIsY0FBYyx3QkFBd0IsS0FDUSxHQUFpQixtQkFBbUI7RUFDbkg7RUFDQSxVQUFVO0NBQ1gsQ0FBQztDQUNELElBQUkscUJBQXFCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGVBQWU7RUFDckUsbUJBQW1CO0VBQ25CLGdCQUFnQjtFQUNoQixVQUFVLE9BQU8sY0FBYztHQUM5QixJQUFJLFdBQVcsS0FBSyxHQUFHO0lBQ3RCLE1BQU0sWUFBWSxNQUFNO0lBQ3hCLE1BQU07R0FDUDtHQUMyQyxRQUFRLEtBQUssa0NBQWtDLE1BQU0sSUFBSTtHQUNwRyxlQUFlLE9BQU8sU0FBUztFQUNoQztFQUNBLFVBQVU7Q0FDWCxDQUFDO0NBQ0QsSUFBSSxnQkFBZ0IsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUEsYUFBWSxVQUFVO0VBQ25FLFVBQVU7RUFDVixVQUFVO0NBQ1gsQ0FBQztDQUNELE1BQU0sb0JBQWlDLE9BQU8sWUFBYSxNQUFNLGFBQWEsT0FBQSxjQUFzQixPQUFPLFFBQVEsb0JBQW9DLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxxQkFBbUIsQ0FBQyxDQUFDLElBQUk7Q0FDcEwsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLE1BQU0sUUFBUSxpQkFBaUIsS0FBSztDQUMxRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxhQUFhLFVBQVU7RUFDakQsT0FBTyxNQUFNO0VBQ2IsVUFBVSxpQkFBaUMsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUssZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLFNBQVMsaUJBQWlCLEVBQUUsQ0FBQyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBS0MsbUJBQUFBLFVBQVUsRUFBRSxVQUFVLENBQUMsU0FBUyxpQkFBaUIsRUFBRSxDQUFDO0NBQ3hMLENBQUM7QUFDRjtBQUNBLElBQUksYUFBQSxhQUFxQixLQUFLLFNBQVMsZUFBZSxFQUFFLFNBQVM7Q0FDaEUsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxVQUFVLE1BQU07Q0FDdEIsTUFBTSxRQUFRLE9BQU8sV0FBVztDQUNoQyxNQUFNLE1BQUEsYUFBYyxjQUFjO0VBQ2pDLE1BQU0sZUFBZSxNQUFNLFFBQVEsZUFBZSxPQUFPLFFBQVEsbUJBQUEsR0FBc0I7R0FDdEY7R0FDQSxZQUFZLE1BQU07R0FDbEIsUUFBUSxNQUFNO0dBQ2QsUUFBUSxNQUFNO0VBQ2YsQ0FBQztFQUNELE9BQU8sY0FBYyxLQUFLLFVBQVUsV0FBVyxJQUFJLEtBQUs7Q0FDekQsR0FBRztFQUNGO0VBQ0EsTUFBTTtFQUNOLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTSxRQUFRO0VBQ2QsT0FBTyxRQUFRO0NBQ2hCLENBQUM7Q0FDRCxNQUFNLE1BQUEsYUFBYyxjQUFjO0VBQ2pDLE1BQU0sT0FBTyxNQUFNLFFBQVEsYUFBYSxPQUFPLFFBQVE7RUFDdkQsT0FBTyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNLENBQUMsR0FBRyxHQUFHLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFFBQVEsQ0FBQyxDQUFDO0NBQ2xGLEdBQUc7RUFDRjtFQUNBLE1BQU0sUUFBUTtFQUNkLE9BQU8sUUFBUTtDQUNoQixDQUFDO0NBQ0QsSUFBSSxNQUFNLFdBQVcsV0FBVztFQUMvQixJQUFJLE9BQU8sT0FBTyxDQUFDLGtCQUFrQixRQUFRLE9BQU8sTUFBTSxHQUFHLEdBQUcsT0FBTztFQUN2RSxJQUFJLE9BQU8sS0FBSyxNQUFNLE9BQU8sSUFBSTtFQUNqQyxPQUFPLGNBQWMsUUFBUSxLQUFLO0NBQ25DO0NBQ0EsSUFBSSxNQUFNLFdBQVcsWUFBWSxPQUFPLG9CQUFvQixRQUFRLE9BQU8sTUFBTSxLQUFLO0NBQ3RGLElBQUksTUFBTSxXQUFXLFNBQVM7RUFDN0IsSUFBZ0IsT0FBTyxVQU10QixPQUErQywrQkFBK0IsaUJBTHpDLEdBQUEsbUJBQUEsSUFBQSxFQUFLLE1BQU0sUUFBUSxrQkFBa0IsT0FBTyxRQUFRLDBCQUEwQixnQkFBZ0I7R0FDbEksT0FBTyxNQUFNO0dBQ2IsT0FBTyxLQUFLO0dBQ1osTUFBTSxFQUFFLGdCQUFnQixHQUFHO0VBQzVCLENBQzhFLEdBQWMsZ0JBQWdCO0VBRTdHLE1BQU0sTUFBTTtDQUNiO0NBQ0EsT0FBTztBQUNSLENBQUM7Ozs7Ozs7QUFPRCxJQUFJLFNBQUEsYUFBaUIsS0FBSyxTQUFTLGFBQWE7Q0FDSjtFQUMxQyxNQUFNLG9CQUFBLGFBQTRCLFdBQVcsd0JBQXdCO0VBQ3JFLElBQUksbUJBQW1CLFFBQVEsS0FBSyxnREFBZ0Qsa0JBQWtCLCtEQUErRDtDQUN0SztDQUNBLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sVUFBQSxhQUFrQixXQUFXLFlBQVk7Q0FDL0MsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sVUFBVSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQzFDLE1BQU0sY0FBYyxRQUFRLFdBQVcsVUFBVSxNQUFNLFlBQVksT0FBTztFQUMxRSxNQUFNLGNBQWMsUUFBUTtFQUM1Qix1QkFBdUIsQ0FBQyxDQUFDLFlBQVk7RUFDckMsc0JBQXNCLFlBQVk7RUFDbEMsZUFBZSxRQUFRLGNBQWMsRUFBRSxFQUFFO0NBQzFDLE9BQU87RUFDTixNQUFNLG1CQUFtQixPQUFPLE9BQU8sY0FBYyxPQUFPO0VBQzVELENBQUMsc0JBQXNCLHVCQUF1QixZQUFZLG1CQUFtQixVQUFVLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVyxNQUFNLEtBQUssR0FBRyxFQUFFLFNBQVMsMEJBQTBCLENBQUM7RUFDL0osZUFBZSxZQUFZLE9BQU8sT0FBTyxNQUFNLFFBQVE7R0FDdEQsT0FBTyxJQUFJLElBQUksUUFBUSxPQUFPLElBQUk7RUFDbkMsQ0FBQztDQUNGO0NBQ0EsSUFBSSxzQkFBc0IsT0FBTyxvQkFBb0IsUUFBUSxPQUFPLFdBQVcsVUFBVSxtQkFBbUI7Q0FDNUcsSUFBSSxDQUFDLGNBQWMsT0FBTztDQUMxQixNQUFNLFlBQTRCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sRUFBRSxTQUFTLGFBQWEsQ0FBQztDQUN0RSxJQUFJLFlBQUEsWUFBeUIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUEsYUFBWSxVQUFVO0VBQ3pFLFVBQVUsY0FBYyxNQUFNO0VBQzlCLFVBQVU7Q0FDWCxDQUFDO0NBQ0QsT0FBTztBQUNSLENBQUM7OztBQy9KRCxTQUFTLFlBQVksT0FBTyxVQUFVO0NBQ3JDLE1BQU0sU0FBUyxNQUFNO0NBQ3JCLE1BQU0sU0FBUztDQUNmLFNBQVMsUUFBUTtBQUNsQjtBQUNBLFNBQVMsYUFBYSxFQUFFLEtBQUs7Q0FDNUIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxrQkFBa0IsT0FBTyxjQUFjLENBQUM7Q0FDOUMsTUFBTSxVQUFBLGFBQTBELE9BQU8sS0FBSztDQUM1RSxPQUFPLG1CQUFtQixJQUFJLGFBQWEsSUFBSSxTQUFTLFlBQVk7RUFDbkUsWUFBWSxpQkFBaUIsS0FBSztFQUNsQyxnQkFBZ0IsS0FBSyxVQUFVLE9BQU87RUFDdEMsRUFBRSxNQUFNO0VBQ1IsYUFBUSxnQkFBZ0IsRUFBRTtDQUMzQixDQUFDO0NBQ0Qsc0JBQXNCO0VBQ3JCLE1BQU0sUUFBUSxPQUFPLFFBQVEsVUFBVSxPQUFPLElBQUk7RUFDbEQsSUFBSSxTQUFTLFNBQVMsT0FBTztFQUM3QixJQUFJLFNBQVMsUUFBUSxVQUFVO0VBQy9CLE9BQU8scUJBQXFCO0VBQzVCLE1BQU0sV0FBVyxPQUFPO0VBQ3hCLE1BQU0sZUFBZSxPQUFPLGNBQWM7R0FDekMsSUFBSSxTQUFTO0dBQ2IsUUFBUTtHQUNSLFFBQVE7R0FDUixNQUFNO0dBQ04sT0FBTztHQUNQLHdCQUF3QjtFQUN6QixDQUFDO0VBQ0QsSUFBSSxjQUFjLFNBQVMsVUFBVSxNQUFNLGNBQWMsYUFBYSxVQUFVLEdBQUc7R0FDbEYsT0FBTyxlQUFlO0lBQ3JCLEdBQUc7SUFDSCxTQUFTO0lBQ1QsZUFBZTtHQUNoQixDQUFDO0dBQ0QsT0FBTztFQUNSO0VBQ0EsTUFBTSxtQkFBbUIsT0FBTyxPQUFPLGlCQUFpQixJQUFJO0VBQzVELElBQUksa0JBQWtCLFNBQVMsU0FBUyxRQUFRLGlCQUFpQixNQUFNLGNBQWMsU0FBUyxNQUFNLFdBQVcsZ0JBQWdCLEtBQUssT0FBTyxPQUFPLFFBQVEsSUFBSSxJQUFJLGFBQWE7R0FDOUssSUFBSSxVQUFVLE9BQU8sS0FBSztJQUN6QixNQUFNO0lBQ04sR0FBRyxzQkFBc0Isa0JBQWtCLGdCQUFnQjtHQUM1RCxDQUFDO0VBQ0YsQ0FBQztPQUNJLElBQUksQ0FBQyxPQUFPLEtBQUssT0FBTyxLQUFLLEVBQUUsTUFBTSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sUUFBUSxLQUFLO0VBQ3JFLE9BQU87Q0FDUixHQUFHLENBQUMsUUFBUSxPQUFPLE9BQU8sQ0FBQztDQUMzQixPQUFPO0FBQ1I7Ozs7Ozs7QUNwQ0EsU0FBUyxVQUFVO0NBQ2xCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sWUFBWSxPQUFPLFdBQVc7Q0FDcEMsTUFBTSxpQkFBaUIsY0FBYyxRQUFRLFNBQVM7Q0FDdEQsTUFBTSxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBS0MsbUJBQUFBLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBYyxPQUFPLFlBQTZCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGNBQWMsRUFBRSxHQUFBLGFBQVcsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQWdCLE9BQU8sWUFBYSxPQUFPLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGNBQWMsQ0FBQyxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFBLGFBQVksVUFBVTtFQUN4UixVQUFVO0VBQ1YsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksY0FBYyxDQUFDLENBQUM7Q0FDL0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQztDQUNMLE9BQU8sT0FBTyxRQUFRLFlBQTRCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sUUFBUSxXQUFXLEVBQUUsVUFBVSxNQUFNLENBQUMsSUFBSTtBQUN4RztBQUNBLFNBQVMsZUFBZTtDQUN2QixNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLGtCQUFrQixPQUFPO0NBQy9CLE1BQU0sVUFBc0IsT0FBTyxXQUFXLE9BQU8sT0FBTyxRQUFRLElBQUksSUFBSSxZQUFZLE9BQU8sT0FBTyxVQUFVLFVBQVUsZ0JBQWdCLE1BQU0sS0FBSztDQUNySixNQUFNLFFBQVEsUUFBUTtDQUN0QixNQUFNLFVBQVUsT0FBTztDQUN2QixzQkFBc0I7RUFDckIsSUFBSSxnQkFBZ0IsT0FBTyxTQUFTLFlBQVksaUJBQWlCLElBQUk7Q0FDdEUsR0FBRyxDQUFDLGlCQUFpQixPQUFPLENBQUM7Q0FDN0IsTUFBTSxpQkFBaUIsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFJO0NBQzNFLE9BQU8sT0FBTyxRQUFRLDZCQUE2QixpQkFBaUMsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZUFBZTtFQUN0RyxtQkFBbUI7RUFDbkIsVUFBa0QsVUFBVTtHQUMzRCxRQUFRLEtBQUsscUlBQXFJO0dBQ2xKLFFBQVEsS0FBSyxZQUFZLEtBQUs7RUFDL0I7RUFDQSxVQUFVO0NBQ1gsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLGdCQUFnQjtDQUN4QixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVUsUUFBUSxTQUFTO0VBQ2pELE1BQU0sRUFBRSxTQUFTLGVBQWUsT0FBTyxlQUFlLEdBQUcsU0FBUztFQUNsRSxPQUFPLE9BQU8sV0FBVyxNQUFNO0dBQzlCO0dBQ0E7R0FDQTtHQUNBO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsT0FBQSxhQUFlLGFBQWEsU0FBUztFQUNwQyxNQUFNLEVBQUUsU0FBUyxlQUFlLE9BQU8sZUFBZSxHQUFHLFNBQVM7RUFDbEUsT0FBTyxPQUFPLFdBQVcsTUFBTTtHQUM5QjtHQUNBO0dBQ0E7R0FDQTtFQUNELENBQUM7Q0FDRixHQUFHO0VBQ0Y7RUFDQSxZQUFZLE9BQU8sT0FBTyxXQUFXLGFBQWEsU0FBUyxJQUFJO0VBQy9ELFlBQVksT0FBTyxPQUFPLG1CQUFtQixhQUFhLFVBQVUsSUFBSTtFQUN4RSxZQUFZLE9BQU8sT0FBTyxNQUFNO0NBQ2pDLENBQUM7QUFDRjs7Ozs7Ozs7QUFRQSxTQUFTLFdBQVcsT0FBTztDQUMxQixNQUFNLFNBQVMsY0FBYyxDQUFDLENBQUMsS0FBSztDQUNwQyxJQUFJLE9BQU8sTUFBTSxhQUFhLFlBQVksT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUN0RSxPQUFPLFNBQVMsTUFBTSxXQUFXO0FBQ2xDO0FBQ0EsU0FBUyxXQUFXLE1BQU07Q0FDekIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sVUFBVSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQzFDLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLElBQUk7Q0FDOUM7Q0FDQSxPQUFPLFlBQVksT0FBTyxPQUFPLFNBQVMscUJBQXFCLE1BQU0sTUFBTSxDQUFDO0FBQzdFOzs7OztBQUtBLFNBQVMsaUJBQWlCLE1BQU07Q0FDL0IsTUFBTSxpQkFBQSxhQUF5QixXQUFXLFlBQVk7Q0FDdEQsT0FBTyxXQUFXO0VBQ2pCLFNBQVMsWUFBWTtHQUNwQixVQUFVLFFBQVEsTUFBTSxHQUFHLFFBQVEsV0FBVyxNQUFNLEVBQUUsWUFBWSxjQUFjLENBQUM7R0FDakYsT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLE9BQU8sSUFBSTtFQUM5QztFQUNBLG1CQUFtQixNQUFNO0NBQzFCLENBQUM7QUFDRjs7Ozs7QUFLQSxTQUFTLGdCQUFnQixNQUFNO0NBQzlCLE1BQU0saUJBQUEsYUFBeUIsV0FBVyxZQUFZO0NBQ3RELE9BQU8sV0FBVztFQUNqQixTQUFTLFlBQVk7R0FDcEIsVUFBVSxRQUFRLE1BQU0sUUFBUSxXQUFXLE1BQU0sRUFBRSxZQUFZLGNBQWMsSUFBSSxDQUFDO0dBQ2xGLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLElBQUk7RUFDOUM7RUFDQSxtQkFBbUIsTUFBTTtDQUMxQixDQUFDO0FBQ0Y7OztBQ3BJQSxJQUFJLG1CQUFtQixTQUFTO0NBQy9CLElBQWdCLEtBQUssVUFBVSxPQUFPO0VBQ3JDLG9CQUFvQjtFQUNwQixxQkFBcUI7RUFDckIsUUFBUSxPQUFPLEdBQUc7Q0FDbkI7Q0FDQSxPQUFPO0VBQ04sb0JBQW9CO0VBQ3BCLHFCQUFxQjtFQUNyQjtDQUNEO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7O0FDREEsSUFBSSxnQkFBZ0IsWUFBWTtDQUMvQixPQUFPLElBQUksT0FBTyxPQUFPO0FBQzFCO0FBQ0EsSUFBSSxTQUFTLGNBQWMsV0FBVztDQUNyQyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxTQUFTLGVBQWU7Q0FDL0I7QUFDRDs7Ozs7OztBQ1ZBLFNBQVMsc0JBQXNCLEVBQUUsUUFBUSxVQUFVLEdBQUcsUUFBUTtDQUM3RCxJQUFJLFFBQVEsSUFBSSxHQUFHLE9BQU8sT0FBTztFQUNoQyxHQUFHLE9BQU87RUFDVixHQUFHO0VBQ0gsU0FBUztHQUNSLEdBQUcsT0FBTyxRQUFRO0dBQ2xCLEdBQUcsS0FBSztFQUNUO0NBQ0QsQ0FBQztDQUNELE1BQU0sV0FBMkIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksY0FBYyxVQUFVO0VBQzVELE9BQU87RUFDUDtDQUNELENBQUM7Q0FDRCxJQUFJLE9BQU8sUUFBUSxNQUFNLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sUUFBUSxNQUFNLEVBQUUsVUFBVSxTQUFTLENBQUM7Q0FDL0YsT0FBTztBQUNSOzs7Ozs7Ozs7O0FBVUEsU0FBUyxlQUFlLEVBQUUsUUFBUSxHQUFHLFFBQVE7Q0FDNUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksdUJBQXVCO0VBQ2pEO0VBQ0EsR0FBRztFQUNILFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFNBQVMsQ0FBQyxDQUFDO0NBQzFDLENBQUM7QUFDRjs7O0FDdkNBLFNBQVMsdUJBQXVCO0NBQy9CLHVCQUF1QixVQUFVLEdBQUcsSUFBSTtBQUN6Qzs7OztBQUlBLFNBQVMsa0JBQWtCLFFBQVE7Q0FDbEMscUJBQXFCO0NBQ3VCLFFBQVEsS0FBSyx1R0FBdUc7Q0FDaEssT0FBTztBQUNSO0FBQ0EsU0FBUyw0QkFBNEIsU0FBUztDQUM3QyxxQkFBcUI7Q0FDckIsT0FBTyxpQ0FBaUMsVUFBVSxHQUFHLE9BQU87QUFDN0Q7OztBQ2JBLFNBQVMsb0JBQW9CLE1BQU0sV0FBVztDQUM3QyxJQUFJLFNBQVMsS0FBSyxHQUFHLE9BQU87RUFDM0IscUJBQXFCO0VBQ3JCLGNBQWM7Q0FDZjtDQUNBLElBQUksbUJBQW1CLE1BQU0sT0FBTztDQUNwQyxJQUFJLE9BQU8sU0FBUyxZQUFZO0VBQy9CLE1BQU0sY0FBYyxRQUFRLGFBQWEsSUFBSTtFQUM3QyxNQUFNLG1CQUFtQixZQUFZO0dBQ3BDLElBQUksYUFBYSxPQUFPLE1BQU0sS0FBSztHQUNuQyxPQUFPO0VBQ1I7RUFDQSxPQUFPO0dBQ04sZUFBZTtHQUNmLG9CQUFvQjtHQUNwQixjQUFjO0VBQ2Y7Q0FDRDtDQUNBLE1BQU0sY0FBYyxRQUFRLEtBQUssYUFBYSxJQUFJO0NBQ2xELE1BQU0sS0FBSyxLQUFLO0NBQ2hCLE1BQU0sbUJBQW1CLFlBQVk7RUFDcEMsSUFBSSxlQUFlLE9BQU8sS0FBSyxHQUFHLE9BQU8sTUFBTSxHQUFHO0VBQ2xELE9BQU87Q0FDUjtDQUNBLE9BQU87RUFDTixlQUFlO0VBQ2Ysb0JBQW9CO0VBQ3BCLGNBQWMsT0FBTyxLQUFLO0NBQzNCO0FBQ0Q7QUFDQSxTQUFTLFdBQVcsTUFBTSxXQUFXO0NBQ3BDLE1BQU0sRUFBRSxlQUFlLHFCQUFxQixNQUFNLFdBQVcsT0FBTyxlQUFlLFVBQVUsb0JBQW9CLE1BQU0sU0FBUztDQUNoSSxNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLEVBQUUsWUFBWTtDQUNwQixNQUFNLENBQUMsVUFBVSxlQUFBLGFBQXVCLFNBQVM7RUFDaEQsUUFBUTtFQUNSLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLFFBQVEsS0FBSztFQUNiLFNBQVMsS0FBSztFQUNkLE9BQU8sS0FBSztDQUNiLENBQUM7Q0FDRCxhQUFRLGdCQUFnQjtFQUN2QixNQUFNLG9CQUFvQixPQUFPLGtCQUFrQjtHQUNsRCxTQUFTLFlBQVksVUFBVTtJQUM5QixNQUFNLGlCQUFpQixPQUFPLGNBQWMsUUFBUTtJQUNwRCxNQUFNLEdBQUcsV0FBVyxjQUFjLE9BQU8saUJBQWlCLGVBQWUsUUFBUTtJQUNqRixJQUFJLGVBQWUsS0FBSyxHQUFHLE9BQU87S0FDakMsU0FBUztLQUNULFVBQVUsZUFBZTtLQUN6QixVQUFVLGVBQWU7S0FDekIsUUFBUTtLQUNSLFFBQVEsT0FBTyxRQUFRLFlBQVksU0FBUyxNQUFNO0lBQ25EO0lBQ0EsT0FBTztLQUNOLFNBQVMsV0FBVztLQUNwQixVQUFVLFdBQVc7S0FDckIsVUFBVSxlQUFlO0tBQ3pCLFFBQVE7S0FDUixRQUFRLE9BQU8sUUFBUSxZQUFZLFNBQVMsTUFBTTtJQUNuRDtHQUNEO0dBQ0EsTUFBTSxVQUFVLFlBQVksY0FBYyxlQUFlO0dBQ3pELE1BQU0sT0FBTyxZQUFZLGNBQWMsWUFBWTtHQUNuRCxJQUFJLFFBQVEsWUFBWSxrQkFBa0IsS0FBSyxZQUFZLGdCQUFnQixPQUFPO0dBQ2xGLE1BQU0sY0FBYyxNQUFNLGNBQWM7SUFDdkMsUUFBUSxjQUFjO0lBQ3RCO0lBQ0E7R0FDRCxDQUFDO0dBQ0QsSUFBSSxDQUFDLGNBQWMsT0FBTztHQUMxQixJQUFJLENBQUMsYUFBYSxPQUFPO0dBQ3pCLE1BQU0sbUJBQW1CLE1BQU0sSUFBSSxTQUFTLFlBQVk7SUFDdkQsWUFBWTtLQUNYLFFBQVE7S0FDUjtLQUNBO0tBQ0EsUUFBUSxjQUFjO0tBQ3RCLGVBQWUsUUFBUSxLQUFLO0tBQzVCLGFBQWEsUUFBUSxJQUFJO0lBQzFCLENBQUM7R0FDRixDQUFDO0dBQ0QsWUFBWTtJQUNYLFFBQVE7SUFDUixTQUFTLEtBQUs7SUFDZCxNQUFNLEtBQUs7SUFDWCxRQUFRLEtBQUs7SUFDYixTQUFTLEtBQUs7SUFDZCxPQUFPLEtBQUs7R0FDYixDQUFDO0dBQ0QsT0FBTztFQUNSO0VBQ0EsT0FBTyxXQUFXLEtBQUssSUFBSSxRQUFRLE1BQU07R0FDeEMsV0FBVztHQUNYO0VBQ0QsQ0FBQztDQUNGLEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBQ0EsSUFBSSw2QkFBNkIsVUFBVTtDQUMxQyxJQUFJLG1CQUFtQixPQUFPLE9BQU8sRUFBRSxHQUFHLE1BQU07Q0FDaEQsTUFBTSxjQUFjLFFBQVEsTUFBTSxhQUFhLElBQUk7Q0FDbkQsTUFBTSxLQUFLLE1BQU07Q0FDakIsTUFBTSxtQkFBbUIsWUFBWTtFQUNwQyxJQUFJLGVBQWUsT0FBTyxLQUFLLEdBQUcsT0FBTyxNQUFNLEdBQUc7RUFDbEQsT0FBTztDQUNSO0NBQ0EsT0FBTztFQUNOLGVBQWU7RUFDZixvQkFBb0I7RUFDcEIsY0FBYyxPQUFPLEtBQUs7Q0FDM0I7QUFDRDtBQUNBLFNBQVMsTUFBTSxNQUFNO0NBQ3BCLE1BQU0sRUFBRSxVQUFVLEdBQUcsU0FBUztDQUM5QixNQUFNLFdBQVcsV0FBVywwQkFBMEIsSUFBSSxDQUFDO0NBQzNELE9BQU8sV0FBVyxPQUFPLGFBQWEsYUFBYSxTQUFTLFFBQVEsSUFBSSxXQUFXO0FBQ3BGOzs7Ozs7Ozs7Ozs7Ozs7QUM5R0EsU0FBUyxlQUFlLE1BQU07Q0FDN0IsTUFBTSxnQkFBZ0IsVUFBVSxFQUFFLE1BQU0sTUFBTSxXQUFXLEtBQUssRUFBRSxDQUFDO0NBQ2pFLE1BQU0sU0FBUyxNQUFNLFVBQVU7Q0FDL0IsSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sUUFBUSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQ3hDLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxLQUFLLElBQUk7Q0FDNUM7Q0FDQSxPQUFPLFlBQVksT0FBTyxPQUFPLFNBQVMscUJBQXFCLE1BQU0sTUFBTSxDQUFDO0FBQzdFOzs7Ozs7Ozs7Ozs7OztBQ1RBLFNBQVMsWUFBWSxNQUFNO0NBQzFCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQWdCLE9BQU8sVUFBVTtFQUNoQyxNQUFNLFdBQVcsT0FBTyxPQUFPLFNBQVMsSUFBSTtFQUM1QyxPQUFPLE1BQU0sU0FBUyxLQUFLLE9BQU8sUUFBUSxJQUFJO0NBQy9DO0NBQ0EsT0FBTyxZQUFZLE9BQU8sT0FBTyxVQUFVLHFCQUFxQixNQUFNLE1BQU0sQ0FBQztBQUM5RTs7O0FDcEJBLFNBQVMsZUFBZTtDQUN2QixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVUsT0FBTyxPQUFPLE9BQU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxNQUFNLGdCQUFnQjtDQUMzRixPQUFPLFlBQVksT0FBTyxPQUFPLFdBQVcsYUFBYSxTQUFTLE1BQU0sZ0JBQWdCLENBQUM7QUFDMUY7OztBQ0RBLElBQUksNEJBQTRCO0FBQ2hDLElBQUksMEJBQTBCLENBQUM7QUFDL0IsU0FBUyxlQUFlLFFBQVEsT0FBTztDQUN0QyxJQUFJLENBQUMsT0FBTztDQUNaLEtBQUssTUFBTSxDQUFDLEtBQUssVUFBVSxPQUFPLFFBQVEsS0FBSyxHQUFHLElBQUksUUFBUSw4QkFBOEIsVUFBVSxLQUFLLEtBQUssVUFBVSxPQUFPLE9BQU8sYUFBYSxLQUFLLE9BQU8sVUFBVSxZQUFZLEtBQUssT0FBTyxLQUFLLENBQUM7QUFDMU07QUFDQSxTQUFTLE1BQU0sT0FBTztDQUNyQixNQUFNLEVBQUUsT0FBTyxVQUFVLE9BQU8sdUJBQXVCO0NBQ3ZELE1BQU0sWUFBQSxhQUFvQixjQUFjLGFBQWEsS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLFFBQVEsU0FBUyxHQUFHLENBQUMsUUFBUSxDQUFDO0NBQ3ZHLFFBQVEsTUFBTSxLQUFkO0VBQ0MsS0FBSyxTQUFTLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFNBQVM7R0FDakQsR0FBRztHQUNILDBCQUEwQjtHQUMxQjtFQUNELENBQUM7RUFDRCxLQUFLLFFBQVEsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksUUFBUTtHQUMvQyxHQUFHO0dBQ0gsMEJBQTBCO0VBQzNCLENBQUM7RUFDRCxLQUFLLFFBQVEsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksUUFBUTtHQUMvQyxHQUFHO0dBQ0gsWUFBWSxPQUFPLGVBQWUsT0FBTyxRQUFRLGVBQWUsWUFBWSxLQUFLO0dBQ2pGO0dBQ0EsMEJBQTBCO0VBQzNCLENBQUM7RUFDRCxLQUFLO0dBQ0osSUFBSSxNQUFNLGNBQWMsUUFBUSxJQUFJLDJCQUEyQixVQUFVLFFBQVEsSUFBSSwyQkFBMkIsS0FBSyxLQUFBLEtBQUEsSUFBZ0IsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZ0JBQWdCO0lBQy9LO0lBQ0E7SUFDQTtHQUNELENBQUM7R0FDRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxTQUFTO0lBQ25DLEdBQUc7SUFDSCx5QkFBeUI7SUFDekI7R0FDRCxDQUFDO0VBQ0YsS0FBSyxVQUFVLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFFBQVE7R0FDakQ7R0FDQTtHQUNBO0VBQ0QsQ0FBQztFQUNELFNBQVMsT0FBTztDQUNqQjtBQUNEO0FBQ0EsU0FBUyxlQUFlLEVBQUUsT0FBTyxVQUFVLFNBQVM7Q0FDbkQsTUFBTSx5QkFBeUIsYUFBYSxLQUFLO0NBQ2pELE1BQU0sQ0FBQyxxQkFBQSxhQUE2QixlQUFlO0VBQ2xELElBQUksQ0FBQywwQkFBMEIsT0FBTyxhQUFhLGFBQWE7RUFDaEUsT0FBTyxTQUFTLGNBQWMsU0FBUywwQkFBMEIsRUFBRSxDQUFDLEVBQUUsZUFBZSxLQUFLO0NBQzNGLENBQUM7Q0FDRCxNQUFNLE9BQU8seUJBQXlCLHFCQUFxQixLQUFLLFlBQVk7Q0FDNUUsTUFBTSxZQUFBLGFBQW9CLGVBQWUsRUFBRSxRQUFRLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQztDQUNsRSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxTQUFTO0VBQ25DLEdBQUc7R0FDRiw0QkFBNEI7RUFDN0IseUJBQXlCO0VBQ3pCO0VBQ0EsMEJBQTBCO0NBQzNCLENBQUM7QUFDRjtBQUNBLFNBQVMsT0FBTyxFQUFFLE9BQU8sVUFBVSxzQkFBc0I7Q0FDeEQsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxZQUFBLGFBQW9CLGNBQWMsYUFBYSxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsUUFBUSxTQUFTLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDdkcsTUFBTSxhQUFhLE9BQU8sT0FBTyxTQUFTLFlBQVksTUFBTSxTQUFTLE1BQU0sTUFBTSxTQUFTLHFCQUFxQixNQUFNLFNBQVM7Q0FDOUgsSUFBNkMsT0FBTyxPQUFPLE9BQU8sYUFBYSxZQUFZLFNBQVMsS0FBSyxDQUFDLENBQUMsUUFBUSxRQUFRLEtBQUssMklBQTJJO0NBQzNRLGFBQVEsZ0JBQWdCO0VBQ3ZCLElBQUksWUFBWTtFQUNoQixJQUFJLE9BQU8sS0FBSztHQUNmLE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztHQUN2QyxLQUFLLE9BQU8sTUFBTTtHQUNsQixNQUFNLFVBQVUsS0FBSztHQUNyQixLQUFLLE1BQU0sTUFBTSxTQUFTLFNBQVMsSUFBSSxHQUFHLFFBQVEsU0FBUztHQUMzRCxNQUFNLFNBQVMsU0FBUyxjQUFjLFFBQVE7R0FDOUMsZUFBZSxRQUFRLEtBQUs7R0FDNUIsU0FBUyxLQUFLLFlBQVksTUFBTTtHQUNoQyxhQUFhLE9BQU8sT0FBTztFQUM1QjtFQUNBLElBQUksT0FBTyxhQUFhLFVBQVU7R0FDakMsTUFBTSxXQUFXLE9BQU8sT0FBTyxTQUFTLFdBQVcsTUFBTSxPQUFPO0dBQ2hFLE1BQU0sWUFBWSxPQUFPLE9BQU8sVUFBVSxXQUFXLE1BQU0sUUFBUSxLQUFLO0dBQ3hFLEtBQUssTUFBTSxNQUFNLFNBQVMsU0FBUztJQUNsQyxJQUFJLEdBQUcsYUFBYSxLQUFLLEdBQUc7SUFDNUIsTUFBTSxRQUFRLEdBQUcsYUFBYSxNQUFNLEtBQUs7SUFDekMsTUFBTSxTQUFTLEdBQUcsYUFBYSxPQUFPLEtBQUssS0FBSztJQUNoRCxJQUFJLEdBQUcsZ0JBQWdCLFlBQVksVUFBVSxZQUFZLFdBQVcsV0FBVztHQUNoRjtHQUNBLE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtHQUM5QyxPQUFPLGNBQWM7R0FDckIsZUFBZSxRQUFRLEtBQUs7R0FDNUIsU0FBUyxLQUFLLFlBQVksTUFBTTtHQUNoQyxhQUFhLE9BQU8sT0FBTztFQUM1QjtDQUNELEdBQUc7RUFDRjtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLElBQUksT0FBTyxLQUFLO0dBQ2YsSUFBSSxDQUFDLG9CQUFvQixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0lBQzdELEdBQUc7SUFDSCwwQkFBMEI7R0FDM0IsQ0FBQztHQUNELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7SUFDcEMsR0FBRztJQUNILFFBQVE7SUFDUiwwQkFBMEI7R0FDM0IsQ0FBQztFQUNGO0VBQ0EsSUFBSSxPQUFPLGFBQWEsVUFBVSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0dBQ3RFLEdBQUc7R0FDSCx5QkFBeUI7R0FDekIsMEJBQTBCO0VBQzNCLENBQUM7RUFDRCxPQUFPO0NBQ1I7Q0FDQSxJQUFJLGNBQWMsT0FBTyxhQUFhLFVBQVUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtFQUNwRixHQUFHO0VBQ0gsMEJBQTBCO0VBQzFCLHlCQUF5QjtDQUMxQixDQUFDO0NBQ0QsSUFBSSxDQUFDLFVBQVU7RUFDZCxJQUFJLE9BQU8sS0FBSyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0dBQ3BELEdBQUc7R0FDSCwwQkFBMEI7RUFDM0IsQ0FBQztFQUNELElBQUksT0FBTyxhQUFhLFVBQVUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtHQUN0RSxHQUFHO0dBQ0gseUJBQXlCO0dBQ3pCLDBCQUEwQjtFQUMzQixDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7OztBQ3ZJQSxTQUFTLHFCQUFxQixRQUFRLE9BQU8sU0FBUyxrQkFBa0I7Q0FDdkUsVUFBVSxpQkFBaUIsT0FBTztDQUNsQyxNQUFNLFlBQVksUUFBUSxLQUFLLFVBQVUsTUFBTSxJQUFJLENBQUMsQ0FBQyxRQUFRLFNBQVMsU0FBUyxLQUFLLENBQUM7Q0FDckYsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxrQkFBa0IsQ0FBQztDQUN6QixJQUFJO0NBQ0osS0FBSyxJQUFJLElBQUksVUFBVSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7RUFDL0MsTUFBTSxRQUFRLFVBQVU7RUFDeEIsS0FBSyxJQUFJLElBQUksTUFBTSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDM0MsTUFBTSxJQUFJLE1BQU07R0FDaEIsSUFBSSxDQUFDLEdBQUc7R0FDUixJQUFJLEVBQUUsT0FDRDtRQUFBLENBQUMsT0FBTyxRQUFRO0tBQ25CLEtBQUs7S0FDTCxVQUFVLEVBQUU7SUFDYjtHQUFBLE9BQ00sSUFBSSxvQkFBb0IsR0FBRyxJQUFJO0lBQ3JDLE1BQU0sT0FBTyxLQUFLLFVBQVUsRUFBRSxpQkFBaUI7SUFDL0MsV0FBVyxLQUFLO0tBQ2YsS0FBSztLQUNMLE9BQU8sRUFBRSxNQUFNLHNCQUFzQjtLQUNyQyxVQUFVLFdBQVcsSUFBSTtJQUMxQixDQUFDO0dBQ0YsUUFBUSxDQUFDO1FBQ0o7SUFDSixNQUFNLFlBQVksRUFBRSxRQUFRLEVBQUU7SUFDOUIsSUFBSSxXQUFXLElBQUksZ0JBQWdCLFlBQVk7U0FDMUMsZ0JBQWdCLGFBQWE7SUFDbEMsV0FBVyxLQUFLO0tBQ2YsS0FBSztLQUNMLE9BQU87TUFDTixHQUFHO01BQ0g7S0FDRDtJQUNELENBQUM7R0FDRjtFQUNEO0NBQ0Q7Q0FDQSxJQUFJLE9BQU8sV0FBVyxLQUFLLEtBQUs7Q0FDaEMsSUFBSSxPQUFPLFdBQVcsS0FBSztFQUMxQixLQUFLO0VBQ0wsT0FBTztHQUNOLFVBQVU7R0FDVixTQUFTO0VBQ1Y7Q0FDRCxDQUFDO0NBQ0QsV0FBVyxRQUFRO0NBQ25CLE1BQU0sbUJBQW1CLFFBQVEsU0FBUyxVQUFVLE1BQU0sU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsU0FBUyxTQUFTLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVO0VBQ3ZILEtBQUs7RUFDTCxPQUFPO0dBQ04sR0FBRztHQUNIO0VBQ0Q7Q0FDRCxFQUFFO0NBQ0YsTUFBTSxXQUFXLE9BQU8sS0FBSztDQUM3QixNQUFNLGtCQUFrQixDQUFDO0NBQ3pCLElBQUksVUFBVTtFQUNiLFFBQVEsU0FBUyxVQUFVO0dBQzFCLENBQUMsU0FBUyxPQUFPLE1BQU0sUUFBUSxFQUFFLElBQUEsRUFBTSxTQUFTLFNBQVM7SUFDeEQsTUFBTSxlQUFlLHVCQUF1QixJQUFJO0lBQ2hELGdCQUFnQixLQUFLO0tBQ3BCLEtBQUs7S0FDTCxPQUFPO01BQ04sS0FBSztNQUNMLEdBQUc7TUFDSCxhQUFhLG9CQUFvQixrQkFBa0IsWUFBWSxLQUFLLGFBQWE7TUFDakYsMEJBQTBCO01BQzFCO0tBQ0Q7SUFDRCxDQUFDO0dBQ0YsQ0FBQztFQUNGLENBQUM7RUFDRCxJQUFJLFNBQVMsYUFBYSxnQkFBZ0IsS0FBSztHQUM5QyxLQUFLO0dBQ0wsT0FBTztJQUNOLEdBQUcsU0FBUyxZQUFZO0lBQ3hCO0dBQ0Q7R0FDQSxVQUFVLFNBQVMsWUFBWTtHQUMvQixXQUFXO0VBQ1osQ0FBQztDQUNGO0NBQ0EsTUFBTSxlQUFlLENBQUM7Q0FDdEIsSUFBSSxVQUFVLFFBQVEsU0FBUyxVQUFVO0VBQ3hDLFNBQVMsT0FBTyxNQUFNLFFBQVEsRUFBRSxVQUFVLFNBQVMsWUFBWTtHQUM5RCxhQUFhLEtBQUs7SUFDakIsS0FBSztJQUNMLE9BQU87S0FDTixHQUFHLHNCQUFzQixVQUFVLFNBQVMsZ0JBQWdCO0tBQzVEO0lBQ0Q7R0FDRCxDQUFDO0VBQ0YsQ0FBQztDQUNGLENBQUM7Q0FDRCxNQUFNLFNBQVMsUUFBUSxTQUFTLFVBQVUsTUFBTSxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxVQUFVLFVBQVUsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUUsVUFBVSxHQUFHLGFBQWE7RUFDbEksS0FBSztFQUNMLE9BQU87R0FDTixHQUFHO0dBQ0g7RUFDRDtFQUNBO0NBQ0QsRUFBRTtDQUNGLE1BQU0sY0FBYyxRQUFRLFNBQVMsVUFBVSxNQUFNLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLFdBQVcsV0FBVyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLEdBQUcsY0FBYztFQUMvSSxLQUFLO0VBQ0wsT0FBTztHQUNOLEdBQUc7R0FDSDtFQUNEO0VBQ0E7Q0FDRCxFQUFFO0NBQ0YsTUFBTSxPQUFPLENBQUM7Q0FDZCxxQkFBcUIsTUFBTSxVQUFVO0NBQ3JDLEtBQUssS0FBSyxHQUFHLFlBQVk7Q0FDekIscUJBQXFCLE1BQU0sZ0JBQWdCO0NBQzNDLEtBQUssS0FBSyxHQUFHLGVBQWU7Q0FDNUIscUJBQXFCLE1BQU0sTUFBTTtDQUNqQyxxQkFBcUIsTUFBTSxXQUFXO0NBQ3RDLE9BQU87QUFDUjs7Ozs7QUFLQSxJQUFJLFdBQVcscUJBQXFCO0NBQ25DLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sUUFBUSxPQUFPLFFBQVEsS0FBSztDQUNsQyxJQUFnQixPQUFPLFVBQVUsT0FBTyxxQkFBcUIsUUFBUSxPQUFPLE9BQU8sT0FBTyxRQUFRLElBQUksR0FBRyxnQkFBZ0I7Q0FDekgsTUFBTSxhQUFBLGFBQXFCLGFBQWEsWUFBWSxxQkFBcUIsUUFBUSxPQUFPLFNBQVMsZ0JBQWdCLEdBQUc7RUFDbkg7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE9BQU8sWUFBWSxPQUFPLE9BQU8sU0FBUyxZQUFZLEVBQUUsU0FBUyxVQUFVLENBQUM7QUFDN0U7OztBQ25JQSxJQUFJLG1CQUFtQixFQUFFLDBCQUEwQixLQUFLOzs7Ozs7QUFNeEQsSUFBSSxnQkFBZ0I7Q0FDbkIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxRQUFRLE9BQU8sUUFBUSxLQUFLO0NBQ2xDLE1BQU0sWUFBWSxZQUFZO0VBQzdCLE1BQU0sUUFBUSxzQkFBc0IsU0FBUyxPQUFPLEtBQUssVUFBVSxPQUFPLGdCQUFnQjtFQUMxRixLQUFLLE1BQU0sVUFBVSxNQUFNLElBQUksSUFBSSxPQUFPLE9BQU8sT0FBTyxRQUFRLFVBQVU7R0FDekUsTUFBTSxrQkFBa0I7R0FDeEIsZ0JBQWdCLHFCQUFxQjtFQUN0QztFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sY0FBYyxZQUFZO0VBQy9CLE9BQU8sc0JBQXNCLFNBQVMsT0FBTyxDQUFDO0NBQy9DO0NBQ0EsSUFBZ0IsT0FBTyxVQUFVLE9BQU8sY0FBYyxzQkFBc0IsU0FBUyxPQUFPLE9BQU8sUUFBUSxJQUFJLENBQUMsR0FBRyxPQUFPLFdBQVcsK0JBQStCLENBQUMsQ0FBQztDQUN0SyxPQUFPLGNBQWMsWUFBWSxPQUFPLE9BQU8sU0FBUyxZQUFZLEVBQUUsU0FBUyxVQUFVLENBQUMsQ0FBQztBQUM1RjtBQUNBLFNBQVMsY0FBYyxTQUFTO0NBQy9CLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxtQkFBQUEsVUFBVSxFQUFFLFVBQVUsUUFBUSxLQUFLLE9BQU8sTUFBc0IsaUJBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBYyxPQUFPO0VBQy9HLEdBQUc7RUFDSCxLQUFLLGVBQWUsTUFBTSxJQUFJLEdBQUc7Q0FDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNOOzs7Ozs7Ozs7Ozs7QUNqQkEsU0FBUyxZQUFZLE9BQU87Q0FDM0IsTUFBTSxPQUFPLFFBQVEsTUFBTSxnQkFBZ0I7Q0FDM0MsTUFBTSxRQUFRLFVBQVUsQ0FBQyxDQUFDLFFBQVEsS0FBSztDQUN2QyxNQUFNLFdBQVcsWUFBWTtDQUM3QixhQUFRLGdCQUFnQjtFQUN2QixJQUFJLFVBQVUsU0FBUyxpQkFBaUIsUUFBUSxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsU0FBUyxPQUFPLEdBQUcsT0FBTyxDQUFDO0NBQ2hHLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDYixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSUMsbUJBQUFBLFVBQVUsRUFBRSxXQUFXLFdBQVcsS0FBSyxRQUFRLFFBQVEsSUFBSSxRQUFRLFVBQVUsSUFBSSxRQUFBLHVDQUE2QixJQUFJLElBQUksS0FBQSxDQUFNLEtBQUssUUFBd0IsaUJBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBYyxPQUFPO0VBQ3hNLEdBQUc7RUFDSCxLQUFLLFlBQVksS0FBSyxVQUFVLEdBQUc7RUFDbkM7Q0FDRCxDQUFDLENBQUMsRUFBRSxDQUFDO0FBQ04iLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0Myw0NCw0NSw0Niw0Nyw0OCw0OSw1MCw1MSw1Miw1Myw1NCw1NSw1Niw1Nyw1OCw1OSw2MCw2MSw2Miw2Myw2NCw2NSw2Niw2Nyw2OCw2OSw3MCw3MV19