import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/auth/session.tsx");const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { queryOptions, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { useNavigate, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { isAxiosError } from "/node_modules/.vite/deps/axios.js?v=bc216558";
import { http } from "/src/shared/api/http.ts";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/session.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
export const sessionKey = ["session"];
export const sessionOptions = () => queryOptions({
	queryKey: sessionKey,
	queryFn: async ({ signal }) => (await http.get("/session", { signal })).data,
	staleTime: Infinity,
	retry: false,
	retryOnMount: false,
	refetchOnWindowFocus: false
});
export const privateKey = (scope) => ["private", scope];
export const activeScope = (client, scope) => client.getQueryData(sessionKey)?.scope === scope;
export const scopedConfig = (scope, signal) => ({
	headers: { "X-Session-Scope": scope },
	signal
});
export function apiMessage(error) {
	return isAxiosError(error) ? error.response?.data.message ?? "Falha de conexão. Tente novamente." : "Não foi possível concluir. Tente novamente.";
}
export function apiFields(error) {
	return isAxiosError(error) ? error.response?.data.fieldErrors ?? {} : {};
}
export function reportExpired(error, scope, favorite = "", enabled = true) {
	if (isAxiosError(error) && error.response?.data.code === "SESSION_EXPIRED") window.dispatchEvent(new CustomEvent("session-expired", { detail: {
		scope,
		favorite,
		favoriteMode: enabled ? undefined : "remove"
	} }));
}
export async function replaceSession(client, incoming) {
	await client.cancelQueries({ queryKey: ["private"] });
	client.removeQueries({ queryKey: ["private"] });
	client.getMutationCache().clear();
	client.setQueryData(sessionKey, incoming);
}
const SessionContext = createContext(null);
_c = SessionContext;
export function useSession() {
	_s();
	const session = useContext(SessionContext);
	if (!session) throw new Error("SessionProvider required");
	return session;
}
_s(useSession, "ooQyqqm5xggN3tVJPUB1Y0jMDIk=");
export function SessionProvider({ children }) {
	_s2();
	const client = useQueryClient(), navigate = useNavigate(), router = useRouter();
	const query = useQuery(sessionOptions());
	useEffect(() => {
		let pending = false, alive = true;
		const expired = async (event) => {
			const detail = event.detail;
			const scope = typeof detail === "string" ? detail : detail.scope;
			if (pending || !activeScope(client, scope)) return;
			pending = true;
			try {
				const incoming = (await http.get("/session")).data;
				if (!alive || !activeScope(client, scope)) return;
				await replaceSession(client, incoming);
				const href = router.state.location.href;
				if (!/^\/(login|signup)/.test(href)) await navigate({
					to: "/login",
					search: {
						returnTo: href,
						favorite: typeof detail === "string" ? "" : detail.favorite,
						favoriteMode: typeof detail === "string" ? undefined : detail.favoriteMode
					}
				});
			} finally {
				pending = false;
			}
		};
		const listener = (event) => {
			void expired(event);
		};
		window.addEventListener("session-expired", listener);
		if (query.data?.expired && !/^\/(login|signup)/.test(router.state.location.pathname)) void navigate({
			to: "/login",
			search: {
				returnTo: router.state.location.href,
				favorite: ""
			}
		});
		const remaining = query.data?.expiresAt ? Math.max(0, query.data.expiresAt - Date.now()) : null;
		const timer = remaining !== null ? window.setTimeout(() => window.dispatchEvent(new CustomEvent("session-expired", { detail: query.data?.scope })), remaining) : undefined;
		return () => {
			alive = false;
			window.removeEventListener("session-expired", listener);
			window.clearTimeout(timer);
		};
	}, [
		client,
		navigate,
		router,
		query.data?.scope,
		query.data?.expiresAt,
		query.data?.expired
	]);
	if (!query.data) return /* @__PURE__ */ _jsxDEV("main", {
		className: "empty-state",
		role: query.isError ? "alert" : "status",
		children: [/* @__PURE__ */ _jsxDEV("p", { children: query.isError ? "Não foi possível recuperar a sessão." : "Recuperando sessão…" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 99
		}, this), query.isError && /* @__PURE__ */ _jsxDEV("button", {
			onClick: () => void query.refetch(),
			children: "Tentar novamente"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 204
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 50,
		columnNumber: 27
	}, this);
	return /* @__PURE__ */ _jsxDEV(SessionContext.Provider, {
		value: query.data,
		children: /* @__PURE__ */ _jsxDEV("div", { children }, query.data.scope, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 54
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 10
	}, this);
}
_s2(SessionProvider, "EG/1aHW/v3//hg13vkqe8ZfiYPk=", false, function() {
	return [
		useQueryClient,
		useNavigate,
		useRouter,
		useQuery
	];
});
_c2 = SessionProvider;
var _c, _c2;
$RefreshReg$(_c, "SessionContext");
$RefreshReg$(_c2, "SessionProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/auth/session.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/session.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/session.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/auth/session.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLFlBQVksaUJBQWlDO0FBQ3JFLFNBQVMsY0FBYyxVQUFVLHNCQUF3QztBQUN6RSxTQUFTLGFBQWEsaUJBQWlCO0FBQ3ZDLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsWUFBWTs7OztBQUVyQixPQUFPLE1BQU0sYUFBYSxDQUFDLFNBQVM7QUFDcEMsT0FBTyxNQUFNLHVCQUF1QixhQUFhO0NBQUUsVUFBVTtDQUFZLFNBQVMsT0FBTyxFQUFFLGNBQWMsTUFBTSxLQUFLLElBQWEsWUFBWSxFQUFFLE9BQU8sQ0FBQyxFQUFDLENBQUU7Q0FBTSxXQUFXO0NBQVUsT0FBTztDQUFPLGNBQWM7Q0FBTyxzQkFBc0I7QUFBTSxDQUFDO0FBQ3JQLE9BQU8sTUFBTSxjQUFjLFVBQWtCLENBQUMsV0FBVyxLQUFLO0FBQzlELE9BQU8sTUFBTSxlQUFlLFFBQXFCLFVBQWtCLE9BQU8sYUFBc0IsVUFBVSxDQUFDLEVBQUUsVUFBVTtBQUN2SCxPQUFPLE1BQU0sZ0JBQWdCLE9BQWUsWUFBMEI7Q0FBRSxTQUFTLEVBQUUsbUJBQW1CLE1BQU07Q0FBRztBQUFPO0FBQ3RILE9BQU8sU0FBUyxXQUFXLE9BQWdCO0NBQUUsT0FBTyxhQUF1QixLQUFLLElBQUksTUFBTSxVQUFVLEtBQUssV0FBVyx1Q0FBdUM7QUFBOEM7QUFDek0sT0FBTyxTQUFTLFVBQVUsT0FBZ0I7Q0FBRSxPQUFPLGFBQXVCLEtBQUssSUFBSSxNQUFNLFVBQVUsS0FBSyxlQUFlLENBQUMsSUFBSSxDQUFDO0FBQUU7QUFDL0gsT0FBTyxTQUFTLGNBQWMsT0FBZ0IsT0FBZSxXQUFXLElBQUksVUFBVSxNQUFNO0NBQzFGLElBQUksYUFBdUIsS0FBSyxLQUFLLE1BQU0sVUFBVSxLQUFLLFNBQVMsbUJBQW1CLE9BQU8sY0FBYyxJQUFJLFlBQVksbUJBQW1CLEVBQUUsUUFBUTtFQUFFO0VBQU87RUFBVSxjQUFjLFVBQVUsWUFBWTtDQUFTLEVBQUUsQ0FBQyxDQUFDO0FBQzlOO0FBQ0EsT0FBTyxlQUFlLGVBQWUsUUFBcUIsVUFBbUI7Q0FDM0UsTUFBTSxPQUFPLGNBQWMsRUFBRSxVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7Q0FDcEQsT0FBTyxjQUFjLEVBQUUsVUFBVSxDQUFDLFNBQVMsRUFBRSxDQUFDO0NBQzlDLE9BQU8saUJBQWlCLENBQUMsQ0FBQyxNQUFNO0NBQ2hDLE9BQU8sYUFBYSxZQUFZLFFBQVE7QUFDMUM7QUFDQSxNQUFNLGlCQUFpQixjQUE4QixJQUFJOztBQUN6RCxPQUFPLFNBQVMsYUFBYTs7Q0FBRSxNQUFNLFVBQVUsV0FBVyxjQUFjO0NBQUcsSUFBSSxDQUFDLFNBQVMsTUFBTSxJQUFJLE1BQU0sMEJBQTBCO0NBQUcsT0FBTztBQUFROztBQUNySixPQUFPLFNBQVMsZ0JBQWdCLEVBQUUsWUFBcUM7O0NBQ3JFLE1BQU0sU0FBUyxlQUFlLEdBQUcsV0FBVyxZQUFZLEdBQUcsU0FBUyxVQUFVO0NBQzlFLE1BQU0sUUFBUSxTQUFTLGVBQWUsQ0FBQztDQUN2QyxnQkFBZ0I7RUFDZCxJQUFJLFVBQVUsT0FBTyxRQUFRO0VBQzdCLE1BQU0sVUFBVSxPQUFPLFVBQWlCO0dBQ3RDLE1BQU0sU0FBVSxNQUE2RjtHQUM3RyxNQUFNLFFBQVEsT0FBTyxXQUFXLFdBQVcsU0FBUyxPQUFPO0dBQzNELElBQUksV0FBVyxDQUFDLFlBQVksUUFBUSxLQUFLLEdBQUc7R0FDNUMsVUFBVTtHQUNWLElBQUk7SUFDRixNQUFNLFlBQVksTUFBTSxLQUFLLElBQWEsVUFBVSxFQUFDLENBQUU7SUFDdkQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLFFBQVEsS0FBSyxHQUFHO0lBQzNDLE1BQU0sZUFBZSxRQUFRLFFBQVE7SUFDckMsTUFBTSxPQUFPLE9BQU8sTUFBTSxTQUFTO0lBQ25DLElBQUksQ0FBQyxvQkFBb0IsS0FBSyxJQUFJLEdBQUcsTUFBTSxTQUFTO0tBQUUsSUFBSTtLQUFVLFFBQVE7TUFBRSxVQUFVO01BQU0sVUFBVSxPQUFPLFdBQVcsV0FBVyxLQUFLLE9BQU87TUFBVSxjQUFjLE9BQU8sV0FBVyxXQUFXLFlBQVksT0FBTztLQUFhO0lBQUUsQ0FBQztHQUMzTyxVQUFVO0lBQUUsVUFBVTtHQUFNO0VBQzlCO0VBQ0EsTUFBTSxZQUFZLFVBQWlCO0dBQUUsS0FBSyxRQUFRLEtBQUs7RUFBRTtFQUN6RCxPQUFPLGlCQUFpQixtQkFBbUIsUUFBUTtFQUNuRCxJQUFJLE1BQU0sTUFBTSxXQUFXLENBQUMsb0JBQW9CLEtBQUssT0FBTyxNQUFNLFNBQVMsUUFBUSxHQUFHLEtBQUssU0FBUztHQUFFLElBQUk7R0FBVSxRQUFRO0lBQUUsVUFBVSxPQUFPLE1BQU0sU0FBUztJQUFNLFVBQVU7R0FBRztFQUFFLENBQUM7RUFDcEwsTUFBTSxZQUFZLE1BQU0sTUFBTSxZQUFZLEtBQUssSUFBSSxHQUFHLE1BQU0sS0FBSyxZQUFZLEtBQUssSUFBSSxDQUFDLElBQUk7RUFDM0YsTUFBTSxRQUFRLGNBQWMsT0FBTyxPQUFPLGlCQUFpQixPQUFPLGNBQWMsSUFBSSxZQUFZLG1CQUFtQixFQUFFLFFBQVEsTUFBTSxNQUFNLE1BQU0sQ0FBQyxDQUFDLEdBQUcsU0FBUyxJQUFJO0VBQ2pLLGFBQWE7R0FBRSxRQUFRO0dBQU8sT0FBTyxvQkFBb0IsbUJBQW1CLFFBQVE7R0FBRyxPQUFPLGFBQWEsS0FBSztFQUFFO0NBQ3BILEdBQUc7RUFBQztFQUFRO0VBQVU7RUFBUSxNQUFNLE1BQU07RUFBTyxNQUFNLE1BQU07RUFBVyxNQUFNLE1BQU07Q0FBTyxDQUFDO0NBQzVGLElBQUksQ0FBQyxNQUFNLE1BQU0sT0FBTyx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFjLE1BQU0sTUFBTSxVQUFVLFVBQVU7WUFBOUQsQ0FBd0Usd0JBQUMsS0FBRCxZQUFJLE1BQU0sVUFBVSx5Q0FBeUMsc0JBQXlCOzs7O1lBQUUsTUFBTSxXQUFXLHdCQUFDLFVBQUQ7R0FBUSxlQUFlLEtBQUssTUFBTSxRQUFRO2FBQUc7RUFBd0I7Ozs7VUFBUTs7Ozs7O0NBQ3RSLE9BQU8sd0JBQUMsZUFBZSxVQUFoQjtFQUF5QixPQUFPLE1BQU07WUFBTSx3QkFBQyxPQUFELEVBQTZCLFNBQWMsR0FBakMsTUFBTSxLQUFLOzs7O1NBQXNCO0NBQTBCOzs7OztBQUMxSCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzZXNzaW9uLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVDb250ZXh0LCB1c2VDb250ZXh0LCB1c2VFZmZlY3QsIHR5cGUgUmVhY3ROb2RlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBxdWVyeU9wdGlvbnMsIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCwgdHlwZSBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VSb3V0ZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgaXNBeGlvc0Vycm9yIH0gZnJvbSAnYXhpb3MnXG5pbXBvcnQgeyBodHRwIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2h0dHAnXG5pbXBvcnQgdHlwZSB7IEFwaUVycm9yLCBTZXNzaW9uIH0gZnJvbSAnLi9jb250cmFjdHMnXG5leHBvcnQgY29uc3Qgc2Vzc2lvbktleSA9IFsnc2Vzc2lvbiddIGFzIGNvbnN0XG5leHBvcnQgY29uc3Qgc2Vzc2lvbk9wdGlvbnMgPSAoKSA9PiBxdWVyeU9wdGlvbnMoeyBxdWVyeUtleTogc2Vzc2lvbktleSwgcXVlcnlGbjogYXN5bmMgKHsgc2lnbmFsIH0pID0+IChhd2FpdCBodHRwLmdldDxTZXNzaW9uPignL3Nlc3Npb24nLCB7IHNpZ25hbCB9KSkuZGF0YSwgc3RhbGVUaW1lOiBJbmZpbml0eSwgcmV0cnk6IGZhbHNlLCByZXRyeU9uTW91bnQ6IGZhbHNlLCByZWZldGNoT25XaW5kb3dGb2N1czogZmFsc2UgfSlcbmV4cG9ydCBjb25zdCBwcml2YXRlS2V5ID0gKHNjb3BlOiBzdHJpbmcpID0+IFsncHJpdmF0ZScsIHNjb3BlXSBhcyBjb25zdFxuZXhwb3J0IGNvbnN0IGFjdGl2ZVNjb3BlID0gKGNsaWVudDogUXVlcnlDbGllbnQsIHNjb3BlOiBzdHJpbmcpID0+IGNsaWVudC5nZXRRdWVyeURhdGE8U2Vzc2lvbj4oc2Vzc2lvbktleSk/LnNjb3BlID09PSBzY29wZVxuZXhwb3J0IGNvbnN0IHNjb3BlZENvbmZpZyA9IChzY29wZTogc3RyaW5nLCBzaWduYWw/OiBBYm9ydFNpZ25hbCkgPT4gKHsgaGVhZGVyczogeyAnWC1TZXNzaW9uLVNjb3BlJzogc2NvcGUgfSwgc2lnbmFsIH0pXG5leHBvcnQgZnVuY3Rpb24gYXBpTWVzc2FnZShlcnJvcjogdW5rbm93bikgeyByZXR1cm4gaXNBeGlvc0Vycm9yPEFwaUVycm9yPihlcnJvcikgPyBlcnJvci5yZXNwb25zZT8uZGF0YS5tZXNzYWdlID8/ICdGYWxoYSBkZSBjb25leMOjby4gVGVudGUgbm92YW1lbnRlLicgOiAnTsOjbyBmb2kgcG9zc8OtdmVsIGNvbmNsdWlyLiBUZW50ZSBub3ZhbWVudGUuJyB9XG5leHBvcnQgZnVuY3Rpb24gYXBpRmllbGRzKGVycm9yOiB1bmtub3duKSB7IHJldHVybiBpc0F4aW9zRXJyb3I8QXBpRXJyb3I+KGVycm9yKSA/IGVycm9yLnJlc3BvbnNlPy5kYXRhLmZpZWxkRXJyb3JzID8/IHt9IDoge30gfVxuZXhwb3J0IGZ1bmN0aW9uIHJlcG9ydEV4cGlyZWQoZXJyb3I6IHVua25vd24sIHNjb3BlOiBzdHJpbmcsIGZhdm9yaXRlID0gJycsIGVuYWJsZWQgPSB0cnVlKSB7XG4gIGlmIChpc0F4aW9zRXJyb3I8QXBpRXJyb3I+KGVycm9yKSAmJiBlcnJvci5yZXNwb25zZT8uZGF0YS5jb2RlID09PSAnU0VTU0lPTl9FWFBJUkVEJykgd2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEN1c3RvbUV2ZW50KCdzZXNzaW9uLWV4cGlyZWQnLCB7IGRldGFpbDogeyBzY29wZSwgZmF2b3JpdGUsIGZhdm9yaXRlTW9kZTogZW5hYmxlZCA/IHVuZGVmaW5lZCA6ICdyZW1vdmUnIH0gfSkpXG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVwbGFjZVNlc3Npb24oY2xpZW50OiBRdWVyeUNsaWVudCwgaW5jb21pbmc6IFNlc3Npb24pIHtcbiAgYXdhaXQgY2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleTogWydwcml2YXRlJ10gfSlcbiAgY2xpZW50LnJlbW92ZVF1ZXJpZXMoeyBxdWVyeUtleTogWydwcml2YXRlJ10gfSlcbiAgY2xpZW50LmdldE11dGF0aW9uQ2FjaGUoKS5jbGVhcigpXG4gIGNsaWVudC5zZXRRdWVyeURhdGEoc2Vzc2lvbktleSwgaW5jb21pbmcpXG59XG5jb25zdCBTZXNzaW9uQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8U2Vzc2lvbiB8IG51bGw+KG51bGwpXG5leHBvcnQgZnVuY3Rpb24gdXNlU2Vzc2lvbigpIHsgY29uc3Qgc2Vzc2lvbiA9IHVzZUNvbnRleHQoU2Vzc2lvbkNvbnRleHQpOyBpZiAoIXNlc3Npb24pIHRocm93IG5ldyBFcnJvcignU2Vzc2lvblByb3ZpZGVyIHJlcXVpcmVkJyk7IHJldHVybiBzZXNzaW9uIH1cbmV4cG9ydCBmdW5jdGlvbiBTZXNzaW9uUHJvdmlkZXIoeyBjaGlsZHJlbiB9OiB7IGNoaWxkcmVuOiBSZWFjdE5vZGUgfSkge1xuICBjb25zdCBjbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpLCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKCksIHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IHF1ZXJ5ID0gdXNlUXVlcnkoc2Vzc2lvbk9wdGlvbnMoKSlcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgcGVuZGluZyA9IGZhbHNlLCBhbGl2ZSA9IHRydWVcbiAgICBjb25zdCBleHBpcmVkID0gYXN5bmMgKGV2ZW50OiBFdmVudCkgPT4ge1xuICAgICAgY29uc3QgZGV0YWlsID0gKGV2ZW50IGFzIEN1c3RvbUV2ZW50PHN0cmluZyB8IHsgc2NvcGU6IHN0cmluZzsgZmF2b3JpdGU6IHN0cmluZzsgZmF2b3JpdGVNb2RlPzogJ3JlbW92ZScgfT4pLmRldGFpbFxuICAgICAgY29uc3Qgc2NvcGUgPSB0eXBlb2YgZGV0YWlsID09PSAnc3RyaW5nJyA/IGRldGFpbCA6IGRldGFpbC5zY29wZVxuICAgICAgaWYgKHBlbmRpbmcgfHwgIWFjdGl2ZVNjb3BlKGNsaWVudCwgc2NvcGUpKSByZXR1cm5cbiAgICAgIHBlbmRpbmcgPSB0cnVlXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBpbmNvbWluZyA9IChhd2FpdCBodHRwLmdldDxTZXNzaW9uPignL3Nlc3Npb24nKSkuZGF0YVxuICAgICAgICBpZiAoIWFsaXZlIHx8ICFhY3RpdmVTY29wZShjbGllbnQsIHNjb3BlKSkgcmV0dXJuXG4gICAgICAgIGF3YWl0IHJlcGxhY2VTZXNzaW9uKGNsaWVudCwgaW5jb21pbmcpXG4gICAgICAgIGNvbnN0IGhyZWYgPSByb3V0ZXIuc3RhdGUubG9jYXRpb24uaHJlZlxuICAgICAgICBpZiAoIS9eXFwvKGxvZ2lufHNpZ251cCkvLnRlc3QoaHJlZikpIGF3YWl0IG5hdmlnYXRlKHsgdG86ICcvbG9naW4nLCBzZWFyY2g6IHsgcmV0dXJuVG86IGhyZWYsIGZhdm9yaXRlOiB0eXBlb2YgZGV0YWlsID09PSAnc3RyaW5nJyA/ICcnIDogZGV0YWlsLmZhdm9yaXRlLCBmYXZvcml0ZU1vZGU6IHR5cGVvZiBkZXRhaWwgPT09ICdzdHJpbmcnID8gdW5kZWZpbmVkIDogZGV0YWlsLmZhdm9yaXRlTW9kZSB9IH0pXG4gICAgICB9IGZpbmFsbHkgeyBwZW5kaW5nID0gZmFsc2UgfVxuICAgIH1cbiAgICBjb25zdCBsaXN0ZW5lciA9IChldmVudDogRXZlbnQpID0+IHsgdm9pZCBleHBpcmVkKGV2ZW50KSB9XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Nlc3Npb24tZXhwaXJlZCcsIGxpc3RlbmVyKVxuICAgIGlmIChxdWVyeS5kYXRhPy5leHBpcmVkICYmICEvXlxcLyhsb2dpbnxzaWdudXApLy50ZXN0KHJvdXRlci5zdGF0ZS5sb2NhdGlvbi5wYXRobmFtZSkpIHZvaWQgbmF2aWdhdGUoeyB0bzogJy9sb2dpbicsIHNlYXJjaDogeyByZXR1cm5Ubzogcm91dGVyLnN0YXRlLmxvY2F0aW9uLmhyZWYsIGZhdm9yaXRlOiAnJyB9IH0pXG4gICAgY29uc3QgcmVtYWluaW5nID0gcXVlcnkuZGF0YT8uZXhwaXJlc0F0ID8gTWF0aC5tYXgoMCwgcXVlcnkuZGF0YS5leHBpcmVzQXQgLSBEYXRlLm5vdygpKSA6IG51bGxcbiAgICBjb25zdCB0aW1lciA9IHJlbWFpbmluZyAhPT0gbnVsbCA/IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHdpbmRvdy5kaXNwYXRjaEV2ZW50KG5ldyBDdXN0b21FdmVudCgnc2Vzc2lvbi1leHBpcmVkJywgeyBkZXRhaWw6IHF1ZXJ5LmRhdGE/LnNjb3BlIH0pKSwgcmVtYWluaW5nKSA6IHVuZGVmaW5lZFxuICAgIHJldHVybiAoKSA9PiB7IGFsaXZlID0gZmFsc2U7IHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdzZXNzaW9uLWV4cGlyZWQnLCBsaXN0ZW5lcik7IHdpbmRvdy5jbGVhclRpbWVvdXQodGltZXIpIH1cbiAgfSwgW2NsaWVudCwgbmF2aWdhdGUsIHJvdXRlciwgcXVlcnkuZGF0YT8uc2NvcGUsIHF1ZXJ5LmRhdGE/LmV4cGlyZXNBdCwgcXVlcnkuZGF0YT8uZXhwaXJlZF0pXG4gIGlmICghcXVlcnkuZGF0YSkgcmV0dXJuIDxtYWluIGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCIgcm9sZT17cXVlcnkuaXNFcnJvciA/ICdhbGVydCcgOiAnc3RhdHVzJ30+PHA+e3F1ZXJ5LmlzRXJyb3IgPyAnTsOjbyBmb2kgcG9zc8OtdmVsIHJlY3VwZXJhciBhIHNlc3PDo28uJyA6ICdSZWN1cGVyYW5kbyBzZXNzw6Nv4oCmJ308L3A+e3F1ZXJ5LmlzRXJyb3IgJiYgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB2b2lkIHF1ZXJ5LnJlZmV0Y2goKX0+VGVudGFyIG5vdmFtZW50ZTwvYnV0dG9uPn08L21haW4+XG4gIHJldHVybiA8U2Vzc2lvbkNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3F1ZXJ5LmRhdGF9PjxkaXYga2V5PXtxdWVyeS5kYXRhLnNjb3BlfT57Y2hpbGRyZW59PC9kaXY+PC9TZXNzaW9uQ29udGV4dC5Qcm92aWRlcj5cbn1cbiJdfQ==