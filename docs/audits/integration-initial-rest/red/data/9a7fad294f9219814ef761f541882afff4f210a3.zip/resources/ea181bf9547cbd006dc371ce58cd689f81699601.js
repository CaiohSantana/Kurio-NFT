import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/favorites/FavoriteButton.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import { useIsMutating, useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { useNavigate, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { Heart } from "/node_modules/.vite/deps/lucide-react.js?v=643d2d14";
import { http } from "/src/shared/api/http.ts";
import { activeScope, apiMessage, privateKey, reportExpired, scopedConfig, useSession } from "/src/features/auth/session.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/favorites/FavoriteButton.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export const favoritesKey = (scope) => [...privateKey(scope), "favorites"];
export function FavoriteButton({ id, name, className = "" }) {
	_s();
	const session = useSession(), client = useQueryClient(), navigate = useNavigate(), router = useRouter();
	const key = favoritesKey(session.scope);
	const pendingFavorites = useIsMutating({ mutationKey: key });
	const query = useQuery({
		queryKey: key,
		enabled: !!session.user,
		retry: false,
		staleTime: 3e4,
		queryFn: async ({ signal }) => {
			try {
				return (await http.get("/favorites", scopedConfig(session.scope, signal))).data;
			} catch (error) {
				reportExpired(error, session.scope);
				throw error;
			}
		}
	});
	const selected = query.data?.includes(id) ?? false;
	const mutation = useMutation({
		mutationKey: [...key, id],
		scope: { id: `favorite:${session.scope}` },
		retry: false,
		mutationFn: async (enable) => (await http.request({
			...scopedConfig(session.scope),
			method: enable ? "PUT" : "DELETE",
			url: `/favorites/${id}`
		})).data,
		onMutate: async (enable) => {
			await client.cancelQueries({ queryKey: key });
			const snapshot = client.getQueryData(key);
			if (activeScope(client, session.scope)) client.setQueryData(key, (old = []) => enable ? [...new Set([...old, id])] : old.filter((value) => value !== id));
			return { snapshot };
		},
		onError: (error, enable, context) => {
			if (activeScope(client, session.scope)) client.setQueryData(key, context?.snapshot ?? []);
			reportExpired(error, session.scope, id, enable);
		},
		onSettled: () => {
			if (activeScope(client, session.scope)) void client.invalidateQueries({ queryKey: key });
		}
	});
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `favorite-control ${className}`,
		children: [
			/* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				"aria-label": `${selected ? "Desfavoritar" : "Favoritar"} ${name}`,
				"aria-pressed": selected,
				disabled: pendingFavorites > 0 || !!session.user && !query.data,
				onClick: () => {
					if (!session.user) void navigate({
						to: "/login",
						search: {
							returnTo: router.state.location.href,
							favorite: id
						}
					});
					else mutation.mutate(!selected);
				},
				children: /* @__PURE__ */ _jsxDEV(Heart, {
					size: 18,
					fill: selected ? "currentColor" : "none"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 6
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 60
			}, this),
			mutation.isError && /* @__PURE__ */ _jsxDEV("span", {
				role: "alert",
				children: apiMessage(mutation.error)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 97
			}, this),
			query.isError && /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => void query.refetch(),
				children: "Recarregar favoritos"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 170
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 10
	}, this);
}
_s(FavoriteButton, "LnwBlr9fn4mNQMvvgFSOnsxsCVc=", false, function() {
	return [
		useSession,
		useQueryClient,
		useNavigate,
		useRouter,
		useIsMutating,
		useQuery,
		useMutation
	];
});
_c = FavoriteButton;
var _c;
$RefreshReg$(_c, "FavoriteButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/favorites/FavoriteButton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/favorites/FavoriteButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/favorites/FavoriteButton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/favorites/FavoriteButton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLGFBQWEsVUFBVSxzQkFBc0I7QUFDckUsU0FBUyxhQUFhLGlCQUFpQjtBQUN2QyxTQUFTLGFBQWE7QUFDdEIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsYUFBYSxZQUFZLFlBQVksZUFBZSxjQUFjLGtCQUFrQjs7OztBQUM3RixPQUFPLE1BQU0sZ0JBQWdCLFVBQWtCLENBQUMsR0FBRyxXQUFXLEtBQUssR0FBRyxXQUFXO0FBQ2pGLE9BQU8sU0FBUyxlQUFlLEVBQUUsSUFBSSxNQUFNLFlBQVksTUFBd0Q7O0NBQzdHLE1BQU0sVUFBVSxXQUFXLEdBQUcsU0FBUyxlQUFlLEdBQUcsV0FBVyxZQUFZLEdBQUcsU0FBUyxVQUFVO0NBQ3RHLE1BQU0sTUFBTSxhQUFhLFFBQVEsS0FBSztDQUN0QyxNQUFNLG1CQUFtQixjQUFjLEVBQUUsYUFBYSxJQUFJLENBQUM7Q0FDM0QsTUFBTSxRQUFRLFNBQVM7RUFBRSxVQUFVO0VBQUssU0FBUyxDQUFDLENBQUMsUUFBUTtFQUFNLE9BQU87RUFBTyxXQUFXO0VBQU8sU0FBUyxPQUFPLEVBQUUsYUFBYTtHQUM5SCxJQUFJO0lBQUUsUUFBUSxNQUFNLEtBQUssSUFBYyxjQUFjLGFBQWEsUUFBUSxPQUFPLE1BQU0sQ0FBQyxFQUFDLENBQUU7R0FBSyxTQUFTLE9BQU87SUFBRSxjQUFjLE9BQU8sUUFBUSxLQUFLO0lBQUcsTUFBTTtHQUFNO0VBQ3JLO0NBQUUsQ0FBQztDQUNILE1BQU0sV0FBVyxNQUFNLE1BQU0sU0FBUyxFQUFFLEtBQUs7Q0FDN0MsTUFBTSxXQUFXLFlBQVk7RUFBRSxhQUFhLENBQUMsR0FBRyxLQUFLLEVBQUU7RUFBRyxPQUFPLEVBQUUsSUFBSSxZQUFZLFFBQVEsUUFBUTtFQUFHLE9BQU87RUFDM0csWUFBWSxPQUFPLFlBQXFCLE1BQU0sS0FBSyxRQUFrQjtHQUFFLEdBQUcsYUFBYSxRQUFRLEtBQUs7R0FBRyxRQUFRLFNBQVMsUUFBUTtHQUFVLEtBQUssY0FBYztFQUFLLENBQUMsRUFBQyxDQUFFO0VBQ3RLLFVBQVUsT0FBTyxXQUFXO0dBQzFCLE1BQU0sT0FBTyxjQUFjLEVBQUUsVUFBVSxJQUFJLENBQUM7R0FBRyxNQUFNLFdBQVcsT0FBTyxhQUF1QixHQUFHO0dBQ2pHLElBQUksWUFBWSxRQUFRLFFBQVEsS0FBSyxHQUFHLE9BQU8sYUFBdUIsTUFBTSxNQUFNLENBQUMsTUFBTSxTQUFTLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLFFBQVEsVUFBVSxVQUFVLEVBQUUsQ0FBQztHQUNsSyxPQUFPLEVBQUUsU0FBUztFQUNwQjtFQUNBLFVBQVUsT0FBTyxRQUFRLFlBQVk7R0FBRSxJQUFJLFlBQVksUUFBUSxRQUFRLEtBQUssR0FBRyxPQUFPLGFBQWEsS0FBSyxTQUFTLFlBQVksQ0FBQyxDQUFDO0dBQUcsY0FBYyxPQUFPLFFBQVEsT0FBTyxJQUFJLE1BQU07RUFBRTtFQUNsTCxpQkFBaUI7R0FBRSxJQUFJLFlBQVksUUFBUSxRQUFRLEtBQUssR0FBRyxLQUFLLE9BQU8sa0JBQWtCLEVBQUUsVUFBVSxJQUFJLENBQUM7RUFBRTtDQUM5RyxDQUFDO0NBQ0QsT0FBTyx3QkFBQyxRQUFEO0VBQU0sV0FBVyxvQkFBb0I7WUFBckM7R0FBa0Qsd0JBQUMsVUFBRDtJQUFRLE1BQUs7SUFBUyxjQUFZLEdBQUcsV0FBVyxpQkFBaUIsWUFBWSxHQUFHO0lBQVEsZ0JBQWM7SUFBVSxVQUFVLG1CQUFtQixLQUFNLENBQUMsQ0FBQyxRQUFRLFFBQVEsQ0FBQyxNQUFNO0lBQU8sZUFBZTtLQUN6UCxJQUFJLENBQUMsUUFBUSxNQUFNLEtBQUssU0FBUztNQUFFLElBQUk7TUFBVSxRQUFRO09BQUUsVUFBVSxPQUFPLE1BQU0sU0FBUztPQUFNLFVBQVU7TUFBRztLQUFFLENBQUM7VUFDNUcsU0FBUyxPQUFPLENBQUMsUUFBUTtJQUNoQztjQUFHLHdCQUFDLE9BQUQ7S0FBTyxNQUFNO0tBQUksTUFBTSxXQUFXLGlCQUFpQjtJQUFTOzs7OztHQUFTOzs7OztHQUFFLFNBQVMsV0FBVyx3QkFBQyxRQUFEO0lBQU0sTUFBSztjQUFTLFdBQVcsU0FBUyxLQUFLO0dBQVE7Ozs7O0dBQUcsTUFBTSxXQUFXLHdCQUFDLFVBQUQ7SUFBUSxlQUFlLEtBQUssTUFBTSxRQUFRO2NBQUc7R0FBNEI7Ozs7O0VBQVE7Ozs7OztBQUMxUCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJGYXZvcml0ZUJ1dHRvbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlSXNNdXRhdGluZywgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHVzZU5hdmlnYXRlLCB1c2VSb3V0ZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgSGVhcnQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBodHRwIH0gZnJvbSAnQC9zaGFyZWQvYXBpL2h0dHAnXG5pbXBvcnQgeyBhY3RpdmVTY29wZSwgYXBpTWVzc2FnZSwgcHJpdmF0ZUtleSwgcmVwb3J0RXhwaXJlZCwgc2NvcGVkQ29uZmlnLCB1c2VTZXNzaW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9hdXRoL3Nlc3Npb24nXG5leHBvcnQgY29uc3QgZmF2b3JpdGVzS2V5ID0gKHNjb3BlOiBzdHJpbmcpID0+IFsuLi5wcml2YXRlS2V5KHNjb3BlKSwgJ2Zhdm9yaXRlcyddIGFzIGNvbnN0XG5leHBvcnQgZnVuY3Rpb24gRmF2b3JpdGVCdXR0b24oeyBpZCwgbmFtZSwgY2xhc3NOYW1lID0gJycgfTogeyBpZDogc3RyaW5nOyBuYW1lOiBzdHJpbmc7IGNsYXNzTmFtZT86IHN0cmluZyB9KSB7XG4gIGNvbnN0IHNlc3Npb24gPSB1c2VTZXNzaW9uKCksIGNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KCksIG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKSwgcm91dGVyID0gdXNlUm91dGVyKClcbiAgY29uc3Qga2V5ID0gZmF2b3JpdGVzS2V5KHNlc3Npb24uc2NvcGUpXG4gIGNvbnN0IHBlbmRpbmdGYXZvcml0ZXMgPSB1c2VJc011dGF0aW5nKHsgbXV0YXRpb25LZXk6IGtleSB9KVxuICBjb25zdCBxdWVyeSA9IHVzZVF1ZXJ5KHsgcXVlcnlLZXk6IGtleSwgZW5hYmxlZDogISFzZXNzaW9uLnVzZXIsIHJldHJ5OiBmYWxzZSwgc3RhbGVUaW1lOiAzMDAwMCwgcXVlcnlGbjogYXN5bmMgKHsgc2lnbmFsIH0pID0+IHtcbiAgICB0cnkgeyByZXR1cm4gKGF3YWl0IGh0dHAuZ2V0PHN0cmluZ1tdPignL2Zhdm9yaXRlcycsIHNjb3BlZENvbmZpZyhzZXNzaW9uLnNjb3BlLCBzaWduYWwpKSkuZGF0YSB9IGNhdGNoIChlcnJvcikgeyByZXBvcnRFeHBpcmVkKGVycm9yLCBzZXNzaW9uLnNjb3BlKTsgdGhyb3cgZXJyb3IgfVxuICB9IH0pXG4gIGNvbnN0IHNlbGVjdGVkID0gcXVlcnkuZGF0YT8uaW5jbHVkZXMoaWQpID8/IGZhbHNlXG4gIGNvbnN0IG11dGF0aW9uID0gdXNlTXV0YXRpb24oeyBtdXRhdGlvbktleTogWy4uLmtleSwgaWRdLCBzY29wZTogeyBpZDogYGZhdm9yaXRlOiR7c2Vzc2lvbi5zY29wZX1gIH0sIHJldHJ5OiBmYWxzZSxcbiAgICBtdXRhdGlvbkZuOiBhc3luYyAoZW5hYmxlOiBib29sZWFuKSA9PiAoYXdhaXQgaHR0cC5yZXF1ZXN0PHN0cmluZ1tdPih7IC4uLnNjb3BlZENvbmZpZyhzZXNzaW9uLnNjb3BlKSwgbWV0aG9kOiBlbmFibGUgPyAnUFVUJyA6ICdERUxFVEUnLCB1cmw6IGAvZmF2b3JpdGVzLyR7aWR9YCB9KSkuZGF0YSxcbiAgICBvbk11dGF0ZTogYXN5bmMgKGVuYWJsZSkgPT4ge1xuICAgICAgYXdhaXQgY2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pOyBjb25zdCBzbmFwc2hvdCA9IGNsaWVudC5nZXRRdWVyeURhdGE8c3RyaW5nW10+KGtleSlcbiAgICAgIGlmIChhY3RpdmVTY29wZShjbGllbnQsIHNlc3Npb24uc2NvcGUpKSBjbGllbnQuc2V0UXVlcnlEYXRhPHN0cmluZ1tdPihrZXksIChvbGQgPSBbXSkgPT4gZW5hYmxlID8gWy4uLm5ldyBTZXQoWy4uLm9sZCwgaWRdKV0gOiBvbGQuZmlsdGVyKCh2YWx1ZSkgPT4gdmFsdWUgIT09IGlkKSlcbiAgICAgIHJldHVybiB7IHNuYXBzaG90IH1cbiAgICB9LFxuICAgIG9uRXJyb3I6IChlcnJvciwgZW5hYmxlLCBjb250ZXh0KSA9PiB7IGlmIChhY3RpdmVTY29wZShjbGllbnQsIHNlc3Npb24uc2NvcGUpKSBjbGllbnQuc2V0UXVlcnlEYXRhKGtleSwgY29udGV4dD8uc25hcHNob3QgPz8gW10pOyByZXBvcnRFeHBpcmVkKGVycm9yLCBzZXNzaW9uLnNjb3BlLCBpZCwgZW5hYmxlKSB9LFxuICAgIG9uU2V0dGxlZDogKCkgPT4geyBpZiAoYWN0aXZlU2NvcGUoY2xpZW50LCBzZXNzaW9uLnNjb3BlKSkgdm9pZCBjbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pIH0sXG4gIH0pXG4gIHJldHVybiA8c3BhbiBjbGFzc05hbWU9e2BmYXZvcml0ZS1jb250cm9sICR7Y2xhc3NOYW1lfWB9PjxidXR0b24gdHlwZT1cImJ1dHRvblwiIGFyaWEtbGFiZWw9e2Ake3NlbGVjdGVkID8gJ0Rlc2Zhdm9yaXRhcicgOiAnRmF2b3JpdGFyJ30gJHtuYW1lfWB9IGFyaWEtcHJlc3NlZD17c2VsZWN0ZWR9IGRpc2FibGVkPXtwZW5kaW5nRmF2b3JpdGVzID4gMCB8fCAoISFzZXNzaW9uLnVzZXIgJiYgIXF1ZXJ5LmRhdGEpfSBvbkNsaWNrPXsoKSA9PiB7XG4gICAgaWYgKCFzZXNzaW9uLnVzZXIpIHZvaWQgbmF2aWdhdGUoeyB0bzogJy9sb2dpbicsIHNlYXJjaDogeyByZXR1cm5Ubzogcm91dGVyLnN0YXRlLmxvY2F0aW9uLmhyZWYsIGZhdm9yaXRlOiBpZCB9IH0pXG4gICAgZWxzZSBtdXRhdGlvbi5tdXRhdGUoIXNlbGVjdGVkKVxuICB9fT48SGVhcnQgc2l6ZT17MTh9IGZpbGw9e3NlbGVjdGVkID8gJ2N1cnJlbnRDb2xvcicgOiAnbm9uZSd9IC8+PC9idXR0b24+e211dGF0aW9uLmlzRXJyb3IgJiYgPHNwYW4gcm9sZT1cImFsZXJ0XCI+e2FwaU1lc3NhZ2UobXV0YXRpb24uZXJyb3IpfTwvc3Bhbj59e3F1ZXJ5LmlzRXJyb3IgJiYgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB2b2lkIHF1ZXJ5LnJlZmV0Y2goKX0+UmVjYXJyZWdhciBmYXZvcml0b3M8L2J1dHRvbj59PC9zcGFuPlxufVxuIl19