const createRoot = __vite__cjsImport0_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=11bd9012";
import { QueryClient, QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { RouterProvider } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { router } from "/src/app/router.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/app/bootstrap.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
export function mount(root) {
	const queryClient = new QueryClient();
	createRoot(root).render(/* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ _jsxDEV(RouterProvider, {
			router,
			context: { queryClient }
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 69
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 27
	}, this));
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxhQUFhLDJCQUEyQjtBQUNqRCxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGNBQWM7OztBQUV2QixPQUFPLFNBQVMsTUFBTSxNQUFtQjtDQUN2QyxNQUFNLGNBQWMsSUFBSSxZQUFZO0NBQ3BDLFdBQVcsSUFBSSxDQUFDLENBQUMsT0FBTyx3QkFBQyxxQkFBRDtFQUFxQixRQUFRO1lBQWEsd0JBQUMsZ0JBQUQ7R0FBd0I7R0FBUSxTQUFTLEVBQUUsWUFBWTtFQUFJOzs7OztDQUFzQjs7OztTQUFDO0FBQ3RKIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImJvb3RzdHJhcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnXG5pbXBvcnQgeyBRdWVyeUNsaWVudCwgUXVlcnlDbGllbnRQcm92aWRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IFJvdXRlclByb3ZpZGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IHJvdXRlciB9IGZyb20gJy4vcm91dGVyJ1xuXG5leHBvcnQgZnVuY3Rpb24gbW91bnQocm9vdDogSFRNTEVsZW1lbnQpIHtcbiAgY29uc3QgcXVlcnlDbGllbnQgPSBuZXcgUXVlcnlDbGllbnQoKVxuICBjcmVhdGVSb290KHJvb3QpLnJlbmRlcig8UXVlcnlDbGllbnRQcm92aWRlciBjbGllbnQ9e3F1ZXJ5Q2xpZW50fT48Um91dGVyUHJvdmlkZXIgcm91dGVyPXtyb3V0ZXJ9IGNvbnRleHQ9e3sgcXVlcnlDbGllbnQgfX0gLz48L1F1ZXJ5Q2xpZW50UHJvdmlkZXI+KVxufVxuIl19