import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/catalog/CatalogPage.tsx");const useLayoutEffect = __vite__cjsImport1_react["useLayoutEffect"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport14_react_jsxDevRuntime["Fragment"];import { mobileIcons } from "/src/shared/ui/mobile-icons.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=4f1d3af0";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { useLocation, useNavigate, useSearch } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { Search, SlidersHorizontal } from "/node_modules/.vite/deps/lucide-react.js?v=643d2d14";
import { Modal } from "/src/shared/ui/modal.tsx";
import { Button } from "/src/shared/ui/button.tsx";
import { Skeleton } from "/src/shared/ui/skeleton.tsx";
import { catalogOptions } from "/src/features/catalog/api.ts";
import { validateCatalogSearch } from "/src/features/catalog/contracts.ts";
import { Filters } from "/src/features/catalog/Filters.tsx";
import { NftCard } from "/src/features/catalog/NftCard.tsx";
import { Hero, HomeSections } from "/src/features/catalog/HomeSections.tsx";
import { scrollToCatalog } from "/src/features/catalog/CatalogLink.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogPage.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function CatalogPage() {
	_s();
	const search = validateCatalogSearch(useSearch({ strict: false })), navigate = useNavigate({ from: "/" });
	const query = useQuery(catalogOptions(search));
	const [filterOpen, setFilterOpen] = useState(false);
	const location = useLocation();
	useLayoutEffect(() => {
		if (location.pathname === "/" && location.hash === "catalog") scrollToCatalog();
	}, [location.pathname, location.hash]);
	const change = (patch) => {
		void navigate({ search: {
			...search,
			...patch,
			page: patch.page ?? 1
		} });
	};
	return /* @__PURE__ */ _jsxDEV("main", { children: [
		/* @__PURE__ */ _jsxDEV("div", {
			className: "catalog-search-row",
			children: [/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (e) => {
					e.preventDefault();
					change({ q: String(new FormData(e.currentTarget).get("q") ?? "") });
				},
				children: [
					/* @__PURE__ */ _jsxDEV(Search, {
						className: "catalog-icon-default",
						size: 22
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 172
					}, this),
					/* @__PURE__ */ _jsxDEV("img", {
						className: "catalog-icon-reference",
						src: mobileIcons.search,
						width: "22",
						height: "22",
						alt: ""
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 225
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						className: "sr-only",
						htmlFor: "catalog-search",
						children: "Buscar NFTs"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 322
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "catalog-search",
						name: "q",
						defaultValue: search.q,
						placeholder: "Explorar coleções"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 393
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "sr-only",
						type: "submit",
						children: "Buscar"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 487
					}, this)
				]
			}, search.q, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 41
			}, this), /* @__PURE__ */ _jsxDEV("button", {
				className: "filter-toggle",
				"aria-label": "Abrir filtros",
				onClick: () => setFilterOpen(true),
				children: [/* @__PURE__ */ _jsxDEV(SlidersHorizontal, {
					className: "catalog-icon-default",
					size: 22
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 648
				}, this), /* @__PURE__ */ _jsxDEV("img", {
					className: "catalog-icon-reference",
					src: mobileIcons.filter,
					width: "16",
					height: "16",
					alt: ""
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 712
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 551
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 25,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV(Hero, { featured: query.data?.featured }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "catalog-layout",
			id: "catalog",
			"aria-label": "Catálogo de NFTs",
			children: [/* @__PURE__ */ _jsxDEV("aside", {
				className: "catalog-sidebar",
				children: [/* @__PURE__ */ _jsxDEV(Filters, {
					search,
					facets: query.data?.facets,
					change
				}, `${search.minPrice}:${search.maxPrice}`, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 42
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "featured-banner",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "NFT EM DESTAQUE" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 192
						}, this),
						/* @__PURE__ */ _jsxDEV("h3", { children: "OFERTA LIMITADA" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 216
						}, this),
						/* @__PURE__ */ _jsxDEV("a", {
							href: "/nfts/sage-009",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: "/assets/optimized/83794-900.webp",
								alt: "Sage Nomad em destaque",
								width: "310",
								height: "368"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 28,
								columnNumber: 265
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 240
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 159
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "catalog-results",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "catalog-toolbar",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "catalog-tabs",
						"aria-label": "Categorias do catálogo",
						children: [
							["all", "Todos os NFTs"],
							["new", "Novos lançamentos"],
							["trending", "Em alta"]
						].map(([value, label]) => /* @__PURE__ */ _jsxDEV("button", {
							"aria-pressed": search.tab === value,
							className: search.tab === value ? "selected" : "",
							onClick: () => change({ tab: value }),
							children: label
						}, value, false, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 246
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 73
					}, this), /* @__PURE__ */ _jsxDEV("label", {
						className: "sort-control",
						children: ["Ordenar por:", /* @__PURE__ */ _jsxDEV("select", {
							"aria-label": "Ordenar NFTs",
							value: search.sort,
							onChange: (e) => change({ sort: e.target.value }),
							children: [
								/* @__PURE__ */ _jsxDEV("option", {
									value: "recent",
									children: "Listados recentemente"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 29,
									columnNumber: 614
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "price-asc",
									children: "Menor preço"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 29,
									columnNumber: 667
								}, this),
								/* @__PURE__ */ _jsxDEV("option", {
									value: "price-desc",
									children: "Maior preço"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 29,
									columnNumber: 713
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 484
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 440
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 40
				}, this), query.isPending ? /* @__PURE__ */ _jsxDEV("div", {
					role: "status",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "sr-only",
						children: "Carregando catálogo"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 47
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "nft-grid",
						children: Array.from({ length: 9 }, (_, i) => /* @__PURE__ */ _jsxDEV("div", {
							className: "nft-card",
							children: [
								/* @__PURE__ */ _jsxDEV(Skeleton, { className: "card-art proof-skeleton" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 30,
									columnNumber: 196
								}, this),
								/* @__PURE__ */ _jsxDEV(Skeleton, { className: "proof-skeleton mt-3 h-5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 30,
									columnNumber: 244
								}, this),
								/* @__PURE__ */ _jsxDEV(Skeleton, { className: "proof-skeleton mt-2 h-5 w-1/2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 30,
									columnNumber: 292
								}, this)
							]
						}, i, true, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 162
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 99
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 28
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [query.isError && /* @__PURE__ */ _jsxDEV("div", {
					className: "query-error",
					role: "alert",
					children: [/* @__PURE__ */ _jsxDEV("p", { children: "Não foi possível carregar o catálogo." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 71
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						onClick: () => void query.refetch(),
						children: "Tentar novamente"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 31,
						columnNumber: 115
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 29
				}, this), query.data && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					query.isFetching && /* @__PURE__ */ _jsxDEV("p", {
						role: "status",
						className: "background-loading",
						children: "Atualizando catálogo…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 49
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "sr-only",
						role: "status",
						children: [query.data.total, " NFTs encontrados"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 123
					}, this),
					query.data.items.length ? /* @__PURE__ */ _jsxDEV("div", {
						className: "nft-grid",
						children: query.data.items.map((nft) => /* @__PURE__ */ _jsxDEV(NftCard, { nft }, nft.id, false, {
							fileName: _jsxFileName,
							lineNumber: 32,
							columnNumber: 283
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 226
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "empty-state",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: "Nenhum NFT encontrado" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 357
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Experimente outros filtros ou uma nova busca." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 387
							}, this),
							/* @__PURE__ */ _jsxDEV(Button, {
								onClick: () => change({
									q: "",
									collections: [],
									networks: [],
									minPrice: "0.02",
									maxPrice: "12.30",
									tab: "all"
								}),
								children: "Limpar busca e filtros"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 32,
								columnNumber: 439
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 32,
						columnNumber: 328
					}, this),
					/* @__PURE__ */ _jsxDEV("nav", {
						className: "pagination",
						"aria-label": "Paginação",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								disabled: search.page <= 1,
								"aria-label": "Página anterior",
								onClick: () => change({ page: search.page - 1 }),
								children: "‹"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 62
							}, this),
							Array.from({ length: query.data.pages }, (_, i) => /* @__PURE__ */ _jsxDEV("button", {
								"aria-label": `Página ${i + 1}`,
								"aria-current": search.page === i + 1 ? "page" : undefined,
								onClick: () => change({ page: i + 1 }),
								children: i + 1
							}, i, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 239
							}, this)),
							/* @__PURE__ */ _jsxDEV("button", {
								disabled: search.page >= query.data.pages,
								"aria-label": "Próxima página",
								onClick: () => change({ page: search.page + 1 }),
								children: "›"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 33,
								columnNumber: 402
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 11
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 26
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 369
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 29,
				columnNumber: 7
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV(Modal, {
			title: "Filtros de NFTs",
			open: filterOpen,
			onClose: () => setFilterOpen(false),
			children: [/* @__PURE__ */ _jsxDEV(Filters, {
				search,
				facets: query.data?.facets,
				change
			}, `${search.minPrice}:${search.maxPrice}`, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 91
			}, this), /* @__PURE__ */ _jsxDEV(Button, {
				onClick: () => setFilterOpen(false),
				children: "Ver resultados"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 208
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 5
		}, this),
		/* @__PURE__ */ _jsxDEV(HomeSections, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 5
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 10
	}, this);
}
_s(CatalogPage, "JqzbltISlI4d8ka5puml+cz4/YM=", false, function() {
	return [
		useSearch,
		useNavigate,
		useQuery,
		useLocation
	];
});
_c = CatalogPage;
var _c;
$RefreshReg$(_c, "CatalogPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/catalog/CatalogPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/catalog/CatalogPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxpQkFBaUIsZ0JBQWdCO0FBQzFDLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsYUFBYSxhQUFhLGlCQUFpQjtBQUNwRCxTQUFTLFFBQVEseUJBQXlCO0FBQzFDLFNBQVMsYUFBYTtBQUN0QixTQUFTLGNBQWM7QUFDdkIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxzQkFBc0I7QUFFL0IsU0FBUyw2QkFBNkI7QUFDdEMsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZUFBZTtBQUN4QixTQUFTLE1BQU0sb0JBQW9CO0FBQ25DLFNBQVMsdUJBQXVCOzs7O0FBRWhDLE9BQU8sU0FBUyxjQUFjOztDQUM1QixNQUFNLFNBQVMsc0JBQXNCLFVBQVUsRUFBRSxRQUFRLE1BQU0sQ0FBQyxDQUFDLEdBQUcsV0FBVyxZQUFZLEVBQUUsTUFBTSxJQUFJLENBQUM7Q0FDeEcsTUFBTSxRQUFRLFNBQVMsZUFBZSxNQUFNLENBQUM7Q0FDN0MsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsS0FBSztDQUNsRCxNQUFNLFdBQVcsWUFBWTtDQUM3QixzQkFBc0I7RUFBRSxJQUFJLFNBQVMsYUFBYSxPQUFPLFNBQVMsU0FBUyxXQUFXLGdCQUFnQjtDQUFFLEdBQUcsQ0FBQyxTQUFTLFVBQVUsU0FBUyxJQUFJLENBQUM7Q0FDN0ksTUFBTSxVQUFVLFVBQWtDO0VBQUUsS0FBSyxTQUFTLEVBQUUsUUFBUTtHQUFFLEdBQUc7R0FBUSxHQUFHO0dBQU8sTUFBTSxNQUFNLFFBQVE7RUFBRSxFQUFFLENBQUM7Q0FBRTtDQUM5SCxPQUFPLHdCQUFDLFFBQUQ7RUFDTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQW9DLHdCQUFDLFFBQUQ7SUFBcUIsV0FBVyxNQUFNO0tBQUUsRUFBRSxlQUFlO0tBQUcsT0FBTyxFQUFFLEdBQUcsT0FBTyxJQUFJLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQyxJQUFJLEdBQUcsS0FBSyxFQUFFLEVBQUUsQ0FBQztJQUFFO2NBQWhJO0tBQW1JLHdCQUFDLFFBQUQ7TUFBUSxXQUFVO01BQXVCLE1BQU07S0FBSzs7Ozs7S0FBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtNQUF5QixLQUFLLFlBQVk7TUFBUSxPQUFNO01BQUssUUFBTztNQUFLLEtBQUk7S0FBSTs7Ozs7S0FBQyx3QkFBQyxTQUFEO01BQU8sV0FBVTtNQUFVLFNBQVE7Z0JBQWlCO0tBQWtCOzs7OztLQUFDLHdCQUFDLFNBQUQ7TUFBTyxJQUFHO01BQWlCLE1BQUs7TUFBSSxjQUFjLE9BQU87TUFBRyxhQUFZO0tBQXFCOzs7OztLQUFDLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQVUsTUFBSztnQkFBUztLQUFjOzs7OztJQUFPO01BQWxmLE9BQU87Ozs7VUFBMmUsR0FBQyx3QkFBQyxVQUFEO0lBQVEsV0FBVTtJQUFnQixjQUFXO0lBQWdCLGVBQWUsY0FBYyxJQUFJO2NBQTlGLENBQWlHLHdCQUFDLG1CQUFEO0tBQW1CLFdBQVU7S0FBdUIsTUFBTTtJQUFLOzs7O2NBQUMsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBeUIsS0FBSyxZQUFZO0tBQVEsT0FBTTtLQUFLLFFBQU87S0FBSyxLQUFJO0lBQUk7Ozs7WUFBUzs7Ozs7V0FBTTs7Ozs7O0VBQ2x6Qix3QkFBQyxNQUFELEVBQU0sVUFBVSxNQUFNLE1BQU0sU0FBVzs7Ozs7RUFDdkMsd0JBQUMsV0FBRDtHQUFTLFdBQVU7R0FBaUIsSUFBRztHQUFVLGNBQVc7YUFBNUQsQ0FDRSx3QkFBQyxTQUFEO0lBQU8sV0FBVTtjQUFqQixDQUFtQyx3QkFBQyxTQUFEO0tBQStEO0tBQVEsUUFBUSxNQUFNLE1BQU07S0FBZ0I7SUFBUyxHQUF0RyxHQUFHLE9BQU8sU0FBUyxHQUFHLE9BQU87Ozs7V0FBeUUsR0FBQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQWlDLHdCQUFDLE1BQUQsWUFBSSxrQkFBbUI7Ozs7O01BQUMsd0JBQUMsTUFBRCxZQUFJLGtCQUFtQjs7Ozs7TUFBQyx3QkFBQyxLQUFEO09BQUcsTUFBSztpQkFBaUIsd0JBQUMsT0FBRDtRQUFLLEtBQUk7UUFBbUMsS0FBSTtRQUF5QixPQUFNO1FBQU0sUUFBTztPQUFPOzs7OztNQUFJOzs7OztLQUFNOzs7OztZQUFROzs7OzthQUN2WCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQWlDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FBaUMsd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBZSxjQUFXO2dCQUEwQjtPQUFDLENBQUMsT0FBTyxlQUFlO09BQUcsQ0FBQyxPQUFPLG1CQUFtQjtPQUFHLENBQUMsWUFBWSxTQUFTO01BQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLFdBQVcsd0JBQUMsVUFBRDtPQUFvQixnQkFBYyxPQUFPLFFBQVE7T0FBTyxXQUFXLE9BQU8sUUFBUSxRQUFRLGFBQWE7T0FBSSxlQUFlLE9BQU8sRUFBRSxLQUFLLE1BQThCLENBQUM7aUJBQUk7TUFBYyxHQUE1Szs7OzthQUE0SyxDQUFDO0tBQU87Ozs7ZUFBQyx3QkFBQyxTQUFEO01BQU8sV0FBVTtnQkFBakIsQ0FBZ0MsZ0JBQVksd0JBQUMsVUFBRDtPQUFRLGNBQVc7T0FBZSxPQUFPLE9BQU87T0FBTSxXQUFXLE1BQU0sT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLE1BQStCLENBQUM7aUJBQS9IO1FBQWtJLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFTO1FBQTZCOzs7OztRQUFDLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFZO1FBQW1COzs7OztRQUFDLHdCQUFDLFVBQUQ7U0FBUSxPQUFNO21CQUFhO1FBQW1COzs7OztPQUFTOzs7OztjQUFROzs7OzthQUFNOzs7OztjQUNwd0IsTUFBTSxZQUFZLHdCQUFDLE9BQUQ7S0FBSyxNQUFLO2VBQVYsQ0FBbUIsd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVU7S0FBeUI7Ozs7ZUFBQyx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBWSxNQUFNLEtBQUssRUFBRSxRQUFRLEVBQUUsSUFBSSxHQUFHLE1BQU0sd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFBa0Msd0JBQUMsVUFBRCxFQUFVLFdBQVUsMEJBQTJCOzs7OztRQUFDLHdCQUFDLFVBQUQsRUFBVSxXQUFVLDBCQUEyQjs7Ozs7UUFBQyx3QkFBQyxVQUFELEVBQVUsV0FBVSxnQ0FBaUM7Ozs7O09BQU07U0FBOUo7Ozs7YUFBOEosQ0FBQztLQUFPOzs7O2FBQU07Ozs7O2VBQUksZ0RBQ3JXLE1BQU0sV0FBVyx3QkFBQyxPQUFEO0tBQUssV0FBVTtLQUFjLE1BQUs7ZUFBbEMsQ0FBMEMsd0JBQUMsS0FBRCxZQUFHLHdDQUF3Qzs7OztlQUFDLHdCQUFDLFFBQUQ7TUFBUSxlQUFlLEtBQUssTUFBTSxRQUFRO2dCQUFHO0tBQXdCOzs7O2FBQU07Ozs7O2NBQ2xMLE1BQU0sUUFBUTtLQUFHLE1BQU0sY0FBYyx3QkFBQyxLQUFEO01BQUcsTUFBSztNQUFTLFdBQVU7Z0JBQXFCO0tBQXdCOzs7OztLQUFFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO01BQVUsTUFBSztnQkFBNUIsQ0FBc0MsTUFBTSxLQUFLLE9BQU0sbUJBQW9COzs7Ozs7S0FBRSxNQUFNLEtBQUssTUFBTSxTQUFTLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFZLE1BQU0sS0FBSyxNQUFNLEtBQUssUUFBUSx3QkFBQyxTQUFELEVBQWMsSUFBbUIsR0FBVCxJQUFJOzs7O2FBQUssQ0FBQztLQUFPOzs7O2dCQUFJLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQTZCLHdCQUFDLE1BQUQsWUFBSSx3QkFBeUI7Ozs7O09BQUMsd0JBQUMsS0FBRCxZQUFHLGdEQUFnRDs7Ozs7T0FBQyx3QkFBQyxRQUFEO1FBQVEsZUFBZSxPQUFPO1NBQUUsR0FBRztTQUFJLGFBQWEsQ0FBQztTQUFHLFVBQVUsQ0FBQztTQUFHLFVBQVU7U0FBUSxVQUFVO1NBQVMsS0FBSztRQUFNLENBQUM7a0JBQUc7T0FBOEI7Ozs7O01BQU07Ozs7OztLQUMxa0Isd0JBQUMsT0FBRDtNQUFLLFdBQVU7TUFBYSxjQUFXO2dCQUF2QztPQUFtRCx3QkFBQyxVQUFEO1FBQVEsVUFBVSxPQUFPLFFBQVE7UUFBRyxjQUFXO1FBQWtCLGVBQWUsT0FBTyxFQUFFLE1BQU0sT0FBTyxPQUFPLEVBQUUsQ0FBQztrQkFBRztPQUFTOzs7OztPQUFFLE1BQU0sS0FBSyxFQUFFLFFBQVEsTUFBTSxLQUFLLE1BQU0sSUFBSSxHQUFHLE1BQU0sd0JBQUMsVUFBRDtRQUFnQixjQUFZLFVBQVUsSUFBSTtRQUFLLGdCQUFjLE9BQU8sU0FBUyxJQUFJLElBQUksU0FBUztRQUFXLGVBQWUsT0FBTyxFQUFFLE1BQU0sSUFBSSxFQUFFLENBQUM7a0JBQUksSUFBSTtPQUFVLEdBQW5KOzs7O2NBQW1KLENBQUM7T0FBRSx3QkFBQyxVQUFEO1FBQVEsVUFBVSxPQUFPLFFBQVEsTUFBTSxLQUFLO1FBQU8sY0FBVztRQUFpQixlQUFlLE9BQU8sRUFBRSxNQUFNLE9BQU8sT0FBTyxFQUFFLENBQUM7a0JBQUc7T0FBUzs7Ozs7TUFBTTs7Ozs7O0lBQUc7Ozs7WUFDMWhCOzs7O1lBQ0M7Ozs7O1dBQ0U7Ozs7OztFQUNULHdCQUFDLE9BQUQ7R0FBTyxPQUFNO0dBQWtCLE1BQU07R0FBWSxlQUFlLGNBQWMsS0FBSzthQUFuRixDQUFzRix3QkFBQyxTQUFEO0lBQStEO0lBQVEsUUFBUSxNQUFNLE1BQU07SUFBZ0I7R0FBUyxHQUF0RyxHQUFHLE9BQU8sU0FBUyxHQUFHLE9BQU87Ozs7VUFBeUUsR0FBQyx3QkFBQyxRQUFEO0lBQVEsZUFBZSxjQUFjLEtBQUs7Y0FBRztHQUFzQjs7OztXQUFROzs7Ozs7RUFDdFIsd0JBQUMsY0FBRCxDQUFlOzs7OztDQUNYOzs7OztBQUNSIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhdGFsb2dQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtb2JpbGVJY29ucyB9IGZyb20gJ0Avc2hhcmVkL3VpL21vYmlsZS1pY29ucydcclxuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VRdWVyeSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24sIHVzZU5hdmlnYXRlLCB1c2VTZWFyY2ggfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xyXG5pbXBvcnQgeyBTZWFyY2gsIFNsaWRlcnNIb3Jpem9udGFsIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xyXG5pbXBvcnQgeyBNb2RhbCB9IGZyb20gJ0Avc2hhcmVkL3VpL21vZGFsJ1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL3NoYXJlZC91aS9idXR0b24nXHJcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9zaGFyZWQvdWkvc2tlbGV0b24nXHJcbmltcG9ydCB7IGNhdGFsb2dPcHRpb25zIH0gZnJvbSAnLi9hcGknXHJcbmltcG9ydCB0eXBlIHsgQ2F0YWxvZ1NlYXJjaCB9IGZyb20gJy4vY29udHJhY3RzJ1xyXG5pbXBvcnQgeyB2YWxpZGF0ZUNhdGFsb2dTZWFyY2ggfSBmcm9tICcuL2NvbnRyYWN0cydcclxuaW1wb3J0IHsgRmlsdGVycyB9IGZyb20gJy4vRmlsdGVycydcclxuaW1wb3J0IHsgTmZ0Q2FyZCB9IGZyb20gJy4vTmZ0Q2FyZCdcclxuaW1wb3J0IHsgSGVybywgSG9tZVNlY3Rpb25zIH0gZnJvbSAnLi9Ib21lU2VjdGlvbnMnXHJcbmltcG9ydCB7IHNjcm9sbFRvQ2F0YWxvZyB9IGZyb20gJy4vQ2F0YWxvZ0xpbmsnXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQ2F0YWxvZ1BhZ2UoKSB7XHJcbiAgY29uc3Qgc2VhcmNoID0gdmFsaWRhdGVDYXRhbG9nU2VhcmNoKHVzZVNlYXJjaCh7IHN0cmljdDogZmFsc2UgfSkpLCBuYXZpZ2F0ZSA9IHVzZU5hdmlnYXRlKHsgZnJvbTogJy8nIH0pXHJcbiAgY29uc3QgcXVlcnkgPSB1c2VRdWVyeShjYXRhbG9nT3B0aW9ucyhzZWFyY2gpKVxyXG4gIGNvbnN0IFtmaWx0ZXJPcGVuLCBzZXRGaWx0ZXJPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKVxyXG4gIHVzZUxheW91dEVmZmVjdCgoKSA9PiB7IGlmIChsb2NhdGlvbi5wYXRobmFtZSA9PT0gJy8nICYmIGxvY2F0aW9uLmhhc2ggPT09ICdjYXRhbG9nJykgc2Nyb2xsVG9DYXRhbG9nKCkgfSwgW2xvY2F0aW9uLnBhdGhuYW1lLCBsb2NhdGlvbi5oYXNoXSlcclxuICBjb25zdCBjaGFuZ2UgPSAocGF0Y2g6IFBhcnRpYWw8Q2F0YWxvZ1NlYXJjaD4pID0+IHsgdm9pZCBuYXZpZ2F0ZSh7IHNlYXJjaDogeyAuLi5zZWFyY2gsIC4uLnBhdGNoLCBwYWdlOiBwYXRjaC5wYWdlID8/IDEgfSB9KSB9XHJcbiAgcmV0dXJuIDxtYWluPlxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJjYXRhbG9nLXNlYXJjaC1yb3dcIj48Zm9ybSBrZXk9e3NlYXJjaC5xfSBvblN1Ym1pdD17KGUpID0+IHsgZS5wcmV2ZW50RGVmYXVsdCgpOyBjaGFuZ2UoeyBxOiBTdHJpbmcobmV3IEZvcm1EYXRhKGUuY3VycmVudFRhcmdldCkuZ2V0KCdxJykgPz8gJycpIH0pIH19PjxTZWFyY2ggY2xhc3NOYW1lPVwiY2F0YWxvZy1pY29uLWRlZmF1bHRcIiBzaXplPXsyMn0gLz48aW1nIGNsYXNzTmFtZT1cImNhdGFsb2ctaWNvbi1yZWZlcmVuY2VcIiBzcmM9e21vYmlsZUljb25zLnNlYXJjaH0gd2lkdGg9XCIyMlwiIGhlaWdodD1cIjIyXCIgYWx0PVwiXCIgLz48bGFiZWwgY2xhc3NOYW1lPVwic3Itb25seVwiIGh0bWxGb3I9XCJjYXRhbG9nLXNlYXJjaFwiPkJ1c2NhciBORlRzPC9sYWJlbD48aW5wdXQgaWQ9XCJjYXRhbG9nLXNlYXJjaFwiIG5hbWU9XCJxXCIgZGVmYXVsdFZhbHVlPXtzZWFyY2gucX0gcGxhY2Vob2xkZXI9XCJFeHBsb3JhciBjb2xlw6fDtWVzXCIgLz48YnV0dG9uIGNsYXNzTmFtZT1cInNyLW9ubHlcIiB0eXBlPVwic3VibWl0XCI+QnVzY2FyPC9idXR0b24+PC9mb3JtPjxidXR0b24gY2xhc3NOYW1lPVwiZmlsdGVyLXRvZ2dsZVwiIGFyaWEtbGFiZWw9XCJBYnJpciBmaWx0cm9zXCIgb25DbGljaz17KCkgPT4gc2V0RmlsdGVyT3Blbih0cnVlKX0+PFNsaWRlcnNIb3Jpem9udGFsIGNsYXNzTmFtZT1cImNhdGFsb2ctaWNvbi1kZWZhdWx0XCIgc2l6ZT17MjJ9IC8+PGltZyBjbGFzc05hbWU9XCJjYXRhbG9nLWljb24tcmVmZXJlbmNlXCIgc3JjPXttb2JpbGVJY29ucy5maWx0ZXJ9IHdpZHRoPVwiMTZcIiBoZWlnaHQ9XCIxNlwiIGFsdD1cIlwiIC8+PC9idXR0b24+PC9kaXY+XHJcbiAgICA8SGVybyBmZWF0dXJlZD17cXVlcnkuZGF0YT8uZmVhdHVyZWR9IC8+XHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJjYXRhbG9nLWxheW91dFwiIGlkPVwiY2F0YWxvZ1wiIGFyaWEtbGFiZWw9XCJDYXTDoWxvZ28gZGUgTkZUc1wiPlxyXG4gICAgICA8YXNpZGUgY2xhc3NOYW1lPVwiY2F0YWxvZy1zaWRlYmFyXCI+PEZpbHRlcnMga2V5PXtgJHtzZWFyY2gubWluUHJpY2V9OiR7c2VhcmNoLm1heFByaWNlfWB9IHNlYXJjaD17c2VhcmNofSBmYWNldHM9e3F1ZXJ5LmRhdGE/LmZhY2V0c30gY2hhbmdlPXtjaGFuZ2V9IC8+PGRpdiBjbGFzc05hbWU9XCJmZWF0dXJlZC1iYW5uZXJcIj48aDI+TkZUIEVNIERFU1RBUVVFPC9oMj48aDM+T0ZFUlRBIExJTUlUQURBPC9oMz48YSBocmVmPVwiL25mdHMvc2FnZS0wMDlcIj48aW1nIHNyYz1cIi9hc3NldHMvb3B0aW1pemVkLzgzNzk0LTkwMC53ZWJwXCIgYWx0PVwiU2FnZSBOb21hZCBlbSBkZXN0YXF1ZVwiIHdpZHRoPVwiMzEwXCIgaGVpZ2h0PVwiMzY4XCIgLz48L2E+PC9kaXY+PC9hc2lkZT5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXRhbG9nLXJlc3VsdHNcIj48ZGl2IGNsYXNzTmFtZT1cImNhdGFsb2ctdG9vbGJhclwiPjxkaXYgY2xhc3NOYW1lPVwiY2F0YWxvZy10YWJzXCIgYXJpYS1sYWJlbD1cIkNhdGVnb3JpYXMgZG8gY2F0w6Fsb2dvXCI+e1tbJ2FsbCcsICdUb2RvcyBvcyBORlRzJ10sIFsnbmV3JywgJ05vdm9zIGxhbsOnYW1lbnRvcyddLCBbJ3RyZW5kaW5nJywgJ0VtIGFsdGEnXV0ubWFwKChbdmFsdWUsIGxhYmVsXSkgPT4gPGJ1dHRvbiBrZXk9e3ZhbHVlfSBhcmlhLXByZXNzZWQ9e3NlYXJjaC50YWIgPT09IHZhbHVlfSBjbGFzc05hbWU9e3NlYXJjaC50YWIgPT09IHZhbHVlID8gJ3NlbGVjdGVkJyA6ICcnfSBvbkNsaWNrPXsoKSA9PiBjaGFuZ2UoeyB0YWI6IHZhbHVlIGFzIENhdGFsb2dTZWFyY2hbJ3RhYiddIH0pfT57bGFiZWx9PC9idXR0b24+KX08L2Rpdj48bGFiZWwgY2xhc3NOYW1lPVwic29ydC1jb250cm9sXCI+T3JkZW5hciBwb3I6PHNlbGVjdCBhcmlhLWxhYmVsPVwiT3JkZW5hciBORlRzXCIgdmFsdWU9e3NlYXJjaC5zb3J0fSBvbkNoYW5nZT17KGUpID0+IGNoYW5nZSh7IHNvcnQ6IGUudGFyZ2V0LnZhbHVlIGFzIENhdGFsb2dTZWFyY2hbJ3NvcnQnXSB9KX0+PG9wdGlvbiB2YWx1ZT1cInJlY2VudFwiPkxpc3RhZG9zIHJlY2VudGVtZW50ZTwvb3B0aW9uPjxvcHRpb24gdmFsdWU9XCJwcmljZS1hc2NcIj5NZW5vciBwcmXDp288L29wdGlvbj48b3B0aW9uIHZhbHVlPVwicHJpY2UtZGVzY1wiPk1haW9yIHByZcOnbzwvb3B0aW9uPjwvc2VsZWN0PjwvbGFiZWw+PC9kaXY+XHJcbiAgICAgICAge3F1ZXJ5LmlzUGVuZGluZyA/IDxkaXYgcm9sZT1cInN0YXR1c1wiPjxzcGFuIGNsYXNzTmFtZT1cInNyLW9ubHlcIj5DYXJyZWdhbmRvIGNhdMOhbG9nbzwvc3Bhbj48ZGl2IGNsYXNzTmFtZT1cIm5mdC1ncmlkXCI+e0FycmF5LmZyb20oeyBsZW5ndGg6IDkgfSwgKF8sIGkpID0+IDxkaXYgY2xhc3NOYW1lPVwibmZ0LWNhcmRcIiBrZXk9e2l9PjxTa2VsZXRvbiBjbGFzc05hbWU9XCJjYXJkLWFydCBwcm9vZi1za2VsZXRvblwiIC8+PFNrZWxldG9uIGNsYXNzTmFtZT1cInByb29mLXNrZWxldG9uIG10LTMgaC01XCIgLz48U2tlbGV0b24gY2xhc3NOYW1lPVwicHJvb2Ytc2tlbGV0b24gbXQtMiBoLTUgdy0xLzJcIiAvPjwvZGl2Pil9PC9kaXY+PC9kaXY+IDogPD5cclxuICAgICAgICAgIHtxdWVyeS5pc0Vycm9yICYmIDxkaXYgY2xhc3NOYW1lPVwicXVlcnktZXJyb3JcIiByb2xlPVwiYWxlcnRcIj48cD5Ow6NvIGZvaSBwb3Nzw612ZWwgY2FycmVnYXIgbyBjYXTDoWxvZ28uPC9wPjxCdXR0b24gb25DbGljaz17KCkgPT4gdm9pZCBxdWVyeS5yZWZldGNoKCl9PlRlbnRhciBub3ZhbWVudGU8L0J1dHRvbj48L2Rpdj59XHJcbiAgICAgICAgICB7cXVlcnkuZGF0YSAmJiA8PntxdWVyeS5pc0ZldGNoaW5nICYmIDxwIHJvbGU9XCJzdGF0dXNcIiBjbGFzc05hbWU9XCJiYWNrZ3JvdW5kLWxvYWRpbmdcIj5BdHVhbGl6YW5kbyBjYXTDoWxvZ2/igKY8L3A+fTxwIGNsYXNzTmFtZT1cInNyLW9ubHlcIiByb2xlPVwic3RhdHVzXCI+e3F1ZXJ5LmRhdGEudG90YWx9IE5GVHMgZW5jb250cmFkb3M8L3A+e3F1ZXJ5LmRhdGEuaXRlbXMubGVuZ3RoID8gPGRpdiBjbGFzc05hbWU9XCJuZnQtZ3JpZFwiPntxdWVyeS5kYXRhLml0ZW1zLm1hcCgobmZ0KSA9PiA8TmZ0Q2FyZCBuZnQ9e25mdH0ga2V5PXtuZnQuaWR9IC8+KX08L2Rpdj4gOiA8ZGl2IGNsYXNzTmFtZT1cImVtcHR5LXN0YXRlXCI+PGgyPk5lbmh1bSBORlQgZW5jb250cmFkbzwvaDI+PHA+RXhwZXJpbWVudGUgb3V0cm9zIGZpbHRyb3Mgb3UgdW1hIG5vdmEgYnVzY2EuPC9wPjxCdXR0b24gb25DbGljaz17KCkgPT4gY2hhbmdlKHsgcTogJycsIGNvbGxlY3Rpb25zOiBbXSwgbmV0d29ya3M6IFtdLCBtaW5QcmljZTogJzAuMDInLCBtYXhQcmljZTogJzEyLjMwJywgdGFiOiAnYWxsJyB9KX0+TGltcGFyIGJ1c2NhIGUgZmlsdHJvczwvQnV0dG9uPjwvZGl2Pn1cclxuICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwicGFnaW5hdGlvblwiIGFyaWEtbGFiZWw9XCJQYWdpbmHDp8Ojb1wiPjxidXR0b24gZGlzYWJsZWQ9e3NlYXJjaC5wYWdlIDw9IDF9IGFyaWEtbGFiZWw9XCJQw6FnaW5hIGFudGVyaW9yXCIgb25DbGljaz17KCkgPT4gY2hhbmdlKHsgcGFnZTogc2VhcmNoLnBhZ2UgLSAxIH0pfT7igLk8L2J1dHRvbj57QXJyYXkuZnJvbSh7IGxlbmd0aDogcXVlcnkuZGF0YS5wYWdlcyB9LCAoXywgaSkgPT4gPGJ1dHRvbiBrZXk9e2l9IGFyaWEtbGFiZWw9e2BQw6FnaW5hICR7aSArIDF9YH0gYXJpYS1jdXJyZW50PXtzZWFyY2gucGFnZSA9PT0gaSArIDEgPyAncGFnZScgOiB1bmRlZmluZWR9IG9uQ2xpY2s9eygpID0+IGNoYW5nZSh7IHBhZ2U6IGkgKyAxIH0pfT57aSArIDF9PC9idXR0b24+KX08YnV0dG9uIGRpc2FibGVkPXtzZWFyY2gucGFnZSA+PSBxdWVyeS5kYXRhLnBhZ2VzfSBhcmlhLWxhYmVsPVwiUHLDs3hpbWEgcMOhZ2luYVwiIG9uQ2xpY2s9eygpID0+IGNoYW5nZSh7IHBhZ2U6IHNlYXJjaC5wYWdlICsgMSB9KX0+4oC6PC9idXR0b24+PC9uYXY+PC8+fVxyXG4gICAgICAgIDwvPn1cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgICA8TW9kYWwgdGl0bGU9XCJGaWx0cm9zIGRlIE5GVHNcIiBvcGVuPXtmaWx0ZXJPcGVufSBvbkNsb3NlPXsoKSA9PiBzZXRGaWx0ZXJPcGVuKGZhbHNlKX0+PEZpbHRlcnMga2V5PXtgJHtzZWFyY2gubWluUHJpY2V9OiR7c2VhcmNoLm1heFByaWNlfWB9IHNlYXJjaD17c2VhcmNofSBmYWNldHM9e3F1ZXJ5LmRhdGE/LmZhY2V0c30gY2hhbmdlPXtjaGFuZ2V9IC8+PEJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRGaWx0ZXJPcGVuKGZhbHNlKX0+VmVyIHJlc3VsdGFkb3M8L0J1dHRvbj48L01vZGFsPlxyXG4gICAgPEhvbWVTZWN0aW9ucyAvPlxyXG4gIDwvbWFpbj5cclxufVxyXG4iXX0=