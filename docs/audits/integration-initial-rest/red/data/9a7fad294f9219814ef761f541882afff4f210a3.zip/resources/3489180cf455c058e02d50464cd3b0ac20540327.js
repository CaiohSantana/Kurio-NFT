import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/CartLink.tsx");const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import { mobileIcons } from "/src/shared/ui/mobile-icons.ts";
import { useQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=b034412f";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=8002d6fe";
import { ShoppingCart } from "/node_modules/.vite/deps/lucide-react.js?v=643d2d14";
import { useSession } from "/src/features/auth/session.tsx";
import { cartOptions } from "/src/features/cart/api.ts";
import { useCatalogDestination } from "/src/features/catalog/CatalogLink.tsx";
var _jsxFileName = "C:/Users/caiod/Desktop/Kurio NFT/src/features/cart/CartLink.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=4f1d3af0";
var _s = $RefreshSig$();
export function CartLink({ size = 24 }) {
	_s();
	const session = useSession(), query = useQuery(cartOptions(session.scope));
	const search = useCatalogDestination();
	const count = query.data?.items.reduce((sum, item) => sum + item.quantity, 0);
	return /* @__PURE__ */ _jsxDEV(Link, {
		to: "/cart",
		state: { catalogSearch: search },
		className: "cart-nav-link",
		"aria-label": count === undefined ? "Carrinho, consultando quantidade" : `Carrinho, ${count} ${count === 1 ? "item" : "itens"}`,
		children: [
			/* @__PURE__ */ _jsxDEV(ShoppingCart, {
				className: "cart-icon-default",
				size
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 214
			}, this),
			/* @__PURE__ */ _jsxDEV("img", {
				className: "cart-icon-reference",
				src: mobileIcons.cart,
				width: "20",
				height: "20",
				alt: ""
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 272
			}, this),
			/* @__PURE__ */ _jsxDEV("span", {
				"aria-hidden": "true",
				className: "cart-badge",
				"data-testid": "cart-badge",
				children: count ?? "…"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 364
			}, this),
			query.isError && /* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: "Falha ao consultar quantidade"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 476
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 10
	}, this);
}
_s(CartLink, "5UKSGgORBhmj7ErdsgWQ36I0GB8=", false, function() {
	return [
		useSession,
		useQuery,
		useCatalogDestination
	];
});
_c = CartLink;
var _c;
$RefreshReg$(_c, "CartLink");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/features/cart/CartLink.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/caiod/Desktop/Kurio NFT/src/features/cart/CartLink.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/caiod/Desktop/Kurio NFT/src/features/cart/CartLink.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/caiod/Desktop/Kurio NFT/src/features/cart/CartLink.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsb0JBQW9CO0FBQzdCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsNkJBQTZCOzs7O0FBQ3RDLE9BQU8sU0FBUyxTQUFTLEVBQUUsT0FBTyxNQUF5Qjs7Q0FDekQsTUFBTSxVQUFVLFdBQVcsR0FBRyxRQUFRLFNBQVMsWUFBWSxRQUFRLEtBQUssQ0FBQztDQUN6RSxNQUFNLFNBQVMsc0JBQXNCO0NBQ3JDLE1BQU0sUUFBUSxNQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssU0FBUyxNQUFNLEtBQUssVUFBVSxDQUFDO0NBQzVFLE9BQU8sd0JBQUMsTUFBRDtFQUFNLElBQUc7RUFBUSxPQUFPLEVBQUUsZUFBZSxPQUFPO0VBQUcsV0FBVTtFQUFnQixjQUFZLFVBQVUsWUFBWSxxQ0FBcUMsYUFBYSxNQUFNLEdBQUcsVUFBVSxJQUFJLFNBQVM7WUFBak07R0FBNE0sd0JBQUMsY0FBRDtJQUFjLFdBQVU7SUFBMEI7R0FBTzs7Ozs7R0FBQyx3QkFBQyxPQUFEO0lBQUssV0FBVTtJQUFzQixLQUFLLFlBQVk7SUFBTSxPQUFNO0lBQUssUUFBTztJQUFLLEtBQUk7R0FBSTs7Ozs7R0FBQyx3QkFBQyxRQUFEO0lBQU0sZUFBWTtJQUFPLFdBQVU7SUFBYSxlQUFZO2NBQWMsU0FBUztHQUFVOzs7OztHQUFFLE1BQU0sV0FBVyx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFVO0dBQW1DOzs7OztFQUFROzs7Ozs7QUFDaGlCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNhcnRMaW5rLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBtb2JpbGVJY29ucyB9IGZyb20gJ0Avc2hhcmVkL3VpL21vYmlsZS1pY29ucydcclxuaW1wb3J0IHsgdXNlUXVlcnkgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXHJcbmltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xyXG5pbXBvcnQgeyBTaG9wcGluZ0NhcnQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXHJcbmltcG9ydCB7IHVzZVNlc3Npb24gfSBmcm9tICdAL2ZlYXR1cmVzL2F1dGgvc2Vzc2lvbidcclxuaW1wb3J0IHsgY2FydE9wdGlvbnMgfSBmcm9tICcuL2FwaSdcclxuaW1wb3J0IHsgdXNlQ2F0YWxvZ0Rlc3RpbmF0aW9uIH0gZnJvbSAnQC9mZWF0dXJlcy9jYXRhbG9nL0NhdGFsb2dMaW5rJ1xyXG5leHBvcnQgZnVuY3Rpb24gQ2FydExpbmsoeyBzaXplID0gMjQgfTogeyBzaXplPzogbnVtYmVyIH0pIHtcclxuICBjb25zdCBzZXNzaW9uID0gdXNlU2Vzc2lvbigpLCBxdWVyeSA9IHVzZVF1ZXJ5KGNhcnRPcHRpb25zKHNlc3Npb24uc2NvcGUpKVxyXG4gIGNvbnN0IHNlYXJjaCA9IHVzZUNhdGFsb2dEZXN0aW5hdGlvbigpXHJcbiAgY29uc3QgY291bnQgPSBxdWVyeS5kYXRhPy5pdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgaXRlbS5xdWFudGl0eSwgMClcclxuICByZXR1cm4gPExpbmsgdG89XCIvY2FydFwiIHN0YXRlPXt7IGNhdGFsb2dTZWFyY2g6IHNlYXJjaCB9fSBjbGFzc05hbWU9XCJjYXJ0LW5hdi1saW5rXCIgYXJpYS1sYWJlbD17Y291bnQgPT09IHVuZGVmaW5lZCA/ICdDYXJyaW5obywgY29uc3VsdGFuZG8gcXVhbnRpZGFkZScgOiBgQ2FycmluaG8sICR7Y291bnR9ICR7Y291bnQgPT09IDEgPyAnaXRlbScgOiAnaXRlbnMnfWB9PjxTaG9wcGluZ0NhcnQgY2xhc3NOYW1lPVwiY2FydC1pY29uLWRlZmF1bHRcIiBzaXplPXtzaXplfSAvPjxpbWcgY2xhc3NOYW1lPVwiY2FydC1pY29uLXJlZmVyZW5jZVwiIHNyYz17bW9iaWxlSWNvbnMuY2FydH0gd2lkdGg9XCIyMFwiIGhlaWdodD1cIjIwXCIgYWx0PVwiXCIgLz48c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIiBjbGFzc05hbWU9XCJjYXJ0LWJhZGdlXCIgZGF0YS10ZXN0aWQ9XCJjYXJ0LWJhZGdlXCI+e2NvdW50ID8/ICfigKYnfTwvc3Bhbj57cXVlcnkuaXNFcnJvciAmJiA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+RmFsaGEgYW8gY29uc3VsdGFyIHF1YW50aWRhZGU8L3NwYW4+fTwvTGluaz5cclxufVxyXG4iXX0=